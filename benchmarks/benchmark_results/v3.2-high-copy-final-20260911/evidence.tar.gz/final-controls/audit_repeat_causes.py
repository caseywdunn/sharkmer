import hashlib
import json
from pathlib import Path


root = Path(__file__).parent
summary_path = root / "summary.json"
summary = json.loads(summary_path.read_text())
assert not summary["failed_labels"]
expected_causes = {
    "repeat-a19": "withheld_by_self_loop_node_paths",
    "repeat-a40": "withheld_by_self_loop_node_paths",
    "repeat-ac40": "withheld_by_collision_edge_paths",
}
checks = []
for result in summary["results"]:
    if result["version"] != "candidate" or result["label"] not in expected_causes:
        continue
    genes = result["stats"]["pcr_results"]
    assert len(genes) == 1
    gene = genes[0]
    cause = expected_causes[result["label"]]
    assert gene["status"] == "fail" and gene["n_products"] == 0
    assert "repeat length unresolved" in gene["failure_reason"]
    assert any(diagnostic[cause] > 0 for diagnostic in gene["threshold_diagnostics"])
    checks.append({"case": result["label"], "cause": cause, "passed": True})
assert len(checks) == 3
with (root / "repeat-cause-audit.json").open("x") as output:
    json.dump({
        "summary_sha256": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
        "checks": checks,
        "scope": "Explicit failure text and positive path-local cause counts; not merely presence of diagnostic field names.",
    }, output, indent=2)
    output.write("\n")
