{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-high-copy-20260911/final-execution/reference_databases/angiospermae/references.fasta",
  "number-of-letters": 14881,
  "number-of-sequences": 21,
  "last-updated": "2026-09-11T10:38:00",
  "number-of-volumes": 1,
  "bytes-total": 43578,
  "bytes-to-cache": 4174,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
