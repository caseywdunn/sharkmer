{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-high-copy-20260911/final-execution/reference_databases/cnidaria/references.fasta",
  "number-of-letters": 38619,
  "number-of-sequences": 31,
  "last-updated": "2026-09-11T10:38:00",
  "number-of-volumes": 1,
  "bytes-total": 50580,
  "bytes-to-cache": 10228,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
