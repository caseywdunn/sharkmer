import argparse
import hashlib
import importlib.util
from pathlib import Path
import re


parser = argparse.ArgumentParser()
parser.add_argument("--pre-fix")
parser.add_argument("--candidate", required=True)
parser.add_argument("--workspace", type=Path, required=True)
arguments = parser.parse_args()
for commit in (arguments.pre_fix, arguments.candidate):
    if commit is None:
        continue
    if re.fullmatch("[0-9a-f]{40}", commit) is None:
        raise ValueError("Use exact full commit hashes")
builder_path = Path("/tmp/sharkmer-release-comparison/build_versions.py")
if hashlib.sha256(builder_path.read_bytes()).hexdigest() != "1c7128c86d74f1d10ca15900721ecc9acf933cc53d86d5d5ba8cfc9633324f87":
    raise ValueError("Frozen clean-export builder changed")
specification = importlib.util.spec_from_file_location("clean_export_builder", builder_path)
builder = importlib.util.module_from_spec(specification)
specification.loader.exec_module(builder)
builder.WORKSPACE = arguments.workspace
builder.VERSIONS = {"candidate": arguments.candidate}
if arguments.pre_fix:
    builder.VERSIONS = {"pre_fix": arguments.pre_fix, **builder.VERSIONS}
builder.main()
