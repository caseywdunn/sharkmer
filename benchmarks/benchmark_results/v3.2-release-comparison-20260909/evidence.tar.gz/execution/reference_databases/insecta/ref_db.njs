{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-release-comparison/execution/reference_databases/insecta/references.fasta",
  "number-of-letters": 26115,
  "number-of-sequences": 41,
  "last-updated": "2026-09-09T16:40:00",
  "number-of-volumes": 1,
  "bytes-total": 48779,
  "bytes-to-cache": 7222,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
