{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-release-comparison/normalized/reference_databases/cnidaria/references.fasta",
  "number-of-letters": 38619,
  "number-of-sequences": 31,
  "last-updated": "2026-09-09T16:43:00",
  "number-of-volumes": 1,
  "bytes-total": 50572,
  "bytes-to-cache": 10220,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
