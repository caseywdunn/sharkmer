{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-release-comparison/normalized/reference_databases/human/references.fasta",
  "number-of-letters": 18974,
  "number-of-sequences": 9,
  "last-updated": "2026-09-09T16:43:00",
  "number-of-volumes": 1,
  "bytes-total": 42965,
  "bytes-to-cache": 5037,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
