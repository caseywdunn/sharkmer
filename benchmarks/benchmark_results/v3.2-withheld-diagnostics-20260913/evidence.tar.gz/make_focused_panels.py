#!/usr/bin/env python3
"""Create fixed two-target diagnostic panel clones without changing target parameters."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path

import yaml


ROOT = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
SOURCE = Path('/home/claude/repos/sharkmer/panels/insecta.yaml')
OUTPUT = ROOT / 'focused_panels'
SELECTIONS = {
    'SRR27962769': ['CO1_1', 'ITS_2'],
    'SRR31887760': ['12S', '16S_2'],
    'SRR1057608': ['ND1'],
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def logical_gene(primer: dict) -> str:
    index = primer.get('index')
    return primer['gene'] if index is None else f"{primer['gene']}_{index}"


def write_new(path: Path, content: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'w') as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def main() -> int:
    if OUTPUT.exists():
        raise ValueError(f'Refusing existing focused-panel directory: {OUTPUT}')
    source_bytes = SOURCE.read_bytes()
    source_panel = yaml.safe_load(source_bytes)
    OUTPUT.mkdir()
    rows = []
    for accession, targets in SELECTIONS.items():
        clone = copy.deepcopy(source_panel)
        clone['primers'] = [primer for primer in source_panel['primers'] if logical_gene(primer) in targets]
        clone['references'] = [reference for reference in source_panel['references'] if reference['gene'] in targets]
        actual_targets = [logical_gene(primer) for primer in clone['primers']]
        if actual_targets != targets:
            raise ValueError(f'{accession}: selected targets differ: {actual_targets} != {targets}')
        clone_path = OUTPUT / f'{accession}.insecta.focused.yaml'
        write_new(clone_path, yaml.safe_dump(clone, sort_keys=False, allow_unicode=True))
        rows.append({
            'accession': accession,
            'path': str(clone_path),
            'sha256': digest(clone_path),
            'target_logical_genes': targets,
            'source_panel_sha256': hashlib.sha256(source_bytes).hexdigest(),
            'source_primer_count': len(source_panel['primers']),
            'focused_primer_count': len(clone['primers']),
            'source_reference_group_count': len(source_panel['references']),
            'focused_reference_group_count': len(clone['references']),
            'effective_per_gene_threshold_node_budget': 100000,
            'budget_scope': 'auto-derived from each capped input below 150M accepted bases; no cap tuning or CLI override',
        })
    write_new(OUTPUT / 'manifest.json', json.dumps({
        'schema_version': 1,
        'purpose': 'Predeclared diagnostic-only focused panel clones; only primers and matching reference groups are selected.',
        'source_panel': str(SOURCE),
        'source_panel_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'rows': rows,
    }, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': str(OUTPUT), 'rows': len(rows)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
