#!/usr/bin/env python3
"""Bind focused clones to selected primer objects by gene and index identity."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import yaml


ROOT = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
SOURCE = Path('/home/claude/repos/sharkmer/panels/insecta.yaml')
FOCUSED = ROOT / 'focused_panels'
OUTPUT = FOCUSED / 'identity.json'
SELECTIONS = {
    'SRR27962769': ['CO1_1', 'ITS_2'],
    'SRR31887760': ['12S', '16S_2'],
    'SRR1057608': ['ND1'],
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def object_digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def logical_gene(primer: dict) -> str:
    index = primer.get('index')
    return primer['gene'] if index is None else f"{primer['gene']}_{index}"


def write_new(path: Path, value: object) -> None:
    encoded = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'wb') as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())


def main() -> int:
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise ValueError(f'Refusing existing identity receipt: {OUTPUT}')
    source = yaml.safe_load(SOURCE.read_text())
    source_primers = {logical_gene(primer): primer for primer in source['primers']}
    rows = []
    for accession, targets in SELECTIONS.items():
        clone_path = FOCUSED / f'{accession}.insecta.focused.yaml'
        clone = yaml.safe_load(clone_path.read_text())
        clone_primers = {logical_gene(primer): primer for primer in clone['primers']}
        if list(clone_primers) != targets:
            raise ValueError(f'{accession}: clone target order differs: {list(clone_primers)}')
        target_rows = []
        for target in targets:
            source_primer = source_primers.get(target)
            clone_primer = clone_primers.get(target)
            if source_primer is None or clone_primer is None:
                raise ValueError(f'{accession}: target unavailable: {target}')
            if source_primer != clone_primer:
                raise ValueError(f'{accession}: target parameters changed: {target}')
            target_rows.append({
                'logical_gene': target,
                'gene': source_primer['gene'],
                'index': source_primer.get('index'),
                'primer_object_sha256': object_digest(source_primer),
            })
        rows.append({
            'accession': accession,
            'focused_panel': str(clone_path),
            'focused_panel_sha256': digest(clone_path),
            'source_panel_name': source['name'],
            'source_panel_sha256': digest(SOURCE),
            'targets_in_source_order': target_rows,
        })
    write_new(OUTPUT, {'schema_version': 1, 'selection_key': 'gene plus optional index, never array position', 'rows': rows})
    print(json.dumps({'output': str(OUTPUT), 'rows': len(rows)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
