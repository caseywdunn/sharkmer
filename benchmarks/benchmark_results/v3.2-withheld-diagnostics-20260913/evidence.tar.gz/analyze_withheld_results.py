import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent
CAPS = {
    "threshold": {"paths": 32, "sequence_bases": 512 * 1024, "marker_occurrences": 4096},
    "gene": {"paths": 64, "sequence_bases": 1024 * 1024, "marker_occurrences": 8192},
    "run": {"paths": 256, "sequence_bases": 4 * 1024 * 1024, "marker_occurrences": 32768},
}
CAUSES = {
    "pre_prune_omitted_self_loop_node": ("omitted_self_loop_marker_occurrences", "oriented_node_sequence"),
    "pre_prune_cyclic_scc_node": ("cyclic_scc_marker_occurrences", "oriented_node_sequence"),
    "retained_collision_edge": ("retained_collision_marker_occurrences", "oriented_edge_sequence"),
}
DROP_FIELDS = (
    "dropped_oversize_sequence", "dropped_oversize_marker_set", "dropped_path_cap",
    "dropped_sequence_base_cap", "dropped_marker_cap",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(contents):
    return hashlib.sha256(contents).hexdigest()


def integer(value):
    require(type(value) is int and value >= 0, "Expected a nonnegative integer")
    return value


def merged_spans(occurrences):
    merged = []
    for start, end in sorted((entry["start"], entry["end"]) for entry in occurrences):
        if merged and start <= merged[-1]["end"]:
            merged[-1]["end"] = max(merged[-1]["end"], end)
        else:
            merged.append({"start": start, "end": end})
    return merged


def validate_record(record, kmer_length):
    sequence = record["oriented_sequence"]
    require(isinstance(sequence, str) and sequence and not set(sequence) - set("ACGT"), "Nonliteral candidate sequence")
    require(integer(record["sequence_length"]) == len(sequence), "Candidate length mismatch")
    require(digest(sequence.encode()) == record["sequence_sha256"], "Candidate hash mismatch")
    require(1 <= integer(record["max_observed_node_visits"]) <= integer(record["node_visit_limit"]), "Invalid node visit metadata")
    occurrences = record["marker_occurrences"]
    require(isinstance(occurrences, list) and occurrences, "Withheld candidate has no complete marker set")
    counts = dict.fromkeys(CAUSES, 0)
    seen = set()
    for occurrence in occurrences:
        cause = occurrence["cause"]
        require(cause in CAUSES, "Unknown marker cause")
        identity_kind = CAUSES[cause][1]
        require(occurrence["identity_kind"] == identity_kind, "Cause and identity kind disagree")
        start, end = integer(occurrence["start"]), integer(occurrence["end"])
        identity = occurrence["identity_sequence"]
        require(0 <= start < end <= len(sequence), "Marker coordinates outside candidate")
        expected_length = kmer_length if identity_kind == "oriented_edge_sequence" else kmer_length - 1
        require(end - start == expected_length and sequence[start:end] == identity, "Marker identity/span mismatch")
        require(digest(identity.encode()) == occurrence["identity_sha256"], "Marker hash mismatch")
        signature = (cause, start, end, identity)
        require(signature not in seen, "Duplicate marker occurrence")
        seen.add(signature)
        counts[cause] += 1
    for cause, count in counts.items():
        require(integer(record[CAUSES[cause][0]]) == count, "Marker cause count mismatch")
    require(record["marker_covered_runs"] == merged_spans(occurrences), "Marker-covered union mismatch")
    return {"paths": 1, "sequence_bases": len(sequence), "marker_occurrences": len(occurrences)}


def validate_payload(payload, threshold, kmer_length, gene_index, gene_count, previous):
    require(payload["schema_version"] == 1, "Unsupported payload schema")
    require(payload["coordinate_system"] == "zero_based_half_open", "Wrong coordinate semantics")
    require(payload["purpose"] == "diagnostic_only_unsupported_candidate_hypotheses", "Wrong diagnostic status")
    require(payload["marker_span_scope"] == "marker_covered_positions_not_complete_ambiguity_or_bridge_ready_intervals", "Unsupported ambiguity claim")
    require(payload["read_support_evaluation"] == "not_evaluated", "Unsupported read-evidence claim")
    limits = payload["limits"]
    for level, cap in CAPS.items():
        require(limits[level] == cap, "Diagnostic limits differ from preregistration")
    require(limits["unused_share_is_not_redistributed"] is True, "Unexpected quota redistribution")
    allocated = {
        key: min(CAPS["gene"][key], total // gene_count + int(gene_index < total % gene_count))
        for key, total in CAPS["run"].items()
    }
    require(limits["allocated_run_share_for_gene"] == allocated, "Static run allocation mismatch")
    require(payload["gene_usage_before_threshold"] == previous, "Gene usage does not carry across thresholds")
    totals = dict.fromkeys(CAPS["run"], 0)
    for record in payload["paths"]:
        require(record["node_visit_limit"] == payload["node_visit_limit"], "Inconsistent node visit limit")
        usage = validate_record(record, kmer_length)
        for key in totals:
            totals[key] += usage[key]
    for key, field in (("paths", "retained_paths"), ("sequence_bases", "retained_sequence_bases"), ("marker_occurrences", "retained_marker_occurrences")):
        require(integer(payload[field]) == totals[key], "Retained payload accounting mismatch")
        require(totals[key] <= CAPS["threshold"][key], "Threshold diagnostic cap exceeded")
        after = integer(payload["gene_usage_after_threshold"][key])
        require(after == integer(previous[key]) + totals[key] and after <= allocated[key], "Gene/run-share diagnostic cap exceeded")
    observed = integer(payload["observed_withheld_paths"])
    dropped = integer(payload["observed_not_retained_paths"])
    require(observed == integer(threshold["withheld_candidate_paths"]) == totals["paths"] + dropped, "Withheld-path accounting mismatch")
    require(dropped == sum(integer(payload[field]) for field in DROP_FIELDS), "Omission reason accounting mismatch")
    if payload["dropped_path_cap"]:
        require(totals["paths"] == CAPS["threshold"]["paths"] or payload["gene_usage_after_threshold"]["paths"] == allocated["paths"], "Path-cap omission without a saturated path cap")
    require(payload["retention_truncated"] is (dropped > 0), "Truncation status mismatch")
    integer(payload["node_visit_skips"])
    return payload["gene_usage_after_threshold"]


def load_harness():
    specification = importlib.util.spec_from_file_location("withheld_parity_harness", ROOT / "run_three_way.py")
    harness = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(harness)
    return harness


def validate_envelope(execution, protocol, historical_path, harness):
    before, after = execution["source_before"], execution["source_after"]
    require(after is not None and harness.stable_receipt(before) == harness.stable_receipt(after), "Source bookends differ")
    require(before["diagnostic_args"] == ["--diagnose-withheld-paths"], "Unreviewed diagnostic arguments")
    for key, path in {
        "protocol": ROOT / "protocol.json", "runner": ROOT / "run_three_way.py",
        "analyzer": Path(__file__), "analyzer_tests": ROOT / "test_analyze_withheld_results.py",
        "historical_map": historical_path,
    }.items():
        require(before["hashes"][key] == digest(path.read_bytes()), f"Frozen source differs: {key}")
    jobs = harness.build_jobs(protocol)
    expected = [(job["accession"], job["role"]) for job in jobs]
    require([(job["accession"], job["role"]) for job in execution["jobs"]] == expected, "Execution job matrix/order differs")
    comparisons = execution["comparisons"]
    expected_comparisons = [("full_panel", accession) for accession in sorted(protocol["samples"])]
    expected_comparisons.extend(("focused_vs_full", job["accession"]) for job in jobs if job["focused_diagnostic_only"])
    require([(row["kind"], row["accession"]) for row in comparisons] == expected_comparisons, "Comparison identity matrix differs")
    return jobs


def analyze(execution_path, historical_path):
    execution_bytes = execution_path.read_bytes()
    execution = json.loads(execution_bytes)
    require(len(execution["jobs"]) == 12 and not execution["source_changed_during_execution"] and execution["after_validation_error"] is None, "Incomplete or source-drifted execution")
    require(execution["comparisons"] and all(entry["passed"] for entry in execution["comparisons"]), "Parity verification failed")
    protocol = json.loads((ROOT / "protocol.json").read_bytes())
    harness = load_harness()
    expected_jobs = validate_envelope(execution, protocol, historical_path, harness)
    historical_bytes = historical_path.read_bytes()
    historical = json.loads(historical_bytes)
    require(historical["source_candidate_manifest_sha256"] == "a8df6371680394dfc37b8aec62cd2aed0e2968306f36420a6858221046b59b4e", "Historical source differs from frozen audit")
    require(len(historical["rows"]) == 7, "Expected seven historical identities")
    historical_rows = historical["rows"]
    rows = []
    localized = []
    sources = []
    for job, expected_job in zip(execution["jobs"], expected_jobs):
        require(job["returncode"] == 0 and job["validated_output"] and not job["timed_out"], "Failed invocation")
        require(harness.stable_receipt(job["source_before"]) == harness.stable_receipt(execution["source_before"]), "Per-job source binding differs")
        for key in ("binary_role", "focused_diagnostic_only"):
            require(job[key] == expected_job[key], f"Unexpected job metadata: {key}")
        require(job.get("selected_targets") == expected_job.get("selected_targets"), "Selected target list differs")
        receipt_path = execution_path.parent / f"{job['accession']}.{job['role']}.receipt.json"
        require(json.loads(receipt_path.read_text()) == job, "Per-job receipt differs")
        output = job["outputs"]
        stats_bytes = Path(output["stats_path"]).read_bytes()
        require(digest(stats_bytes) == output["stats_sha256"], "Stats artifact hash mismatch")
        stats = yaml.safe_load(stats_bytes)
        require(stats == output["stats"], "Parsed stats differ from execution receipt")
        binary_field = "baseline_binary" if job["binary_role"] == "baseline_off" else "changed_binary"
        sample = protocol["samples"][job["accession"]]
        require(len(job["command"]) > 10, "Incomplete command wrapper")
        binary_path = Path(job["command"][10])
        require(harness.digest(binary_path) == execution["source_before"]["hashes"][binary_field], "Command executable differs from frozen binary")
        expected_command = harness.make_command(
            binary_path, protocol, sample, expected_job["panel"], Path(job["output_directory"]),
            f"withheld_{job['accession']}", ["--diagnose-withheld-paths"] if job["binary_role"] == "changed_on" else [],
        )
        require(job["command"] == expected_command, "Command differs from preregistered invocation")
        sharkmer_command = job["command"][10:]
        observed_output = harness.capture_outputs(
            Path(job["output_directory"]), f"withheld_{job['accession']}", Path(expected_job["panel"]),
            protocol["common_invocation"]["k"], sharkmer_command, Path(sample["input"]), sample["prefix"],
            job["binary_role"] == "changed_on", protocol["comparison_contract"]["preregistered_payload_key"],
        )
        require(observed_output == output, "Raw output validation differs from captured results")
        for basename, expected_hash in output["fasta_files"].items():
            require(Path(basename).name == basename, "Unsafe FASTA receipt name")
            require(digest((Path(job["output_directory"]) / basename).read_bytes()) == expected_hash, "FASTA hash mismatch")
        sources.append({"accession": job["accession"], "role": job["role"], "stats_sha256": digest(stats_bytes), "wall_time_seconds": job["wall_time_seconds"], "maximum_rss_bytes": job["maximum_rss_bytes"]})
        enabled = job["binary_role"] == "changed_on"
        genes = stats["pcr_results"]
        run_usage = dict.fromkeys(CAPS["run"], 0)
        for gene_index, gene in enumerate(genes):
            previous = dict.fromkeys(CAPS["run"], 0)
            captures = []
            for threshold in gene.get("threshold_diagnostics", []):
                payload = threshold.get("withheld_path_diagnostics")
                if not enabled:
                    require(payload is None, "Disabled diagnostic payload present")
                    continue
                require(payload is not None, "Enabled attempted threshold lacks diagnostic payload")
                previous = validate_payload(payload, threshold, stats["kmer_length"], gene_index, len(genes), previous)
                rows.append({
                    "accession": job["accession"], "role": job["role"], "gene": gene["gene_name"], "threshold": threshold["threshold"],
                    "observed_withheld_paths": payload["observed_withheld_paths"], "retained_paths": payload["retained_paths"],
                    "omitted_paths": payload["observed_not_retained_paths"], "retention_truncated": payload["retention_truncated"],
                    "node_visit_skips": payload["node_visit_skips"], "allocated_run_share_for_gene": payload["limits"]["allocated_run_share_for_gene"],
                })
                captures.append((threshold, payload))
            for key in run_usage:
                run_usage[key] += previous[key]
            if not enabled:
                continue
            for historical_row in historical_rows:
                if historical_row["accession"] != job["accession"] or gene["gene_name"] != "insecta_" + historical_row["gene"]:
                    continue
                matches = [
                    {"threshold": threshold["threshold"], "record": record}
                    for threshold, payload in captures for record in payload["paths"]
                    if record["sequence_sha256"] == historical_row["lost_sha256"]
                ]
                localized.append({
                    "accession": job["accession"], "role": job["role"], "gene": gene["gene_name"],
                    "historical_sha256": historical_row["lost_sha256"], "historical_length": historical_row["lost_length"],
                    "gene_status": gene["status"], "gene_failure_reason": gene.get("failure_reason"),
                    "status": "current_withheld_identity_localized" if matches else "not_observed_in_retained_current_run_paths",
                    "retention_truncated": any(payload["retention_truncated"] for _, payload in captures),
                    "node_visit_skips": sum(payload["node_visit_skips"] for _, payload in captures),
                    "search_diagnostics": [{key: threshold[key] for key in ("threshold", "connectivity_found", "node_budget_reached", "path_search_evaluated", "dfs_limit_reached", "path_quota_reached", "max_length_reached")} for threshold, _ in captures],
                    "matches": matches, "biological_correctness": "not_established", "marker_scope": "not_complete_ambiguity_or_bridge_ready_intervals",
                })
        require(all(run_usage[key] <= cap for key, cap in CAPS["run"].items()), "Run diagnostic cap exceeded")
    require(len(localized) == 14, "Missing historical identity/full-focused outcome rows")
    payload_key = protocol["comparison_contract"]["preregistered_payload_key"]
    comparisons = harness.compare_full_roles(execution["jobs"], payload_key) + harness.compare_focused_runs(execution["jobs"], payload_key)
    require(comparisons == execution["comparisons"] and all(row["passed"] for row in comparisons), "Recomputed parity differs")
    return {
        "schema_version": 1, "execution_sha256": digest(execution_bytes), "historical_map_sha256": digest(historical_bytes),
        "analyzer_sha256": digest(Path(__file__).read_bytes()), "sources": sources, "thresholds": rows,
        "historical_localization": localized,
        "limits": "Matching identities localize only actual marker footprints; absent identities under sampling/search bounds remain unresolved. No admission or biological-truth inference.",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execution", type=Path, required=True)
    parser.add_argument("--historical", type=Path, default=ROOT / "historical_lost_retained_map.json")
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    result = analyze(arguments.execution, arguments.historical)
    with arguments.output.open("x") as destination:
        destination.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"historical_rows": len(result["historical_localization"]), "localized_rows": sum(bool(row["matches"]) for row in result["historical_localization"])}))


if __name__ == "__main__":
    main()
