#!/usr/bin/env python3
"""Execution-disabled three-way manifest/parity smoke using the reviewed harness."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
from pathlib import Path

import yaml


ROOT = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
HARNESS_PATH = ROOT / 'run_three_way.py'
SPECIFICATION = importlib.util.spec_from_file_location('withheld_harness', HARNESS_PATH)
HARNESS = importlib.util.module_from_spec(SPECIFICATION)
assert SPECIFICATION.loader is not None
SPECIFICATION.loader.exec_module(HARNESS)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, contents: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'w') as handle:
        handle.write(contents)
        handle.flush()
        os.fsync(handle.fileno())


def make_fixture(root: Path) -> tuple[Path, Path, dict]:
    sequence = 'ACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGTACGT'
    fastq = root / 'smoke.fastq'
    write_new(fastq, ''.join(f'@read{ordinal}\n{sequence}\n+\n{"I" * len(sequence)}\n' for ordinal in range(1, 9)))
    prefix = HARNESS.inspect_prefix(fastq, 8)
    panel = {'name': 'smoke', 'schema_version': '2', 'panel_version': '1.0.0', 'description': 'withheld diagnostics smoke fixture', 'clade': 'Synthetic', 'maintainers': [{'name': 'smoke'}], 'primers': [{'gene': 'target', 'forward_seq': 'ACGTACGTACGTACG', 'reverse_seq': 'CGTACGTACGTACGT', 'min_length': 20, 'max_length': 80, 'expected_length': 60, 'min_count': 2, 'mismatches': 0, 'trim': 15}], 'validation': {'samples': []}, 'references': []}
    panel_path = root / 'smoke.yaml'
    write_new(panel_path, yaml.safe_dump(panel, sort_keys=False))
    return fastq, panel_path, prefix


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--changed', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    arguments = parser.parse_args()
    if not arguments.execute:
        print('Refusing to execute smoke without --execute.')
        return 2
    if arguments.output.exists() or arguments.output.is_symlink():
        raise ValueError(f'Refusing existing smoke output: {arguments.output}')
    arguments.output.mkdir(parents=True)
    fixture_root = arguments.output / 'fixture'
    fixture_root.mkdir()
    fastq, panel_path, prefix = make_fixture(fixture_root)
    protocol = {'common_invocation': {'k': 19, 'threads': 2, 'chunks': 0, 'max_reads': 8, 'address_space_limit_bytes': 42949672960, 'cpu_list': '0,1', 'timeout_seconds': 1800}, 'comparison_contract': {'preregistered_payload_key': 'withheld_path_diagnostics'}, 'samples': {'smoke': {'input': str(fastq), 'prefix': prefix}}}
    binaries = {'baseline_off': arguments.baseline, 'changed_off': arguments.changed, 'changed_on': arguments.changed}
    source_before = {'smoke_driver_sha256': digest(Path(__file__)), 'harness_sha256': digest(HARNESS_PATH), 'baseline_sha256': digest(arguments.baseline), 'changed_sha256': digest(arguments.changed)}
    records = []
    for role in ('baseline_off', 'changed_off', 'changed_on'):
        job = {'accession': 'smoke', 'role': role, 'binary_role': role, 'panel': str(panel_path), 'focused_diagnostic_only': False}
        record = HARNESS.run_job(job, protocol, binaries, ['--diagnose-withheld-paths'], arguments.output / 'runs', source_before)
        HARNESS.write_new_json(arguments.output / f'{role}.receipt.json', record)
        if record['returncode'] != 0 or not record.get('validated_output'):
            raise ValueError(f'Smoke job failed: {role}')
        records.append(record)
    comparisons = HARNESS.compare_full_roles(records, 'withheld_path_diagnostics')
    if not all(item['passed'] for item in comparisons):
        raise ValueError(f'Smoke parity failed: {comparisons}')
    source_after = {'smoke_driver_sha256': digest(Path(__file__)), 'harness_sha256': digest(HARNESS_PATH), 'baseline_sha256': digest(arguments.baseline), 'changed_sha256': digest(arguments.changed)}
    HARNESS.write_new_json(arguments.output / 'smoke_receipt.json', {'schema_version': 1, 'source_before': source_before, 'source_after': source_after, 'source_changed': source_before != source_after, 'records': records, 'comparisons': comparisons})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
