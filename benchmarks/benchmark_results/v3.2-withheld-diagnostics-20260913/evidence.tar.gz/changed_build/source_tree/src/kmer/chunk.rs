// kmer/chunk.rs
//! Chunk: groups reads for incremental kmer counting.

use anyhow::Result;

use super::counting::KmerCounts;
use super::encoding::count_valid_bases;

pub struct Chunk {
    kmer_counts: KmerCounts,
    n_reads: u64,
    n_bases: u64,
}

impl Chunk {
    pub fn new(k: &usize) -> Chunk {
        Chunk {
            kmer_counts: KmerCounts::new(k),
            n_reads: 0,
            n_bases: 0,
        }
    }

    /// Ingest a single FASTQ sequence directly from ASCII, bypassing Read encoding.
    pub fn ingest_seq(&mut self, seq: &str) -> Result<()> {
        self.kmer_counts.ingest_seq(seq)?;
        self.n_reads += 1;
        self.n_bases += count_valid_bases(seq);
        Ok(())
    }

    pub fn get_kmer_counts(&self) -> &KmerCounts {
        &self.kmer_counts
    }

    pub fn get_n_kmers(&self) -> u64 {
        self.kmer_counts.get_n_kmers()
    }

    pub fn get_n_reads(&self) -> u64 {
        self.n_reads
    }

    pub fn get_n_bases(&self) -> u64 {
        self.n_bases
    }
}
