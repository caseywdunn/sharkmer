use anyhow::{Context, Result, bail, ensure};
use indicatif::{ProgressBar, ProgressStyle};
use log::{debug, info, warn};
use std::io::BufRead;
use std::io::IsTerminal;
use std::io::Write;
use std::path::PathBuf;

use crate::cli::Args;
use crate::format::{format_bytes, format_count, format_duration};
use crate::kmer;
use crate::kmer::{Chunk, KmerCounts};

pub(crate) const FASTA_LINE_WIDTH: usize = 80;
pub(crate) const N_READS_PER_BATCH: u64 = 1000;

/// Describes how to re-acquire read data for Pass 2 (read threading).
pub(crate) enum ReadSourcePlan {
    /// Local files that can be reopened
    LocalFiles(Vec<PathBuf>),
    /// Remote files cached locally (paths to cached files)
    CachedRemote(Vec<PathBuf>),
    /// Remote files that must be re-downloaded (URLs)
    UncachedRemote(Vec<String>),
    /// Cannot re-read (stdin or replay otherwise unavailable)
    Unavailable,
}

/// Plan for Pass 2 re-reading of FASTQ data.
pub(crate) struct ReadPlan {
    pub(crate) source: ReadSourcePlan,
    pub(crate) paired: bool,
    pub(crate) max_reads: u64,
}

/// A retained read for Pass 2 threading.
pub(crate) struct ReadRecord {
    /// Raw sequence (ASCII ACGT)
    pub(crate) sequence: String,
    /// Global read index (0-based, in order of ingestion)
    pub(crate) index: u64,
    /// Mate designation for paired-end reads
    pub(crate) mate: Mate,
}

/// Mate designation for paired-end reads.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Mate {
    Unpaired,
    R1,
    R2,
}

/// Result of querying ENA for an accession.
pub(crate) struct EnaResult {
    pub(crate) urls: Vec<String>,
    pub(crate) scientific_name: Option<String>,
}

/// Query ENA filereport API to get FASTQ URLs and metadata for an accession.
/// Returns URLs ordered by mate number (R1 first, then R2 if paired-end),
/// plus the scientific_name if available.
pub(crate) fn get_ena_fastq_urls(accession: &str) -> Result<EnaResult> {
    let url = format!(
        "https://www.ebi.ac.uk/ena/portal/api/filereport?accession={}&result=read_run&fields=run_accession,fastq_ftp,scientific_name",
        accession
    );

    info!("Querying ENA for accession {}...", accession);
    let response = ureq::get(&url)
        .call()
        .with_context(|| format!("Failed to query ENA API for accession {}", accession))?;

    let body = response
        .into_string()
        .context("Failed to read ENA API response")?;

    // Response is TSV: header row, then data rows
    // Fields: run_accession\tfastq_ftp\tscientific_name
    let lines: Vec<&str> = body.lines().collect();
    ensure!(
        lines.len() >= 2,
        "ENA returned no results for accession '{}'. Check that the accession is valid.",
        accession
    );

    // Parse header to find column indices
    let headers: Vec<&str> = lines[0].split('\t').collect();
    let ftp_idx = headers
        .iter()
        .position(|h| *h == "fastq_ftp")
        .context("ENA response missing fastq_ftp column")?;
    let sci_name_idx = headers.iter().position(|h| *h == "scientific_name");

    let data_line = lines[1];
    let fields: Vec<&str> = data_line.split('\t').collect();
    ensure!(
        fields.len() > ftp_idx && !fields[ftp_idx].is_empty(),
        "ENA returned no FASTQ URLs for accession '{}'. The run may not have public FASTQ files.",
        accession
    );

    let urls: Vec<String> = fields[ftp_idx]
        .split(';')
        .map(|u| {
            if u.starts_with("ftp://") || u.starts_with("http") {
                u.to_string()
            } else {
                format!("http://{}", u)
            }
        })
        .collect();

    let scientific_name = sci_name_idx
        .and_then(|idx| fields.get(idx))
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string());

    info!(
        "Found {} FASTQ file(s) for {}: {}",
        urls.len(),
        accession,
        urls.join(", ")
    );
    if let Some(ref name) = scientific_name {
        info!("Scientific name: {}", name);
    }

    Ok(EnaResult {
        urls,
        scientific_name,
    })
}

/// Warn if an output file already exists (it will be overwritten).
pub(crate) fn warn_if_exists(path: &str) {
    if std::path::Path::new(path).exists() {
        warn!("Overwriting existing file {}", path);
    }
}

/// Write a FASTA record with sequence lines wrapped at FASTA_LINE_WIDTH characters.
pub(crate) fn write_fasta_record(
    writer: &mut impl Write,
    record: &bio::io::fasta::Record,
) -> std::io::Result<()> {
    write!(writer, ">{}", record.id())?;
    if let Some(desc) = record.desc() {
        write!(writer, " {}", desc)?;
    }
    writeln!(writer)?;
    for chunk in record.seq().chunks(FASTA_LINE_WIDTH) {
        writer.write_all(chunk)?;
        writeln!(writer)?;
    }
    Ok(())
}

/// Validate a FASTQ record (4 lines). Returns an error if the record is malformed.
fn validate_fastq_record(
    header: &str,
    _sequence: &str,
    separator: &str,
    quality: &str,
    sequence_len: usize,
    record_num: u64,
) -> Result<()> {
    if header.starts_with('>') {
        bail!(
            "Input appears to be FASTA format, not FASTQ (record {} starts with '>'). \
             sharkmer requires FASTQ input with quality scores.",
            record_num + 1,
        );
    }
    ensure!(
        header.starts_with('@'),
        "FASTQ record {} has invalid header (expected '@', got '{}'): {}",
        record_num + 1,
        header.chars().next().unwrap_or(' '),
        header,
    );
    ensure!(
        separator.starts_with('+'),
        "FASTQ record {} has invalid separator line (expected '+', got '{}'): {}",
        record_num + 1,
        separator.chars().next().unwrap_or(' '),
        separator,
    );
    ensure!(
        quality.len() == sequence_len,
        "FASTQ record {} has mismatched sequence ({}) and quality ({}) lengths",
        record_num + 1,
        sequence_len,
        quality.len(),
    );
    Ok(())
}

/// Mutable state for FASTQ reading, shared across multiple input sources.
pub(crate) struct FastqReadState {
    pub(crate) chunks: Vec<kmer::Chunk>,
    pub(crate) chunk_index: usize,
    pub(crate) seqs: Vec<String>,
    pub(crate) n_reads_read: u64,
    pub(crate) n_bases_read: u64,
}

/// Build a context-rich error message for an I/O error that occurred mid-stream
/// during FASTQ reading. Distinguishes abrupt connection drops (the common ENA
/// failure mode) from actual FASTQ parse issues, and suggests the cache as a
/// workaround when streaming fails.
fn stream_io_error(
    line_role: &str,
    err: &std::io::Error,
    source_name: &str,
    n_reads_read: u64,
) -> anyhow::Error {
    use std::io::ErrorKind;
    let is_stream_drop = matches!(
        err.kind(),
        ErrorKind::UnexpectedEof
            | ErrorKind::ConnectionReset
            | ErrorKind::ConnectionAborted
            | ErrorKind::BrokenPipe
            | ErrorKind::TimedOut
            | ErrorKind::Interrupted
    );
    let is_remote = source_name.starts_with("http://") || source_name.starts_with("https://");

    if is_stream_drop {
        if is_remote {
            anyhow::anyhow!(
                "Stream from {} dropped while reading {} line of record {} (I/O error: {} — kind {:?}).\n\
                 This is usually a transient network interruption, not a bad FASTQ file.\n\
                 Retry the run. If it repeats, use the read cache (the default for --ena); \
                 cached downloads are verified by SHA-256 and do not suffer mid-stream drops.",
                source_name,
                line_role,
                n_reads_read + 1,
                err,
                err.kind(),
            )
        } else {
            anyhow::anyhow!(
                "Local read stream ended unexpectedly while reading {} line of record {} in {} \
                 (I/O error: {} — kind {:?}). The file may be truncated or corrupted.",
                line_role,
                n_reads_read + 1,
                source_name,
                err,
                err.kind(),
            )
        }
    } else {
        anyhow::anyhow!(
            "Failed to read {} line of record {} in {}: {} (kind {:?})",
            line_role,
            n_reads_read + 1,
            source_name,
            err,
            err.kind(),
        )
    }
}

/// Read FASTQ records from a buffered reader, ingesting sequences into chunks.
///
/// Reads 4 lines at a time (header, sequence, separator, quality) and validates
/// the format. Returns true if max_reads was reached.
fn read_fastq<R: BufRead>(
    reader: R,
    state: &mut FastqReadState,
    max_reads: u64,
    validate_every: u64,
    source_name: &str,
    progress: &ProgressBar,
) -> Result<bool> {
    let mut lines = reader.lines();
    let n_chunks = state.chunks.len();

    while let Some(header_result) = lines.next() {
        // Read 4 lines for one FASTQ record
        let header = header_result
            .map_err(|e| stream_io_error("header", &e, source_name, state.n_reads_read))?;

        let sequence = match lines.next() {
            Some(line) => {
                line.map_err(|e| stream_io_error("sequence", &e, source_name, state.n_reads_read))?
            }
            None => bail!(
                "Truncated FASTQ record at record {} in {}: missing sequence line",
                state.n_reads_read + 1,
                source_name,
            ),
        };

        let separator = match lines.next() {
            Some(line) => {
                line.map_err(|e| stream_io_error("separator", &e, source_name, state.n_reads_read))?
            }
            None => bail!(
                "Truncated FASTQ record at record {} in {}: missing separator line",
                state.n_reads_read + 1,
                source_name,
            ),
        };

        let quality = match lines.next() {
            Some(line) => {
                line.map_err(|e| stream_io_error("quality", &e, source_name, state.n_reads_read))?
            }
            None => bail!(
                "Truncated FASTQ record at record {} in {}: missing quality line",
                state.n_reads_read + 1,
                source_name,
            ),
        };

        // Validate the record
        let should_validate = state.n_reads_read == 0
            || (validate_every > 0 && state.n_reads_read % validate_every == 0);
        if should_validate {
            validate_fastq_record(
                &header,
                &sequence,
                &separator,
                &quality,
                sequence.len(),
                state.n_reads_read,
            )?;
        }

        // Process the sequence
        state.n_bases_read += sequence.len() as u64;
        state.seqs.push(sequence);
        state.n_reads_read += 1;

        // If we have read enough reads, ingest them into current chunk
        if state.n_reads_read % N_READS_PER_BATCH == 0 {
            drain_batch(state, n_chunks)?;
            progress.set_position(state.n_reads_read);
        }

        if max_reads > 0 && state.n_reads_read >= max_reads {
            progress.set_position(state.n_reads_read);
            return Ok(true); // reached max reads
        }
    }

    Ok(false) // did not reach max reads (EOF)
}

/// Drain accumulated sequences into the current chunk.
fn drain_batch(state: &mut FastqReadState, n_chunks: usize) -> Result<()> {
    for seq in state.seqs.drain(..) {
        state.chunks[state.chunk_index].ingest_seq(&seq)?;
    }
    state.chunk_index = (state.chunk_index + 1) % n_chunks;
    Ok(())
}

/// Ingest FASTQ reads from all input sources (ENA, files, or stdin).
/// Returns the read state with populated chunks, summary statistics, and a
/// `ReadPlan` describing how to re-read the same data in Pass 2.
pub(crate) fn ingest_reads(
    args: &Args,
    k: usize,
    mut cached_ena_result: Option<EnaResult>,
    cache_config: Option<&crate::cache::CacheConfig>,
    show_progress: bool,
) -> Result<(FastqReadState, u64, u64, u64, ReadPlan)> {
    let _ = k;
    let start = std::time::Instant::now();
    info!("Ingesting reads...");

    // When chunks == 0, allocate 1 internal chunk for kmer storage (needed for sPCR)
    let n_chunks = if args.chunks == 0 { 1 } else { args.chunks };
    let chunks: Vec<kmer::Chunk> = (0..n_chunks).map(|_| Chunk::new(&k)).collect();

    let mut state = FastqReadState {
        chunks,
        chunk_index: 0,
        seqs: Vec::new(),
        n_reads_read: 0,
        n_bases_read: 0,
    };

    let mut max_reads = args.max_reads.unwrap_or(0);

    // Create progress indicator: bar with ETA if max_reads is known, spinner otherwise.
    let progress = if show_progress && max_reads > 0 {
        let pb = ProgressBar::new(max_reads);
        pb.set_style(
            ProgressStyle::with_template(
                "Ingesting reads {bar:30} {human_pos}/{human_len} [{per_sec}] [ETA {eta}]",
            )
            .expect("valid progress template"),
        );
        pb
    } else if show_progress {
        let pb = ProgressBar::new_spinner();
        pb.set_style(
            ProgressStyle::with_template("Ingesting reads {spinner} {human_pos} [{per_sec}]")
                .expect("valid progress template"),
        );
        pb
    } else {
        ProgressBar::hidden()
    };

    // Track the input source for Pass 2 re-reading
    let mut read_source_plan = ReadSourcePlan::Unavailable;

    if let Some(accession) = &args.ena {
        // Stream reads from ENA (use cached result if available)
        let ena_result = match cached_ena_result.take() {
            Some(r) => r,
            None => get_ena_fastq_urls(accession)?,
        };
        let mut cached_paths: Vec<PathBuf> = Vec::new();
        let mut is_cached = false;
        for url in &ena_result.urls {
            let reader: Box<dyn BufRead> = if let Some(cache) = cache_config {
                // Use cache: lookup or download
                let local_path = match cache.lookup(url, max_reads)? {
                    Some(path) => {
                        info!("Cache hit for {}", url);
                        path
                    }
                    None => {
                        info!("Cache miss for {}, downloading...", url);
                        cache.download_to_cache(url, max_reads)?
                    }
                };
                cached_paths.push(local_path.clone());
                is_cached = true;
                let file = std::fs::File::open(&local_path).with_context(|| {
                    format!("Failed to open cached file: {}", local_path.display())
                })?;
                Box::new(std::io::BufReader::new(flate2::read::MultiGzDecoder::new(
                    file,
                )))
            } else {
                // No cache: stream directly
                info!("Streaming from {} (no cache)...", url);
                let response = ureq::get(url)
                    .call()
                    .with_context(|| format!("Failed to download {}", url))?;
                Box::new(std::io::BufReader::new(flate2::read::MultiGzDecoder::new(
                    response.into_reader(),
                )))
            };
            let reached_max = read_fastq(
                reader,
                &mut state,
                max_reads,
                args.validate_every,
                url,
                &progress,
            )?;
            if reached_max {
                break;
            }
        }
        read_source_plan = if is_cached {
            ReadSourcePlan::CachedRemote(cached_paths)
        } else {
            warn!("Read threading will require re-downloading reads from ENA (no cache)");
            ReadSourcePlan::UncachedRemote(ena_result.urls)
        };
    } else if let Some(input_files) = &args.input {
        if args.paired {
            // Paired-end: alternate reads from R1 and R2
            let reader1 = open_fastq_reader(&input_files[0])?;
            let reader2 = open_fastq_reader(&input_files[1])?;
            let name1 = input_files[0].to_string_lossy().to_string();
            let name2 = input_files[1].to_string_lossy().to_string();
            // Round max_reads up to even so Pass 1 consumes balanced
            // pairs. The rounded value is also recorded in the ReadPlan
            // below so Pass 2 (re-read for threading) consumes the same
            // number of reads; leaving the unrounded value here would
            // cause Pass 2 to stop one R2 short of Pass 1 and drop the
            // final read pair silently.
            if max_reads > 0 && max_reads % 2 != 0 {
                max_reads += 1;
            }
            read_fastq_paired(
                reader1,
                reader2,
                &mut state,
                max_reads,
                args.validate_every,
                &name1,
                &name2,
                &progress,
            )?;
        } else {
            // Read from one or more files sequentially
            for file_path in input_files.iter() {
                let reader = open_fastq_reader(file_path)?;
                let file_name = file_path.to_string_lossy();
                let reached_max = read_fastq(
                    reader,
                    &mut state,
                    max_reads,
                    args.validate_every,
                    &file_name,
                    &progress,
                )?;
                if reached_max {
                    break;
                }
            }
        }
        read_source_plan = ReadSourcePlan::LocalFiles(input_files.clone());
    } else {
        // Read from stdin (cannot re-read for Pass 2)
        let stdin = std::io::stdin();
        ensure!(
            !stdin.is_terminal(),
            "No input files specified and stdin is a terminal.\n\
             Provide FASTQ files as arguments, use --ena, or pipe data via stdin.\n\
             Example: sharkmer -s sample -k 21 reads.fastq\n\
             Example: sharkmer -s sample --ena SRR5324768\n\
             Example: zcat reads.fastq.gz | sharkmer -s sample -k 21"
        );
        let handle = stdin.lock();

        read_fastq(
            handle,
            &mut state,
            max_reads,
            args.validate_every,
            "stdin",
            &progress,
        )?;
        // read_source_plan remains Unavailable for stdin
    }

    progress.finish_and_clear();

    // Ingest any remaining sequences
    let n_chunks = state.chunks.len();
    drain_batch(&mut state, n_chunks)?;

    let mut n_reads_ingested: u64 = 0;
    let mut n_bases_ingested: u64 = 0;
    let mut n_kmers_ingested: u64 = 0;
    for chunk in state.chunks.iter() {
        n_reads_ingested += chunk.get_n_reads();
        n_bases_ingested += chunk.get_n_bases();
        n_kmers_ingested += chunk.get_n_kmers();
    }

    info!(
        "Read {} reads, {} bases",
        format_count(state.n_reads_read),
        format_bytes(state.n_bases_read)
    );
    info!(
        "Ingested {} subreads, {} bases, {} kmers",
        format_count(n_reads_ingested),
        format_bytes(n_bases_ingested),
        format_count(n_kmers_ingested)
    );

    // Warn if very few reads for sPCR
    let has_pcr = !args.pcr_panel.is_empty()
        || !args.pcr_panel_file.is_empty()
        || !args.pcr_primers.is_empty();
    if has_pcr && state.n_reads_read < 10_000 {
        warn!(
            "Only {} FASTQ records read. sPCR typically needs many more reads to produce results.",
            state.n_reads_read
        );
    }
    info!("Time to ingest reads: {}", format_duration(start.elapsed()));

    if n_reads_ingested == 0 {
        bail!("No reads were ingested. Check that input files contain valid FASTQ records.");
    }

    let read_plan = ReadPlan {
        source: read_source_plan,
        paired: args.paired,
        max_reads,
    };

    Ok((
        state,
        n_reads_ingested,
        n_bases_ingested,
        n_kmers_ingested,
        read_plan,
    ))
}

/// Open a FASTQ file as a buffered reader, with automatic gzip detection.
fn open_fastq_reader(file_path: &std::path::Path) -> Result<Box<dyn BufRead>> {
    let file_name = file_path.to_string_lossy();
    let has_gz_ext = file_name.ends_with(".gz") || file_name.ends_with(".gzip");

    // Open the file once. If we need to peek at the gzip magic bytes, do so
    // through the BufReader: fill_buf() loads bytes into the internal buffer
    // without consuming them, so subsequent reads (including through a
    // MultiGzDecoder wrapper) see the stream from position 0. This avoids a
    // redundant second open that showed up as two syscalls per FASTQ file.
    let file = std::fs::File::open(file_path)
        .with_context(|| format!("Failed to open file: {}", file_path.display()))?;
    let mut buf_reader = std::io::BufReader::new(file);

    let use_gzip = if has_gz_ext {
        true
    } else {
        let magic = buf_reader.fill_buf().context("Failed to peek at file")?;
        magic.len() >= 2 && magic[0] == 0x1f && magic[1] == 0x8b
    };

    if use_gzip {
        Ok(Box::new(std::io::BufReader::new(
            flate2::read::MultiGzDecoder::new(buf_reader),
        )))
    } else {
        Ok(Box::new(buf_reader))
    }
}

/// Read FASTQ sequences from two files in alternating order (R1, R2, R1, R2, ...).
/// Returns true if max_reads was reached.
#[allow(clippy::too_many_arguments)]
fn read_fastq_paired<R1: BufRead, R2: BufRead>(
    reader1: R1,
    reader2: R2,
    state: &mut FastqReadState,
    max_reads: u64,
    validate_every: u64,
    source1_name: &str,
    source2_name: &str,
    progress: &ProgressBar,
) -> Result<bool> {
    let mut lines1 = reader1.lines();
    let mut lines2 = reader2.lines();
    let n_chunks = state.chunks.len();
    let mut r1_records: u64 = 0;
    let mut r2_records: u64 = 0;
    let mismatch_exit: bool;

    loop {
        // Read one record from R1
        let r1_done = read_one_fastq_record(&mut lines1, state, validate_every, source1_name)?;
        if r1_done {
            // R1 exhausted. Verify R2 is also at EOF so we don't silently drop
            // unmatched R2 records (truncated R1, mismatched inputs).
            let r2_extra = read_one_fastq_record(&mut lines2, state, validate_every, source2_name)?;
            mismatch_exit = !r2_extra;
            if !r2_extra {
                r2_records += 1;
            }
            break;
        }
        r1_records += 1;
        if state.n_reads_read % N_READS_PER_BATCH == 0 {
            drain_batch(state, n_chunks)?;
            progress.set_position(state.n_reads_read);
        }
        if max_reads > 0 && state.n_reads_read >= max_reads {
            progress.set_position(state.n_reads_read);
            return Ok(true);
        }

        // Read one record from R2
        let r2_done = read_one_fastq_record(&mut lines2, state, validate_every, source2_name)?;
        if r2_done {
            // R2 ended mid-pair: R1 already consumed one more record than R2.
            mismatch_exit = true;
            break;
        }
        r2_records += 1;
        if state.n_reads_read % N_READS_PER_BATCH == 0 {
            drain_batch(state, n_chunks)?;
            progress.set_position(state.n_reads_read);
        }
        if max_reads > 0 && state.n_reads_read >= max_reads {
            progress.set_position(state.n_reads_read);
            return Ok(true);
        }
    }

    if mismatch_exit && r1_records != r2_records {
        warn!(
            "Paired-end input length mismatch: {} has {} reads, {} has {} reads. \
             Extra reads in the longer file were not processed.",
            source1_name, r1_records, source2_name, r2_records
        );
    }

    Ok(false)
}

/// Read a single FASTQ record (4 lines) from a lines iterator.
/// Returns true if EOF was reached (no more records).
fn read_one_fastq_record<R: BufRead>(
    lines: &mut std::io::Lines<R>,
    state: &mut FastqReadState,
    validate_every: u64,
    source_name: &str,
) -> Result<bool> {
    let header = match lines.next() {
        Some(result) => {
            result.map_err(|e| stream_io_error("header", &e, source_name, state.n_reads_read))?
        }
        None => return Ok(true), // EOF
    };

    let sequence = match lines.next() {
        Some(line) => {
            line.map_err(|e| stream_io_error("sequence", &e, source_name, state.n_reads_read))?
        }
        None => bail!(
            "Truncated FASTQ record at record {} in {}: missing sequence line",
            state.n_reads_read + 1,
            source_name,
        ),
    };

    let separator = match lines.next() {
        Some(line) => {
            line.map_err(|e| stream_io_error("separator", &e, source_name, state.n_reads_read))?
        }
        None => bail!(
            "Truncated FASTQ record at record {} in {}: missing separator line",
            state.n_reads_read + 1,
            source_name,
        ),
    };

    let quality = match lines.next() {
        Some(line) => {
            line.map_err(|e| stream_io_error("quality", &e, source_name, state.n_reads_read))?
        }
        None => bail!(
            "Truncated FASTQ record at record {} in {}: missing quality line",
            state.n_reads_read + 1,
            source_name,
        ),
    };

    let should_validate =
        state.n_reads_read == 0 || (validate_every > 0 && state.n_reads_read % validate_every == 0);
    if should_validate {
        validate_fastq_record(
            &header,
            &sequence,
            &separator,
            &quality,
            sequence.len(),
            state.n_reads_read,
        )?;
    }

    state.n_bases_read += sequence.len() as u64;
    state.seqs.push(sequence);
    state.n_reads_read += 1;

    Ok(false) // not EOF
}

/// Re-read FASTQ sequences for Pass 2 (read threading).
/// Opens the same sources used in Pass 1 and collects sequences into `ReadRecord`s.
pub(crate) fn reread_sequences(plan: &ReadPlan, show_progress: bool) -> Result<Vec<ReadRecord>> {
    let start = std::time::Instant::now();
    info!("Pass 2: re-reading sequences for read threading...");

    // Temp files held here are auto-deleted when this vec drops at end of
    // function. Each NamedTempFile has a unique path (random suffix), so
    // concurrent sharkmer invocations and same-length URLs cannot collide.
    let mut _pass2_tempfiles: Vec<tempfile::NamedTempFile> = Vec::new();
    let files: Vec<PathBuf> = match &plan.source {
        ReadSourcePlan::LocalFiles(paths) => paths.clone(),
        ReadSourcePlan::CachedRemote(paths) => paths.clone(),
        ReadSourcePlan::UncachedRemote(urls) => {
            // Re-download to temporary cache paths
            warn!("Re-downloading reads for Pass 2 (use --cache-dir to avoid this)");
            let mut paths = Vec::new();
            for url in urls {
                info!("Downloading {} for Pass 2...", url);
                let response = ureq::get(url)
                    .call()
                    .with_context(|| format!("Failed to download {} for Pass 2", url))?;
                // Create a unique temp file (random suffix) in the system temp
                // directory. The NamedTempFile guard is kept alive in
                // `_pass2_tempfiles` below so the file persists through Pass 2
                // reading and is deleted on function return.
                let mut tmp = tempfile::Builder::new()
                    .prefix("sharkmer_pass2_")
                    .suffix(".fastq.gz")
                    .tempfile()
                    .context("Failed to create temp file for Pass 2")?;
                std::io::copy(&mut response.into_reader(), tmp.as_file_mut())
                    .context("Failed to write Pass 2 temp file")?;
                paths.push(tmp.path().to_path_buf());
                _pass2_tempfiles.push(tmp);
            }
            paths
        }
        ReadSourcePlan::Unavailable => {
            return Ok(Vec::new());
        }
    };

    let progress = if show_progress && plan.max_reads > 0 {
        let pb = ProgressBar::new(plan.max_reads);
        pb.set_style(
            ProgressStyle::with_template("Pass 2 {bar:30} {human_pos}/{human_len} [{per_sec}]")
                .expect("valid progress template"),
        );
        pb
    } else if show_progress {
        let pb = ProgressBar::new_spinner();
        pb.set_style(
            ProgressStyle::with_template("Pass 2 {spinner} {human_pos} [{per_sec}]")
                .expect("valid progress template"),
        );
        pb
    } else {
        ProgressBar::hidden()
    };

    let mut records: Vec<ReadRecord> = Vec::new();
    let mut index: u64 = 0;

    if plan.paired && files.len() == 2 {
        // Paired-end: alternate R1 and R2. Track per-side record counts
        // so a truncated mate file can be surfaced to the user rather
        // than silently producing an unbalanced read set for Pass 2
        // threading. This mirrors the check in read_fastq_paired for
        // Pass 1.
        let reader1 = open_fastq_reader(&files[0])?;
        let reader2 = open_fastq_reader(&files[1])?;
        let name1 = files[0].to_string_lossy().to_string();
        let name2 = files[1].to_string_lossy().to_string();
        let mut lines1 = reader1.lines();
        let mut lines2 = reader2.lines();
        let mut r1_records: u64 = 0;
        let mut r2_records: u64 = 0;
        let mismatch_exit: bool;

        'outer: loop {
            // Read R1
            match read_sequence_only(&mut lines1)? {
                Some(seq) => {
                    records.push(ReadRecord {
                        sequence: seq,
                        index,
                        mate: Mate::R1,
                    });
                    index += 1;
                    r1_records += 1;
                }
                None => {
                    // R1 exhausted. Check whether R2 also reached EOF —
                    // if not, R2 has extra unmatched records.
                    let r2_extra = read_sequence_only(&mut lines2)?.is_some();
                    mismatch_exit = r2_extra;
                    if r2_extra {
                        r2_records += 1; // counted so the warning numbers are meaningful
                    }
                    break 'outer;
                }
            }
            progress.set_position(index);
            if plan.max_reads > 0 && index >= plan.max_reads {
                mismatch_exit = false;
                break;
            }

            // Read R2
            match read_sequence_only(&mut lines2)? {
                Some(seq) => {
                    records.push(ReadRecord {
                        sequence: seq,
                        index,
                        mate: Mate::R2,
                    });
                    index += 1;
                    r2_records += 1;
                }
                None => {
                    // R2 ended mid-pair: R1 already consumed one more.
                    mismatch_exit = true;
                    break 'outer;
                }
            }
            progress.set_position(index);
            if plan.max_reads > 0 && index >= plan.max_reads {
                mismatch_exit = false;
                break;
            }
        }

        if mismatch_exit && r1_records != r2_records {
            warn!(
                "Pass 2 paired-end input length mismatch: {} has {} reads, {} has {} reads. \
                 Extra reads in the longer file were not re-read for threading.",
                name1, r1_records, name2, r2_records
            );
        }
    } else {
        // Unpaired: read files sequentially
        for file_path in &files {
            let reader = open_fastq_reader(file_path)?;
            let mut lines = reader.lines();

            while let Some(seq) = read_sequence_only(&mut lines)? {
                records.push(ReadRecord {
                    sequence: seq,
                    index,
                    mate: Mate::Unpaired,
                });
                index += 1;
                if index % 10_000 == 0 {
                    progress.set_position(index);
                }
                if plan.max_reads > 0 && index >= plan.max_reads {
                    break;
                }
            }
            if plan.max_reads > 0 && index >= plan.max_reads {
                break;
            }
        }
    }

    progress.finish_and_clear();
    info!(
        "Pass 2: collected {} reads for threading in {}",
        format_count(index),
        format_duration(start.elapsed())
    );

    Ok(records)
}

/// Read a single FASTQ record and return only the sequence line.
/// Returns None at EOF.
fn read_sequence_only<R: BufRead>(lines: &mut std::io::Lines<R>) -> Result<Option<String>> {
    // Header
    match lines.next() {
        Some(result) => {
            result.context("Failed to read FASTQ header")?;
        }
        None => return Ok(None),
    }
    // Sequence
    let sequence = match lines.next() {
        Some(result) => result.context("Failed to read FASTQ sequence")?,
        None => bail!("Truncated FASTQ record: missing sequence line"),
    };
    // Separator
    match lines.next() {
        Some(result) => {
            result.context("Failed to read FASTQ separator")?;
        }
        None => bail!("Truncated FASTQ record: missing separator line"),
    }
    // Quality
    match lines.next() {
        Some(result) => {
            result.context("Failed to read FASTQ quality")?;
        }
        None => bail!("Truncated FASTQ record: missing quality line"),
    }
    Ok(Some(sequence))
}

/// Consolidate chunks into a single KmerCounts table, optionally writing histograms.
/// Returns (kmer_counts, n_singleton_kmers).
pub(crate) fn consolidate_and_histogram(
    state: &mut FastqReadState,
    args: &Args,
    k: usize,
    sample: &str,
    directory: &str,
    n_kmers_ingested: u64,
    show_progress: bool,
) -> Result<(KmerCounts, Option<u64>)> {
    let spinner_msg = if args.chunks > 0 {
        "Consolidating kmer counts..."
    } else {
        "Merging kmer counts..."
    };
    info!("{}", spinner_msg);
    let spinner_style =
        ProgressStyle::with_template("{spinner:.cyan} {msg}").expect("valid spinner template");
    let consolidate_spinner = if show_progress {
        let sp = ProgressBar::new_spinner();
        sp.set_style(spinner_style);
        sp.set_message(spinner_msg.to_string());
        sp.enable_steady_tick(std::time::Duration::from_millis(80));
        sp
    } else {
        ProgressBar::hidden()
    };
    let start = std::time::Instant::now();

    let estimated_capacity: usize = state.chunks.iter().map(|c| c.get_kmer_counts().len()).sum();
    let mut kmer_counts: KmerCounts = KmerCounts::new_with_capacity(&k, estimated_capacity);
    let mut n_singleton_kmers: Option<u64> = None;

    let histo_comment = format!(
        "# sharkmer {} k={} chunks={}",
        env!("CARGO_PKG_VERSION"),
        args.k,
        args.chunks
    );

    if args.chunks > 0 {
        // Incremental histogram mode: update histogram as chunks are merged.
        // Snapshot only the Vec<u64> at each step (not the full Histogram struct
        // with its `histo_large` AHashMap tail).
        let mut histo_vecs: Vec<Vec<u64>> = Vec::with_capacity(args.chunks);
        let mut running_histo = kmer::Histogram::new(&args.histo_max);

        for chunk in state.chunks.drain(..) {
            kmer_counts.extend_with_histogram(chunk.get_kmer_counts(), &mut running_histo)?;
            drop(chunk);

            histo_vecs.push(running_histo.get_vector()?);
        }
        consolidate_spinner.finish_and_clear();
        info!(
            "Chunks consolidated, time: {}",
            format_duration(start.elapsed())
        );

        let n_hashed_kmers: u64 = kmer_counts.get_n_kmers();
        info!(
            "{} unique kmers with a total count of {} were found",
            kmer_counts.get_n_unique_kmers(),
            n_hashed_kmers
        );

        ensure!(
            n_hashed_kmers == n_kmers_ingested,
            "The total count of hashed kmers ({}) does not equal the number of ingested kmers ({})",
            n_hashed_kmers,
            n_kmers_ingested,
        );

        // Write incremental histograms with header
        info!("Writing histograms to file...");
        let histo_path = format!("{}{}.histo", directory, sample);
        warn_if_exists(&histo_path);
        let mut file =
            std::fs::File::create(&histo_path).context("Failed to create histogram file")?;

        // Comment line with version and parameters
        writeln!(file, "{}", histo_comment).context("Failed to write histogram comment")?;

        // Header row
        let header: String = std::iter::once("count".to_string())
            .chain((1..=histo_vecs.len()).map(|i| format!("chunk_{}", i)))
            .collect::<Vec<_>>()
            .join("\t");
        writeln!(file, "{}", header).context("Failed to write histogram header")?;

        // Data rows — histo_vecs already contains the precomputed vectors
        for i in 1..args.histo_max as usize + 2 {
            let line: String = std::iter::once(i.to_string())
                .chain(histo_vecs.iter().map(|v| v[i].to_string()))
                .collect::<Vec<_>>()
                .join("\t");
            writeln!(file, "{}", line).context("Failed to write histogram data")?;
        }

        // Write the final histogram with header
        info!("Writing final histogram to file...");
        let last_histo_vec = histo_vecs.last().context("No histograms were produced")?;

        let final_histo_path = format!("{}{}.final.histo", directory, sample);
        warn_if_exists(&final_histo_path);
        let mut file = std::fs::File::create(&final_histo_path)
            .context("Failed to create final histogram file")?;

        writeln!(file, "{}", histo_comment).context("Failed to write final histogram comment")?;
        writeln!(file, "count\tfrequency").context("Failed to write final histogram header")?;

        for (i, value) in last_histo_vec
            .iter()
            .enumerate()
            .skip(1)
            .take(args.histo_max as usize + 1)
        {
            writeln!(file, "{}\t{}", i, value).context("Failed to write final histogram data")?;
        }

        let singleton_count = *last_histo_vec
            .get(1)
            .context("Histogram vector too short to contain singleton count")?;
        n_singleton_kmers = Some(singleton_count);

        // Warn if singleton rate is very high (>95% of unique kmers)
        let n_unique = running_histo.get_n_unique_kmers();
        if n_unique > 0 {
            let singleton_rate = singleton_count as f64 / n_unique as f64;
            if singleton_rate > 0.95 {
                warn!(
                    "Very high singleton rate ({:.1}%). This may indicate very low coverage \
                     or contamination. sPCR results may be unreliable.",
                    singleton_rate * 100.0
                );
            }
        }

        let n_unique_kmers_histo: u64 = running_histo.get_n_unique_kmers();
        let n_kmers_histo: u64 = running_histo.get_n_kmers();

        debug!("{} unique kmers in histogram", n_unique_kmers_histo);
        debug!("{} kmers in histogram", n_kmers_histo);

        ensure!(
            n_kmers_histo == n_kmers_ingested,
            "The total count of kmers in the histogram ({}) does not equal the total expected count of kmers ({})",
            n_kmers_histo,
            n_kmers_ingested,
        );

        ensure!(
            n_unique_kmers_histo == kmer_counts.get_n_unique_kmers(),
            "The total count of unique kmers in the histogram ({}) does not equal the total count of hashed kmers ({})",
            n_unique_kmers_histo,
            kmer_counts.get_n_unique_kmers(),
        );
    } else {
        // No histogram mode: merge all chunks into a single kmer count table
        for chunk in state.chunks.drain(..) {
            kmer_counts.extend(chunk.get_kmer_counts())?;
            drop(chunk);
        }
        consolidate_spinner.finish_and_clear();
        info!(
            "Kmer counts merged, time: {}",
            format_duration(start.elapsed())
        );

        let n_hashed_kmers: u64 = kmer_counts.get_n_kmers();
        info!(
            "{} unique kmers with a total count of {} were found",
            kmer_counts.get_n_unique_kmers(),
            n_hashed_kmers
        );

        ensure!(
            n_hashed_kmers == n_kmers_ingested,
            "The total count of hashed kmers ({}) does not equal the number of ingested kmers ({})",
            n_hashed_kmers,
            n_kmers_ingested,
        );
    }

    Ok((kmer_counts, n_singleton_kmers))
}

#[cfg(test)]
mod tests {
    use super::*;

    const RECORD_ONE: &str = "@read-one\nACGT\n+\n!!!!\n";
    const RECORD_TWO: &str = "@read-two\nTGCA\n+\n####\n";
    const RECORD_THREE: &str = "@read-three\nGATC\n+\n$$$$\n";
    const RECORD_FOUR: &str = "@read-four\nCTAG\n+\n%%%%\n";

    fn gzip_member(contents: &str) -> Vec<u8> {
        let mut encoder = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
        encoder.write_all(contents.as_bytes()).unwrap();
        encoder.finish().unwrap()
    }

    fn concatenated_gzip(records: &[&str]) -> Vec<u8> {
        records
            .iter()
            .flat_map(|record| gzip_member(record))
            .collect()
    }

    fn fastq_state() -> FastqReadState {
        let kmer_length = 3;
        FastqReadState {
            chunks: vec![Chunk::new(&kmer_length)],
            chunk_index: 0,
            seqs: Vec::new(),
            n_reads_read: 0,
            n_bases_read: 0,
        }
    }

    fn read_sequences(
        path: &std::path::Path,
        max_reads: u64,
    ) -> Result<(Vec<String>, u64, u64, bool)> {
        let reader = open_fastq_reader(path)?;
        let mut state = fastq_state();
        let reached_max = read_fastq(
            reader,
            &mut state,
            max_reads,
            0,
            &path.to_string_lossy(),
            &ProgressBar::hidden(),
        )?;
        let sequences = state.seqs.clone();
        let n_chunks = state.chunks.len();
        drain_batch(&mut state, n_chunks)?;
        let n_reads = state.chunks.iter().map(Chunk::get_n_reads).sum();
        let n_kmers = state.chunks.iter().map(Chunk::get_n_kmers).sum();
        Ok((sequences, n_reads, n_kmers, reached_max))
    }

    #[test]
    fn gzip_magic_detection_matches_plain_fastq() {
        let directory = tempfile::tempdir().unwrap();
        let plain_path = directory.path().join("reads.fastq");
        let compressed_path = directory.path().join("reads-compressed.fastq");
        let fastq = format!("{}{}", RECORD_ONE, RECORD_TWO);
        std::fs::write(&plain_path, &fastq).unwrap();
        std::fs::write(
            &compressed_path,
            concatenated_gzip(&[RECORD_ONE, RECORD_TWO]),
        )
        .unwrap();

        let compressed = read_sequences(&compressed_path, 0).unwrap();
        let plain = read_sequences(&plain_path, 0).unwrap();

        assert_eq!(compressed.0, plain.0);
        assert_eq!(compressed.1, plain.1);
        assert_eq!(compressed.2, plain.2);
    }

    #[test]
    fn concatenated_gzip_members_ingest_all_records() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("reads.fastq.gz");
        std::fs::write(&path, concatenated_gzip(&[RECORD_ONE, RECORD_TWO])).unwrap();

        assert_eq!(
            read_sequences(&path, 0).unwrap().0,
            ["ACGT".to_string(), "TGCA".to_string()]
        );
    }

    #[test]
    fn corrupt_second_gzip_member_returns_an_error() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("reads.fastq.gz");
        let mut corrupt_second_member = gzip_member(RECORD_TWO);
        *corrupt_second_member.last_mut().unwrap() ^= 0xff;
        let mut compressed = gzip_member(RECORD_ONE);
        compressed.extend(corrupt_second_member);
        std::fs::write(&path, compressed).unwrap();

        let error = read_sequences(&path, 0).unwrap_err();
        assert!(error.to_string().contains("Failed to read header line"));
    }

    #[test]
    fn paired_readers_continue_across_concatenated_members() {
        let directory = tempfile::tempdir().unwrap();
        let r1_path = directory.path().join("r1.fastq.gz");
        let r2_path = directory.path().join("r2.fastq.gz");
        std::fs::write(&r1_path, concatenated_gzip(&[RECORD_ONE, RECORD_TWO])).unwrap();
        std::fs::write(&r2_path, concatenated_gzip(&[RECORD_THREE, RECORD_FOUR])).unwrap();

        let mut state = fastq_state();
        let reached_max = read_fastq_paired(
            open_fastq_reader(&r1_path).unwrap(),
            open_fastq_reader(&r2_path).unwrap(),
            &mut state,
            0,
            0,
            "r1",
            "r2",
            &ProgressBar::hidden(),
        )
        .unwrap();

        assert!(!reached_max);
        assert_eq!(
            state.seqs,
            [
                "ACGT".to_string(),
                "GATC".to_string(),
                "TGCA".to_string(),
                "CTAG".to_string(),
            ]
        );
    }

    #[test]
    fn max_reads_stops_within_a_concatenated_member() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("reads.fastq.gz");
        std::fs::write(
            &path,
            concatenated_gzip(&[
                &format!("{}{}", RECORD_ONE, RECORD_TWO),
                &format!("{}{}", RECORD_THREE, RECORD_FOUR),
            ]),
        )
        .unwrap();

        let (sequences, _, _, reached_max) = read_sequences(&path, 3).unwrap();
        assert!(reached_max);
        assert_eq!(
            sequences,
            ["ACGT".to_string(), "TGCA".to_string(), "GATC".to_string()]
        );
    }

    #[test]
    fn replay_matches_initial_ingestion_for_concatenated_members() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("cached.fastq.gz");
        std::fs::write(
            &path,
            concatenated_gzip(&[RECORD_ONE, RECORD_TWO, RECORD_THREE]),
        )
        .unwrap();

        let ingested_sequences = read_sequences(&path, 0).unwrap().0;
        let replayed = reread_sequences(
            &ReadPlan {
                source: ReadSourcePlan::CachedRemote(vec![path]),
                paired: false,
                max_reads: 0,
            },
            false,
        )
        .unwrap();

        assert_eq!(
            replayed
                .iter()
                .map(|record| record.sequence.clone())
                .collect::<Vec<_>>(),
            ingested_sequences
        );
        assert!(replayed.iter().all(|record| record.mate == Mate::Unpaired));
        assert_eq!(
            replayed
                .iter()
                .map(|record| record.index)
                .collect::<Vec<_>>(),
            [0, 1, 2]
        );
    }
}
