# Independent pre-run review

Date: 2026-09-13. Reviewer: Astra (`/root/review_129`).

**Approved to launch the preregistered twelve diagnostic/parity invocations.**
This is review authorization for evidence collection, not a biological verdict,
assembly-policy exception, performance conclusion, or release approval.

## Verified scope

- Read-only Rust diff review: existing search order, admission, quotas, push/pop,
  counts and default serialization remain unchanged. Diagnostic retention checks
  whole-path/base/marker budgets before reconstruction and retains complete
  sequence-bound marker occurrences only. Causes distinguish pre-pruning
  membership from retained collision edges; unions are not complete ambiguity
  or bridge-ready intervals.
- All three focused panels preserve exact selected primer/reference objects,
  source order and other panel metadata. Focused runs change static diagnostic
  allocation only; their time/RSS are not whole-panel comparisons.
- Independently ran 9/9 harness tests and 11/11 analyzer tests. The latter include
  a twelve-job orchestration fixture, fourteen historical outcome rows, and
  duplicate/order/source-bookend/historical-map/parity adversaries. That fixture
  mocks raw-output capture; it is not twelve real Sharkmer invocations.
- Independently revalidated all three real-binary smoke-v3 raw outputs, exact
  recorded commands/local input metadata, eight-record prefix bytes and counts,
  per-job receipts, source bookends and complete gene-result parity. The smoke
  has zero products and zero retained withheld paths: it verifies CLI/manifest/
  provenance plumbing, not real-sample localization. Rust marker-record tests
  and analyzer record tests cover retained-record behavior separately.
- Verified the changed build's successful unchanged-source receipt, all 34
  current source fingerprints, source snapshot and frozen executable hash.
- Analyzer binds the ordered twelve-job/six-comparison matrix, frozen historical
  map, source bookends, per-job receipts and reconstructed commands; revalidates
  raw outputs and parity; checks sequence/marker identities, coordinates, unions
  and threshold/gene/run accounting. Exact historical matches establish only
  current enumerated-withheld identity and marker footprints. Capped or otherwise
  unobserved identities remain unresolved.

No real-sample diagnostic outcomes were inspected for this approval. Preserve
the earlier smoke attempts and all subsequent failed or changed-source receipts.
No post-outcome cap or target tuning is authorized by this review.

## Frozen hashes (SHA-256)

| Artifact | SHA-256 |
| --- | --- |
| `protocol.json` | `970550748a89cae5169f2f57c54681207137d251e66343a8966a84605871e62f` |
| `run_three_way.py` | `9d9f86a5e8756179be22c9ae10d737546f057d9be50c1a599480446fd9aade47` |
| `test_run_three_way.py` | `14e6df7f134f276faec685f3319f35b8dfb907ab51b9d30d466cada85df829af` |
| `analyze_withheld_results.py` | `b0a327635f6133b71f59503179d2852fce15e8d3640f89214a05723b9b24af1d` |
| `test_analyze_withheld_results.py` | `4494eec3f145c8e62ab5b413b7925c5001a39c11557c5f86889232b48a804b19` |
| `historical_lost_retained_map.json` | `f5397ae30c629eb89262172991fccb21248abfc35314debc7d2c4a9be6dfa16f` |
| `smoke-execution-v3/smoke_receipt.json` | `99fb31d08a46cd089bad2ef7c16076eb17f883bd1d7c3368abd1fadd121d075c` |
| Baseline executable | `d481ba32d9d1b0fe6f46f50cbe5fd82be4a1dfcafb45ea5a63ef97d79dab98c2` |
| Changed executable | `267c82a5bfca9cc3ee3cb503725d95e07d6cf3b9f5b200aeec31ce11d2703a6f` |
| `changed_build/build_receipt.json` | `ff663a4487e12edbd5f571c8149822c8be0eb5f777d0359e15ef810a36c89512` |
| `changed_build/source_snapshot.json` | `e3542fd67e460142d94f1e36f133de9abfb109009a185debe5298de8e778aeba` |

This document is a retrospective record of the independent pre-run review,
not a replacement for executable build, test or raw invocation receipts.
