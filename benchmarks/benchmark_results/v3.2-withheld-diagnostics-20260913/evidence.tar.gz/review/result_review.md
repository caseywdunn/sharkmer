# Independent completed-result review

Date: 2026-09-13. Reviewer: Astra (`/root/review_129`).

**Approved diagnostic-result interpretation and parity evidence; no blockers.**
This approval does not authorize admission changes, new biological truth
labels, performance-equivalence claims, or release.

`check_completed.py` ran successfully against the twelve completed invocations.
It does not import the production harness or analyzer. Its machine-readable
receipt and stdout/stderr are retained alongside this note.

Verified independently:

- The ordered twelve-job matrix, six full/focused parity comparisons, exact
  reconstructed commands, per-job receipts, complete raw YAML/FASTA transaction
  checksums, full headers/sequences and pre-existing complete gene outcomes.
- All 23 source-bookend hashes against current bytes and all 34 reviewed source
  fingerprints; unchanged executable/input identities and recorded prefix
  before/after equality. This review does not rescan multi-gigabyte inputs;
  full-file/prefix verification remains bound to the harness's recorded checks.
- All 80 retained records and 9,494 marker occurrences: oriented sequence and
  marker SHA-256, exact zero-based half-open substring coordinates, cause counts,
  duplicate occurrence exclusion, covered-position unions, sequence revisit
  multiplicity, whole-record retention totals, omitted-record accounting and
  threshold/gene/run caps.
- Five of seven exact historical identities occur in both full and focused
  diagnostic runs. The 487/499 bp Drosophila 12S identities remain unobserved
  under explicit retention/search limits, not proven absent.
- ITS 978 bp at threshold 4 has five pre-pruning SCC-node markers, no self-loop
  or collision marker, and no repeated traversed 18-mer. Its marker unions are
  `[93,112)` and `[276,296)`. This establishes a concrete current non-revisiting
  withheld path, not full-haplotype correctness or complete SCC entry/exit
  intervals. CO1's marker union `[310,349)` agrees with the earlier structural
  assay question without overturning that assay's preference for the shorter
  locally read-corroborated structure.
- Reported retention totals, counts, descriptive times/RSS and percentages match
  raw receipts. Single trios do not establish statistical equivalence. Focused
  panels are not whole-panel performance comparisons.

The pinned insect panel has **21**, not 43, primer targets. Actual allocation
uses the correct runtime target count: 12–13 paths and 1,560–1,561 marker
occurrences per full-panel gene. The earlier prose mistake (including this
reviewer's initial estimate sent during design) must remain visible in the
frozen snapshot with an explicit maintained-document erratum. No frozen panel,
execution parameter, cap, or allocation rule changed as a consequence.

Graph membership itself is source-attested; no archived graph was independently
reconstructed here. Marker-covered unions remain localization evidence only,
not automatically complete ambiguity intervals or read-bridge requests.

## Receipt bindings

- Checker SHA-256: `1a075877cd576a8c23d30b1ebf4180a266ef741c836d38c46101a991c556bfe0`.
- Execution SHA-256: `b1cdc20b50b0d355007f37b3637aace48674f2c5f8f42457d4ca4d1a9de8b516`.
- Analyzed results SHA-256: `307b7798ea111ed8329d8fe40a4ed576638442ec1254f0dc6312811430b4b462`.

This is a recorded independent review, not a replacement raw-run receipt.
Final archive byte/index verification is a separate pending packaging step.
