import argparse
import collections
import copy
import hashlib
import json
from pathlib import Path

import yaml


CAPS = {
    "threshold": {"paths": 32, "sequence_bases": 524288, "marker_occurrences": 4096},
    "gene": {"paths": 64, "sequence_bases": 1048576, "marker_occurrences": 8192},
    "run": {"paths": 256, "sequence_bases": 4194304, "marker_occurrences": 32768},
}
CAUSE_FIELDS = {
    "pre_prune_omitted_self_loop_node": "omitted_self_loop_marker_occurrences",
    "pre_prune_cyclic_scc_node": "cyclic_scc_marker_occurrences",
    "retained_collision_edge": "retained_collision_marker_occurrences",
}
DROP_FIELDS = (
    "dropped_oversize_sequence", "dropped_oversize_marker_set", "dropped_path_cap",
    "dropped_sequence_base_cap", "dropped_marker_cap",
)
COUNT_FIELDS = ("n_reads_read", "n_bases_read", "n_subreads_ingested", "n_bases_ingested", "n_kmers")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def stable(receipt):
    return {key: receipt[key] for key in ("hashes", "diagnostic_args", "inputs", "reviewed_files")}


def fasta_records(path):
    records = []
    for line in path.read_text().splitlines():
        if line.startswith(">"):
            records.append([line[1:], ""])
        else:
            assert records
            records[-1][1] += line
    assert all(sequence and set(sequence) <= set("ACGT") for _, sequence in records)
    return records


def plain_genes(stats):
    genes = copy.deepcopy(stats["pcr_results"])
    for gene in genes:
        for threshold in gene.get("threshold_diagnostics", []):
            threshold.pop("withheld_path_diagnostics", None)
    return genes


def check_record(record, kmer_length):
    sequence = record["oriented_sequence"]
    assert set(sequence) <= set("ACGT") and sequence
    assert record["sequence_length"] == len(sequence)
    assert digest(sequence.encode()) == record["sequence_sha256"]
    counts = collections.Counter()
    identities = set()
    positions = set()
    for marker in record["marker_occurrences"]:
        cause = marker["cause"]
        assert cause in CAUSE_FIELDS
        edge = cause == "retained_collision_edge"
        start, end = marker["start"], marker["end"]
        assert 0 <= start < end <= len(sequence)
        assert end - start == kmer_length - (not edge)
        assert marker["identity_kind"] == ("oriented_edge_sequence" if edge else "oriented_node_sequence")
        assert sequence[start:end] == marker["identity_sequence"]
        assert digest(sequence[start:end].encode()) == marker["identity_sha256"]
        signature = (cause, start, end)
        assert signature not in identities
        identities.add(signature)
        counts[cause] += 1
        positions.update(range(start, end))
    assert identities
    for cause, field in CAUSE_FIELDS.items():
        assert record[field] == counts[cause]
    run_positions = set()
    previous_end = -1
    for span in record["marker_covered_runs"]:
        assert previous_end < span["start"] < span["end"]
        run_positions.update(range(span["start"], span["end"]))
        previous_end = span["end"]
    assert run_positions == positions
    visits = collections.Counter(sequence[start:start + kmer_length - 1] for start in range(len(sequence) - kmer_length + 2))
    assert max(visits.values()) == record["max_observed_node_visits"] <= record["node_visit_limit"]
    return {"paths": 1, "sequence_bases": len(sequence), "marker_occurrences": len(identities)}


def main(root, output_path):
    protocol = read_json(root / "protocol.json")
    execution = read_json(root / "execution/execution.json")
    analysis = read_json(root / "withheld_results.json")
    historical = read_json(root / "historical_lost_retained_map.json")["rows"]
    before = execution["source_before"]
    assert execution["after_validation_error"] is None and not execution["source_changed_during_execution"]
    assert stable(before) == stable(execution["source_after"])
    assert before["diagnostic_args"] == ["--diagnose-withheld-paths"]
    source_paths = {
        "protocol": root / "protocol.json", "runner": root / "run_three_way.py",
        "panel": Path(protocol["panel"]["path"]), "baseline_binary": Path(protocol["baseline_binary"]["path"]),
        "changed_binary": root / "changed_build/sharkmer-changed",
        "interpreter": Path("/home/claude/miniforge3/bin/python3.13"),
        "time_binary": Path("/usr/bin/time"), "taskset_binary": Path("/usr/bin/taskset"), "prlimit_binary": Path("/usr/bin/prlimit"),
        "validator": Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/runner.py"),
        "baseline_build_receipt": Path(protocol["baseline_binary"]["build_receipt"]),
        "changed_source_snapshot": root / "changed_build/source_snapshot.json",
        "changed_build_receipt": root / "changed_build/build_receipt.json",
        "analyzer": root / "analyze_withheld_results.py", "analyzer_tests": root / "test_analyze_withheld_results.py",
        "historical_map": root / "historical_lost_retained_map.json", "historical_localization": root / "historical_localization.json",
        "protocol_snapshot": root / "WITHHELD_PATH_DIAGNOSTICS.snapshot.md",
        "focused_identity_receipt": Path(protocol["focused_diagnostic_only"]["identity_receipt"]),
        "focused_manifest": Path(protocol["focused_diagnostic_only"]["manifest"]),
    }
    for focused in protocol["focused_diagnostic_only"]["runs_after_full_panel"]:
        source_paths["focused_panel_" + focused["accession"]] = Path(focused["panel"])
    assert set(source_paths) == set(before["hashes"])
    for name, path in source_paths.items():
        assert digest(path.read_bytes()) == before["hashes"][name], name
    for name, expected in before["reviewed_files"].items():
        assert digest(Path(name).read_bytes()) == expected, name
    expected_jobs = [(accession, role, protocol["panel"]["path"], None) for accession, sample in protocol["samples"].items() for role in sample["roles"]]
    expected_jobs += [(row["accession"], "changed_on_focused", row["panel"], row["targets"]) for row in protocol["focused_diagnostic_only"]["runs_after_full_panel"]]
    assert len(execution["jobs"]) == len(expected_jobs) == 12
    jobs = {}
    totals_by_job = []
    matches = []
    record_count = 0
    marker_count = 0
    for job, (accession, role, panel_path, selected_targets) in zip(execution["jobs"], expected_jobs):
        assert (job["accession"], job["role"]) == (accession, role)
        assert job["returncode"] == 0 and job["validated_output"] and not job["timed_out"]
        assert job == read_json(root / "execution" / f"{accession}.{role}.receipt.json")
        assert stable(job["source_before"]) == stable(before)
        enabled = role in {"changed_on", "changed_on_focused"}
        assert job["binary_role"] == ("changed_on" if enabled else role)
        assert job["selected_targets"] == selected_targets
        assert job["focused_diagnostic_only"] == (selected_targets is not None)
        directory = Path(job["output_directory"])
        assert directory == root / "execution" / accession / role
        sample = protocol["samples"][accession]
        prefix = sample["prefix"]
        assert job["input_prefix_before"] == job["input_prefix_after"] == prefix
        assert before["inputs"][accession] == {"path": sample["input"], "full_sha256": sample["full_sha256"], "prefix": prefix}
        binary = str(source_paths["baseline_binary" if role == "baseline_off" else "changed_binary"])
        common = protocol["common_invocation"]
        command = ["/usr/bin/prlimit", f"--as={common['address_space_limit_bytes']}", "--", "/usr/bin/time", "-v", "-o", str(directory / "time.txt"), "/usr/bin/taskset", "-c", common["cpu_list"], binary, "-k", str(common["k"]), "-t", str(common["threads"]), "--chunks", str(common["chunks"]), "--max-reads", str(common["max_reads"]), "-o", str(directory), "-s", "withheld_" + accession, "--pcr-panel-file", panel_path]
        if enabled:
            command.append("--diagnose-withheld-paths")
        command.append(sample["input"])
        assert job["command"] == command
        for stream in ("stdout", "stderr"):
            assert digest((directory / (stream + ".txt")).read_bytes()) == job[stream + "_sha256"]
        raw_stats = Path(job["outputs"]["stats_path"]).read_bytes()
        assert digest(raw_stats) == job["outputs"]["stats_sha256"]
        stats = yaml.safe_load(raw_stats)
        assert stats == job["outputs"]["stats"] and stats["command"] == " ".join(command[10:])
        assert stats["input_source"] == {"kind": "local_files", "inputs": [sample["input"]], "paired": False, "max_reads": prefix["records"]}
        assert stats["n_reads_read"] == prefix["records"] and stats["n_bases_read"] == prefix["bases"]
        assert stats["kmer_length"] == 19 and stats["chunks"] == 0
        manifest = yaml.safe_load((directory / stats["output_manifest"]).read_bytes())
        assert manifest["status"] == stats["run_status"] == "complete"
        assert manifest["run_id"] == stats["run_id"] and manifest["sample"] == stats["sample"]
        names = [entry["path"] for entry in manifest["files"]]
        assert len(names) == len(set(names))
        expected_names = {Path(job["outputs"]["stats_path"]).name} | set(job["outputs"]["fasta_files"])
        assert set(names) == expected_names
        products = {}
        for entry in manifest["files"]:
            assert Path(entry["path"]).name == entry["path"]
            assert digest((directory / entry["path"]).read_bytes()) == entry["sha256"]
        panel = yaml.safe_load(Path(panel_path).read_bytes())
        gene_names = [panel["name"] + "_" + primer["gene"] + ("-" + primer["region"] if primer.get("region") else "") + ("_" + str(primer["index"]) if primer.get("index") is not None else "") for primer in panel["primers"]]
        assert [gene["gene_name"] for gene in stats["pcr_results"]] == gene_names
        run_usage = dict.fromkeys(CAPS["run"], 0)
        for gene_index, gene in enumerate(stats["pcr_results"]):
            if gene["status"] == "success":
                products[gene["gene_name"]] = fasta_records(directory / gene["output_file"])
                assert len(products[gene["gene_name"]]) == gene["n_products"]
            else:
                assert gene["n_products"] == 0
            previous = dict.fromkeys(CAPS["run"], 0)
            allocated = {key: min(CAPS["gene"][key], limit // len(gene_names) + (gene_index < limit % len(gene_names))) for key, limit in CAPS["run"].items()}
            for threshold in gene.get("threshold_diagnostics", []):
                payload = threshold.get("withheld_path_diagnostics")
                if not enabled:
                    assert payload is None
                    continue
                assert payload["gene_usage_before_threshold"] == previous
                assert payload["limits"] == {**CAPS, "allocated_run_share_for_gene": allocated, "unused_share_is_not_redistributed": True}
                usage = dict.fromkeys(CAPS["run"], 0)
                for record in payload["paths"]:
                    observed = check_record(record, 19)
                    record_count += 1
                    marker_count += observed["marker_occurrences"]
                    for key in usage:
                        usage[key] += observed[key]
                    for historical_row in historical:
                        if historical_row["accession"] == accession and "insecta_" + historical_row["gene"] == gene["gene_name"] and historical_row["lost_sha256"] == record["sequence_sha256"]:
                            matches.append({"accession": accession, "role": role, "gene": gene["gene_name"], "sha256": record["sequence_sha256"], "threshold": threshold["threshold"], "record": record})
                assert usage == {"paths": payload["retained_paths"], "sequence_bases": payload["retained_sequence_bases"], "marker_occurrences": payload["retained_marker_occurrences"]}
                dropped = payload["observed_not_retained_paths"]
                assert payload["observed_withheld_paths"] == threshold["withheld_candidate_paths"] == usage["paths"] + dropped
                assert sum(payload[field] for field in DROP_FIELDS) == dropped
                assert payload["retention_truncated"] == bool(dropped)
                for key in usage:
                    assert usage[key] <= CAPS["threshold"][key]
                    previous[key] += usage[key]
                    assert previous[key] <= allocated[key]
                assert payload["gene_usage_after_threshold"] == previous
            for key in previous:
                run_usage[key] += previous[key]
        assert all(run_usage[key] <= CAPS["run"][key] for key in run_usage)
        totals_by_job.append({"accession": accession, "role": role, **run_usage})
        jobs[accession, role] = {"counts": [stats[field] for field in COUNT_FIELDS], "genes": plain_genes(stats), "products": products}
    for accession in protocol["samples"]:
        assert jobs[accession, "baseline_off"] == jobs[accession, "changed_off"] == jobs[accession, "changed_on"]
        full, focused = jobs[accession, "changed_on"], jobs[accession, "changed_on_focused"]
        selected = {gene["gene_name"] for gene in focused["genes"]}
        assert focused == {"counts": full["counts"], "genes": [gene for gene in full["genes"] if gene["gene_name"] in selected], "products": {gene: records for gene, records in full["products"].items() if gene in selected}}
    expected_matches = [{"accession": row["accession"], "role": row["role"], "gene": row["gene"], "sha256": row["historical_sha256"], "threshold": match["threshold"], "record": match["record"]} for row in analysis["historical_localization"] for match in row["matches"]]
    assert matches == expected_matches
    assert len(analysis["historical_localization"]) == 14
    assert analysis["execution_sha256"] == digest((root / "execution/execution.json").read_bytes())
    assert analysis["historical_map_sha256"] == digest((root / "historical_lost_retained_map.json").read_bytes())
    result = {
        "status": "pass", "checker_sha256": digest(Path(__file__).read_bytes()),
        "execution_sha256": analysis["execution_sha256"], "analysis_sha256": digest((root / "withheld_results.json").read_bytes()),
        "jobs": 12, "parity_comparisons": 6, "source_bookend_hashes": len(source_paths), "reviewed_source_files": len(before["reviewed_files"]),
        "retained_records_verified": record_count, "marker_occurrences_verified": marker_count,
        "job_retention": totals_by_job, "historical_matches": matches,
        "scope": "Independent raw YAML/FASTA, receipt, command, current source, sequence/marker-coordinate and cap accounting verification without importing production harness/analyzer. Full input files were not rescanned; pinned full/prefix hashes rely on recorded pre/post harness inspection. Marker membership itself is source-attested, not independently reconstructed from an archived graph. Localized footprints do not establish complete graph ambiguity intervals, read support, or biological truth.",
    }
    with output_path.open("x") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({key: value for key, value in result.items() if key not in {"historical_matches", "job_retention"}}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    main(arguments.root, arguments.output)
