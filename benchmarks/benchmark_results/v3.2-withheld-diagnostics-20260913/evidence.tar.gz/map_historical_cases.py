#!/usr/bin/env python3
"""Map frozen historical lost products to retained same-gene alternatives."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


ROOT = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
SOURCE = Path('/tmp/sharkmer-read-audit-20260913/candidates/candidate_manifest.json')
OUTPUT = ROOT / 'historical_lost_retained_map.json'


def write_new(value: object) -> None:
    encoded = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    descriptor = os.open(OUTPUT, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'wb') as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())


def main() -> int:
    source_bytes = SOURCE.read_bytes()
    source = json.loads(source_bytes)
    rows = []
    for case in source['cases']:
        retained = [{'sha256': product['sha256'], 'length': product['length']} for product in case['retained_same_gene_products']]
        for product in case['lost_products']:
            difference = product.get('difference_from_retained_same_gene')
            rows.append({
                'accession': case['accession'],
                'taxon': case['taxon'],
                'gene': case['gene'],
                'lost_sha256': product['sha256'],
                'lost_length': product['length'],
                'retained_same_gene_products': retained,
                'coordinate_difference': difference,
                'historical_gate_diagnostics': case['gate_diagnostics'],
                'interpretation_limit': 'Coordinates compare serialized output sequences only. A missing product in the capped first-million-record collection does not establish absence of a graph path, template, or sequence outside that collection.',
            })
    if len(rows) != 7:
        raise ValueError(f'Expected seven historical lost products, found {len(rows)}')
    write_new({
        'schema_version': 1,
        'source_candidate_manifest_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'coordinate_system': source['coordinate_system'],
        'rows': rows,
    })
    print(json.dumps({'output': str(OUTPUT), 'rows': len(rows)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
