# Withheld-Path Diagnostics Artifacts

## Preregistered material

- `README.preregistered.md` preserves the pre-execution plan verbatim.
- `protocol.json` is the machine-readable matrix and fixed-input contract.
- `WITHHELD_PATH_DIAGNOSTICS.snapshot.md` is the captured protocol document.
- `focused_panels/` holds the preregistered focused-panel clones and identity receipts.
- `historical_lost_retained_map.json` and `historical_localization.json` are historical mapping/localization context, not newly measured changed-binary findings.

## Final measured material

- `execution/execution.json` is the completed twelve-job aggregate receipt; it includes source and input pre/post attestations plus each exact command.
- `execution/comparison.json` contains the full/focused parity comparison outcome.
- `execution/*.receipt.json` are durable per-job receipts. Each job has a separate output directory, stdout/stderr, GNU time report, stats, manifest, and FASTA receipts below `execution/<accession>/<role>/`.
- `execution-driver-v2.stdout.txt` and `execution-driver-v2.stderr.txt` are the final launcher streams.
- `environment_post_run.txt` is a lightweight post-run host observation only; it was not enforced or attested per job.
- `ATTEMPT_LINEAGE.md` distinguishes the preserved failed and passing smoke attempts, the rejected pre-launch invocation, and the final completed matrix.

## Limitations

- The historical mappings, smoke fixtures, and final 1M real-input execution answer different questions and must not be conflated.
- The final run is sequential and single-observation per role. Its wall time and RSS fields are descriptive, not statistical benchmark evidence.
- The final outputs preserve diagnostics and parity evidence. They do not alone establish read support, haplotype phase, biological correctness, or a general recovery claim.
- This artifact directory preserves evidence for review; it does not modify repository source, panels, the frozen harness, protocol, analyzer, or test suite.
