#!/usr/bin/env python3
"""Validate frozen historical withheld-product localization inputs without read inference."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


ROOT = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
SOURCE = Path('/tmp/sharkmer-read-audit-20260913/candidates/candidate_manifest.json')
OUTPUT = ROOT / 'historical_localization.json'
EXPECTED_SOURCE_SHA256 = 'a8df6371680394dfc37b8aec62cd2aed0e2968306f36420a6858221046b59b4e'


def write_new(value: object) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    descriptor = os.open(OUTPUT, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'wb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def validate_intervals(sequence: str, evidence: dict) -> None:
    for interval in evidence.get('consolidated_intervals', []):
        start, end = interval['repeat_span']
        if not (0 <= start < end <= len(sequence)):
            raise ValueError(f'Invalid marker span {start}:{end} for length {len(sequence)}')


def main() -> int:
    raw = SOURCE.read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_SOURCE_SHA256:
        raise ValueError('Frozen candidate manifest hash differs')
    manifest = json.loads(raw)
    rows = []
    for case in manifest['cases']:
        retained = []
        for product in case['retained_same_gene_products']:
            if hashlib.sha256(product['sequence'].encode()).hexdigest() != product['sha256']:
                raise ValueError(f"Retained sequence hash differs for {case['gene']}")
            validate_intervals(product['sequence'], product.get('repeat_evidence', {}))
            retained.append({'sha256': product['sha256'], 'length': len(product['sequence'])})
        diagnostics = case['gate_diagnostics']['threshold_diagnostics']
        for diagnostic in diagnostics:
            for key in ('withheld_by_scc_node_paths', 'withheld_by_self_loop_node_paths', 'withheld_by_collision_edge_paths', 'withheld_candidate_paths'):
                if not isinstance(diagnostic.get(key), int) or diagnostic[key] < 0:
                    raise ValueError(f"Invalid diagnostic {key} for {case['gene']}")
        for product in case['lost_products']:
            if hashlib.sha256(product['sequence'].encode()).hexdigest() != product['sha256']:
                raise ValueError(f"Lost sequence hash differs for {case['gene']}")
            validate_intervals(product['sequence'], product.get('repeat_evidence', {}))
            rows.append({
                'accession': case['accession'], 'gene': case['gene'], 'lost_sha256': product['sha256'], 'lost_length': len(product['sequence']),
                'retained_same_gene': retained, 'coordinate_difference': product.get('difference_from_retained_same_gene'),
                'sequence_marker_footprints': product.get('repeat_evidence'), 'threshold_diagnostics': diagnostics,
                'effective_per_gene_threshold_node_budget': 100000,
                'budget_scope': 'Historical diagnostics serialize budget-reached booleans, not per-path consumption; no unused budget is inferred.',
                'bounded_absence_interpretation': 'No read observation or missing capped-input output is treated as a graph-path, template, or biological absence result; it remains unresolved under the stated bounds.',
            })
    if len(rows) != 7:
        raise ValueError(f'Expected seven lost products, found {len(rows)}')
    write_new({'schema_version': 1, 'source_manifest_sha256': EXPECTED_SOURCE_SHA256, 'rows': rows})
    print(json.dumps({'output': str(OUTPUT), 'rows': len(rows)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
