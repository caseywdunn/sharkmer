# Withheld-Path Diagnostics Attempt Lineage

This file records observed execution attempts without altering their receipts, harnesses, inputs, or outputs.

## 1. Schema-smoke v1: failed fixture validation

- Directory: `/tmp/sharkmer-withheld-diagnostics-20260913/smoke-execution/`
- Receipt: `baseline_off.receipt.json`
- Status: attempted once; Sharkmer exited `1`, `validated_output: false`, and no timeout occurred.
- Cause: the original stderr at `runs/smoke/baseline_off/stderr.txt` says the fixture declared `schema_version: "2"` but lacked the required `clade` field.
- Scope: this failure occurred before a valid three-role smoke comparison and does not provide a behavioral comparison result.

## 2. Schema-smoke v2: passing comparison

- Directory: `/tmp/sharkmer-withheld-diagnostics-20260913/smoke-execution-v2/`
- Aggregate receipt: `smoke_receipt.json`
- Status: baseline-off, changed-off, and changed-on each exited `0` with validated output; the aggregate comparison passed and recorded `source_changed: false`.
- Input: the dedicated eight-record `fixture/smoke.fastq`; it is not a 1M benchmark input.

## 3. Schema-smoke v3: passing final-comparator smoke

- Directory: `/tmp/sharkmer-withheld-diagnostics-20260913/smoke-execution-v3/`
- Aggregate receipt: `smoke_receipt.json`
- Harness test log: `/tmp/sharkmer-withheld-diagnostics-20260913/smoke-v3-harness-tests.log`
- Status: baseline-off, changed-off, and changed-on each exited `0` with validated output; the final-comparator aggregate passed and recorded `source_changed: false`.
- Scope: this is the final harness smoke, still using the dedicated eight-record fixture rather than any real 1M prefix.

## 4. Rejected first real launcher: no job started

- Captured stderr: `/tmp/sharkmer-withheld-diagnostics-20260913/execution-driver.stderr.txt`
- Captured stdout: `/tmp/sharkmer-withheld-diagnostics-20260913/execution-driver.stdout.txt`
- Status: `argparse` rejected the invocation because `--diagnostic-arg` lacked its required argument. It produced no `execution/` directory and launched no Sharkmer job.
- Rejected argument form: `--diagnostic-arg --diagnose-withheld-paths`.

## 5. Final twelve-run execution: completed

- Output directory: `/tmp/sharkmer-withheld-diagnostics-20260913/execution/`
- Aggregate receipt: `execution/execution.json`
- Parity receipt: `execution/comparison.json`
- Driver stdout: `/tmp/sharkmer-withheld-diagnostics-20260913/execution-driver-v2.stdout.txt`
- Driver stderr: `/tmp/sharkmer-withheld-diagnostics-20260913/execution-driver-v2.stderr.txt`
- Status: all twelve job receipts report `returncode: 0`, `validated_output: true`, and `timed_out: false`. The aggregate records `source_changed_during_execution: false` and no post-run validation error. The parity receipt reports no failures.

The exact final launcher argv, with the interpreter resolved to the binary whose SHA256 is bound in `execution/execution.json`, was:

```text
/home/claude/miniforge3/bin/python3 /tmp/sharkmer-withheld-diagnostics-20260913/run_three_way.py --execute --baseline /tmp/sharkmer-withheld-diagnostics-20260913/sharkmer-base-58ca2a6 --changed /tmp/sharkmer-withheld-diagnostics-20260913/changed_build/sharkmer-changed --changed-source-snapshot /tmp/sharkmer-withheld-diagnostics-20260913/changed_build/source_snapshot.json --changed-build-receipt /tmp/sharkmer-withheld-diagnostics-20260913/changed_build/build_receipt.json --diagnostic-arg=--diagnose-withheld-paths --output /tmp/sharkmer-withheld-diagnostics-20260913/execution
```

The twelve exact nested per-job argv arrays, resource limits, paths, prefix receipts, output validations, and command logs are preserved in `execution/execution.json` and the individual `execution/*.receipt.json` files. The order was the preregistered three full-panel trios followed by three changed-on focused diagnostics.

## Boundaries

- The final comparison uses fixed first-1M-record unpaired R1 prefixes, `k=19`, two threads, `--chunks 0`, and no read threading, as recorded in the receipt.
- Resource timings are descriptive single observations, not a performance benchmark or a global no-regression conclusion.
- This lineage does not interpret diagnostic payloads as biological, read-support, phasing, or recovery conclusions. Those interpretations require the separately frozen analyzer and root review.
