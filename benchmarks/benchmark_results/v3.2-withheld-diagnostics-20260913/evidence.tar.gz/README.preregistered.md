# Withheld-Path Diagnostic Parity Plan

This directory freezes a verified `58ca2a6` baseline executable, its isolated
archive-build verification, three unpaired R1 prefixes, and an execution-disabled
nine full-panel jobs plus three predeclared focused diagnostic-only jobs. It does
not contain changed-binary results.

The exact sequential order is Gryllus `baseline_off`, `changed_off`,
`changed_on`; Drosophila `changed_on`, `baseline_off`, `changed_off`; and
Heliconius `changed_off`, `changed_on`, `baseline_off`. Every command uses
`k=19`, two threads, zero chunks, one million records, the pinned insect panel,
and local unpaired FASTQ input. Complete staged-file and consumed-prefix hashes
are checked before runs; prewarming is outside measured wall time.

After the nine full-panel jobs, three changed-binary diagnostic-only runs use
frozen clones of the current insect panel: Gryllus `CO1_1` and `ITS_2`,
Drosophila `12S` and `16S_2`, and Heliconius `ND1`. The clones retain each
selected target's names and parameters, with only unrelated primers/reference
groups removed. Each run records the fixed clone hash, target list, and the
unchanged auto-derived per-gene/per-threshold node budget of 100,000. Focused
timing and RSS are not aggregate parity metrics.

Each job will use a fresh directory and exclusive receipt. The harness rejects
output reuse and no run starts without `--execute` plus a reviewed diagnostic
flag. Timings and maximum RSS are descriptive single-trio observations only.
The comparison requires five count fields and ordered FASTA headers/sequences to
match exactly. Diagnostics may differ only at the preregistered opt-in payload
key. Absence in the capped input is not evidence that no graph path or sequence
exists outside that collection.
