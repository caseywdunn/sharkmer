import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = Path('/home/claude/repos/sharkmer')
DESTINATION = REPO / 'benchmarks/benchmark_results/v3.2-withheld-diagnostics-20260913'
EXCLUDED_ROOTS = {'base-source', 'base-target', '__pycache__'}


def main():
    members = {}
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if relative.parts[0] in EXCLUDED_ROOTS or '__pycache__' in relative.parts:
            continue
        if not path.is_file() or path.name in {'sharkmer-base-58ca2a6', 'sharkmer-changed'}:
            continue
        if path.is_symlink():
            raise ValueError(f'Unexpected symlink: {path}')
        members[str(relative)] = path.read_bytes()
    for name in ('dev_docs/WITHHELD_PATH_DIAGNOSTICS.md', 'dev_docs/WITHHELD_PATH_DIAGNOSTICS_RESULTS.md', 'dev_docs/PLAN.md', 'README.md', 'scripts/sharkmer_validate/runner.py'):
        members['repository_snapshot/' + name] = (REPO / name).read_bytes()
    candidate = Path('/tmp/sharkmer-read-audit-20260913/candidates/candidate_manifest.json').read_bytes()
    if hashlib.sha256(candidate).hexdigest() != 'a8df6371680394dfc37b8aec62cd2aed0e2968306f36420a6858221046b59b4e':
        raise ValueError('Historical candidate manifest changed')
    members['historical_source/candidate_manifest.json'] = candidate
    members['repository_changes.patch'] = subprocess.check_output(['git', 'diff', '58ca2a6', '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock', 'README.md', 'dev_docs/PLAN.md'], cwd=REPO)
    archive_path = DESTINATION / 'evidence.tar.gz'
    with archive_path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, contents in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(contents)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(contents))
    inventory = {name: {'size_bytes': len(contents), 'sha256': hashlib.sha256(contents).hexdigest()} for name, contents in sorted(members.items())}
    index_path = DESTINATION / 'ARCHIVE_CONTENTS.json'
    with index_path.open('x') as output:
        output.write(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
    with (DESTINATION / 'SHA256SUMS').open('x') as output:
        for path in (archive_path, index_path):
            output.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n')
    print(json.dumps({'members': len(members), 'archive_bytes': archive_path.stat().st_size, 'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
