import copy
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import yaml


SPEC = importlib.util.spec_from_file_location("analyze_withheld_results", Path(__file__).with_name("analyze_withheld_results.py"))
ANALYZER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ANALYZER)


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.zero = {"paths": 0, "sequence_bases": 0, "marker_occurrences": 0}
        self.record = {
            "oriented_sequence": "ACGTA", "sequence_length": 5,
            "sequence_sha256": ANALYZER.digest(b"ACGTA"), "node_visit_limit": 2,
            "max_observed_node_visits": 1, "omitted_self_loop_marker_occurrences": 1,
            "cyclic_scc_marker_occurrences": 0, "retained_collision_marker_occurrences": 0,
            "marker_occurrences": [{"cause": "pre_prune_omitted_self_loop_node", "identity_kind": "oriented_node_sequence", "identity_sequence": "CG", "identity_sha256": ANALYZER.digest(b"CG"), "start": 1, "end": 3}],
            "marker_covered_runs": [{"start": 1, "end": 3}],
        }
        self.payload = {
            "schema_version": 1, "coordinate_system": "zero_based_half_open",
            "purpose": "diagnostic_only_unsupported_candidate_hypotheses",
            "marker_span_scope": "marker_covered_positions_not_complete_ambiguity_or_bridge_ready_intervals",
            "read_support_evaluation": "not_evaluated",
            "limits": {**copy.deepcopy(ANALYZER.CAPS), "allocated_run_share_for_gene": copy.deepcopy(ANALYZER.CAPS["gene"]), "unused_share_is_not_redistributed": True},
            "gene_usage_before_threshold": dict(self.zero), "gene_usage_after_threshold": {"paths": 1, "sequence_bases": 5, "marker_occurrences": 1},
            "observed_withheld_paths": 1, "retained_paths": 1, "observed_not_retained_paths": 0,
            "retained_sequence_bases": 5, "retained_marker_occurrences": 1,
            "node_visit_limit": 2, "node_visit_skips": 0,
            "retention_truncated": False, "paths": [self.record],
            **dict.fromkeys(ANALYZER.DROP_FIELDS, 0),
        }

    def validate(self, payload=None, previous=None, observed=1):
        return ANALYZER.validate_payload(payload or self.payload, {"withheld_candidate_paths": observed}, 3, 0, 1, previous or self.zero)

    def test_complete_record_and_accounting(self):
        self.assertEqual(self.validate(), {"paths": 1, "sequence_bases": 5, "marker_occurrences": 1})

    def test_sequence_marker_hash_coordinate_and_union_corruption_fail(self):
        for field, value in (("oriented_sequence", "ACNTA"), ("sequence_sha256", "bad"), ("sequence_length", 4), ("max_observed_node_visits", 3), ("marker_covered_runs", [{"start": 1, "end": 4}])):
            changed = copy.deepcopy(self.record)
            changed[field] = value
            with self.assertRaises(ValueError):
                ANALYZER.validate_record(changed, 3)
        for field, value in (("identity_sha256", "bad"), ("start", 0), ("end", 4), ("identity_sequence", "GT"), ("identity_kind", "oriented_edge_sequence"), ("cause", "unsupported_cause")):
            changed = copy.deepcopy(self.record)
            changed["marker_occurrences"][0][field] = value
            with self.assertRaises(ValueError):
                ANALYZER.validate_record(changed, 3)

    def test_duplicate_occurrence_does_not_inflate_evidence(self):
        self.record["marker_occurrences"] *= 2
        self.record["omitted_self_loop_marker_occurrences"] = 2
        with self.assertRaises(ValueError):
            ANALYZER.validate_record(self.record, 3)

    def test_accounting_limits_and_truth_labels_fail_closed(self):
        for field, value in (("retained_paths", 2), ("observed_not_retained_paths", 1), ("retained_sequence_bases", 4), ("retention_truncated", True), ("read_support_evaluation", "confirmed"), ("coordinate_system", "one_based")):
            changed = copy.deepcopy(self.payload)
            changed[field] = value
            with self.assertRaises(ValueError):
                self.validate(changed)
        changed = copy.deepcopy(self.payload)
        changed["limits"]["allocated_run_share_for_gene"]["paths"] += 1
        with self.assertRaises(ValueError):
            self.validate(changed)

    def test_threshold_and_cumulative_gene_path_caps(self):
        changed = copy.deepcopy(self.payload)
        changed["paths"] *= 33
        changed.update(retained_paths=33, retained_sequence_bases=165, retained_marker_occurrences=33)
        changed["gene_usage_after_threshold"] = {"paths": 33, "sequence_bases": 165, "marker_occurrences": 33}
        with self.assertRaisesRegex(ValueError, "Threshold"):
            self.validate(changed, observed=33)
        previous = {"paths": 64, "sequence_bases": 320, "marker_occurrences": 64}
        changed = copy.deepcopy(self.payload)
        changed["gene_usage_before_threshold"] = previous
        changed["gene_usage_after_threshold"] = {"paths": 65, "sequence_bases": 325, "marker_occurrences": 65}
        with self.assertRaisesRegex(ValueError, "Gene/run-share"):
            self.validate(changed, previous)

    def test_omissions_require_explicit_accounting_and_real_saturation(self):
        self.payload.update(observed_withheld_paths=2, observed_not_retained_paths=1, dropped_path_cap=1, retention_truncated=True)
        with self.assertRaisesRegex(ValueError, "saturated"):
            self.validate(observed=2)
        self.payload["dropped_path_cap"] = 0
        self.payload["dropped_oversize_sequence"] = 1
        self.assertEqual(self.validate(observed=2)["paths"], 1)


class OrchestrationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.fixture_root = Path(self.temporary.name)
        self.original_root = ANALYZER.ROOT
        self.original_historical = self.original_root / "historical_lost_retained_map.json"
        for basename in ("protocol.json", "run_three_way.py", "test_analyze_withheld_results.py"):
            shutil.copyfile(self.original_root / basename, self.fixture_root / basename)
        self.historical_path = self.fixture_root / "historical_lost_retained_map.json"
        shutil.copyfile(self.original_historical, self.historical_path)
        self.protocol = json.loads((self.fixture_root / "protocol.json").read_text())
        self.harness = self._load_real_harness()
        self.outputs_by_directory = {}
        self.execution_path = self.fixture_root / "execution.json"
        self.execution = self._make_execution()
        self._write_execution()

    def tearDown(self):
        self.temporary.cleanup()

    def _load_real_harness(self):
        specification = importlib.util.spec_from_file_location(
            "withheld_parity_harness_fixture", self.fixture_root / "run_three_way.py"
        )
        harness = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(harness)
        return harness

    def _source_receipt(self, baseline_binary, changed_binary):
        paths = {
            "protocol": self.fixture_root / "protocol.json",
            "runner": self.fixture_root / "run_three_way.py",
            "analyzer": Path(ANALYZER.__file__),
            "analyzer_tests": self.fixture_root / "test_analyze_withheld_results.py",
            "historical_map": self.historical_path,
            "baseline_binary": baseline_binary,
            "changed_binary": changed_binary,
        }
        return {
            "hashes": {name: ANALYZER.digest(path.read_bytes()) for name, path in paths.items()},
            "diagnostic_args": ["--diagnose-withheld-paths"],
            "inputs": {"synthetic": "receipt-bound"},
            "reviewed_files": {"synthetic": "receipt-bound"},
            "captured_at": "2026-09-13T00:00:00Z",
        }

    def _payload(self, gene_index, gene_count):
        allocated = {
            key: min(
                ANALYZER.CAPS["gene"][key],
                total // gene_count + int(gene_index < total % gene_count),
            )
            for key, total in ANALYZER.CAPS["run"].items()
        }
        zero = {"paths": 0, "sequence_bases": 0, "marker_occurrences": 0}
        return {
            "schema_version": 1,
            "coordinate_system": "zero_based_half_open",
            "purpose": "diagnostic_only_unsupported_candidate_hypotheses",
            "marker_span_scope": "marker_covered_positions_not_complete_ambiguity_or_bridge_ready_intervals",
            "read_support_evaluation": "not_evaluated",
            "limits": {
                **copy.deepcopy(ANALYZER.CAPS),
                "allocated_run_share_for_gene": allocated,
                "unused_share_is_not_redistributed": True,
            },
            "gene_usage_before_threshold": dict(zero),
            "gene_usage_after_threshold": dict(zero),
            "observed_withheld_paths": 0,
            "retained_paths": 0,
            "observed_not_retained_paths": 0,
            "retained_sequence_bases": 0,
            "retained_marker_occurrences": 0,
            "node_visit_limit": 2,
            "node_visit_skips": 0,
            "retention_truncated": False,
            "paths": [],
            **dict.fromkeys(ANALYZER.DROP_FIELDS, 0),
        }

    def _threshold(self, payload=None):
        threshold = {
            "threshold": 3,
            "connectivity_found": True,
            "node_budget_reached": False,
            "path_search_evaluated": True,
            "dfs_limit_reached": False,
            "path_quota_reached": False,
            "max_length_reached": False,
            "withheld_candidate_paths": 0,
        }
        if payload is not None:
            threshold["withheld_path_diagnostics"] = payload
        return threshold

    def _genes_for_job(self, job):
        historical = json.loads(self.historical_path.read_text())
        gene_names = []
        for row in historical["rows"]:
            if row["accession"] == job["accession"]:
                gene_name = "insecta_" + row["gene"]
                if gene_name not in gene_names:
                    gene_names.append(gene_name)
        genes = []
        for gene_index, gene_name in enumerate(gene_names):
            enabled = job["binary_role"] == "changed_on"
            payload = self._payload(gene_index, len(gene_names)) if enabled else None
            genes.append(
                {
                    "gene_name": gene_name,
                    "status": "success",
                    "failure_reason": None,
                    "threshold_diagnostics": [self._threshold(payload)],
                }
            )
        return genes

    def _write_stats(self, output_directory, stats):
        output_directory.mkdir(parents=True)
        stats_path = output_directory / "synthetic.stats.yaml"
        stats_path.write_text(yaml.safe_dump(stats, sort_keys=True))
        loaded_stats = yaml.safe_load(stats_path.read_bytes())
        return stats_path, loaded_stats

    def _make_execution(self):
        baseline_binary = self.fixture_root / "baseline-sharkmer"
        changed_binary = self.fixture_root / "changed-sharkmer"
        baseline_binary.write_bytes(b"synthetic baseline executable")
        changed_binary.write_bytes(b"synthetic changed executable")
        receipt = self._source_receipt(baseline_binary, changed_binary)
        binaries = {
            "baseline_off": baseline_binary,
            "changed_off": changed_binary,
            "changed_on": changed_binary,
        }
        jobs = []
        for job_index, expected_job in enumerate(self.harness.build_jobs(self.protocol)):
            output_directory = self.fixture_root / "outputs" / expected_job["accession"] / expected_job["role"]
            stats = {
                "kmer_length": 19,
                "n_reads_read": 10,
                "n_bases_read": 1000,
                "n_subreads_ingested": 10,
                "n_bases_ingested": 1000,
                "n_kmers": 820,
                "pcr_results": self._genes_for_job(expected_job),
            }
            stats_path, loaded_stats = self._write_stats(output_directory, stats)
            output = {
                "stats_path": str(stats_path),
                "stats_sha256": ANALYZER.digest(stats_path.read_bytes()),
                "stats": loaded_stats,
                "fasta_records_ordered": [],
                "fasta_files": {},
            }
            sample = self.protocol["samples"][expected_job["accession"]]
            diagnostic_args = ["--diagnose-withheld-paths"] if expected_job["binary_role"] == "changed_on" else []
            command = self.harness.make_command(
                binaries[expected_job["binary_role"]],
                self.protocol,
                sample,
                expected_job["panel"],
                output_directory,
                f"withheld_{expected_job['accession']}",
                diagnostic_args,
            )
            record = {
                **expected_job,
                "command": command,
                "returncode": 0,
                "timed_out": False,
                "validated_output": True,
                "source_before": receipt,
                "output_directory": str(output_directory),
                "outputs": output,
                "wall_time_seconds": 1.0 + job_index,
                "maximum_rss_bytes": 1024 * (job_index + 1),
            }
            jobs.append(record)
            self.outputs_by_directory[str(output_directory)] = output
        payload_key = self.protocol["comparison_contract"]["preregistered_payload_key"]
        comparisons = self.harness.compare_full_roles(jobs, payload_key)
        comparisons.extend(self.harness.compare_focused_runs(jobs, payload_key))
        return {
            "schema_version": 1,
            "jobs": jobs,
            "source_before": receipt,
            "source_after": {**copy.deepcopy(receipt), "captured_at": "2026-09-13T00:01:00Z"},
            "after_validation_error": None,
            "source_changed_during_execution": False,
            "comparisons": comparisons,
        }

    def _write_execution(self):
        for job in self.execution["jobs"]:
            receipt_path = self.fixture_root / f"{job['accession']}.{job['role']}.receipt.json"
            receipt_path.write_text(json.dumps(job, sort_keys=True))
        self.execution_path.write_text(json.dumps(self.execution, sort_keys=True))

    def _capture_outputs(self, output_directory, *unused_args, **unused_kwargs):
        return copy.deepcopy(self.outputs_by_directory[str(output_directory)])

    def _analyze(self):
        real_harness = self.harness
        real_harness.capture_outputs = self._capture_outputs
        with mock.patch.object(ANALYZER, "ROOT", self.fixture_root), mock.patch.object(
            ANALYZER, "load_harness", return_value=real_harness
        ):
            return ANALYZER.analyze(self.execution_path, self.historical_path)

    def test_complete_twelve_job_analysis_returns_fourteen_unlocalized_rows(self):
        result = self._analyze()
        self.assertEqual(len(result["sources"]), 12)
        self.assertEqual(len(result["historical_localization"]), 14)
        self.assertTrue(
            all(
                row["status"] == "not_observed_in_retained_current_run_paths"
                and not row["matches"]
                for row in result["historical_localization"]
            )
        )

    def test_duplicate_and_reordered_jobs_are_rejected(self):
        original_jobs = copy.deepcopy(self.execution["jobs"])
        mutations = (
            [copy.deepcopy(original_jobs[0]), *copy.deepcopy(original_jobs[1:])],
            [copy.deepcopy(original_jobs[1]), copy.deepcopy(original_jobs[0]), *copy.deepcopy(original_jobs[2:])],
        )
        mutations[0][1] = copy.deepcopy(mutations[0][0])
        for changed_jobs in mutations:
            with self.subTest(roles=[job["role"] for job in changed_jobs[:2]]):
                self.execution["jobs"] = changed_jobs
                self._write_execution()
                with self.assertRaisesRegex(ValueError, "job matrix/order"):
                    self._analyze()
        self.execution["jobs"] = original_jobs

    def test_source_bookend_tamper_is_rejected(self):
        self.execution["source_after"]["hashes"]["runner"] = "0" * 64
        self._write_execution()
        with self.assertRaisesRegex(ValueError, "Source bookends differ"):
            self._analyze()

    def test_historical_map_byte_tamper_is_rejected(self):
        self.historical_path.write_bytes(self.historical_path.read_bytes() + b"\n")
        with self.assertRaisesRegex(ValueError, "Frozen source differs: historical_map"):
            self._analyze()

    def test_recomputed_parity_rejects_falsely_passed_comparison(self):
        changed_job = next(job for job in self.execution["jobs"] if job["role"] == "changed_off")
        changed_job["outputs"]["stats"]["n_kmers"] += 1
        stats_path = Path(changed_job["outputs"]["stats_path"])
        stats_path.write_text(yaml.safe_dump(changed_job["outputs"]["stats"], sort_keys=True))
        changed_job["outputs"]["stats"] = yaml.safe_load(stats_path.read_bytes())
        changed_job["outputs"]["stats_sha256"] = ANALYZER.digest(stats_path.read_bytes())
        self.outputs_by_directory[changed_job["output_directory"]] = changed_job["outputs"]
        self._write_execution()
        with self.assertRaisesRegex(ValueError, "Recomputed parity differs"):
            self._analyze()


if __name__ == "__main__":
    unittest.main()
