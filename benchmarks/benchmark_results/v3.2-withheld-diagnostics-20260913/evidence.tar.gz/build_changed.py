import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path


REPOSITORY = Path("/home/claude/repos/sharkmer")
OUTPUT = Path(__file__).resolve().parent / "changed_build"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_files():
    paths = [REPOSITORY / "Cargo.toml", REPOSITORY / "Cargo.lock"]
    paths.extend(REPOSITORY.joinpath("src").rglob("*.rs"))
    paths.extend(REPOSITORY.joinpath("tests").rglob("*.rs"))
    paths.extend(REPOSITORY.joinpath("panels").glob("*.yaml"))
    return {str(path): digest(path) for path in sorted(paths)}


def main():
    OUTPUT.mkdir(exist_ok=False)
    before = source_files()
    command = ["cargo", "build", "--locked", "--release"]
    rustc = subprocess.check_output(["rustc", "-Vv"], text=True)
    cargo = subprocess.check_output(["cargo", "-V"], text=True)
    environment = {name: os.environ.get(name) for name in (
        "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_BUILD_TARGET",
        "CARGO_TARGET_DIR", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
    )}
    if environment["CARGO_TARGET_DIR"] or environment["CARGO_BUILD_TARGET"]:
        raise ValueError("This freeze requires the ordinary native target directory")
    completed = subprocess.run(command, cwd=REPOSITORY, capture_output=True, text=True)
    (OUTPUT / "build.stdout.txt").write_text(completed.stdout)
    (OUTPUT / "build.stderr.txt").write_text(completed.stderr)
    after = source_files()
    receipt = {
        "schema_version": 1, "command": command, "cwd": str(REPOSITORY),
        "rustc_version_verbose": rustc, "cargo_version": cargo,
        "environment": environment, "features": "default (ahashmap)",
        "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPOSITORY, text=True).strip(),
        "returncode": completed.returncode, "source_before": before,
        "source_after": after, "source_changed_during_build": before != after,
        "build_script_sha256": digest(Path(__file__)),
    }
    if completed.returncode == 0 and before == after:
        binary = OUTPUT / "sharkmer-changed"
        shutil.copy2(REPOSITORY / "target/release/sharkmer", binary)
        receipt["binary_path"] = str(binary)
        receipt["binary_sha256"] = digest(binary)
        snapshot = OUTPUT / "source_snapshot.json"
        snapshot.write_text(json.dumps({"files": before}, indent=2, sort_keys=True) + "\n")
        receipt["source_snapshot_sha256"] = digest(snapshot)
        for name in before:
            source = Path(name)
            target = OUTPUT / "source_tree" / source.relative_to(REPOSITORY)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            if digest(target) != before[name]:
                raise ValueError("Source changed while copying the reviewed snapshot")
    (OUTPUT / "build_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    if completed.returncode != 0 or before != after:
        raise ValueError("Build failed or sources changed; preserve this failed attempt")
    print(json.dumps({"binary": receipt["binary_path"], "sha256": receipt["binary_sha256"], "sources": len(before)}))


if __name__ == "__main__":
    main()
