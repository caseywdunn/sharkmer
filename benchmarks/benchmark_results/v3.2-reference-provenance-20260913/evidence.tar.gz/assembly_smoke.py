import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/claude/repos/sharkmer')
SCRATCH = Path('/tmp/sharkmer-reference-audit-20260913/assembly-smoke')
sys.path.insert(0, str(ROOT / 'scripts'))
from sharkmer_validate import runner

SCRATCH.mkdir(exist_ok=True)
old_panel = SCRATCH / 'before_cnidaria.yaml'
old_panel.write_bytes(subprocess.check_output(['git', 'show', '6fe7658:panels/cnidaria.yaml'], cwd=ROOT))
binaries = {
    'before': Path('/tmp/sharkmer-high-copy-20260911/issue155-build/binaries/sharkmer-candidate'),
    'after': ROOT / 'target/release/sharkmer',
}
count_fields = ['n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers']
summary = {'scope': 'offline assembly/count smoke; not throughput or biological held-out evidence',
           'binaries': {role: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for role, path in binaries.items()},
           'comparisons': []}
for kmer_length in (19, 31):
    observations = {}
    for role, binary in binaries.items():
        run = runner.run_sharkmer(
            old_panel if role == 'before' else ROOT / 'panels/cnidaria.yaml',
            'cnidaria', 'ERR571460', 100000, SCRATCH / f'k{kmer_length}_{role}',
            threads=2, k=kmer_length, executable=binary,
            input_path=ROOT / 'tests/fixtures/ERR571460_100k_R1.fastq.gz',
        )
        assert run['success'], run.get('error')
        (SCRATCH / f'k{kmer_length}_{role}.json').write_text(json.dumps(run,sort_keys=True,indent=2)+'\n')
        observations[role] = {
            'counts': {field: run['run_stats'][field] for field in count_fields},
            'products': sorted((gene['gene'], product['length'], hashlib.sha256(product['sequence'].encode()).hexdigest())
                               for gene in run['genes'] for product in gene.get('products', [])),
        }
    identical = observations['before'] == observations['after']
    summary['comparisons'].append({'k': kmer_length, 'observations': observations, 'identical': identical})
    assert identical, observations
(SCRATCH / 'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True))
