import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/claude/repos/sharkmer')
SCRATCH = Path('/tmp/sharkmer-reference-audit-20260913')
OUTPUT = ROOT / 'benchmarks/benchmark_results/v3.2-reference-provenance-20260913'
OUTPUT.mkdir(exist_ok=True)
files = {}
for name in ['legacy_references.json', 'migration_proposal_nonunique_final.json',
             'annotation_decisions.json', 'catalog_nonunique_final.json',
             'cargo-test-release.log', 'python-tests.log', 'assembly_smoke.py',
             'assembly-smoke.log', 'package_evidence.py']:
    files[name] = (SCRATCH / name).read_bytes()
for directory in ['source-archive', 'assembly-smoke', 'reclassification']:
    for path in sorted((SCRATCH / directory).rglob('*')):
        if directory == 'reclassification' and path.name not in {
            'audit_panel_migration.py', 'panel_migration_audit.json',
            'reclassify_saved_outputs.py', 'saved_output_reclassification.json',
        }:
            continue
        if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            files[str(path.relative_to(SCRATCH))] = path.read_bytes()
panel_paths = sorted((ROOT / 'panels').glob('*.yaml')) + [ROOT / 'panels/examples/reference.yaml']
for path in panel_paths:
    relative = str(path.relative_to(ROOT))
    files['frozen_before/' + relative] = subprocess.check_output(['git', 'show', f'6fe7658:{relative}'], cwd=ROOT)
    files['source_tree/' + relative] = path.read_bytes()
for path in sorted((ROOT / 'scripts/sharkmer_validate').glob('*.py')):
    files['source_tree/' + str(path.relative_to(ROOT))] = path.read_bytes()
for name in ['scripts/audit_panel_references.py', 'scripts/validate_panel.py', 'scripts/bootstrap_references.py',
             'scripts/bootstrap_from_runs.py', 'scripts/sweep_summary.py', 'benchmarks/run_benchmark.py',
             'src/pcr/preconfigured.rs', 'schemas/panel/v2.json', 'tests/test_reference_catalog.py',
             'tests/test_reference_provenance.py', 'tests/test_validation_harness.py', 'panels/reference_sources.json.gz']:
    files['source_tree/' + name] = (ROOT / name).read_bytes()
rows = json.loads((SCRATCH / 'reclassification/saved_output_reclassification.json').read_text())['results']['products']
supported = {
    role: sorted((row['invocation']['panel'], row['invocation']['input'], row['gene'], row['sha256'])
                 for row in rows if row['invocation']['version'] == role and
                 row['new_reference_match']['status'] in {'gene_supported_expected_taxon', 'gene_supported_other_taxon'})
    for role in ('baseline', 'candidate')
}
assert supported['baseline'] == supported['candidate']
assert len(supported['baseline']) == 30
files['reclassification/supported_identity_comparison.json'] = (json.dumps(
    {'scope': 'gene support against eligible short public regions; not complete biological truth',
     'identical_sets': True, 'supported_per_role': 30, 'identities': supported}, sort_keys=True, indent=2) + '\n').encode()
manifest = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, content in sorted(files.items()):
        information = tarfile.TarInfo(name)
        information.size = len(content)
        information.mode = 0o644
        archive.addfile(information, io.BytesIO(content))
        manifest.append({'path': name, 'size_bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
archive_path = OUTPUT / 'evidence.tar.gz'
archive_path.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
(OUTPUT / 'ARCHIVE_CONTENTS.json').write_text(json.dumps({'schema_version': 1, 'file_count': len(manifest), 'files': manifest}, indent=2, sort_keys=True)+'\n')
(OUTPUT / 'SHA256SUMS').write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.name+'\n' for path in [archive_path, OUTPUT / 'ARCHIVE_CONTENTS.json']))
print(json.dumps({'files': len(manifest), 'archive_bytes': archive_path.stat().st_size,
                  'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()}, sort_keys=True))
