#!/usr/bin/env python3
"""Reclassify receipt-verified saved FASTA outputs against migrated references."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import shlex
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

import yaml


REPOSITORY_ROOT = Path("/home/claude/repos/sharkmer")
DEFAULT_RESULTS = Path("/tmp/sharkmer-high-copy-20260911/final-execution/results")
DEFAULT_CATALOG = REPOSITORY_ROOT / "panels/reference_sources.json.gz"
FOCUS_PRODUCTS = {
    "23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c": "Gryllus ITS_2 978",
    "e86a7ccf9e78adaf259ec804eb05dadaf8557bc4a7c637b483dfacd330a7e3ba": "Gryllus CO1_1 373",
    "bde6ccaf771a24982439c53e7d38c45748cb2773f6ce05660c2a31a85d9203be": "Drosophila 12S 475",
    "d147d2a3d79608354456b94cbfeb6df52eae820d135852530fb2d8798d54b39c": "Drosophila 12S 487",
    "c1a643a6313600b14ac0faae530e4fd93b48fa5007978c93ae81f089efa04148": "Drosophila 12S 499",
    "6d6a1fe8e2de508afa9a757ceca421c0796eb2e7a70dcdd39b357190764f4049": "Drosophila 16S_2 590",
    "3ba955f286a5468dbd65fc5e81601dbd53f0d898189a6c576c91bc744098728f": "Heliconius ND1 263",
    "e2d376bc5b0f09a954f7dfb6083ff3e4a768a2b687685e18349f66dd25cfc9c0": "Gryllus CO1_1 retained 352",
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def executable_receipt(name: str) -> dict:
    resolved = shutil.which(name)
    if resolved is None:
        raise ValueError(f"Required executable is unavailable: {name}")
    executable = Path(resolved).resolve()
    if not executable.is_file() or executable.is_symlink():
        raise ValueError(f"Required executable is not a regular file: {executable}")
    completed = subprocess.run(
        [str(executable), "-version"], check=True, capture_output=True, text=True
    )
    return {
        "path": str(executable),
        "sha256": sha256_bytes(executable.read_bytes()),
        "version": completed.stdout.strip(),
    }


def normalized_gene(panel: str, raw_gene: str) -> str:
    prefix = f"{panel}_"
    return raw_gene[len(prefix) :] if raw_gene.startswith(prefix) else raw_gene


def parse_header_fields(header: str) -> dict[str, str]:
    return {
        key: value
        for token in shlex.split(header)
        if "=" in token
        for key, value in [token.split("=", 1)]
    }


def parse_fasta(path: Path, panel: str) -> list[dict]:
    records = []
    header = None
    sequence_lines: list[str] = []
    for line in path.read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                records.append(fasta_record(header, sequence_lines, panel, len(records)))
            header = line[1:]
            sequence_lines = []
        elif header is not None:
            sequence_lines.append(line.strip())
        elif line.strip():
            raise ValueError(f"FASTA data precedes header: {path}")
    if header is not None:
        records.append(fasta_record(header, sequence_lines, panel, len(records)))
    return records


def fasta_record(header: str, sequence_lines: list[str], panel: str, record_order: int) -> dict:
    fields = parse_header_fields(header)
    raw_gene = fields.get("gene")
    if not raw_gene:
        raise ValueError(f"FASTA header lacks gene field: {header}")
    sequence = "".join(sequence_lines).upper()
    if not sequence:
        raise ValueError(f"FASTA header has an empty sequence: {header}")
    product = fields.get("product")
    if product is None or not product.isdecimal():
        raise ValueError(f"FASTA header lacks numeric product field: {header}")
    return {
        "gene": normalized_gene(panel, raw_gene),
        "header": header,
        "length": len(sequence),
        "product_index": int(product),
        "record_order": record_order,
        "sequence": sequence,
        "sha256": sha256_bytes(sequence.encode()),
    }


def receipt_files(result: dict, result_path: Path) -> tuple[Path, list[Path]]:
    output_dir = Path(result["attempt_dir"]) / "output"
    if not output_dir.is_dir() or output_dir.is_symlink():
        raise ValueError(f"Output directory is unavailable: {output_dir}")
    fasta_paths = []
    for receipt in result.get("raw_output_files", []):
        relative_path = receipt.get("path")
        if not isinstance(relative_path, str) or Path(relative_path).name != relative_path:
            raise ValueError(f"Invalid raw output receipt in {result_path}")
        output_path = output_dir / relative_path
        if not output_path.is_file() or output_path.is_symlink():
            raise ValueError(f"Receipt file is unavailable: {output_path}")
        content = output_path.read_bytes()
        if receipt.get("size_bytes") != len(content) or receipt.get("sha256") != sha256_bytes(content):
            raise ValueError(f"Receipt differs for {output_path}")
        if output_path.suffix == ".fasta":
            fasta_paths.append(output_path)
    return output_dir, sorted(fasta_paths)


def stored_products(result: dict) -> dict[tuple[str, int], dict]:
    products = {}
    for gene_result in result.get("genes", []):
        gene = gene_result.get("gene")
        for product in gene_result.get("products", []):
            product_index = product.get("product_index")
            product_hash = product.get("sha256")
            if not isinstance(gene, str) or not isinstance(product_index, int) or not isinstance(product_hash, str):
                raise ValueError("Saved result has an invalid product record")
            key = (gene, product_index)
            if key in products:
                raise ValueError(f"Saved result duplicates product key {key}")
            products[key] = product
    return products


def read_saved_result(result_path: Path) -> dict:
    raw = result_path.read_bytes()
    result = json.loads(raw)
    if result.get("status") != "complete" or result.get("classification_status") != "complete":
        raise ValueError(f"Result is not complete: {result_path}")
    invocation = result.get("signature", {}).get("invocation", {})
    required = ["panel", "input", "depth", "pair_index", "version", "sample_prefix", "taxon"]
    if any(not invocation.get(key) for key in required):
        raise ValueError(f"Result has an incomplete invocation signature: {result_path}")
    output_dir, fasta_paths = receipt_files(result, result_path)
    parsed = [record for fasta_path in fasta_paths for record in parse_fasta(fasta_path, invocation["panel"])]
    stored = stored_products(result)
    parsed_keys = {(record["gene"], record["product_index"]) for record in parsed}
    if parsed_keys != set(stored):
        raise ValueError(f"Saved FASTA/products differ in {result_path}")
    for record in parsed:
        prior = stored[(record["gene"], record["product_index"])]
        if prior.get("sha256") != record["sha256"] or prior.get("length") != record["length"]:
            raise ValueError(f"Saved FASTA record differs from result summary in {result_path}")
        record["old_reference_match"] = copy.deepcopy(prior.get("reference_match"))
    return {
        "result_path": str(result_path),
        "result_sha256": sha256_bytes(raw),
        "output_dir": str(output_dir),
        "invocation": invocation,
        "products": parsed,
    }


def product_fingerprint(products: list[dict]) -> str:
    encoded = json.dumps(
        sorted(
            (record["gene"], record["product_index"], record["sha256"])
            for record in products
        ),
        separators=(",", ":"),
    ).encode()
    return sha256_bytes(encoded)


def stable_reference_match(match: dict) -> dict:
    stable = copy.deepcopy(match)
    provenance = stable.get("reference_database_provenance")
    if isinstance(provenance, dict):
        provenance.pop("manifest_sha256", None)
        for field, value in provenance.items():
            if field.endswith("_path") and isinstance(value, str):
                provenance[field] = Path(value).name
    return stable


def deduplicate(entries: list[dict]) -> tuple[list[dict], list[dict]]:
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for entry in entries:
        invocation = entry["invocation"]
        groups[(invocation["panel"], invocation["input"], invocation["depth"], invocation["version"])].append(entry)
    representatives = []
    records = []
    for group_key, members in sorted(groups.items()):
        fingerprints = {product_fingerprint(member["products"]) for member in members}
        eligible = len(members) == 3 and len(fingerprints) == 1
        selected = [sorted(members, key=lambda item: item["invocation"]["pair_index"])[0]] if eligible else sorted(members, key=lambda item: item["invocation"]["pair_index"])
        representatives.extend(selected)
        records.append(
            {
                "group": {
                    "panel": group_key[0], "input": group_key[1], "depth": group_key[2], "version": group_key[3]
                },
                "member_count": len(members),
                "fingerprints": sorted(fingerprints),
                "deduplicated": eligible,
                "representatives": [member["result_path"] for member in selected],
                "members": [
                    {"result_path": member["result_path"], "result_sha256": member["result_sha256"], "pair_index": member["invocation"]["pair_index"], "product_fingerprint": product_fingerprint(member["products"])}
                    for member in sorted(members, key=lambda item: item["invocation"]["pair_index"])
                ],
            }
        )
    return representatives, records


def classify(representatives: list[dict], repository_root: Path, catalog_path: Path) -> tuple[list[dict], dict]:
    sys.path.insert(0, str(repository_root / "scripts"))
    from sharkmer_validate import blast_references, reference_provenance

    if (
        blast_references.MIN_IDENTITY_PCT != 90.0
        or blast_references.MIN_QUERY_COVERAGE_PCT != 90.0
    ):
        raise ValueError("Classifier defaults differ from the required 90% identity/coverage")

    panels: dict[str, list[dict]] = defaultdict(list)
    for representative in representatives:
        panels[representative["invocation"]["panel"]].append(representative)
    database_receipts = {}
    for panel_name, entries in sorted(panels.items()):
        panel_path = repository_root / "panels" / f"{panel_name}.yaml"
        if not panel_path.is_file():
            raise ValueError(f"Panel path unavailable: {panel_path}")
        panel_data = yaml.safe_load(panel_path.read_text())
        audit = reference_provenance.audit_references(panel_data, catalog_path)
        reference_genes = {reference["gene_name"] for reference in audit["verified"]}
        if not reference_genes:
            raise ValueError(f"Panel has no verified references: {panel_name}")
        with tempfile.TemporaryDirectory(prefix=f"reclassify_{panel_name}_") as temporary:
            database = blast_references.build_reference_db(panel_data, Path(temporary), catalog_path)
            if database is None:
                raise ValueError(f"Verified reference database unavailable: {panel_name}")
            database_receipts[panel_name] = blast_references.reference_checksums(panel_data, catalog_path)
            for entry in entries:
                grouped = defaultdict(list)
                for product in entry["products"]:
                    grouped[product["gene"]].append(product)
                run = {
                    "success": True,
                    "genes": [
                        {"gene": gene, "products": products}
                        for gene, products in sorted(grouped.items())
                    ],
                }
                blast_references.blast_all_products(
                    [run], database, entry["invocation"]["taxon"], reference_genes=reference_genes
                )
                for gene_result in run["genes"]:
                    for product in gene_result["products"]:
                        product["new_reference_match"] = stable_reference_match(
                            product.pop("reference_match")
                        )
    return representatives, database_receipts


def summarize(representatives: list[dict], focus_products: dict[str, str]) -> dict:
    products = []
    for representative in representatives:
        for product in representative["products"]:
            products.append(
                {
                    "source_result": representative["result_path"],
                    "source_result_sha256": representative["result_sha256"],
                    "invocation": representative["invocation"],
                    "gene": product["gene"],
                    "product_index": product["product_index"],
                    "length": product["length"],
                    "sha256": product["sha256"],
                    "old_reference_match": product["old_reference_match"],
                    "new_reference_match": product["new_reference_match"],
                }
            )
    focused = [
        {"focus_label": focus_products[product["sha256"]], **product}
        for product in products
        if product["sha256"] in focus_products
    ]
    focus_presence = {}
    for product_hash, label in focus_products.items():
        matches = [product for product in focused if product["sha256"] == product_hash]
        focus_presence[product_hash] = {
            "label": label,
            "versions_present": sorted({product["invocation"]["version"] for product in matches}),
            "representative_occurrences": len(matches),
        }
    return {
        "products": products,
        "focused_products": focused,
        "focus_presence": focus_presence,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    parser.add_argument("--repository-root", type=Path, default=REPOSITORY_ROOT)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if not arguments.catalog.is_file() or arguments.catalog.is_symlink():
        raise ValueError(f"Catalog is unavailable: {arguments.catalog}")
    blast_tools = {
        "blastn": executable_receipt("blastn"),
        "makeblastdb": executable_receipt("makeblastdb"),
    }
    source_paths = sorted(arguments.results.glob("*.json"))
    if len(source_paths) != 60:
        raise ValueError(f"Expected exactly 60 saved result receipts, found {len(source_paths)}")
    entries = [read_saved_result(path) for path in source_paths]
    representatives, deduplication = deduplicate(entries)
    classified, database_receipts = classify(
        representatives, arguments.repository_root, arguments.catalog
    )
    output = {
        "schema_version": 1,
        "purpose": "Post-hoc reference alignment of immutable saved products; no Sharkmer input or timing rerun.",
        "classification_thresholds": {"min_identity_pct": 90.0, "min_query_coverage_pct": 90.0},
        "catalog": {"path": str(arguments.catalog), "sha256": sha256_bytes(arguments.catalog.read_bytes())},
        "blast_tools": blast_tools,
        "source_results": [{"path": entry["result_path"], "sha256": entry["result_sha256"]} for entry in entries],
        "deduplication": deduplication,
        "reference_databases": database_receipts,
        "results": summarize(classified, FOCUS_PRODUCTS),
        "interpretation": "Reference alignment evaluates only relationship to verified external reference regions. No verified reference, partial alignment, or changed alignment does not establish biological incorrectness, read support, haplotype truth, or SNP/indel origin.",
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
