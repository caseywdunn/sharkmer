#!/usr/bin/env python3
"""Verify reference-only panel migration invariants without altering panels."""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

import yaml


REPOSITORY_ROOT = Path("/home/claude/repos/sharkmer")
AUDIT_ROOT = Path(__file__).resolve().parents[1]
PANEL_PATHS = [
    "panels/angiospermae.yaml",
    "panels/c_elegans.yaml",
    "panels/cnidaria.yaml",
    "panels/human.yaml",
    "panels/hydrozoa.yaml",
    "panels/insecta.yaml",
    "panels/teleostei.yaml",
    "panels/examples/reference.yaml",
]


def canonical(value: object) -> str:
    return json.dumps(
        value,
        default=lambda item: item.isoformat()
        if isinstance(item, (datetime.date, datetime.datetime))
        else str(item),
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def head_panel(repository_root: Path, panel_path: str) -> dict:
    completed = subprocess.run(
        ["git", "show", f"HEAD:{panel_path}"],
        cwd=repository_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return yaml.safe_load(completed.stdout)


def worktree_panel(repository_root: Path, panel_path: str) -> dict:
    return yaml.safe_load((repository_root / panel_path).read_text())


def reference_identifiers(panel_path: str, panel_data: dict) -> set[str]:
    return {
        f"{Path(panel_path).stem}:{group_index}:{sequence_index}"
        for group_index, group in enumerate(panel_data.get("references", []))
        for sequence_index, _reference in enumerate(group.get("sequences", []))
    }


def audit(repository_root: Path, audit_root: Path) -> dict:
    migration = json.loads(
        (audit_root / "migration_proposal_nonunique_final.json").read_text()
    )
    legacy = json.loads((audit_root / "legacy_references.json").read_text())
    annotation_decisions = json.loads(
        (audit_root / "annotation_decisions.json").read_text()
    )
    annotation_quarantined = {
        entry["entry_id"]
        for entry in annotation_decisions["excluded_from_gene_validation"]
    }
    verified = {
        entry["entry_id"]
        for entry in migration["verified_migrations"]
        if entry["entry_id"] not in annotation_quarantined
    }
    quarantined = {entry["entry_id"] for entry in migration["quarantine"]}
    legacy_identifiers = {entry["entry_id"] for entry in legacy["entries"]}
    panel_results = []
    head_identifiers: set[str] = set()
    worktree_identifiers: set[str] = set()
    for panel_path in PANEL_PATHS:
        head_data = head_panel(repository_root, panel_path)
        worktree_data = worktree_panel(repository_root, panel_path)
        head_primers = head_data.get("primers")
        worktree_primers = worktree_data.get("primers")
        head_validation = head_data.get("validation")
        worktree_validation = worktree_data.get("validation")
        head_identifiers.update(reference_identifiers(panel_path, head_data))
        worktree_identifiers.update(reference_identifiers(panel_path, worktree_data))
        panel_results.append(
            {
                "panel_path": panel_path,
                "primers_identical": head_primers == worktree_primers,
                "validation_identical": head_validation == worktree_validation,
                "head_primers_sha256": sha256_text(canonical(head_primers)),
                "worktree_primers_sha256": sha256_text(canonical(worktree_primers)),
                "head_validation_sha256": sha256_text(canonical(head_validation)),
                "worktree_validation_sha256": sha256_text(canonical(worktree_validation)),
                "head_reference_count": len(reference_identifiers(panel_path, head_data)),
                "worktree_reference_count": len(reference_identifiers(panel_path, worktree_data)),
            }
        )
    accounted = verified | quarantined | annotation_quarantined
    return {
        "schema_version": 1,
        "head_commit": subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repository_root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip(),
        "panels": panel_results,
        "panel_fields_identical": all(
            row["primers_identical"] and row["validation_identical"]
            for row in panel_results
        ),
        "legacy_reference_entries": len(legacy_identifiers),
        "head_reference_entries": len(head_identifiers),
        "worktree_reference_entries": len(worktree_identifiers),
        "verified_migrations": len(verified),
        "quarantined_migrations": len(quarantined),
        "annotation_quarantined_migrations": len(annotation_quarantined),
        "annotation_quarantined_not_previously_verified": sorted(
            annotation_quarantined - {entry["entry_id"] for entry in migration["verified_migrations"]}
        ),
        "independent_new_example_references": 1
        if annotation_decisions.get("new_example_reference")
        else 0,
        "overlapping_migration_dispositions": sorted(verified & quarantined),
        "legacy_entries_unaccounted": sorted(legacy_identifiers - accounted),
        "migration_entries_not_legacy": sorted(accounted - legacy_identifiers),
        "head_entries_not_legacy": sorted(head_identifiers - legacy_identifiers),
        "legacy_entries_not_head": sorted(legacy_identifiers - head_identifiers),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository-root", type=Path, default=REPOSITORY_ROOT)
    parser.add_argument("--audit-root", type=Path, default=AUDIT_ROOT)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    result = audit(arguments.repository_root, arguments.audit_root)
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    valid = (
        result["panel_fields_identical"]
        and not result["overlapping_migration_dispositions"]
        and not result["legacy_entries_unaccounted"]
        and not result["migration_entries_not_legacy"]
        and not result["head_entries_not_legacy"]
        and not result["legacy_entries_not_head"]
        and not result["annotation_quarantined_not_previously_verified"]
    )
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
