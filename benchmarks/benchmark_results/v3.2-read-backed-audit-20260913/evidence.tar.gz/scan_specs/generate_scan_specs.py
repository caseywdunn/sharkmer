#!/usr/bin/env python3
"""Adapt frozen candidate and input receipts into scanner-only specifications."""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from pathlib import Path


ROOT = Path('/tmp/sharkmer-read-audit-20260913')
CANDIDATES_PATH = ROOT / 'candidates' / 'candidate_manifest.json'
EVENT_RECEIPT_PATH = ROOT / 'candidates' / 'candidate_manifest.receipt.json'
INPUTS_PATH = ROOT / 'inputs' / 'manifest.json'
OUTPUT_ROOT = ROOT / 'scan_specs'
PROTOCOL_V2_PATH = ROOT / 'protocol' / 'protocol-v2.md'
SCANNER_PATH = Path('/home/claude/repos/sharkmer/scripts/audit_read_bridges.py')
EXPECTED_CANDIDATE_SHA256 = 'a8df6371680394dfc37b8aec62cd2aed0e2968306f36420a6858221046b59b4e'
EXPECTED_EVENT_RECEIPT_SHA256 = '0833a22948ba11380a395e43143d729d24ebdee35eba11438a383f6dce3166c6'
EXPECTED_PROTOCOL_V2_SHA256 = '5affa863c9d80be579436e26fcee628ea23dfc987adc2288f6a067b376c9396b'
EXPECTED_SCANNER_SHA256 = 'f6f1371bb4884c2a8e9475e5c56b99a30b8c429267a294cdeba19905db411983'
FLANK_BASES = 21
MARGINAL_INTERVAL_BASES = 19


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def candidate_id(accession: str, gene: str, sequence_hash: str) -> str:
    return f'{accession}_{sequence_hash[:16]}'


def valid_bases(sequence: str) -> bool:
    return bool(sequence) and set(sequence) <= {'A', 'C', 'G', 'T'}


def preflight(sequence: str, start: int, end: int) -> dict:
    left_start = max(0, start - FLANK_BASES)
    right_end = min(len(sequence), end + FLANK_BASES)
    left = sequence[left_start:start]
    questioned = sequence[start:end]
    right = sequence[end:right_end]
    return {
        'flank_bases_each_side': FLANK_BASES,
        'left_flank_span': [left_start, start],
        'right_flank_span': [end, right_end],
        'has_full_left_flank': len(left) == FLANK_BASES,
        'has_full_right_flank': len(right) == FLANK_BASES,
        'literal_acgt_window': valid_bases(left + questioned + right),
        'status': (
            'eligible_for_scanner_window'
            if len(left) == FLANK_BASES and len(right) == FLANK_BASES and valid_bases(left + questioned + right)
            else 'invalid_or_missing_required_flanks'
        ),
    }


def marginal_starts(sequence_length: int) -> list[int]:
    last_start = sequence_length - FLANK_BASES - MARGINAL_INTERVAL_BASES
    if last_start < FLANK_BASES:
        return []
    starts = list(range(FLANK_BASES, last_start + 1, MARGINAL_INTERVAL_BASES + 1))
    if starts[-1] != last_start:
        starts.append(last_start)
    return starts


def add_candidate(candidates: dict, accession: str, gene: str, product: dict, role: str) -> str:
    sequence = product['sequence']
    sequence_hash = product['sha256']
    if digest(sequence.encode()) != sequence_hash:
        raise ValueError(f'{accession}/{gene}: candidate sequence hash differs')
    identifier = candidate_id(accession, gene, sequence_hash)
    existing = candidates.get(identifier)
    source = {'gene': gene, 'role': role, 'length': len(sequence), 'sequence_sha256': sequence_hash}
    if existing is None:
        candidates[identifier] = {
            'id': identifier,
            'sequence': sequence,
            'sequence_sha256': sequence_hash,
            'source_candidates': [source],
        }
    elif existing['sequence'] != sequence or existing['sequence_sha256'] != sequence_hash:
        raise ValueError(f'{identifier}: identifier collision')
    else:
        existing['source_candidates'].append(source)
    return identifier


def add_event(events: list, identifier: str, candidate: dict, start: int, end: int, role: str, source: dict, comparison_group: str | None = None) -> None:
    if not isinstance(start, int) or not isinstance(end, int) or start < 0 or end <= start or end > len(candidate['sequence']):
        raise ValueError(f'{identifier}: invalid frozen interval [{start}, {end})')
    event = {
        'id': identifier,
        'candidate_id': candidate['id'],
        'start': start,
        'end': end,
        'role': role,
        'preflight': preflight(candidate['sequence'], start, end),
        'source': source,
    }
    if comparison_group is not None:
        event['comparison_group'] = comparison_group
    events.append(event)


def frozen_intervals(product: dict) -> list[tuple[int, int, str, dict]]:
    exact = product.get('exact_indel_placements_against_retained_same_gene')
    if isinstance(exact, dict):
        union = exact['longer_template_placement_union_span']
        intervals = [(union[0], union[1], 'primary_complete_placement_union', {'kind': 'exact_indel_placement_union', 'equivalent_placements': exact['equivalent_deletion_spans']})]
        difference = product.get('difference_from_retained_same_gene', {}).get('lost_span')
        if difference and difference != union:
            intervals.append((difference[0], difference[1], 'supplementary_marginal_difference', {'kind': 'maximal_common_flank_difference'}))
        return intervals
    suspect = product.get('suspect_region', {})
    intervals = suspect.get('intervals', []) if isinstance(suspect, dict) else []
    result = []
    for interval_index, interval in enumerate(intervals):
        if isinstance(interval, list):
            result.append((interval[0], interval[1], 'primary_frozen_suspect_interval', {'kind': 'frozen_suspect_interval', 'interval_index': interval_index}))
        elif isinstance(interval, dict):
            span = interval['repeat_span']
            result.append((span[0], span[1], 'primary_frozen_repeat_interval', {
                'kind': 'frozen_repeat_interval',
                'interval_index': interval_index,
                'local_link_is_full_interval_bridge': interval['local_link_is_full_interval_bridge'],
                'minimum_local_branch_link_bases': interval['minimum_local_branch_link_bases'],
                'repeated_edge_window_count': interval['repeated_edge_window_count'],
                'repeated_node_window_count': interval['repeated_node_window_count'],
            }))
        else:
            raise ValueError('unrecognized frozen suspect interval')
    return result


def retained_family_interval(case: dict, retained: dict) -> tuple[int, int] | None:
    family = case.get('alternative_family_interval')
    if not isinstance(family, dict):
        return None
    span = family['member_variable_spans'].get(retained['sha256'])
    return tuple(span) if span else None


def build_specs(candidate_manifest: dict, input_manifest: dict) -> tuple[dict[str, dict], dict]:
    inputs = {row['accession']: row for row in input_manifest['rows']}
    per_sample = defaultdict(lambda: {'candidates': {}, 'events': [], 'identity': None, 'not_separately_assayed_declarations': []})
    for case in candidate_manifest['cases']:
        accession = case['accession']
        if accession not in inputs:
            raise ValueError(f'{accession}: candidate case lacks frozen input receipt')
        sample = per_sample[accession]
        identity = {'accession': accession, 'panel': case['panel'], 'taxon': case['taxon']}
        if sample['identity'] is None:
            sample['identity'] = identity
        elif sample['identity'] != identity:
            raise ValueError(f'{accession}: inconsistent candidate identity')
        comparison_group = f'{accession}_{case["gene"]}_frozen_alternatives'
        for lost in case['lost_products']:
            lost_id = add_candidate(sample['candidates'], accession, case['gene'], lost, 'withheld_lost_candidate')
            candidate = sample['candidates'][lost_id]
            for interval_index, (start, end, role, source) in enumerate(frozen_intervals(lost)):
                add_event(sample['events'], f'{lost_id}_{role}_{interval_index}', candidate, start, end, role, source, comparison_group)
        for retained in case['retained_same_gene_products']:
            retained_id = add_candidate(sample['candidates'], accession, case['gene'], retained, 'same_gene_retained_alternative')
            interval = retained_family_interval(case, retained)
            if interval and interval[0] < interval[1]:
                candidate = sample['candidates'][retained_id]
                add_event(sample['events'], f'{retained_id}_supplementary_retained_family_interval', candidate, interval[0], interval[1], 'supplementary_retained_family_interval', {'kind': 'frozen_alternative_family_interval'}, comparison_group)
            elif interval:
                sample['not_separately_assayed_declarations'].append({
                    'candidate_id': retained_id,
                    'role': 'supplementary_retained_family_interval',
                    'span': list(interval),
                    'reason': 'zero_length_deletion_junction_is_covered_by_the_retained_placement_union_event',
                })
            exact = next((lost.get('exact_indel_placements_against_retained_same_gene') for lost in case['lost_products'] if isinstance(lost.get('exact_indel_placements_against_retained_same_gene'), dict)), None)
            if exact:
                start, end = exact['shorter_template_corresponding_span']
                candidate = sample['candidates'][retained_id]
                add_event(sample['events'], f'{retained_id}_supplementary_retained_corresponding_interval', candidate, start, end, 'supplementary_retained_corresponding_interval', {'kind': 'exact_indel_shorter_template_corresponding_span'}, comparison_group)
    for control in candidate_manifest['retained_controls']:
        accession = control['accession']
        if accession not in per_sample:
            raise ValueError(f'{accession}: retained control lacks a candidate case')
        add_candidate(per_sample[accession]['candidates'], accession, control['gene'], control, control['role'])
    specs = {}
    summary_rows = []
    for accession, sample in sorted(per_sample.items()):
        input_row = inputs[accession]
        expected_prefix = input_row['benchmark_subset']
        expected = {key: expected_prefix[key] for key in ('records', 'bases', 'size_bytes', 'sha256')}
        for candidate in sorted(sample['candidates'].values(), key=lambda item: item['id']):
            for start in marginal_starts(len(candidate['sequence'])):
                add_event(
                    sample['events'],
                    f"{candidate['id']}_marginal_diagnostic_{start}",
                    candidate,
                    start,
                    start + MARGINAL_INTERVAL_BASES,
                    'marginal_diagnostic',
                    {
                        'kind': 'protocol_v2_uniform_marginal_diagnostic',
                        'scope': 'local occurrence control only; not a structural bridge or gate-rescue event',
                    },
                    f"{candidate['id']}_marginal_diagnostic_group",
                )
        spec = {
            'schema_version': 1,
            'purpose': 'Frozen scanner candidates and intervals only; no read outcomes or haplotype conclusion.',
            'source_candidate_manifest_sha256': EXPECTED_CANDIDATE_SHA256,
            'source_event_receipt_sha256': EXPECTED_EVENT_RECEIPT_SHA256,
            'source_input_manifest_sha256': digest(INPUTS_PATH.read_bytes()),
            'source_protocol_v2_sha256': EXPECTED_PROTOCOL_V2_SHA256,
            'source_scanner_sha256': EXPECTED_SCANNER_SHA256,
            'candidate_identity': sample['identity'],
            'candidates': sorted(sample['candidates'].values(), key=lambda candidate: candidate['id']),
            'events': sorted(sample['events'], key=lambda event: event['id']),
            'not_separately_assayed_declarations': sample['not_separately_assayed_declarations'],
        }
        specs[accession] = {'manifest': spec, 'expected_prefix': expected, 'input_path': input_row['staged_input']['path']}
        summary_rows.append({
            'accession': accession,
            'candidates': len(spec['candidates']),
            'events': len(spec['events']),
            'structural_events': sum(event['role'] != 'marginal_diagnostic' for event in spec['events']),
            'marginal_diagnostic_events': sum(event['role'] == 'marginal_diagnostic' for event in spec['events']),
            'eligible_events': sum(event['preflight']['status'] == 'eligible_for_scanner_window' for event in spec['events']),
            'invalid_or_missing_flank_events': sum(event['preflight']['status'] != 'eligible_for_scanner_window' for event in spec['events']),
            'not_separately_assayed_declarations': len(spec['not_separately_assayed_declarations']),
            'expected_prefix': expected,
        })
    return specs, {'rows': summary_rows}


def validate_spec(spec: dict, expected_prefix: dict) -> None:
    if spec.get('schema_version') != 1:
        raise ValueError('scanner spec schema version differs')
    if set(expected_prefix) != {'records', 'bases', 'size_bytes', 'sha256'}:
        raise ValueError('expected prefix has unexpected fields')
    candidate_map = {candidate['id']: candidate for candidate in spec['candidates']}
    if len(candidate_map) != len(spec['candidates']):
        raise ValueError('scanner spec duplicates candidate identifiers')
    for candidate in candidate_map.values():
        if digest(candidate['sequence'].encode()) != candidate['sequence_sha256']:
            raise ValueError(f"{candidate['id']}: sequence hash differs")
    event_ids = set()
    for event in spec['events']:
        if event['id'] in event_ids:
            raise ValueError(f"{event['id']}: duplicate event identifier")
        event_ids.add(event['id'])
        candidate = candidate_map.get(event['candidate_id'])
        if candidate is None:
            raise ValueError(f"{event['id']}: candidate is missing")
        if not 0 <= event['start'] < event['end'] <= len(candidate['sequence']):
            raise ValueError(f"{event['id']}: coordinates are invalid")
        if event['preflight'] != preflight(candidate['sequence'], event['start'], event['end']):
            raise ValueError(f"{event['id']}: preflight differs")


def main() -> int:
    candidate_raw = CANDIDATES_PATH.read_bytes()
    if digest(candidate_raw) != EXPECTED_CANDIDATE_SHA256:
        raise ValueError('candidate manifest hash differs from frozen receipt')
    if digest(PROTOCOL_V2_PATH.read_bytes()) != EXPECTED_PROTOCOL_V2_SHA256:
        raise ValueError('protocol v2 hash differs from frozen receipt')
    receipt_raw = EVENT_RECEIPT_PATH.read_bytes()
    if digest(receipt_raw) != EXPECTED_EVENT_RECEIPT_SHA256:
        raise ValueError('candidate event receipt hash differs from frozen receipt')
    receipt = json.loads(receipt_raw)
    if receipt.get('manifest_sha256') != EXPECTED_CANDIDATE_SHA256:
        raise ValueError('candidate event receipt does not bind current candidate manifest')
    if digest(SCANNER_PATH.read_bytes()) != EXPECTED_SCANNER_SHA256:
        raise ValueError('scanner hash differs from frozen receipt')
    candidate_manifest = json.loads(candidate_raw)
    input_manifest = json.loads(INPUTS_PATH.read_text())
    specs, summary = build_specs(candidate_manifest, input_manifest)
    command_lines = []
    for accession, values in specs.items():
        manifest_path = OUTPUT_ROOT / f'{accession}.scanner_manifest.json'
        prefix_path = OUTPUT_ROOT / f'{accession}.expected_prefix.json'
        validate_spec(values['manifest'], values['expected_prefix'])
        manifest_path.write_text(json.dumps(values['manifest'], indent=2, sort_keys=True) + '\n')
        prefix_path.write_text(json.dumps(values['expected_prefix'], indent=2, sort_keys=True) + '\n')
        for substitutions, label in ((0, 'exact'), (1, 'one_substitution')):
            command_lines.append(f'python3 {SCANNER_PATH} --fastq {values["input_path"]} --events {manifest_path} --expected-prefix {prefix_path} --max-substitutions {substitutions} --output /tmp/sharkmer-read-audit-20260913/execution/{accession}.{label}.json')
    output = {
        'schema_version': 1,
        'source_candidate_manifest_sha256': EXPECTED_CANDIDATE_SHA256,
        'source_event_receipt_sha256': EXPECTED_EVENT_RECEIPT_SHA256,
        'source_input_manifest_sha256': digest(INPUTS_PATH.read_bytes()),
        'source_protocol_v2_sha256': EXPECTED_PROTOCOL_V2_SHA256,
        'source_scanner_sha256': EXPECTED_SCANNER_SHA256,
        'scanner_execution_status': 'not_run_pending_independent_scanner_review',
        **summary,
    }
    (OUTPUT_ROOT / 'summary.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    (OUTPUT_ROOT / 'COMMANDS_NOT_RUN.txt').write_text('\n'.join(command_lines) + '\n')
    print(json.dumps({'specifications': len(specs), **summary}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
