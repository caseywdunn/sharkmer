#!/usr/bin/env python3
"""Inventory immutable FASTQ inputs used by the three affected benchmark cells."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path


EXECUTION_ROOT = Path('/tmp/sharkmer-high-copy-20260911/final-execution')
RESULTS_ROOT = EXECUTION_ROOT / 'results'
INPUT_RECEIPT = EXECUTION_ROOT / 'receipts' / 'inputs.json'
OUTPUT = Path('/tmp/sharkmer-read-audit-20260913/inputs/manifest.json')
ACCESSIONS = ('SRR27962769', 'SRR31887760', 'SRR1057608')


def sha256_path(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open('rb') as file_handle:
        while block := file_handle.read(1024 * 1024):
            hasher.update(block)
    return hasher.hexdigest()


def quality_encoding(minimum: int, maximum: int) -> str:
    if 33 <= minimum and maximum <= 74:
        return 'phred_plus_33_compatible'
    if 64 <= minimum and maximum <= 104:
        return 'phred_plus_64_compatible'
    return 'undetermined_from_ascii_range'


def mate_label(header: bytes) -> str:
    token = header.decode('ascii', errors='replace').strip()
    if token.endswith('/1') or ' 1:' in token:
        return 'mate_1_label'
    if token.endswith('/2') or ' 2:' in token:
        return 'mate_2_label'
    return 'unlabeled'


def inspect_prefix(path: Path, expected_records: int) -> dict:
    prefix_hasher = hashlib.sha256()
    base_count = 0
    quality_minimum = 127
    quality_maximum = 0
    mate_labels = Counter()
    first_header = None
    last_header = None
    with path.open('rb') as file_handle:
        for record_number in range(expected_records):
            header = file_handle.readline()
            sequence = file_handle.readline()
            separator = file_handle.readline()
            quality = file_handle.readline()
            if not all((header, sequence, separator, quality)):
                raise ValueError(f'{path}: EOF before expected record {record_number + 1}')
            if not header.startswith(b'@') or not separator.startswith(b'+'):
                raise ValueError(f'{path}: malformed four-line FASTQ at record {record_number + 1}')
            sequence_bases = sequence.rstrip(b'\r\n')
            quality_values = quality.rstrip(b'\r\n')
            if len(sequence_bases) != len(quality_values):
                raise ValueError(f'{path}: sequence/quality length mismatch at record {record_number + 1}')
            prefix_hasher.update(header)
            prefix_hasher.update(sequence)
            prefix_hasher.update(separator)
            prefix_hasher.update(quality)
            base_count += len(sequence_bases)
            if quality_values:
                quality_minimum = min(quality_minimum, min(quality_values))
                quality_maximum = max(quality_maximum, max(quality_values))
            mate_labels[mate_label(header)] += 1
            if first_header is None:
                first_header = header.decode('ascii', errors='replace').rstrip('\r\n')
            last_header = header.decode('ascii', errors='replace').rstrip('\r\n')
        size_bytes = file_handle.tell()
    return {
        'records': expected_records,
        'bases': base_count,
        'size_bytes': size_bytes,
        'sha256': prefix_hasher.hexdigest(),
        'first_header': first_header,
        'last_header': last_header,
        'quality_ascii_min': quality_minimum,
        'quality_ascii_max': quality_maximum,
        'quality_encoding_inference': quality_encoding(quality_minimum, quality_maximum),
        'mate_label_counts': dict(sorted(mate_labels.items())),
    }


def result_receipts(accession: str) -> list[dict]:
    matches = []
    for path in sorted(RESULTS_ROOT.glob(f'*_{accession}_*.json')):
        raw = path.read_bytes()
        result = json.loads(raw)
        signature = result.get('signature', {})
        invocation = signature.get('invocation', {})
        if invocation.get('input') != accession:
            raise ValueError(f'{path}: accession does not match signature')
        if result.get('status') != 'complete' or result.get('timing_status') not in {'complete', 'timed_complete'}:
            raise ValueError(f'{path}: result is not a complete timed receipt')
        matches.append({
            'path': str(path),
            'sha256': hashlib.sha256(raw).hexdigest(),
            'signature': signature,
            'binary_command': result.get('binary_command'),
            'full_input_verification': result.get('full_input_verification'),
            'post_run_input_prefix_sha256': result.get('post_run_input_prefix_sha256'),
        })
    if len(matches) != 6:
        raise ValueError(f'{accession}: expected six baseline/candidate triplicate receipts, found {len(matches)}')
    return matches


def consensus(receipts: list[dict], accession: str) -> dict:
    signatures = [receipt['signature'] for receipt in receipts]
    signatures_without_invocation = [{key: value for key, value in signature.items() if key != 'invocation'} for signature in signatures]
    if len({json.dumps(value, sort_keys=True) for value in signatures_without_invocation}) != 2:
        raise ValueError(f'{accession}: non-invocation signature changes within a role')
    baseline = [receipt for receipt in receipts if receipt['signature']['invocation']['version'] == 'baseline']
    candidate = [receipt for receipt in receipts if receipt['signature']['invocation']['version'] == 'candidate']
    if len(baseline) != 3 or len(candidate) != 3:
        raise ValueError(f'{accession}: expected baseline/candidate triplicates')
    baseline_signature = baseline[0]['signature']
    candidate_signature = candidate[0]['signature']
    for role, group in (('baseline', baseline), ('candidate', candidate)):
        role_signatures = [{key: value for key, value in receipt['signature'].items() if key != 'invocation'} for receipt in group]
        if len({json.dumps(value, sort_keys=True) for value in role_signatures}) != 1:
            raise ValueError(f'{accession}: {role} signature is unstable across triplicates')
    if baseline_signature['input_sha256'] != candidate_signature['input_sha256'] or baseline_signature['input_subset'] != candidate_signature['input_subset']:
        raise ValueError(f'{accession}: baseline/candidate input identity differs')
    return {
        'input_sha256': baseline_signature['input_sha256'],
        'input_subset': baseline_signature['input_subset'],
        'settings': baseline_signature['settings'],
        'panel_sha256': baseline_signature['panel_sha256'],
        'baseline_source_commit': baseline_signature['source_commit'],
        'candidate_source_commit': candidate_signature['source_commit'],
        'sample': baseline_signature['invocation']['taxon'],
        'panel': baseline_signature['invocation']['panel'],
        'binary_roles': {
            'baseline': baseline_signature['binary_sha256'],
            'candidate': candidate_signature['binary_sha256'],
        },
    }


def consumed_source_segments(source_consumption: list[dict], records: int) -> list[dict]:
    remaining = records
    segments = []
    for source in source_consumption:
        available = source.get('records')
        url = source.get('url')
        if not isinstance(available, int) or available < 0 or not isinstance(url, str):
            raise ValueError('staged source consumption lacks URL or record count')
        used = min(remaining, available)
        if used:
            source_name = Path(url).name
            segments.append({
                'url': url,
                'source_file_name': source_name,
                'source_record_ordinals_one_based': [1, used],
                'records': used,
                'mate_designation_from_source_name': (
                    'mate_1' if source_name.endswith('_1.fastq.gz') else
                    'mate_2' if source_name.endswith('_2.fastq.gz') else 'unpaired_or_unlabeled'
                ),
            })
            remaining -= used
        if not remaining:
            break
    if remaining:
        raise ValueError('staged source receipt does not account for consumed record prefix')
    return segments


def main() -> int:
    input_receipt = json.loads(INPUT_RECEIPT.read_text())
    input_rows = {row['id']: row for row in input_receipt['inputs']}
    rows = []
    for accession in ACCESSIONS:
        receipts = result_receipts(accession)
        agreed = consensus(receipts, accession)
        staged = input_rows.get(accession)
        if staged is None:
            raise ValueError(f'{accession}: unavailable in staged input receipt')
        input_path = Path(staged['path'])
        if not input_path.is_file() or input_path.is_symlink():
            raise ValueError(f'{accession}: staged input is unavailable or symlinked')
        subset = agreed['input_subset']
        prefix = inspect_prefix(input_path, subset['actual_records'])
        full_hash = sha256_path(input_path)
        if full_hash != staged['sha256'] or full_hash != agreed['input_sha256']:
            raise ValueError(f'{accession}: full staged input hash differs from benchmark receipt')
        if input_path.stat().st_size != staged['size_bytes']:
            raise ValueError(f'{accession}: full staged input size differs from receipt')
        for key in ('records', 'bases', 'size_bytes', 'sha256'):
            expected_key = {'records': 'actual_records', 'bases': 'actual_bases'}.get(key, key)
            if prefix[key] != subset[expected_key]:
                raise ValueError(f'{accession}: prefix {key} differs from benchmark receipt')
        if any(receipt['post_run_input_prefix_sha256'] != prefix['sha256'] for receipt in receipts):
            raise ValueError(f'{accession}: post-run prefix receipt differs')
        source_segments = consumed_source_segments(staged['source_consumption'], subset['actual_records'])
        rows.append({
            'accession': accession,
            'sample': agreed['sample'],
            'panel': agreed['panel'],
            'staged_input': {
                'path': str(input_path),
                'size_bytes': input_path.stat().st_size,
                'sha256': full_hash,
                'total_records': staged['total_records'],
                'total_bases': staged['total_bases'],
                'source_urls_ordered': staged['source_urls_ordered'],
                'source_consumption': staged['source_consumption'],
                'cache_receipt': 'none; this staged input was acquired as an HTTPS gzip prefix, as recorded in source_consumption',
            },
            'benchmark_subset': prefix,
            'consumed_source_segments': source_segments,
            'benchmark_signature': agreed,
            'result_receipts': receipts,
        })
    output = {
        'schema_version': 1,
        'purpose': 'Input identity and provenance inventory only; no read-backed outcome interpretation.',
        'source_execution': str(EXECUTION_ROOT),
        'source_inputs_receipt_sha256': hashlib.sha256(INPUT_RECEIPT.read_bytes()).hexdigest(),
        'record_semantics': 'Each staged file is a sequential uncompressed four-line FASTQ stream. The frozen benchmark used the first 1,000,000 FASTQ records per accession with paired=false; records are not inferred to be fragment pairs and are not counted twice.',
        'rows': rows,
    }
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'valid': True, 'accessions': len(rows), 'output': str(OUTPUT)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
