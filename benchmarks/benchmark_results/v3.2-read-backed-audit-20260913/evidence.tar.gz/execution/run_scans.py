#!/usr/bin/env python3
"""Run frozen read-bridge scans with a maximum of two concurrent processes."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import subprocess
import time
from pathlib import Path


ROOT = Path('/tmp/sharkmer-read-audit-20260913')
SPECS = ROOT / 'scan_specs'
EXECUTION = ROOT / 'execution'
SCANNER = Path('/home/claude/repos/sharkmer/scripts/audit_read_bridges.py')
TESTS = Path('/home/claude/repos/sharkmer/tests/test_read_bridges.py')
INPUT_MANIFEST = ROOT / 'inputs' / 'manifest.json'
CANDIDATES = ROOT / 'candidates' / 'candidate_manifest.json'
CANDIDATE_RECEIPT = ROOT / 'candidates' / 'candidate_manifest.receipt.json'
PROTOCOL = ROOT / 'protocol' / 'protocol-v2.md'
RUNNER = Path(__file__)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_receipts() -> dict[str, str]:
    paths = [RUNNER, SCANNER, TESTS, INPUT_MANIFEST, CANDIDATES, CANDIDATE_RECEIPT, PROTOCOL, SPECS / 'generate_scan_specs.py', SPECS / 'summary.json', SPECS / 'COMMANDS_NOT_RUN.txt']
    paths.extend(sorted(SPECS.glob('SRR*.scanner_manifest.json')))
    paths.extend(sorted(SPECS.glob('SRR*.expected_prefix.json')))
    return {str(path): digest(path) for path in paths}


def scan_jobs() -> list[dict]:
    summary = json.loads((SPECS / 'summary.json').read_text())
    jobs = []
    for row in summary['rows']:
        accession = row['accession']
        events = SPECS / f'{accession}.scanner_manifest.json'
        prefix = SPECS / f'{accession}.expected_prefix.json'
        input_path = Path('/tmp/sharkmer-release-comparison/inputs') / f'{accession}.fastq'
        for substitutions, label in ((0, 'exact'), (1, 'one_substitution')):
            jobs.append({
                'accession': accession,
                'label': label,
                'substitutions': substitutions,
                'events': events,
                'prefix': prefix,
                'input': input_path,
                'output': EXECUTION / f'{accession}.{label}.json',
            })
    return jobs


def run_job(job: dict) -> dict:
    output = job['output']
    command = [
        'python3', str(SCANNER), '--fastq', str(job['input']), '--events', str(job['events']),
        '--expected-prefix', str(job['prefix']), '--max-substitutions', str(job['substitutions']), '--output', str(output),
    ]
    if output.exists():
        if output.is_symlink() or not output.is_file():
            raise ValueError(f'Existing output is not a regular file: {output}')
        result = json.loads(output.read_text())
        return {
            'accession': job['accession'], 'label': job['label'], 'command': command,
            'returncode': 0, 'wall_time_s': None, 'reused_completed_output': True,
            'output': str(output), 'output_sha256': digest(output),
            'provenance': result.get('provenance'), 'event_count': len(result.get('events', [])),
            'matching_ledger_records': len(result.get('read_evidence', [])),
        }
    if output.is_symlink():
        raise ValueError(f'Refusing symlink output {output}')
    started = time.time()
    completed = subprocess.run(command, capture_output=True, text=True)
    finished = time.time()
    stem = f"{job['accession']}.{job['label']}"
    (EXECUTION / f'{stem}.stdout.txt').write_text(completed.stdout)
    (EXECUTION / f'{stem}.stderr.txt').write_text(completed.stderr)
    record = {
        'accession': job['accession'], 'label': job['label'], 'command': command,
        'returncode': completed.returncode, 'wall_time_s': finished - started,
        'stdout_sha256': hashlib.sha256(completed.stdout.encode()).hexdigest(),
        'stderr_sha256': hashlib.sha256(completed.stderr.encode()).hexdigest(),
        'output': str(output),
    }
    if completed.returncode == 0 and output.is_file() and not output.is_symlink():
        record['output_sha256'] = digest(output)
        result = json.loads(output.read_text())
        record['provenance'] = result.get('provenance')
        record['event_count'] = len(result.get('events', []))
        record['matching_ledger_records'] = len(result.get('read_evidence', []))
    return record


def main() -> int:
    if (EXECUTION / 'execution.json').exists():
        raise ValueError('Execution receipt already exists; refusing a rerun')
    EXECUTION.mkdir(parents=True, exist_ok=True)
    before = source_receipts()
    freeze_path = EXECUTION / 'source_freeze.json'
    if freeze_path.exists():
        freeze_path = EXECUTION / 'source_freeze_resume.json'
    if freeze_path.exists() or freeze_path.is_symlink():
        raise ValueError(f'Refusing to overwrite {freeze_path}')
    freeze_path.write_text(json.dumps({'schema_version': 1, 'sources': before}, indent=2, sort_keys=True) + '\n')
    jobs = scan_jobs()
    if len(jobs) != 6:
        raise ValueError(f'Expected six scan jobs, found {len(jobs)}')
    records = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(run_job, job) for job in jobs]
        for future in futures:
            records.append(future.result())
    after = source_receipts()
    source_changed = before != after
    output = {
        'schema_version': 1,
        'concurrency_limit': 2,
        'source_frozen_before': before,
        'source_rechecked_after': after,
        'source_changed_during_execution': source_changed,
        'jobs': sorted(records, key=lambda record: (record['accession'], record['label'])),
    }
    (EXECUTION / 'execution.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    if source_changed or any(record['returncode'] != 0 for record in records):
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
