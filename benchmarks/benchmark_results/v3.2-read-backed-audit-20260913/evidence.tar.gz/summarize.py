import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def covered_bases(intervals):
    total = 0
    previous_end = 0
    for start, end in sorted(intervals):
        total += max(0, end - max(start, previous_end))
        previous_end = max(previous_end, end)
    return total


def main():
    execution_path = ROOT / "execution_replication_outputs/execution.json"
    execution = json.loads(execution_path.read_text())
    if execution["source_changed_during_execution"] or len(execution["jobs"]) != 6:
        raise ValueError("Incomplete or changed-source audit execution")
    candidates = []
    structural = []
    sources = []
    for job in execution["jobs"]:
        if job["returncode"] != 0 or not job["validated_output"] or job.get("reused_completed_output"):
            raise ValueError("Failed or unverified reused scan")
        report_path = Path(job["output_path"])
        if digest(report_path) != job["output_sha256"]:
            raise ValueError("Scanner output checksum differs")
        report = json.loads(report_path.read_text())
        spec_path = ROOT / "scan_specs" / f"{job['accession']}.scanner_manifest.json"
        prefix_path = ROOT / "scan_specs" / f"{job['accession']}.expected_prefix.json"
        spec = json.loads(spec_path.read_text())
        expected = json.loads(prefix_path.read_text())
        if report["provenance"]["event_manifest_sha256"] != digest(spec_path) or report["provenance"]["expected_prefix_manifest_sha256"] != digest(prefix_path):
            raise ValueError("Scanner manifest binding differs")
        if report["input_subset"] != expected or report["provenance"]["scanner_sha256"] != spec["source_scanner_sha256"]:
            raise ValueError("Scanner/input identity differs")
        if len(report["events"]) != len(spec["events"]):
            raise ValueError("Event inventory differs")
        if report["max_substitutions"] != job["max_substitutions"]:
            raise ValueError("Assay sensitivity differs")
        receipt_path = report_path.with_suffix(".receipt.json")
        if json.loads(receipt_path.read_text()) != job:
            raise ValueError("Per-job receipt differs")
        sources.append({"accession": job["accession"], "mode": job["label"], "path": str(report_path), "sha256": digest(report_path), "records": report["input_subset"]["records"], "matching_records": len(report["read_evidence"]), "wall_time_s": job["wall_time_seconds"]})
        for candidate in spec["candidates"]:
            events = [event for event in report["events"] if event["candidate_id"] == candidate["id"]]
            diagnostic = [event for event in events if event["role"] == "marginal_diagnostic"]
            intervals = [(event["window_start"], event["window_end"]) for event in diagnostic if event["records"]]
            row = {
                "accession": job["accession"], "mode": job["label"], "candidate_id": candidate["id"],
                "gene": candidate["source_candidates"][0]["gene"], "length": len(candidate["sequence"]),
                "role": candidate["source_candidates"][0]["role"], "sequence_sha256": candidate["sequence_sha256"],
                "diagnostic_windows": len(diagnostic), "observed_diagnostic_windows": sum(event["records"] > 0 for event in diagnostic),
                "locally_observed_bases": covered_bases(intervals),
                "corroborated_unique_diagnostic_windows": sum(event["local_bridge_status"] == "corroborated_local_bridge" for event in diagnostic),
                "haplotype_truth": "not_established", "gate_relaxation": "not_authorized_by_marginal_diagnostics",
            }
            candidates.append(row)
            for event in events:
                if event["role"] == "marginal_diagnostic":
                    continue
                structural.append({**{key: row[key] for key in ("accession", "mode", "candidate_id", "gene", "length")}, **{key: event[key] for key in ("id", "role", "start", "end", "window_start", "window_end", "callability", "longer_than_every_read", "records", "unique_records", "ambiguous_records", "distinct_ids", "distinct_footprints", "corroboration_witness", "local_bridge_status")}})
    output = {"schema_version": 1, "execution_receipt_sha256": digest(execution_path), "sources": sources, "structural_events": structural, "marginal_candidate_summaries": candidates, "limits": "Observed overlapping local windows do not establish their joint full-length haplotype; missing or uncallable bridges do not establish incorrectness."}
    with (ROOT / "summary.json").open("x") as destination:
        destination.write(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"structural_events": structural, "marginal_candidate_summaries": candidates}, indent=2))


if __name__ == "__main__":
    main()
