import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path


ROOT = Path("/home/claude/repos/sharkmer")
AUDIT = Path("/tmp/sharkmer-read-audit-20260913")
DESTINATION = ROOT / "benchmarks/benchmark_results/v3.2-read-backed-audit-20260913"


def digest(contents):
    return hashlib.sha256(contents).hexdigest()


def main():
    execution = json.loads((AUDIT / "execution_replication_outputs/execution.json").read_text())
    if execution["source_changed_during_execution"] or len(execution["jobs"]) != 6:
        raise ValueError("Replication source freeze or job inventory failed")
    for job in execution["jobs"]:
        if job["returncode"] != 0 or not job["validated_output"] or digest(Path(job["output_path"]).read_bytes()) != job["output_sha256"]:
            raise ValueError("Invalid replication output")
    members = {}
    for path in sorted(AUDIT.rglob("*")):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.is_symlink():
            raise ValueError(f"Unexpected evidence symlink: {path}")
        if path.is_file():
            members[str(path.relative_to(AUDIT))] = path.read_bytes()
    for relative in (
        "scripts/audit_read_bridges.py", "tests/test_read_bridges.py",
        "dev_docs/READ_BACKED_AUDIT_PROTOCOL.md", "dev_docs/READ_BACKED_AUDIT_RESULTS.md",
        "dev_docs/PLAN.md", "dev_docs/BENCHMARK_high_copy_followups.md",
    ):
        members[f"source_tree/{relative}"] = (ROOT / relative).read_bytes()
    members["package_evidence.py"] = Path(__file__).read_bytes()
    members["repository_base.json"] = (json.dumps({
        "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT, text=True).strip(),
        "assembly_code_changed": False,
        "release_authorized": False,
        "historical_source_evidence": "benchmarks/benchmark_results/v3.2-high-copy-final-20260911/evidence.tar.gz",
        "historical_source_evidence_sha256": digest((ROOT / "benchmarks/benchmark_results/v3.2-high-copy-final-20260911/evidence.tar.gz").read_bytes()),
    }, indent=2, sort_keys=True) + "\n").encode()
    DESTINATION.mkdir(parents=True, exist_ok=True)
    for filename in ("evidence.tar.gz", "ARCHIVE_CONTENTS.json", "SHA256SUMS"):
        if (DESTINATION / filename).exists():
            raise ValueError(f"Refusing existing archive artifact: {filename}")
    with (DESTINATION / "evidence.tar.gz").open("xb") as compressed:
        with gzip.GzipFile(fileobj=compressed, filename="", mode="wb", mtime=0) as encoded:
            with tarfile.open(fileobj=encoded, mode="w") as archive:
                for name, contents in sorted(members.items()):
                    member = tarfile.TarInfo(name)
                    member.size = len(contents)
                    member.mode = 0o644
                    archive.addfile(member, io.BytesIO(contents))
    inventory = {"schema_version": 1, "member_count": len(members), "members": [
        {"path": name, "size_bytes": len(contents), "sha256": digest(contents)}
        for name, contents in sorted(members.items())
    ]}
    (DESTINATION / "ARCHIVE_CONTENTS.json").write_text(json.dumps(inventory, indent=2, sort_keys=True) + "\n")
    (DESTINATION / "SHA256SUMS").write_text("".join(
        f"{digest((DESTINATION / filename).read_bytes())}  {filename}\n"
        for filename in ("evidence.tar.gz", "ARCHIVE_CONTENTS.json")
    ))
    print(json.dumps({"members": len(members), "archive_sha256": digest((DESTINATION / "evidence.tar.gz").read_bytes())}))


if __name__ == "__main__":
    main()
