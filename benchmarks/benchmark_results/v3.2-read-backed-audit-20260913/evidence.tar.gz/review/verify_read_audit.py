"""Independently verify completed read-audit receipts and observed evidence."""

import argparse
import collections
import functools
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


COMPLEMENT = str.maketrans("ACGT", "TGCA")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def matches(sequence, pattern, limit):
    found = []
    if limit == 0:
        start = sequence.find(pattern)
        while start >= 0:
            found.append((start, 0))
            start = sequence.find(pattern, start + 1)
        return found
    for start in range(len(sequence) - len(pattern) + 1):
        differences = 0
        for actual, expected in zip(sequence[start:start + len(pattern)], pattern):
            if actual not in "ACGT":
                differences = limit + 1
                break
            differences += actual != expected
            if differences > limit:
                break
        if differences <= limit:
            found.append((start, differences))
    return found


@functools.lru_cache(maxsize=4096)
def placements(window, limit, templates):
    output = []
    for identifier, sequence in templates:
        for strand, oriented in (("+", sequence), ("-", reverse_complement(sequence))):
            output.extend(
                {"candidate_id": identifier, "strand": strand, "start": start, "substitutions": differences}
                for start, differences in matches(oriented, window, limit)
            )
    return output


def observations(record, events, templates, limit):
    output = {}
    for event in events.values():
        if event["callability"] != "assayed":
            continue
        found = []
        for strand, pattern in (("+", event["window_sequence"]), ("-", reverse_complement(event["window_sequence"]))):
            for start, differences in matches(record["sequence"], pattern, limit):
                end = start + len(pattern)
                if min(record["quality"][start:end]) < "5":
                    continue
                observed = record["sequence"][start:end]
                if strand == "-":
                    observed = reverse_complement(observed)
                projected = event["window_start"] - (start if strand == "+" else len(record["sequence"]) - end)
                found.append({
                    "strand": strand, "read_start": start, "read_end": end,
                    "substitutions": differences,
                    "projected_footprint": [projected, projected + len(record["sequence"])],
                    "observed_template_placements": placements(observed, limit, templates),
                })
        if found:
            output[event["id"]] = {
                "event_id": event["id"], "candidate_id": event["candidate_id"],
                "comparison_group": event.get("comparison_group", event["candidate_id"]),
                "matches": found,
                "unique": len(found) == 1 and len(found[0]["observed_template_placements"]) == 1,
            }
    groups = collections.defaultdict(set)
    for observation in output.values():
        groups[observation["comparison_group"]].add(observation["candidate_id"])
    for observation in output.values():
        if len(groups[observation["comparison_group"]]) > 1:
            observation["unique"] = False
    return output


def verify_observations(report, spec):
    templates = tuple((candidate["id"], candidate["sequence"]) for candidate in spec["candidates"])
    declared = {event["id"]: event for event in spec["events"]}
    events = {event["id"]: event for event in report["events"]}
    assert len(events) == len(report["events"]) == len(declared)
    assert set(events) == set(declared)
    for identifier, event in events.items():
        assert all(event[key] == value for key, value in declared[identifier].items())
        assert (event["window_start"], event["window_end"]) == (event["start"] - 21, event["end"] + 21)
        if event["callability"] == "assayed":
            assert event["window_sequence"] == dict(templates)[event["candidate_id"]][event["window_start"]:event["window_end"]]
    counters = collections.defaultdict(lambda: {"records": 0, "unique": 0, "exact": 0, "one_sub": 0, "ids": set(), "footprints": set(), "links": set(), "sequences": set()})
    ordinals = set()
    for record in report["read_evidence"]:
        assert record["ordinal"] not in ordinals
        ordinals.add(record["ordinal"])
        derived = observations(record, events, templates, report["max_substitutions"])
        assert derived == {observation["event_id"]: observation for observation in record["observations"]}
        for identifier, observation in derived.items():
            counter = counters[identifier]
            counter["records"] += 1
            counter["exact"] += any(match["substitutions"] == 0 for match in observation["matches"])
            counter["one_sub"] += any(match["substitutions"] == 1 for match in observation["matches"])
            if observation["unique"]:
                read_id = record["header"].split()[0]
                footprint = tuple(observation["matches"][0]["projected_footprint"])
                counter["unique"] += 1
                counter["ids"].add(read_id)
                counter["footprints"].add(footprint)
                counter["links"].add((read_id, footprint))
                counter["sequences"].add(min(record["sequence"], reverse_complement(record["sequence"])))
    for identifier, event in events.items():
        counter = counters[identifier]
        assert (counter["records"], counter["unique"], counter["exact"], counter["one_sub"]) == (event["records"], event["unique_records"], event["exact_records"], event["one_substitution_records"])
        assert event["ambiguous_records"] == counter["records"] - counter["unique"]
        assert (len(counter["ids"]), len(counter["footprints"]), len(counter["sequences"])) == (event["distinct_ids"], event["distinct_footprints"], event["distinct_sequences"])
        witness = event["corroboration_witness"]
        assert all((item["read_id"], tuple(item["footprint"])) in counter["links"] for item in witness)
        assert len({item["read_id"] for item in witness}) == len(witness)
        assert len({tuple(item["footprint"]) for item in witness}) == len(witness)
        assert (event["local_bridge_status"] == "corroborated_local_bridge") == (len(witness) >= 3)


def verify_prefix(accession, reports):
    needed = collections.defaultdict(list)
    for report in reports:
        for record in report["read_evidence"]:
            needed[record["ordinal"]].append(record)
    exact = next(report for report in reports if report["max_substitutions"] == 0)
    focused = [event for event in exact["events"] if accession == "SRR27962769" and event["role"] != "marginal_diagnostic" and event["callability"] == "assayed"]
    counters = {event["id"]: {"ordinals": set(), "ids": set(), "footprints": set()} for event in focused}
    prefix_hash = hashlib.sha256()
    bases = size = 0
    with Path(exact["input_path"]).open("rb") as source:
        for ordinal in range(1, 1000001):
            lines = [source.readline() for _field in range(4)]
            assert all(lines)
            raw = b"".join(lines)
            prefix_hash.update(raw)
            size += len(raw)
            header, sequence, separator, quality = [line.rstrip(b"\r\n").decode("ascii") for line in lines]
            assert header.startswith("@") and separator.startswith("+") and len(sequence) == len(quality)
            bases += len(sequence)
            sequence = sequence.upper()
            for record in needed.get(ordinal, []):
                assert (record["header"], record["sequence"], record["quality"]) == (header, sequence, quality)
            for event in focused:
                footprints = []
                for strand, pattern in (("+", event["window_sequence"]), ("-", reverse_complement(event["window_sequence"]))):
                    for start, _differences in matches(sequence, pattern, 0):
                        end = start + len(pattern)
                        if min(quality[start:end]) >= "5":
                            projected = event["window_start"] - (start if strand == "+" else len(sequence) - end)
                            footprints.append((projected, projected + len(sequence)))
                if footprints:
                    counters[event["id"]]["ordinals"].add(ordinal)
                    counters[event["id"]]["ids"].add(header.split()[0])
                    if len(footprints) == 1:
                        counters[event["id"]]["footprints"].add(footprints[0])
    observed = {"records": 1000000, "bases": bases, "size_bytes": size, "sha256": prefix_hash.hexdigest()}
    assert all(report["input_subset"] == observed for report in reports)
    focused_receipts = []
    for event in focused:
        counter = counters[event["id"]]
        expected_ordinals = {record["ordinal"] for record in exact["read_evidence"] if any(item["event_id"] == event["id"] for item in record["observations"])}
        assert counter["ordinals"] == expected_ordinals
        assert len(counter["ordinals"]) == event["records"]
        assert len(counter["footprints"]) == event["distinct_footprints"]
        focused_receipts.append({"event_id": event["id"], "records": len(counter["ordinals"]), "distinct_ids": len(counter["ids"]), "distinct_footprints": len(counter["footprints"]), "ordinals": sorted(counter["ordinals"])})
    return {"accession": accession, "prefix": observed, "distinct_matching_ordinals_verified": len(needed), "independent_full_prefix_exact_co1_counts": focused_receipts}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--execution", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    checker_hash = sha256(__file__)
    execution = read_json(arguments.execution / "execution.json")
    assert not execution["source_changed_during_execution"]
    assert execution["source_frozen_before"] == execution["source_rechecked_after"]
    for path, expected in execution["source_rechecked_after"].items():
        assert sha256(path) == expected
    expected_jobs = {(accession, mode) for accession in ("SRR1057608", "SRR27962769", "SRR31887760") for mode in ("exact", "one_substitution")}
    assert {(job["accession"], job["label"]) for job in execution["jobs"]} == expected_jobs
    assert len(execution["jobs"]) == 6
    grouped = collections.defaultdict(list)
    output_receipts = []
    for job in execution["jobs"]:
        assert job["returncode"] == 0 and job["validated_output"] and not job["timed_out"]
        receipt_path = arguments.execution / f"{job['accession']}.{job['label']}.receipt.json"
        assert read_json(receipt_path) == job
        assert sha256(job["output_path"]) == job["output_sha256"]
        assert sha256(job["stdout_path"]) == job["stdout_sha256"]
        assert sha256(job["stderr_path"]) == job["stderr_sha256"]
        report = read_json(job["output_path"])
        spec_path = arguments.root / "scan_specs" / f"{job['accession']}.scanner_manifest.json"
        prefix_path = arguments.root / "scan_specs" / f"{job['accession']}.expected_prefix.json"
        assert report["provenance"] == {"event_manifest_sha256": sha256(spec_path), "expected_prefix_manifest_sha256": sha256(prefix_path), "scanner_sha256": job["scanner_sha256"]}
        assert report["input_subset"] == read_json(prefix_path)
        assert report["max_substitutions"] == (0 if job["label"] == "exact" else 1)
        verify_observations(report, read_json(spec_path))
        grouped[job["accession"]].append(report)
        original = arguments.root / "execution" / f"{job['accession']}.{job['label']}.json"
        assert sha256(original) == job["output_sha256"]
        output_receipts.append({"path": job["output_path"], "sha256": job["output_sha256"], "matches_first_batch_bytes": True, "matching_ledger_records": len(report["read_evidence"])})
        print(f"Verified observations: {job['accession']} {job['label']}", flush=True)
    prefixes = [verify_prefix(accession, reports) for accession, reports in sorted(grouped.items())]
    assert sha256(__file__) == checker_hash
    result = {
        "schema_version": 1, "status": "pass", "reviewed_at": datetime.now(timezone.utc).isoformat(),
        "checker_path": str(Path(__file__).resolve()), "checker_sha256": checker_hash,
        "command": [sys.executable, *sys.argv], "execution_receipt_sha256": sha256(arguments.execution / "execution.json"),
        "reports": output_receipts, "prefixes": prefixes,
        "scope": "Independent retrospective review: all ledger observations, Q20, alternative placements and witnesses recomputed without importing the production scanner; original R1 prefixes reparsed and hashed; complete-prefix independent exact CO1 recount. Not an exhaustive independent sensitivity scan of nonmatching records.",
        "limitations": "Distinct IDs/projected footprints are not certified molecules; local evidence is not full haplotype truth. First batch retained its failed driver-source attestation; clean replication required and checked here.",
    }
    with arguments.output.open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
