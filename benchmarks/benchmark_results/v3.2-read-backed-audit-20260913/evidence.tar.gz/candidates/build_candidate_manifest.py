#!/usr/bin/env python3

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path


EXECUTION_ROOT = Path("/tmp/sharkmer-high-copy-20260911/final-execution")
DIAGNOSTIC_AUDIT = Path(
    "/tmp/sharkmer-high-copy-20260911/final-analysis/diagnostic-audit.json"
)
RECLASSIFICATION = Path(
    "/tmp/sharkmer-public-replacements-20260913/reclassification/"
    "saved_output_reclassification.json"
)
PROTOCOL = Path(
    "/tmp/sharkmer-read-audit-20260913/protocol/protocol-v2.md"
)
KMER_LENGTH = 19
NODE_LENGTH = KMER_LENGTH - 1
ASSAY_FLANK_BASES = 21

CASES = (
    {
        "cell_index": 8,
        "accession": "SRR1057608",
        "taxon": "Heliconius pachinus",
        "gene": "ND1",
        "lost_sha256": (
            "3ba955f286a5468dbd65fc5e81601dbd53f0d898189a6c576c91bc744098728f",
        ),
    },
    {
        "cell_index": 9,
        "accession": "SRR27962769",
        "taxon": "Gryllus bimaculatus",
        "gene": "CO1_1",
        "lost_sha256": (
            "e86a7ccf9e78adaf259ec804eb05dadaf8557bc4a7c637b483dfacd330a7e3ba",
        ),
    },
    {
        "cell_index": 9,
        "accession": "SRR27962769",
        "taxon": "Gryllus bimaculatus",
        "gene": "ITS_2",
        "lost_sha256": (
            "23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c",
        ),
    },
    {
        "cell_index": 7,
        "accession": "SRR31887760",
        "taxon": "Drosophila melanogaster",
        "gene": "12S",
        "lost_sha256": (
            "bde6ccaf771a24982439c53e7d38c45748cb2773f6ce05660c2a31a85d9203be",
            "c1a643a6313600b14ac0faae530e4fd93b48fa5007978c93ae81f089efa04148",
            "d147d2a3d79608354456b94cbfeb6df52eae820d135852530fb2d8798d54b39c",
        ),
    },
    {
        "cell_index": 7,
        "accession": "SRR31887760",
        "taxon": "Drosophila melanogaster",
        "gene": "16S_2",
        "lost_sha256": (
            "6d6a1fe8e2de508afa9a757ceca421c0796eb2e7a70dcdd39b357190764f4049",
        ),
    },
)

CONTROL_SPECS = (
    {
        "cell_index": 8,
        "accession": "SRR1057608",
        "taxon": "Heliconius pachinus",
        "gene": "ND1",
        "sha256": "a38abaa51a1d659ed1d5ba84d99748b57a9244bc3fd68444f8ca013972a7d72c",
        "role": "same-gene retained alternative",
    },
    {
        "cell_index": 9,
        "accession": "SRR27962769",
        "taxon": "Gryllus bimaculatus",
        "gene": "CO1_1",
        "sha256": "e2d376bc5b0f09a954f7dfb6083ff3e4a768a2b687685e18349f66dd25cfc9c0",
        "role": "same-gene retained alternative",
    },
    {
        "cell_index": 9,
        "accession": "SRR27962769",
        "taxon": "Gryllus bimaculatus",
        "gene": "12S",
        "sha256": "8a88bc972180963c12a31346c26f60c6862fd516b5d6ccc2d120855c8e23d47c",
        "role": "same-sample retained mitochondrial control",
    },
    {
        "cell_index": 9,
        "accession": "SRR27962769",
        "taxon": "Gryllus bimaculatus",
        "gene": "16S_2",
        "sha256": "66686929b8d17dfa5e1851e37d6a089bc385a664000b4f50bf5c1431a3c22db4",
        "role": "same-sample retained mitochondrial control",
    },
    {
        "cell_index": 7,
        "accession": "SRR31887760",
        "taxon": "Drosophila melanogaster",
        "gene": "CO1_1",
        "sha256": "4421359eb30276c48af559081691c91a74d132155b4192c72cd44eac885f4af4",
        "role": "same-sample retained mitochondrial control",
    },
)


def sha256_path(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def parse_fasta(path):
    records = []
    header = None
    sequence_parts = []
    for line in path.read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                records.append((header, "".join(sequence_parts)))
            header = line[1:]
            sequence_parts = []
        else:
            if header is None:
                raise ValueError(f"FASTA sequence precedes header: {path}")
            sequence_parts.append(line.strip())
    if header is not None:
        records.append((header, "".join(sequence_parts)))
    if not records:
        raise ValueError(f"FASTA has no records: {path}")
    return records


def invocation_id(case, pair_index, version):
    return (
        f"{case['cell_index']:03d}_insecta_{case['accession']}_1000000_"
        f"pair{pair_index}_{version}"
    )


def verify_result(case, pair_index, version):
    identifier = invocation_id(case, pair_index, version)
    result_path = EXECUTION_ROOT / "results" / f"{identifier}.json"
    result = read_json(result_path)
    if result.get("status") != "complete" or result.get("timing_status") != "complete":
        raise ValueError(f"source result is not complete: {identifier}")
    signature = result.get("signature", {})
    invocation = signature.get("invocation", {})
    if invocation.get("invocation_id") != identifier:
        raise ValueError(f"source invocation identity differs: {identifier}")
    if signature.get("settings", {}).get("k") != KMER_LENGTH:
        raise ValueError(f"source invocation k differs: {identifier}")
    if invocation.get("taxon") != case["taxon"]:
        raise ValueError(f"source invocation taxon differs: {identifier}")
    output_directory = Path(result["attempt_dir"]) / "output"
    receipts = {}
    for receipt in result.get("raw_output_files", []):
        output_path = output_directory / receipt["path"]
        if output_path.is_symlink() or not output_path.is_file():
            raise ValueError(f"source output is not a regular file: {output_path}")
        if output_path.stat().st_size != receipt["size_bytes"]:
            raise ValueError(f"source output size differs: {output_path}")
        if sha256_path(output_path) != receipt["sha256"]:
            raise ValueError(f"source output checksum differs: {output_path}")
        receipts[receipt["path"]] = receipt
    return result_path, result, output_directory, receipts


def verified_gene_products(case, pair_index, version):
    result_path, result, output_directory, receipts = verify_result(
        case, pair_index, version
    )
    gene_result = next(
        gene for gene in result.get("genes", []) if gene.get("gene") == case["gene"]
    )
    expected_products = {
        product["sha256"]: product for product in gene_result.get("products", [])
    }
    matching_paths = sorted(output_directory.glob(f"*_{case['gene']}.fasta"))
    if not expected_products:
        if matching_paths:
            raise ValueError(
                f"unexpected FASTA for empty gene result: {case['gene']} {result_path}"
            )
        return {}, {
            "result_path": str(result_path),
            "result_sha256": sha256_path(result_path),
            "fasta": None,
        }
    if len(matching_paths) != 1:
        raise ValueError(f"expected one gene FASTA: {case['gene']} {result_path}")
    fasta_path = matching_paths[0]
    receipt = receipts.get(fasta_path.name)
    if receipt is None:
        raise ValueError(f"gene FASTA lacks source receipt: {fasta_path}")
    observed_products = {}
    for header, sequence in parse_fasta(fasta_path):
        digest = hashlib.sha256(sequence.encode()).hexdigest()
        expected = expected_products.get(digest)
        if expected is None or expected.get("length") != len(sequence):
            raise ValueError(f"FASTA record differs from result: {fasta_path}")
        observed_products[digest] = {
            "sequence": sequence,
            "length": len(sequence),
            "header": header,
            "product_index": expected.get("product_index"),
            "kmer_count_median": expected.get("kmer_count_median"),
        }
    if set(observed_products) != set(expected_products):
        raise ValueError(f"result product set differs from FASTA: {fasta_path}")
    return observed_products, {
        "result_path": str(result_path),
        "result_sha256": sha256_path(result_path),
        "fasta_path": str(fasta_path),
        "fasta_sha256": receipt["sha256"],
        "fasta_size_bytes": receipt["size_bytes"],
    }


def stable_products(case, version):
    products = None
    evidence = []
    for pair_index in (1, 2, 3):
        observed, receipt = verified_gene_products(case, pair_index, version)
        sequences = {
            digest: product["sequence"] for digest, product in observed.items()
        }
        if products is None:
            products = observed
        elif sequences != {
            digest: product["sequence"] for digest, product in products.items()
        }:
            raise ValueError(
                f"product set is unstable across repetitions: {case['accession']} "
                f"{case['gene']} {version}"
            )
        evidence.append(receipt)
    return products or {}, evidence


def repeated_windows(sequence, width):
    positions = defaultdict(list)
    for start in range(len(sequence) - width + 1):
        positions[sequence[start : start + width]].append(start)
    return [
        {
            "sequence": window,
            "positions": starts,
            "occurrence_count": len(starts),
            "span": [starts[0], starts[-1] + width],
        }
        for window, starts in sorted(positions.items())
        if len(starts) > 1
    ]


def primary_assay(sequence, questioned_span):
    start, end = questioned_span
    left_start = max(0, start - ASSAY_FLANK_BASES)
    right_end = min(len(sequence), end + ASSAY_FLANK_BASES)
    left_flank = sequence[left_start:start]
    right_flank = sequence[end:right_end]
    full_flanks = (
        len(left_flank) == ASSAY_FLANK_BASES
        and len(right_flank) == ASSAY_FLANK_BASES
    )
    literal_bases = not set(left_flank + sequence[start:end] + right_flank) - set(
        "ACGT"
    )
    return {
        "questioned_span": [start, end],
        "requested_flank_bases_each_side": ASSAY_FLANK_BASES,
        "left_flank_span": [left_start, start],
        "right_flank_span": [end, right_end],
        "window_span": [left_start, right_end],
        "window_sequence": sequence[left_start:right_end],
        "left_flank": left_flank,
        "questioned_sequence": sequence[start:end],
        "right_flank": right_flank,
        "has_full_flanks": full_flanks,
        "has_literal_acgt_window": literal_bases,
        "eligible_before_read_length_check": full_flanks and literal_bases,
    }


def consolidated_repeat_intervals(sequence, node_events, edge_events):
    intervals = []
    for event in node_events:
        intervals.append([event["span"][0], event["span"][1]])
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    results = []
    for start, end in merged:
        assay = primary_assay(sequence, [start, end])
        results.append(
            {
                "repeat_span": [start, end],
                "primary_assay": assay,
                "repeated_node_window_count": sum(
                    event["span"][0] < end and event["span"][1] > start
                    for event in node_events
                ),
                "repeated_edge_window_count": sum(
                    event["span"][0] < end and event["span"][1] > start
                    for event in edge_events
                ),
                "minimum_local_branch_link_bases": KMER_LENGTH + 1,
                "local_link_is_full_interval_bridge": KMER_LENGTH + 1
                >= len(assay["window_sequence"]),
            }
        )
    return results


def sequence_repeat_evidence(sequence):
    node_events = repeated_windows(sequence, NODE_LENGTH)
    edge_events = repeated_windows(sequence, KMER_LENGTH)
    return {
        "node_definition": f"exact oriented {NODE_LENGTH}-base de Bruijn node",
        "edge_definition": f"exact oriented {KMER_LENGTH}-base de Bruijn edge",
        "repeated_node_windows": node_events,
        "repeated_edge_windows": edge_events,
        "consolidated_intervals": consolidated_repeat_intervals(
            sequence, node_events, edge_events
        ),
        "scope": (
            "sequence-intrinsic lower bound only; graph SCCs can also be created by "
            "other read-derived branches not present in this product"
        ),
    }


def common_prefix_length(first, second):
    length = 0
    while length < min(len(first), len(second)) and first[length] == second[length]:
        length += 1
    return length


def common_suffix_length(first, second, prefix_length):
    length = 0
    maximum = min(len(first), len(second)) - prefix_length
    while length < maximum and first[-length - 1] == second[-length - 1]:
        length += 1
    return length


def difference_interval(sequence, alternative):
    prefix_length = common_prefix_length(sequence, alternative)
    suffix_length = common_suffix_length(sequence, alternative, prefix_length)
    sequence_end = len(sequence) - suffix_length
    alternative_end = len(alternative) - suffix_length
    return {
        "coordinate_system": "zero_based_half_open",
        "lost_span": [prefix_length, sequence_end],
        "alternative_span": [prefix_length, alternative_end],
        "lost_sequence": sequence[prefix_length:sequence_end],
        "alternative_sequence": alternative[prefix_length:alternative_end],
        "lost_primary_assay": primary_assay(
            sequence, [prefix_length, sequence_end]
        ),
        "alternative_primary_assay": primary_assay(
            alternative, [prefix_length, alternative_end]
        ),
        "placement_note": (
            "maximal exact common prefix/suffix; equivalent placement can be non-unique "
            "inside tandem or low-complexity sequence"
        ),
    }


def exact_deletion_placements(longer, shorter):
    difference = len(longer) - len(shorter)
    if difference <= 0:
        return None
    placements = [
        [start, start + difference]
        for start in range(len(longer) - difference + 1)
        if longer[:start] + longer[start + difference :] == shorter
    ]
    if not placements:
        return None
    union_span = [placements[0][0], placements[-1][1]]
    shorter_span = [placements[0][0], placements[-1][0]]
    return {
        "deleted_base_count": difference,
        "equivalent_deletion_spans": placements,
        "longer_template_placement_union_span": union_span,
        "shorter_template_corresponding_span": shorter_span,
        "longer_primary_assay": primary_assay(longer, union_span),
        "shorter_primary_assay": primary_assay(shorter, shorter_span),
        "interpretation": (
            "all exact equivalent placements are retained; the placement union, not one "
            "arbitrary alignment, defines the complete questioned interval"
        ),
    }


def pairwise_alternative_comparisons(products):
    comparisons = []
    ordered = sorted(products.items())
    for first_index, (first_digest, first_product) in enumerate(ordered):
        for second_digest, second_product in ordered[first_index + 1 :]:
            first_sequence = first_product["sequence"]
            second_sequence = second_product["sequence"]
            if len(first_sequence) >= len(second_sequence):
                longer_digest, longer_sequence = first_digest, first_sequence
                shorter_digest, shorter_sequence = second_digest, second_sequence
            else:
                longer_digest, longer_sequence = second_digest, second_sequence
                shorter_digest, shorter_sequence = first_digest, first_sequence
            comparisons.append(
                {
                    "first_sha256": first_digest,
                    "second_sha256": second_digest,
                    "maximal_common_flank_difference": difference_interval(
                        first_sequence, second_sequence
                    ),
                    "exact_deletion_placements": exact_deletion_placements(
                        longer_sequence, shorter_sequence
                    ),
                    "longer_sha256": longer_digest,
                    "shorter_sha256": shorter_digest,
                }
            )
    return comparisons


def family_variable_interval(products):
    sequences = [product["sequence"] for product in products.values()]
    if len(sequences) < 2:
        return None
    prefix_length = min(
        common_prefix_length(sequences[0], sequence) for sequence in sequences[1:]
    )
    reversed_sequences = [sequence[::-1] for sequence in sequences]
    suffix_length = min(
        common_prefix_length(reversed_sequences[0], sequence)
        for sequence in reversed_sequences[1:]
    )
    suffix_length = min(suffix_length, min(map(len, sequences)) - prefix_length)
    return {
        "coordinate_system": "zero_based_half_open",
        "common_prefix_length": prefix_length,
        "common_suffix_length": suffix_length,
        "member_variable_spans": {
            hashlib.sha256(sequence.encode()).hexdigest(): [
                prefix_length,
                len(sequence) - suffix_length,
            ]
            for sequence in sequences
        },
        "pairwise_comparisons": pairwise_alternative_comparisons(products),
        "interpretation": "alternative product family; no member is selected as sample truth",
    }


def public_context_by_sha256():
    source = read_json(RECLASSIFICATION)
    contexts = {}
    for product in source.get("results", {}).get("products", []):
        match = product.get("new_reference_match") or {}
        contexts[product["sha256"]] = {
            "status": match.get("status"),
            "matched_accession": match.get("matched_accession"),
            "matched_gene": match.get("matched_gene"),
            "matched_taxon": match.get("matched_taxon"),
            "pct_identity": match.get("pct_identity"),
            "query_coverage_pct": match.get("query_coverage_pct"),
            "unmatched_query_regions": match.get("unmatched_query_regions"),
            "sequence_relationship": match.get("sequence_relationship"),
            "alignment_structure_status": match.get("alignment_structure_status"),
            "alignment_evidence": match.get("alignment_evidence"),
            "scope": (
                "verified public locus context only; not sample haplotype truth and not "
                "read support"
            ),
        }
    return contexts


def diagnostic_cases():
    source = read_json(DIAGNOSTIC_AUDIT)
    return {
        (entry["cell"].split("/")[1], entry["gene"]): entry
        for entry in source["high_copy_lost_gene_audits"]
    }


def compact_diagnostics(entry):
    return {
        "candidate_gene_status": entry.get("candidate_gene_status"),
        "candidate_product_count": entry.get("candidate_product_count"),
        "candidate_failure_reason": entry.get("candidate_failure_reason"),
        "threshold_diagnostics": entry.get("threshold_diagnostics"),
        "scope": (
            "counts and outcomes serialized by the candidate run; marker identities and "
            "coordinates were intentionally not serialized"
        ),
    }


def build_manifest():
    public_contexts = public_context_by_sha256()
    diagnostics = diagnostic_cases()
    cases = []
    control_lookup = {}
    control_rows = []
    for control in CONTROL_SPECS:
        products, receipts = stable_products(control, "candidate")
        product = products.get(control["sha256"])
        if product is None:
            raise ValueError(f"retained control is absent: {control['sha256']}")
        row = {
            **control,
            **product,
            "repeat_evidence": sequence_repeat_evidence(product["sequence"]),
            "public_reference_context": public_contexts.get(control["sha256"]),
            "source_repetitions": receipts,
        }
        control_rows.append(row)
        control_lookup[(control["accession"], control["gene"])] = row

    for case in CASES:
        baseline_products, baseline_receipts = stable_products(case, "baseline")
        candidate_products, candidate_receipts = stable_products(case, "candidate")
        expected_lost = set(case["lost_sha256"])
        observed_lost = set(baseline_products) - set(candidate_products)
        if observed_lost != expected_lost:
            raise ValueError(
                f"lost product set differs: {case['accession']} {case['gene']}"
            )
        diagnostic = diagnostics.get((case["accession"], case["gene"]))
        if diagnostic is None:
            raise ValueError(f"missing gate diagnostics: {case['accession']} {case['gene']}")
        if {
            product["sha256"] for product in diagnostic.get("lost_products", [])
        } != expected_lost:
            raise ValueError(f"diagnostic lost set differs: {case['accession']} {case['gene']}")
        same_gene_control = control_lookup.get((case["accession"], case["gene"]))
        lost_rows = []
        for digest in case["lost_sha256"]:
            product = baseline_products[digest]
            repeat_evidence = sequence_repeat_evidence(product["sequence"])
            if repeat_evidence["consolidated_intervals"]:
                suspect_region = {
                    "basis": "exact repeated oriented de Bruijn nodes within product",
                    "intervals": repeat_evidence["consolidated_intervals"],
                }
            else:
                suspect_region = {
                    "basis": "marker identities unavailable in bounded run diagnostics",
                    "intervals": [[0, product["length"]]],
                    "interpretation": (
                        "the current run withheld completed paths at graph markers, but saved "
                        "aggregate diagnostics cannot establish whether this historical product "
                        "was enumerated or localize any gate interval within it; gate attribution "
                        "for this product remains unlocalized and unresolved"
                    ),
                }
            lost_rows.append(
                {
                    **product,
                    "sha256": digest,
                    "repeat_evidence": repeat_evidence,
                    "suspect_region": suspect_region,
                    "difference_from_retained_same_gene": difference_interval(
                        product["sequence"], same_gene_control["sequence"]
                    )
                    if same_gene_control is not None
                    else None,
                    "exact_indel_placements_against_retained_same_gene": (
                        exact_deletion_placements(
                            product["sequence"], same_gene_control["sequence"]
                        )
                        if same_gene_control is not None
                        and len(product["sequence"])
                        >= len(same_gene_control["sequence"])
                        else exact_deletion_placements(
                            same_gene_control["sequence"], product["sequence"]
                        )
                        if same_gene_control is not None
                        else None
                    ),
                    "public_reference_context": public_contexts.get(digest),
                    "classification": (
                        "withheld product candidate; correctness and sample haplotype are "
                        "not established"
                    ),
                }
            )
        cases.append(
            {
                "panel": "insecta",
                "accession": case["accession"],
                "taxon": case["taxon"],
                "gene": case["gene"],
                "k": KMER_LENGTH,
                "lost_products": lost_rows,
                "retained_same_gene_products": [
                    {
                        **product,
                        "sha256": digest,
                        "repeat_evidence": sequence_repeat_evidence(product["sequence"]),
                    }
                    for digest, product in sorted(candidate_products.items())
                ],
                "alternative_family_interval": family_variable_interval(
                    baseline_products
                ),
                "gate_diagnostics": compact_diagnostics(diagnostic),
                "baseline_source_repetitions": baseline_receipts,
                "candidate_source_repetitions": candidate_receipts,
            }
        )
    return {
        "schema_version": 1,
        "purpose": "candidate intervals for discriminating read-evidence audit",
        "coordinate_system": "zero_based_half_open",
        "k": KMER_LENGTH,
        "primary_assay_flank_bases_each_side": ASSAY_FLANK_BASES,
        "counts": {
            "cases": len(cases),
            "lost_products": sum(len(case["lost_products"]) for case in cases),
            "retained_controls": len(control_rows),
        },
        "source_receipts": {
            "audit_protocol": {
                "path": str(PROTOCOL),
                "sha256": sha256_path(PROTOCOL),
            },
            "diagnostic_audit": {
                "path": str(DIAGNOSTIC_AUDIT),
                "sha256": sha256_path(DIAGNOSTIC_AUDIT),
            },
            "public_reference_reclassification": {
                "path": str(RECLASSIFICATION),
                "sha256": sha256_path(RECLASSIFICATION),
            },
            "generator": {
                "path": str(Path(__file__).resolve()),
                "sha256": sha256_path(Path(__file__).resolve()),
            },
        },
        "evidence_limits": {
            "public_reference": (
                "public locus context is independent of products but does not establish the "
                "sample haplotype or support a repeat copy count"
            ),
            "saved_graph_diagnostics": (
                "threshold diagnostics contain cause counts but deliberately omit marker IDs; "
                "absence of a sequence-intrinsic repeated node does not exclude a graph SCC"
            ),
            "threading": (
                "a local adjacent-edge link spans only k+1 bases; marginal edge totals and "
                "paired-link presence cannot phase a full ambiguous interval"
            ),
            "required_discrimination": (
                "positive contiguous read fragments must bridge every relevant interval from "
                "entry flank through exit flank before any repeat-copy rescue is considered"
            ),
            "assays": (
                "primary exact contiguous window and optional separately reported one-"
                "substitution/no-indel sensitivity assay require Q20 throughout, as frozen in "
                "the protocol receipt"
            ),
        },
        "cases": cases,
        "retained_controls": control_rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parent / "candidate_manifest.json",
    )
    arguments = parser.parse_args()
    manifest = build_manifest()
    arguments.output.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    receipt_path = arguments.output.with_suffix(".receipt.json")
    receipt_path.write_text(
        json.dumps(
            {
                "manifest_path": str(arguments.output.resolve()),
                "manifest_sha256": sha256_path(arguments.output),
                "generator_sha256": sha256_path(Path(__file__).resolve()),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    print(arguments.output)


if __name__ == "__main__":
    main()
