import hashlib
import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parent / "build_candidate_manifest.py"
SPEC = importlib.util.spec_from_file_location("build_candidate_manifest", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class CandidateManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = MODULE.build_manifest()

    def test_all_seven_lost_products_are_receipt_verified(self):
        self.assertEqual(self.manifest["counts"]["cases"], 5)
        self.assertEqual(self.manifest["counts"]["lost_products"], 7)
        for case in self.manifest["cases"]:
            self.assertEqual(len(case["baseline_source_repetitions"]), 3)
            self.assertEqual(len(case["candidate_source_repetitions"]), 3)
            for product in case["lost_products"]:
                self.assertEqual(
                    hashlib.sha256(product["sequence"].encode()).hexdigest(),
                    product["sha256"],
                )
                self.assertEqual(len(product["sequence"]), product["length"])

    def test_retained_controls_are_stable_and_present(self):
        self.assertEqual(self.manifest["counts"]["retained_controls"], 5)
        for control in self.manifest["retained_controls"]:
            self.assertEqual(len(control["source_repetitions"]), 3)
            self.assertEqual(
                hashlib.sha256(control["sequence"].encode()).hexdigest(),
                control["sha256"],
            )

    def test_gryllus_co1_repeat_copy_difference_is_explicit(self):
        case = next(
            entry
            for entry in self.manifest["cases"]
            if entry["accession"] == "SRR27962769" and entry["gene"] == "CO1_1"
        )
        product = case["lost_products"][0]
        difference = product["difference_from_retained_same_gene"]
        self.assertEqual(difference["lost_span"], [328, 349])
        self.assertEqual(difference["alternative_span"], [328, 328])
        self.assertEqual(len(difference["lost_sequence"]), 21)
        placements = product["exact_indel_placements_against_retained_same_gene"]
        self.assertEqual(placements["equivalent_deletion_spans"][0], [310, 331])
        self.assertEqual(placements["equivalent_deletion_spans"][-1], [328, 349])
        self.assertEqual(
            placements["longer_template_placement_union_span"], [310, 349]
        )
        self.assertEqual(
            placements["longer_primary_assay"]["window_span"], [289, 370]
        )
        self.assertEqual(
            placements["shorter_primary_assay"]["window_span"], [289, 349]
        )
        self.assertEqual(
            product["repeat_evidence"]["consolidated_intervals"][0]["repeat_span"],
            [310, 349],
        )

    def test_sequence_intrinsic_and_graph_only_evidence_are_distinct(self):
        indexed = {
            (case["accession"], case["gene"]): case for case in self.manifest["cases"]
        }
        self.assertEqual(
            indexed[("SRR27962769", "ITS_2")]["lost_products"][0][
                "repeat_evidence"
            ]["consolidated_intervals"],
            [],
        )
        self.assertEqual(
            indexed[("SRR27962769", "ITS_2")]["lost_products"][0][
                "suspect_region"
            ]["basis"],
            "marker identities unavailable in bounded run diagnostics",
        )
        drosophila_12s = indexed[("SRR31887760", "12S")]
        self.assertTrue(
            all(
                product["repeat_evidence"]["consolidated_intervals"]
                for product in drosophila_12s["lost_products"]
            )
        )

    def test_local_link_is_not_mislabeled_as_full_repeat_bridge(self):
        intervals = [
            interval
            for case in self.manifest["cases"]
            for product in case["lost_products"]
            for interval in product["repeat_evidence"]["consolidated_intervals"]
        ]
        self.assertTrue(intervals)
        self.assertTrue(
            all(
                interval["minimum_local_branch_link_bases"] == MODULE.KMER_LENGTH + 1
                for interval in intervals
            )
        )
        self.assertTrue(
            any(not interval["local_link_is_full_interval_bridge"] for interval in intervals)
        )
        self.assertTrue(
            all(
                interval["primary_assay"]["requested_flank_bases_each_side"] == 21
                for interval in intervals
            )
        )

    def test_public_reference_context_never_claims_sample_truth(self):
        for case in self.manifest["cases"]:
            for product in case["lost_products"]:
                context = product["public_reference_context"]
                self.assertIsNotNone(context)
                self.assertIn("not sample haplotype truth", context["scope"])

    def test_manifest_binds_frozen_protocol(self):
        receipt = self.manifest["source_receipts"]["audit_protocol"]
        self.assertEqual(
            receipt["sha256"],
            "f83416bb68dc2212641ee5798c676e2a88c99f6850ea6af3c4e85f8400793eaf",
        )


if __name__ == "__main__":
    unittest.main()
