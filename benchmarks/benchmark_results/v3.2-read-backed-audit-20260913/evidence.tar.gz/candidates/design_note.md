# Evidence-backed repeat-gate exception: bounded design note

## Scope and decision precondition

This note considers only a future result in which the frozen read audit finds a quality-qualified contiguous read bridge for the Gryllus CO1 long-373 structural-event union. Such a result would support that frozen sequence interval in the consumed reads. It would not establish that the current Sharkmer search enumerated the historical 373 bp product, that the aggregate SCC-withheld count refers to that product, or that every repeat-tainted path is safe to emit.

The existing repeat gate must remain the default. Any exception must apply only to a repeat-tainted path enumerated in the current run and to ambiguous interval(s) derived from that path and its graph markers. An old output, an external reference match, marginal edge support, or aggregate threshold diagnostics cannot authorize the exception.

## Current interface boundary

- `search_assembly_paths` returns eligible paths plus aggregate counters in `PathSearchResult` (`src/pcr/paths.rs:31`). When a complete path touches an omitted-self-loop node, cyclic-SCC node, or retained collision edge, the function increments counters and discards the path (`src/pcr/paths.rs:215`). Its sequence and marker coordinates are therefore unavailable to later code.
- `evaluate_threshold` computes `ThreadingAnnotations` before path search, uses them to rank bubble edges, and passes only eligible paths to `generate_sequences_from_paths` (`src/pcr/mod.rs:557`, `src/pcr/mod.rs:600`, `src/pcr/mod.rs:693`). There is no candidate-verification stage between withholding and publication.
- `ThreadingAnnotations` contains marginal `edge_support`, adjacent-edge `branch_links`, and unconsumed `paired_links` (`src/pcr/threading.rs:30`). Per-read contiguous runs are reduced into these aggregates and then discarded (`src/pcr/threading.rs:301`).
- Pass 2 is opt-in through hidden `--read-threading`. `main` re-reads the complete selected subset into `Vec<ReadRecord>` before any gene is evaluated (`src/main.rs:159`). Each `ReadRecord` stores sequence, ordinal, and mate, but no quality string (`src/io.rs:36`). The CLI already identifies this all-reads-in-RAM behavior as unsuitable for public exposure (`src/cli.rs:295`).
- Local and cached sources can be replayed. Uncached remote sources are downloaded again, stdin is unavailable, and paired replay retains mate labels but not insert size or a gap sequence (`src/io.rs:769`).

## Why present threading evidence is insufficient

`edge_support` is marginal: different reads may support different edges. A chain of supported edges is not evidence that any one fragment traversed the complete ambiguous interval.

`branch_links` joins only adjacent graph edges observed in one contiguous mapped run. It establishes local traversal at a branch, not phase across a repeat-copy interval. Combining links from multiple reads would inflate local evidence into an unsupported full-haplotype claim.

`paired_links` stores each mate's mapped edge list but has no observed intervening sequence or insert-length constraint, and no current consumer reconstructs a path from it. It cannot establish repeat copy count.

Orientation-tied mappings retain only common local evidence. That is deliberately conservative and cannot be converted into a vote for one repeat traversal. Likewise, exact public-reference identity is locus context, not sample read support.

The frozen scanner's Q20 criterion also cannot be reproduced by the current Pass 2 API because `ReadRecord` omits qualities. A sequence-only match would be a weaker, different rule and must not be presented as the audited evidence criterion.

## Smallest defensible runtime design

The narrow design has two explicit stages and remains opt-in:

1. **Retain bounded current-run withheld candidates.** Extend `PathSearchResult` with a separately capped collection such as `withheld_paths: Vec<WithheldPath>`, where each item contains the current `Vec<PathStep>` and path-local cause identities or path offsets. This collection must have its own small cap and truncation diagnostic. Repeat-tainted paths must still not consume `max_paths_per_pair`, while `max_dfs_states`, maximum length, and node-visit bounds remain authoritative. Aggregate counters continue counting observed completed paths even after the retention cap.
2. **Derive candidate-local bridge requests.** Reconstruct an internal candidate sequence without publishing it. For each touched cause, derive the maximal ambiguous graph interval and require unique non-repeat flanks on both entry and exit. Merge overlapping cause intervals. Every separated ambiguous interval on the candidate must receive a bridge; independent reads over separate subintervals must not be composed into whole-path phase.
3. **Verify a single contiguous fragment per interval.** A qualifying read or individual mate must cover the entire ambiguous interval plus both prescribed flanks in one contiguous alignment, with the preregistered base-quality rule and no gap across the event. The verifier must compare all retained competing candidate windows and preserve equivalent placements or ties. Evidence that is compatible with multiple copy counts or paths remains unresolved.
4. **Admit only that enumerated path.** If every candidate-local interval passes, move that exact current-run path to the eligible generation step and record an explicit evidence status, bridge counts, quality rule, truncation state, and whether candidate enumeration was complete. Never clear node/SCC markers globally and never exempt unrelated paths sharing the component.

This can reinstate a current path only. If the long 373 bp sequence is not among the bounded current-run withheld paths, its read bridge cannot make Sharkmer output it. Producing an absent copy-expanded path would require true repeat reconstruction, not a gate exception.

## Replay, memory, and streaming tradeoffs

The mechanically smallest prototype could reuse `reads: Option<&[ReadRecord]>` inside `evaluate_threshold`, scan the retained sequences after path search, and admit a bounded withheld path. That avoids a top-level orchestration rewrite, but it is not release-safe as currently represented:

- qualities must be added to every retained `ReadRecord`, increasing the already substantial all-read RAM cost;
- each gene and attempted threshold could rescan all retained reads for multiple candidate windows, increasing work roughly with reads × genes × thresholds × retained candidates;
- `--read-threading` is currently hidden and off by default, so ordinary runs would still withhold the path; silently enabling it would materially change runtime and memory;
- uncached remote input may be downloaded twice, and stdin cannot supply the evidence pass;
- incomplete candidate enumeration due to DFS or retention caps must remain explicit uncertainty, not a successful exhaustive comparison.

A safer implementation is a targeted streaming second pass: first build graphs and bounded withheld-candidate bridge requests, then reopen the exact consumed input subset once, stream sequence plus qualities through all requests, and finalize products afterward. This avoids storing all reads and permits Q20 verification, but it requires splitting current per-gene evaluation into prepare/evidence/finalize phases. It also requires source-plan lifetime and checksum binding through the later pass, bounded request indexing, paired-record handling, and transactional output delay until verification completes. That is a follow-up architecture change rather than a minimal patch.

## Feasibility conclusion

A narrow proof of concept is feasible behind an explicit experimental option when all of the following hold: the current run enumerates the same withheld path, every ambiguous interval fits within a single read or mate with both unique flanks, qualities are retained and checked, competing candidate windows are compared without arbitrary tie breaking, and all resource-limit/truncation diagnostics remain visible.

It is not safe to make a current-release exception solely from the forthcoming frozen CO1 bridge count. The present code discards withheld path identity, lacks quality-bearing replay records, and retains only local aggregate threading evidence. The recommended release behavior is therefore to keep CO1 withheld unless a separately reviewed follow-up implements candidate retention plus quality-aware targeted replay. If the read audit corroborates long 373, record it as evidence that the conservative gate may have a false negative and as a concrete acceptance fixture for that follow-up.

## Minimum acceptance gates for a follow-up

- A current-run withheld candidate identical to the test template is emitted only when one quality-qualified fragment spans each complete graph-derived ambiguous interval with both flanks.
- The same marginal edge totals and adjacent branch-link counts assembled from different reads do not rescue it.
- A read covering only entry, only exit, or only part of the repeat does not rescue it.
- Equivalent placement/copy-count ties remain withheld; no first-candidate selection occurs.
- A bridge for one interval does not phase a candidate containing a second unbridged interval.
- Unrelated clean paths remain eligible; unrelated paths in the same SCC remain withheld.
- Omitted-self-loop, SCC, and collision-edge controls remain conservative for A19/A40/AC40 unless their own complete candidate-local bridge evidence passes.
- DFS, node, length, candidate-retention, and path quotas remain bounded and serialized; reaching a cap cannot be reported as proof that no competing path exists.
- With read evidence disabled, unavailable, source-mismatched, or quality-missing, behavior is identical to the current gate.
- A frozen historical product plus aggregate SCC diagnostics, without current enumeration, cannot trigger admission.
