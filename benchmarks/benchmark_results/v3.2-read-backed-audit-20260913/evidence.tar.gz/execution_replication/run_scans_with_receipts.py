#!/usr/bin/env python3
"""Run the six frozen bridge scans with independent per-job receipts."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path('/tmp/sharkmer-read-audit-20260913')
SPECS = ROOT / 'scan_specs'
EXECUTION = ROOT / 'execution_replication_outputs'
SCANNER = Path('/home/claude/repos/sharkmer/scripts/audit_read_bridges.py')
TESTS = Path('/home/claude/repos/sharkmer/tests/test_read_bridges.py')
INPUT_MANIFEST = ROOT / 'inputs' / 'manifest.json'
CANDIDATES = ROOT / 'candidates' / 'candidate_manifest.json'
CANDIDATE_RECEIPT = ROOT / 'candidates' / 'candidate_manifest.receipt.json'
PROTOCOL = ROOT / 'protocol' / 'protocol-v2.md'
RUNNER = Path(__file__)
TIMEOUT_SECONDS = 3600


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open('rb') as handle:
        while block := handle.read(1024 * 1024):
            hasher.update(block)
    return hasher.hexdigest()


def write_new_json(path: Path, value: object) -> None:
    serialized = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, 'wb') as handle:
        handle.write(serialized)
        handle.flush()
        os.fsync(handle.fileno())


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def critical_sources() -> dict[str, str]:
    paths = [
        RUNNER, SCANNER, TESTS, INPUT_MANIFEST, CANDIDATES, CANDIDATE_RECEIPT,
        PROTOCOL, SPECS / 'generate_scan_specs.py', SPECS / 'summary.json',
        SPECS / 'COMMANDS_NOT_RUN.txt',
    ]
    paths.extend(sorted(SPECS.glob('SRR*.scanner_manifest.json')))
    paths.extend(sorted(SPECS.glob('SRR*.expected_prefix.json')))
    paths.append(Path(sys.executable).resolve())
    return {str(path): digest(path) for path in paths}


def load_input_rows() -> dict[str, dict]:
    manifest = json.loads(INPUT_MANIFEST.read_text())
    return {row['accession']: row for row in manifest['rows']}


def input_preflight() -> dict[str, dict]:
    verified: dict[str, dict] = {}
    for accession, row in sorted(load_input_rows().items()):
        path = Path('/tmp/sharkmer-release-comparison/inputs') / f'{accession}.fastq'
        expected = row['benchmark_signature']['input_sha256']
        actual = digest(path)
        if actual != expected:
            raise ValueError(f'Full input hash mismatch for {accession}: {actual} != {expected}')
        verified[accession] = {
            'path': str(path),
            'size_bytes': path.stat().st_size,
            'sha256': actual,
        }
    return verified


def jobs() -> list[dict]:
    summaries = json.loads((SPECS / 'summary.json').read_text())['rows']
    all_jobs = []
    for summary in summaries:
        accession = summary['accession']
        for substitutions, label in ((0, 'exact'), (1, 'one_substitution')):
            all_jobs.append({
                'accession': accession,
                'label': label,
                'max_substitutions': substitutions,
                'expected_event_count': summary['events'],
                'events': SPECS / f'{accession}.scanner_manifest.json',
                'prefix': SPECS / f'{accession}.expected_prefix.json',
                'input': Path('/tmp/sharkmer-release-comparison/inputs') / f'{accession}.fastq',
                'output': EXECUTION / f'{accession}.{label}.json',
                'stdout': EXECUTION / f'{accession}.{label}.stdout.txt',
                'stderr': EXECUTION / f'{accession}.{label}.stderr.txt',
                'receipt': EXECUTION / f'{accession}.{label}.receipt.json',
            })
    if len(all_jobs) != 6:
        raise ValueError(f'Expected six jobs, found {len(all_jobs)}')
    return all_jobs


def run_job(job: dict, source_hashes: dict[str, str], full_inputs: dict[str, dict]) -> dict:
    for key in ('output', 'stdout', 'stderr', 'receipt'):
        path = job[key]
        if path.exists() or path.is_symlink():
            raise ValueError(f'Refusing existing job artifact: {path}')
    command = [
        sys.executable, str(SCANNER), '--fastq', str(job['input']), '--events', str(job['events']),
        '--expected-prefix', str(job['prefix']), '--max-substitutions', str(job['max_substitutions']),
        '--output', str(job['output']),
    ]
    started_at = utc_now()
    started = time.monotonic()
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=TIMEOUT_SECONDS)
        returncode = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
        timed_out = False
        execution_error = None
    except subprocess.TimeoutExpired as error:
        returncode = None
        stdout = error.stdout.decode() if isinstance(error.stdout, bytes) else (error.stdout or '')
        stderr = error.stderr.decode() if isinstance(error.stderr, bytes) else (error.stderr or '')
        timed_out = True
        execution_error = None
    except OSError as error:
        returncode = None
        stdout = ''
        stderr = ''
        timed_out = False
        execution_error = str(error)
    finished_at = utc_now()
    wall_time_seconds = time.monotonic() - started
    job['stdout'].write_text(stdout)
    job['stderr'].write_text(stderr)
    record = {
        'schema_version': 1,
        'accession': job['accession'],
        'label': job['label'],
        'command': command,
        'started_at': started_at,
        'finished_at': finished_at,
        'wall_time_seconds': wall_time_seconds,
        'returncode': returncode,
        'timed_out': timed_out,
        'execution_error': execution_error,
        'timeout_seconds': TIMEOUT_SECONDS,
        'output_path': str(job['output']),
        'stdout_path': str(job['stdout']),
        'stderr_path': str(job['stderr']),
        'stdout_sha256': hashlib.sha256(stdout.encode()).hexdigest(),
        'stderr_sha256': hashlib.sha256(stderr.encode()).hexdigest(),
        'input_full_receipt': full_inputs[job['accession']],
        'event_manifest_sha256': source_hashes[str(job['events'])],
        'expected_prefix_sha256': source_hashes[str(job['prefix'])],
        'scanner_sha256': source_hashes[str(SCANNER)],
        'max_substitutions': job['max_substitutions'],
    }
    if returncode == 0 and job['output'].is_file() and not job['output'].is_symlink():
        try:
            result = json.loads(job['output'].read_text())
            if result.get('max_substitutions') != job['max_substitutions']:
                raise ValueError(f"Unexpected substitutions result for {job['accession']} {job['label']}")
            if len(result.get('events', [])) != job['expected_event_count']:
                raise ValueError(f"Unexpected event count for {job['accession']} {job['label']}")
            provenance = result.get('provenance', {})
            if provenance.get('scanner_sha256') != source_hashes[str(SCANNER)]:
                raise ValueError(f"Scanner provenance mismatch for {job['accession']} {job['label']}")
            if provenance.get('event_manifest_sha256') != source_hashes[str(job['events'])]:
                raise ValueError(f"Event provenance mismatch for {job['accession']} {job['label']}")
            if provenance.get('expected_prefix_manifest_sha256') != source_hashes[str(job['prefix'])]:
                raise ValueError(f"Prefix provenance mismatch for {job['accession']} {job['label']}")
            record['output_sha256'] = digest(job['output'])
            record['event_count'] = len(result['events'])
            record['matching_ledger_records'] = len(result.get('read_evidence', []))
            record['validated_output'] = True
        except (OSError, ValueError, json.JSONDecodeError) as error:
            record['validated_output'] = False
            record['validation_error'] = str(error)
    else:
        record['validated_output'] = False
    write_new_json(job['receipt'], record)
    return record


def main() -> int:
    EXECUTION.mkdir(parents=True, exist_ok=False)
    source_before = critical_sources()
    interpreter = Path(sys.executable).resolve()
    full_inputs = input_preflight()
    write_new_json(EXECUTION / 'source_freeze_before.json', {
        'schema_version': 1,
        'captured_at': utc_now(),
        'sources': source_before,
        'python_executable': str(interpreter),
        'python_sha256': digest(interpreter),
        'python_version': sys.version,
        'full_input_preflight': full_inputs,
    })
    records = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(run_job, job, source_before, full_inputs) for job in jobs()]
        for future in futures:
            records.append(future.result())
    source_after = critical_sources()
    output = {
        'schema_version': 1,
        'concurrency_limit': 2,
        'source_frozen_before': source_before,
        'source_rechecked_after': source_after,
        'source_changed_during_execution': source_before != source_after,
        'jobs': sorted(records, key=lambda row: (row['accession'], row['label'])),
    }
    write_new_json(EXECUTION / 'execution.json', output)
    return 0 if not output['source_changed_during_execution'] and all(
        row['returncode'] == 0 and row['validated_output'] for row in records
    ) else 1


if __name__ == '__main__':
    raise SystemExit(main())
