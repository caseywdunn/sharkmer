# Scanner Attempt Lineage

`execution/execution.json` records six fresh completed scanner jobs, but its
source freeze does not attest the first attempt as clean because only
`execution/run_scans.py` changed after its 12:08 source freeze. The six output
hashes still match that receipt, and the scanner, event manifests, prefix
manifests, candidate manifest, protocol, and generator retain their frozen
hashes.

A direct two-job recovery was started before the hidden original child jobs
became observable through the tool interface. It was stopped with Ctrl-C after
the original receipt appeared. Its exit status and timing are not evidence;
x-mode publication left no overwritten original report.

`execution_replication/run_scans_with_receipts.py` is the approved nonblind,
exact six-job replication. It uses a new output directory, verifies full input
hashes before scanning, freezes and rechecks all critical sources including the
resolved Python executable, limits concurrency to two, and writes a receipt for
each job before the aggregate receipt. It completed with six validated outputs,
unchanged source receipts, and output hashes exactly matching the original six.
