import argparse
import importlib.util
from pathlib import Path
import re


parser = argparse.ArgumentParser()
parser.add_argument("--pre-fix", required=True)
parser.add_argument("--candidate", required=True)
parser.add_argument("--workspace", type=Path, required=True)
arguments = parser.parse_args()
for commit in (arguments.pre_fix, arguments.candidate):
    if re.fullmatch("[0-9a-f]{40}", commit) is None:
        raise ValueError("Use exact full commit hashes")
specification = importlib.util.spec_from_file_location(
    "clean_export_builder", "/tmp/sharkmer-release-comparison/build_versions.py"
)
builder = importlib.util.module_from_spec(specification)
specification.loader.exec_module(builder)
builder.WORKSPACE = arguments.workspace
builder.VERSIONS = {"pre_fix": arguments.pre_fix, "candidate": arguments.candidate}
builder.main()
