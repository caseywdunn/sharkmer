{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-high-copy-20260911/issue154-execution/reference_databases/insecta/references.fasta",
  "number-of-letters": 26115,
  "number-of-sequences": 41,
  "last-updated": "2026-09-11T09:20:00",
  "number-of-volumes": 1,
  "bytes-total": 48787,
  "bytes-to-cache": 7230,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
