import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys


PREVIOUS = Path("/tmp/sharkmer-release-comparison")
RELEASE_COMMIT = "5a664680c91ad59f32b8c2a847b8fef37f34a0ae"


def load_module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def install_adapters(helper, legacy):
    original_legacy = helper.validate_legacy_outputs
    original_shared = helper.validate_shared_stats

    def validate_legacy(output_dir, invocation, panel, stats, pcr_results):
        sample = invocation["sample_prefix"]
        expected_genes = {
            f"{sample}_{entry['gene_name']}.fasta": entry["gene_name"]
            for entry in pcr_results if entry["status"] == "success"
        }
        original_parser = helper.parse_fasta_file
        helper.parse_fasta_file = lambda path: legacy.parse_legacy_fasta(
            path, sample, expected_genes[Path(path).name]
        )
        try:
            return original_legacy(output_dir, invocation, panel, stats, pcr_results)
        finally:
            helper.parse_fasta_file = original_parser

    def validate_shared(stats, invocation, panel, input_record, command, expected_version):
        results = original_shared(stats, invocation, panel, input_record, command, expected_version)
        if invocation["version"] != "baseline":
            expected_source = {
                "kind": "local_files", "inputs": [input_record["path"]],
                "paired": False, "max_reads": invocation["depth"],
            }
            if stats.get("input_source") != expected_source:
                raise ValueError("Current stats input source differs from frozen invocation")
        return results

    helper.validate_legacy_outputs = validate_legacy
    helper.validate_shared_stats = validate_shared


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--builds", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    protocol = json.loads(arguments.protocol.read_text())
    builds = json.loads(arguments.builds.read_text())
    helper_path = PREVIOUS / "execution/receipts/driver.py"
    if hashlib.sha256(helper_path.read_bytes()).hexdigest() != "f0d7eee4631819921eadb6b4dddf05b422c5e6eaf4c554db82259cd1c41bec97":
        raise ValueError("Frozen measurement helper changed")
    helper = load_module("frozen_benchmark_helper", helper_path)
    adapter_path = PREVIOUS / "postprocess_legacy.py"
    if helper.sha256_file(adapter_path) != "f9e58a665c530b71c96ad7fb79508ba1598df7119feb7c52ee403aeb3e790aef":
        raise ValueError("Corrected legacy adapter changed")
    install_adapters(helper, load_module("corrected_legacy_adapter", adapter_path))
    if arguments.output.exists():
        raise ValueError("Output exists; preserve prior measurements rather than rerunning them")
    baseline_role = protocol["baseline_role"]
    if baseline_role not in ("pre_fix", "baseline") or set(builds["versions"]) != {baseline_role, "candidate"}:
        raise ValueError("Expected protocol baseline role and candidate clean builds")
    original_builds = json.loads((PREVIOUS / "builds.json").read_text())
    for version, build in builds["versions"].items():
        if build["commit"] != protocol["expected_commits"][version]:
            raise ValueError("Build commit differs from preregistered protocol")
        helper.EXPECTED_COMMITS = {"baseline": RELEASE_COMMIT, "candidate": build["commit"]}
        helper.verify_builds({"schema_version": 1, "versions": {
            "baseline": build if version == "baseline" else original_builds["versions"]["baseline"],
            "candidate": build,
        }})
    compared_builds = list(builds["versions"].values())
    for field in ("rustc", "cargo", "cargo_artifact_features", "cargo_artifact_profile"):
        if compared_builds[0][field] != compared_builds[1][field]:
            raise ValueError(f"Build configurations differ: {field}")
    original_protocol = json.loads((PREVIOUS / "protocol.json").read_text())
    settings = original_protocol["settings"]
    if protocol["settings"] != settings:
        raise ValueError("Algorithm and resource settings differ from original comparison")
    helper.validate_cpu_list(settings["cpu_list"], settings["threads"])
    validator_build = original_builds["versions"]["candidate"]
    if helper.source_tree_sha256(Path(validator_build["source_export"])) != validator_build["source_tree_sha256_after_build"]:
        raise ValueError("Frozen validator source changed")
    runner, blast, validator = helper.load_validator(validator_build["source_export"])
    input_document = json.loads((PREVIOUS / "inputs.json").read_text())
    selected_accessions = {sample["input"] for sample in protocol["samples"]}
    input_document["inputs"] = [record for record in input_document["inputs"] if record["id"] in selected_accessions]
    inputs = helper.verify_inputs(input_document)
    if set(inputs) != selected_accessions:
        raise ValueError("Missing selected input")
    cells = set()
    for sample in protocol["samples"]:
        cell = (sample["panel"], sample["input"], sample["depth"])
        if cell in cells or type(sample["pairs"]) is not int or sample["pairs"] < 1:
            raise ValueError("Duplicate cell or invalid repetition count")
        if sample["depth"] not in inputs[sample["input"]]["prefixes"]:
            raise ValueError("Unregistered input prefix")
        cells.add(cell)
    panels = {}
    for panel_record in original_protocol["panels"]:
        if panel_record["name"] not in {sample["panel"] for sample in protocol["samples"]}:
            continue
        if helper.sha256_file(panel_record["path"]) != panel_record["sha256"]:
            raise ValueError("Original panel changed")
        data = runner.load_panel_yaml(Path(panel_record["path"]))
        metadata_names = [entry["gene"] for entry in protocol["target_metadata"][panel_record["name"]]]
        if len(metadata_names) != len(set(metadata_names)) or set(metadata_names) != set(runner.panel_gene_names(data)):
            raise ValueError("Target metadata identifiers differ from frozen panel")
        prefix = data.get("gene_prefix") or data["name"]
        panels[panel_record["name"]] = {
            **panel_record, "data": data, "output_prefix": prefix,
            "stats_genes": {f"{prefix}_{gene}" for gene in runner.panel_gene_names(data)},
        }
    if not blast.check_blastn_available() or not blast.check_makeblastdb_available():
        raise ValueError("BLAST tools unavailable")
    arguments.output.mkdir(parents=True)
    frozen = {
        "protocol": helper.freeze_receipt(arguments.protocol, arguments.output / "receipts/protocol.json"),
        "builds": helper.freeze_receipt(arguments.builds, arguments.output / "receipts/builds.json"),
        "driver": helper.freeze_receipt(__file__, arguments.output / "receipts/benchmark.py"),
        "helper": helper.freeze_receipt(helper_path, arguments.output / "receipts/helper.py"),
        "legacy_adapter": helper.freeze_receipt(adapter_path, arguments.output / "receipts/postprocess_legacy.py"),
        "builder": helper.freeze_receipt(PREVIOUS / "build_versions.py", arguments.output / "receipts/build_versions.py"),
        "build_wrapper": helper.freeze_receipt(Path(__file__).with_name("build.py"), arguments.output / "receipts/build.py"),
        "original_builds": helper.freeze_receipt(PREVIOUS / "builds.json", arguments.output / "receipts/original-builds.json"),
        "original_protocol": helper.freeze_receipt(PREVIOUS / "protocol.json", arguments.output / "receipts/original-protocol.json"),
        "inputs": helper.freeze_receipt(PREVIOUS / "inputs.json", arguments.output / "receipts/inputs.json"),
    }
    schedule = []
    for sample_index, sample in enumerate(protocol["samples"]):
        for pair_index in range(1, sample["pairs"] + 1):
            order = (baseline_role, "candidate") if (sample_index + pair_index) % 2 else ("candidate", baseline_role)
            for position, version in enumerate(order):
                cell = f"{sample['panel']}/{sample['input']}/{sample['depth']}"
                schedule.append({
                    "invocation_id": f"{sample_index:03d}_{cell.replace('/', '_')}_pair{pair_index}_{version}",
                    "cell": cell, "cell_index": sample_index, "panel": sample["panel"],
                    "input": sample["input"], "taxon": sample["taxon"], "depth": sample["depth"],
                    "pair_index": pair_index, "order_position": position + 1, "version": version,
                })
    helper.atomic_write_json(arguments.output / "provenance.json", {
        "protocol": protocol, "frozen_receipts": frozen, "builds": builds,
        "validator": validator, "inputs": input_document, "schedule": schedule,
        "started_at": helper.utc_now(), "timing_boundary": "all invocations before any BLAST",
        "machine": runner.get_machine_info(), "cpu_affinity": sorted(os.sched_getaffinity(0)),
    })
    results = {}
    for invocation in schedule:
        result = helper.run_invocation(
            invocation, builds["versions"][invocation["version"]], panels[invocation["panel"]],
            inputs[invocation["input"]], settings, arguments.output, runner,
        )
        results[invocation["invocation_id"]] = result
        print(invocation["invocation_id"], result["status"], result["execution"]["wall_time_s"], flush=True)
    databases, references = helper.prepare_reference_databases(panels, blast, arguments.output)
    for invocation in schedule:
        identity = invocation["invocation_id"]
        results[identity] = helper.finalize_classification(
            invocation, results[identity], panels[invocation["panel"]], arguments.output,
            blast, databases[invocation["panel"]],
        )
        if any(
            product.get("reference_match", {}).get("status") == "failed_run"
            for gene in results[identity].get("genes", []) for product in gene["products"]
        ):
            results[identity].update({
                "status": "failed", "classification_status": "failed",
                "failure": "per_product_blast_failed_run",
            })
            helper.atomic_write_json(arguments.output / "results" / f"{identity}.json", results[identity])
    summary_schedule = copy.deepcopy(schedule)
    for invocation in summary_schedule:
        if invocation["version"] == "pre_fix":
            invocation["version"] = "baseline"
    summary = helper.summarize_results(summary_schedule, results)
    summary["baseline_role"] = baseline_role
    summary["protocol"] = protocol
    summary["references"] = references
    summary["limitations"] = protocol["limitations"]
    summary["release_gate"] = "Not automatically decided: review scoped product evidence, runtime and RSS, including any losses or increases."
    helper.atomic_write_json(arguments.output / "comparison.json", summary)
    return bool(summary["failures"])


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
