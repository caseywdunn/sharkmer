{
  "version": "1.2",
  "dbname": "ref_db",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/tmp/sharkmer-k-sweep-20260911/discovery-execution/k19/reference_databases/insecta/references.fasta",
  "number-of-letters": 26115,
  "number-of-sequences": 41,
  "last-updated": "2026-09-11T14:12:00",
  "number-of-volumes": 1,
  "bytes-total": 48795,
  "bytes-to-cache": 7238,
  "files": [
    "ref_db.ndb",
    "ref_db.nhr",
    "ref_db.nin",
    "ref_db.not",
    "ref_db.nsq",
    "ref_db.ntf",
    "ref_db.nto"
  ]
}
