//! Scratch-only observer. This module is never copied into production source.

use anyhow::{Context, Result, ensure};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::fs::OpenOptions;
use std::io::Write;
use std::path::{Path, PathBuf};

pub(super) const ROW_CAP: usize = 4096;
const BYTE_CAP: usize = 8 * 1024 * 1024;

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct CompletionRow {
    pub ordinal: usize,
    pub sequence_length: usize,
    pub sequence_sha256: String,
    pub reverse_complement_sha256: String,
    pub retention_disposition: String,
    pub omitted_self_loop_occurrences: usize,
    pub cyclic_scc_occurrences: usize,
    pub retained_collision_occurrences: usize,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub(crate) struct CompletionLedger {
    pub observed_completions: usize,
    pub omitted_rows: usize,
    pub disposition_counts: BTreeMap<String, usize>,
    pub rows: Vec<CompletionRow>,
}

fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

impl CompletionLedger {
    pub(super) fn observe(
        &mut self,
        sequence: &str,
        disposition: Option<&str>,
        causes: [usize; 3],
    ) {
        self.observe_with_cap(sequence, disposition, causes, ROW_CAP);
    }

    fn observe_with_cap(
        &mut self,
        sequence: &str,
        disposition: Option<&str>,
        causes: [usize; 3],
        cap: usize,
    ) {
        self.observed_completions += 1;
        let disposition = disposition.unwrap_or("retained");
        *self
            .disposition_counts
            .entry(disposition.to_owned())
            .or_default() += 1;
        if self.rows.len() >= cap {
            self.omitted_rows += 1;
            return;
        }
        let reverse_complement: Vec<u8> = sequence
            .bytes()
            .rev()
            .map(|base| match base {
                b'A' => b'T',
                b'C' => b'G',
                b'G' => b'C',
                b'T' => b'A',
                _ => panic!("scratch graph spelling contains a non-ACGT base"),
            })
            .collect();
        self.rows.push(CompletionRow {
            ordinal: self.observed_completions,
            sequence_length: sequence.len(),
            sequence_sha256: digest(sequence.as_bytes()),
            reverse_complement_sha256: digest(&reverse_complement),
            retention_disposition: disposition.to_owned(),
            omitted_self_loop_occurrences: causes[0],
            cyclic_scc_occurrences: causes[1],
            retained_collision_occurrences: causes[2],
        });
    }

    pub(super) fn publish(
        &self,
        output: &str,
        sample: &str,
        gene: &str,
        threshold: u32,
    ) -> Result<PathBuf> {
        self.publish_with_cap(Path::new(output), sample, gene, threshold, BYTE_CAP)
    }

    fn publish_with_cap(
        &self,
        output: &Path,
        sample: &str,
        gene: &str,
        threshold: u32,
        byte_cap: usize,
    ) -> Result<PathBuf> {
        #[derive(Serialize)]
        struct Envelope<'a> {
            schema_version: u32,
            purpose: &'static str,
            sample: &'a str,
            gene: &'a str,
            threshold: u32,
            row_cap: usize,
            byte_cap: usize,
            complete: bool,
            ledger: &'a CompletionLedger,
        }
        let envelope = Envelope {
            schema_version: 1,
            purpose: "scratch_pre_retention_completed_repeat_withheld_graph_paths",
            sample,
            gene,
            threshold,
            row_cap: ROW_CAP,
            byte_cap,
            complete: self.omitted_rows == 0,
            ledger: self,
        };
        let encoded = serde_yaml_ng::to_string(&envelope)?;
        ensure!(
            encoded.len() <= byte_cap,
            "scratch completion ledger exceeds its byte cap"
        );
        let path = output.join(format!(
            "completion_ledger_{}_{}.yaml",
            digest(gene.as_bytes()),
            threshold
        ));
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
            .with_context(|| {
                format!(
                    "Cannot exclusively create scratch ledger {}",
                    path.display()
                )
            })?;
        file.write_all(encoded.as_bytes())?;
        file.sync_all()?;
        Ok(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scratch_ledger_preserves_orientation_duplicates_and_row_bound() {
        let mut ledger = CompletionLedger::default();
        ledger.observe_with_cap("ACGTA", None, [0, 1, 0], 3);
        ledger.observe_with_cap("ACGTA", Some("marker_cap"), [0, 1, 0], 3);
        ledger.observe_with_cap("TACGT", Some("path_cap"), [0, 1, 0], 3);
        ledger.observe_with_cap("TTTAA", Some("marker_cap"), [0, 1, 0], 3);
        assert_eq!(ledger.observed_completions, 4);
        assert_eq!(ledger.rows.len(), 3);
        assert_eq!(ledger.omitted_rows, 1);
        assert_eq!(ledger.rows[0].sequence_sha256, digest(b"ACGTA"));
        assert_eq!(
            ledger.rows[0].sequence_sha256,
            ledger.rows[1].sequence_sha256
        );
        assert_eq!(
            ledger.rows[0].reverse_complement_sha256,
            ledger.rows[2].sequence_sha256
        );
        assert_eq!(ledger.rows[2].ordinal, 3);
        assert_eq!(ledger.disposition_counts["marker_cap"], 2);
    }

    #[test]
    fn scratch_ledger_zero_completion_byte_cap_and_no_overwrite() {
        let directory = tempfile::tempdir().unwrap();
        let ledger = CompletionLedger::default();
        assert!(
            ledger
                .publish_with_cap(directory.path(), "s", "g", 2, 1)
                .is_err()
        );
        assert_eq!(std::fs::read_dir(directory.path()).unwrap().count(), 0);
        let path = ledger
            .publish_with_cap(directory.path(), "s", "g", 2, BYTE_CAP)
            .unwrap();
        let original = std::fs::read(&path).unwrap();
        assert!(
            ledger
                .publish_with_cap(directory.path(), "s", "g", 2, BYTE_CAP)
                .is_err()
        );
        assert_eq!(std::fs::read(path).unwrap(), original);
        let decoded: serde_yaml_ng::Value = serde_yaml_ng::from_slice(&original).unwrap();
        assert_eq!(decoded["complete"].as_bool(), Some(true));
        assert_eq!(decoded["ledger"]["observed_completions"].as_u64(), Some(0));
    }
}
