import copy
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import yaml

from audit_ledger import BYTE_CAP, ROW_CAP, audit, historical_matches, validate_ledger


def fixture():
    seq = "A" * 475
    row = {"ordinal": 1, "sequence_length": len(seq), "sequence_sha256": hashlib.sha256(seq.encode()).hexdigest(), "reverse_complement_sha256": hashlib.sha256(b"T" * 475).hexdigest(), "retention_disposition": "marker_cap", "omitted_self_loop_occurrences": 0, "cyclic_scc_occurrences": 1, "retained_collision_occurrences": 0}
    search = {"threshold": 2, "withheld_candidate_paths": 1, "retention": {"observed_withheld_paths": 1, "retained_paths": 0, "observed_not_retained_paths": 1, "dropped_marker_cap": 1, "dropped_oversize_sequence": 0, "dropped_oversize_marker_set": 0, "dropped_path_cap": 0, "dropped_sequence_base_cap": 0}}
    doc = {"schema_version": 1, "purpose": "scratch_pre_retention_completed_repeat_withheld_graph_paths", "sample": "s", "gene": "g", "threshold": 2, "row_cap": ROW_CAP, "byte_cap": BYTE_CAP, "complete": True, "ledger": {"observed_completions": 1, "omitted_rows": 0, "disposition_counts": {"marker_cap": 1}, "rows": [row]}}
    historical = {"sequence": seq, "length": len(seq), "sequence_sha256": row["sequence_sha256"]}
    search.update(withheld_by_self_loop_node_paths=0, withheld_by_scc_node_paths=1, withheld_by_collision_edge_paths=0)
    return doc, search, historical


class LedgerControls(unittest.TestCase):
    def full_fixture(self, root):
        control, observed, source = (root / name for name in ("control", "observed", "source"))
        for directory in (control, observed, source / "scripts"):
            directory.mkdir(parents=True)
        sample = "synthetic"
        genes, history, paths = [], [], {}
        for name in ("insecta_12S", "insecta_16S_2", *(f"empty_{index}" for index in range(19))):
            products, thresholds = [], []
            if name.startswith("insecta_"):
                sequences = ["C" * 495, "G" * 489, "A" * 475] if name.endswith("12S") else ["C" * 590]
                all_sequences = sequences + ["AC" * 240] * 23 if name.endswith("12S") else sequences
                doc, search, _ = fixture()
                doc.update(sample=sample, gene=name)
                rows = []
                for index, sequence in enumerate(all_sequences):
                    row = dict(doc["ledger"]["rows"][0], ordinal=index + 1, sequence_length=len(sequence), sequence_sha256=hashlib.sha256(sequence.encode()).hexdigest(), reverse_complement_sha256=hashlib.sha256(sequence.translate(str.maketrans("ACGT", "TGCA"))[::-1].encode()).hexdigest(), retention_disposition="retained" if index < len(sequences) else "marker_cap")
                    rows.append(row)
                doc["ledger"].update(observed_completions=len(rows), rows=rows, disposition_counts={"retained": len(sequences)})
                if len(rows) > len(sequences):
                    doc["ledger"]["disposition_counts"]["marker_cap"] = len(rows) - len(sequences)
                search.update(path_search_evaluated=True, withheld_candidate_paths=len(rows), withheld_by_scc_node_paths=len(rows))
                search["retention"].update(observed_withheld_paths=len(rows), retained_paths=len(sequences), observed_not_retained_paths=len(rows) - len(sequences), dropped_marker_cap=len(rows) - len(sequences))
                thresholds = [search]
                for sequence in sequences:
                    products.append({"oriented_sequence": sequence, "sequence_length": len(sequence), "sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest(), "sources": [{"threshold": 2, "omitted_self_loop_marker_occurrences": 0, "cyclic_scc_marker_occurrences": 1, "retained_collision_marker_occurrences": 0}]})
                historical_sequence = sequences[-1]
                history.append({"accession": "SRR31887760", "gene": name.removeprefix("insecta_"), "sequence": historical_sequence, "length": len(historical_sequence), "sequence_sha256": hashlib.sha256(historical_sequence.encode()).hexdigest()})
                path = observed / f"completion_ledger_{hashlib.sha256(name.encode()).hexdigest()}_2.yaml"
                path.write_text(yaml.safe_dump(doc))
                paths[name] = path
            genes.append({"gene_name": name, "uncertain_products": {"thresholds": thresholds, "products": products, "excluded_standard_equivalent_path_records": 0}})
        stats = {"pcr_results": genes}
        for directory in (control, observed):
            (directory / f"{sample}.stats.yaml").write_text(yaml.safe_dump(stats))
        historical = root / "history.json"
        historical.write_text(json.dumps({"rows": history}))
        package = types.ModuleType("sharkmer_validate")
        package.runner = types.SimpleNamespace(_parse_stats_yaml=lambda path: yaml.safe_load(path.read_text()), _validate_output_manifest=lambda *args: {"schema_version": 2}, parse_fasta_products=lambda *args: [])
        return (control, observed, sample, historical, source), paths, package

    def test_full_directory_audit_and_missing_extra_or_mismatched_ledgers(self):
        # Producer validation has its own repository tests. Mock it here to
        # exercise all 21-target observer-directory and source-binding logic.
        with tempfile.TemporaryDirectory() as temporary:
            arguments, paths, package = self.full_fixture(Path(temporary))
            with patch.dict("sys.modules", {"sharkmer_validate": package}):
                result = audit(*arguments)
                self.assertEqual(result["status"], "pass")
                self.assertEqual(len(result["thresholds"]), 2)
                target = paths["insecta_12S"]
                original = target.read_text()
                target.unlink()
                with self.assertRaisesRegex(ValueError, "Missing"):
                    audit(*arguments)
                target.write_text(original)
                extra = arguments[1] / "completion_ledger_extra.yaml"
                extra.write_text(original)
                with self.assertRaisesRegex(ValueError, "Unexpected/missing"):
                    audit(*arguments)
                extra.unlink()
                document = yaml.safe_load(original)
                document["ledger"]["rows"][0]["sequence_sha256"] = "0" * 64
                target.write_text(yaml.safe_dump(document))
                with self.assertRaisesRegex(ValueError, "Retained source missing"):
                    audit(*arguments)

    def test_positive_dropped_completion(self):
        doc, search, historical = fixture()
        rows = validate_ledger(doc, "s", "g", search)
        self.assertEqual(historical_matches([(2, rows[0])], historical)[0]["retention_disposition"], "marker_cap")

    def test_synthetic_477_is_not_475(self):
        doc, _, _ = fixture()
        wrong = {"sequence": "A" * 477, "length": 477, "sequence_sha256": hashlib.sha256(b"A" * 477).hexdigest()}
        self.assertEqual(historical_matches([(2, doc["ledger"]["rows"][0])], wrong), [])

    def test_exact_reverse_complement_is_explicit(self):
        doc, _, _ = fixture()
        reverse = {"sequence": "T" * 475, "length": 475, "sequence_sha256": hashlib.sha256(b"T" * 475).hexdigest()}
        self.assertEqual(historical_matches([(2, doc["ledger"]["rows"][0])], reverse)[0]["orientation"], "reverse_complement")

    def test_duplicates_are_occurrences(self):
        doc, search, _ = fixture()
        doc["ledger"]["rows"].append(dict(doc["ledger"]["rows"][0], ordinal=2))
        doc["ledger"]["observed_completions"] = search["withheld_candidate_paths"] = 2
        search["withheld_by_scc_node_paths"] = 2
        doc["ledger"]["disposition_counts"]["marker_cap"] = 2
        for key in ("observed_withheld_paths", "observed_not_retained_paths", "dropped_marker_cap"):
            search["retention"][key] = 2
        self.assertEqual(len(validate_ledger(doc, "s", "g", search)), 2)

    def test_zero_searched_threshold(self):
        doc, search, _ = fixture()
        doc["ledger"] = {"observed_completions": 0, "omitted_rows": 0, "disposition_counts": {}, "rows": []}
        search["withheld_candidate_paths"] = 0
        search["withheld_by_scc_node_paths"] = 0
        search["retention"] = {key: 0 for key in search["retention"]}
        self.assertEqual(validate_ledger(doc, "s", "g", search), [])

    def test_overflow_missing_forged_and_context_rows_fail(self):
        original, search, _ = fixture()
        changes = [
            lambda d: d.update(complete=False),
            lambda d: d["ledger"].update(omitted_rows=1),
            lambda d: d["ledger"].update(rows=[]),
            lambda d: d["ledger"]["rows"][0].update(ordinal=2),
            lambda d: d["ledger"]["rows"][0].update(sequence_sha256="bad"),
            lambda d: d["ledger"]["rows"][0].update(retention_disposition="retained"),
            lambda d: d.update(threshold=3),
            lambda d: d.update(byte_cap=BYTE_CAP + 1),
            lambda d: d.update(schema_version=True),
            lambda d: d["ledger"].update(observed_completions=True),
            lambda d: d["ledger"]["disposition_counts"].update(marker_cap=True),
            lambda d: d["ledger"]["rows"][0].update(ordinal=True),
            lambda d: d["ledger"]["rows"][0].update(cyclic_scc_occurrences=0, retained_collision_occurrences=1),
        ]
        for change in changes:
            with self.subTest(change=change):
                doc = copy.deepcopy(original)
                change(doc)
                with self.assertRaises(ValueError):
                    validate_ledger(doc, "s", "g", search)

    def test_corrupt_historical_identity_fails(self):
        doc, _, historical = fixture()
        historical["sequence_sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            historical_matches([(2, doc["ledger"]["rows"][0])], historical)


if __name__ == "__main__":
    unittest.main()
