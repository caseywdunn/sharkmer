# Scratch observer execution

Root submits these commands from the repository root. No command has been
submitted by the implementation agent. Preserve every attempt; use a fresh
output name if a prior attempt exists. Production source remains untouched.

## Build and controls

```sh
sbatch --output=tmp/inclusive-release-20260929/slurm/dros12s-build-v1.log \
  tmp/inclusive-release-20260929/dros12s/build_controls.sbatch \
  --source tmp/inclusive-release-20260929/dros12s/source-v1 \
  --source-freeze tmp/inclusive-release-20260929/dros12s/source-freeze-v1.json \
  --output tmp/inclusive-release-20260929/dros12s/build-v1 \
  --cargo /nfs/roberts/project/pi_cwd7/cwd7/sharkmer/tmp/uncertain-products-20260927/toolchain/cargo/bin/cargo \
  --rustc /nfs/roberts/project/pi_cwd7/cwd7/sharkmer/tmp/uncertain-products-20260927/toolchain/cargo/bin/rustc
```

The wrapper reuses the preceding reviewed `build_snapshot.build` and
`run_compiled_checks.run_step` helpers. It builds a default-backend release
binary, checks formatting and Clippy with warnings denied, and runs the full
default release test suite. The three new observer tests must appear as passing
in the test log. The snapshot, `build.json` and `rust-controls.json` bind the
exact frozen sources, build/check scripts, compilers, configuration and binary.
Cargo output remains outside the frozen source directory.

## Replay after independent execution clearance

The independent review must have `status: pass`,
`purpose: scratch_completion_ledger_execution_clearance` and a
`reviewed_artifacts` map. Each value is `{path, sha256, size_bytes}` and must
cover the binary, source freeze, build/controls receipts, historical identities,
exact input/panel, previous control receipt and all its non-lock files, replay
and audit scripts, copied bounded launcher, the job's Python interpreter,
`/usr/bin/prlimit`, `/usr/bin/time`, and `/usr/bin/taskset`. The review must
verify successful Rust observer controls and the binary's source binding.
The wrapper rejects missing or stale bindings before reading the biological
input with the assembler. A digest verification of the pinned FASTQ occurs
during preflight, outside the timed process invocation.

```sh
sbatch --output=tmp/inclusive-release-20260929/slurm/dros12s-replay-v1.log \
  tmp/inclusive-release-20260929/dros12s/run_replay.sbatch \
  --source tmp/inclusive-release-20260929/dros12s/source-v1 \
  --source-freeze tmp/inclusive-release-20260929/dros12s/source-freeze-v1.json \
  --binary tmp/inclusive-release-20260929/dros12s/build-v1/sharkmer \
  --build-receipt tmp/inclusive-release-20260929/dros12s/build-v1/build.json \
  --rust-controls tmp/inclusive-release-20260929/dros12s/build-v1/rust-controls.json \
  --execution-review benchmarks/benchmark_results/v3.2-inclusive-release-20260929/review/dros12s_execution_review.json \
  --control tmp/inclusive-output-20260929/attempt-v1/runs/SRR31887760/default \
  --control-receipt tmp/inclusive-output-20260929/attempt-v1/SRR31887760.default.json \
  --historical benchmarks/benchmark_results/v3.2-uncertain-products-20260927/inputs/historical_losses.json \
  --panel benchmarks/benchmark_results/v3.2-uncertain-products-20260927/inputs/insecta.yaml \
  --fastq tmp/uncertain-products-20260927/reads/SRR31887760.first1M_R1.retry1.fastq \
  --output tmp/inclusive-release-20260929/dros12s/replay-v1
```

The two CPU IDs are selected from the actual Slurm allocation and written in
the command and child-constraint receipt. Search uses normal inclusive defaults
and the exact preceding 21-target panel and 1M R1 prefix. The only experimental
environment value is `SHARKMER_SCRATCH_COMPLETION_LEDGER=1`. Independent review
of the complete replay must precede interpretation. Its timing is diagnostic
overhead, not a release performance comparison.
