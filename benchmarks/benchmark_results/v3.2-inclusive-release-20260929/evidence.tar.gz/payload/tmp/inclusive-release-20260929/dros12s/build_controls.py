#!/usr/bin/env python3
"""Build and check the scratch observer inside a root-submitted allocation."""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
OLD = ROOT / "benchmarks/benchmark_results/v3.2-uncertain-products-20260927"
sys.path.insert(0, str(OLD))
import build_snapshot as builder
from run_compiled_checks import run_step


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser()
    for name in ("source", "source-freeze", "output", "cargo", "rustc"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    require(os.environ.get("SLURM_JOB_ID"), "Build/check execution requires a submitted Slurm allocation")
    require(not os.environ.get("SHARKMER_SCRATCH_COMPLETION_LEDGER"), "Leave scratch sidecar publication disabled during ordinary tests")
    source, output = args.source.resolve(), args.output.resolve()
    require(source != output and source not in output.parents, "Build output must be outside frozen source")
    frozen = json.loads(args.source_freeze.read_text())
    require(frozen["base_commit"] == "ed04bdec5178d055b47cc8085135ee5ae2600998", "Wrong source commit")
    before = builder.tree(source)
    require(set(before) == set(frozen["files"]), "Frozen source file set mismatch")
    for name, row in before.items():
        require(all(row[key] == frozen["files"][name][key] for key in ("sha256", "size_bytes")), "Frozen source mismatch: " + name)
    output.mkdir(parents=True, exist_ok=False)
    dependencies = [Path(__file__), Path(__file__).with_name("build_controls.sbatch"), OLD / "build_snapshot.py", OLD / "run_compiled_checks.py", args.source_freeze]
    bindings = {str(path.resolve()): builder.fingerprint(path.resolve()) for path in dependencies}
    snapshot = {"schema_version": 1, "role": "scratch_completion_observer", "source": str(source), "files": before, "exporter": builder.fingerprint(Path(__file__).resolve()), "provenance": {"base_commit": frozen["base_commit"], "source_freeze": builder.fingerprint(args.source_freeze.resolve()), "changed_paths": frozen["changed_paths"]}}
    builder.write_new(output / "snapshot.json", snapshot)
    receipt = {"schema_version": 1, "status": "failed", "steps": [], "source_before": before, "bound_artifacts_before": bindings, "source_freeze": builder.fingerprint(args.source_freeze.resolve()), "slurm_job_id": os.environ["SLURM_JOB_ID"], "biological_inputs_run": False}
    try:
        cpus = sorted(os.sched_getaffinity(0))[:2]
        require(len(cpus) == 2, "Two allocated CPUs required")
        os.sched_setaffinity(0, cpus)
        receipt["cpu_affinity"] = sorted(os.sched_getaffinity(0))
        builder.build(output, args.cargo.absolute(), args.rustc.absolute())
        build = json.loads((output / "build.json").read_text())
        require(build["status"] == "complete" and build["source_before"] == before == build["source_after"], "Build provenance mismatch")
        receipt["build_receipt"] = builder.fingerprint(output / "build.json")
        receipt["binary"] = builder.fingerprint(output / "sharkmer")
        sysroot = Path(build["compiler_sysroot"])
        tools = {name: (sysroot / "bin" / name).resolve() for name in ("cargo", "rustc", "rustfmt", "cargo-fmt", "cargo-clippy", "clippy-driver")}
        receipt["tools_before"] = {name: builder.fingerprint(path) for name, path in tools.items()}
        environment = dict(os.environ)
        for key in ("RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER"):
            environment.pop(key, None)
        environment.update(PATH=str(sysroot / "bin") + os.pathsep + environment.get("PATH", ""), RUSTC=str(tools["rustc"]), RUSTFMT=str(tools["rustfmt"]), CARGO_TARGET_DIR=str(output / "target"), CARGO_BUILD_JOBS="2", LC_ALL="C")
        receipt["cargo_configs_before"] = builder.cargo_configs(source, environment)
        cargo = str(tools["cargo"])
        commands = [("format", [cargo, "fmt", "--all", "--check"]), ("clippy-default", [cargo, "clippy", "--locked", "--offline", "--all-targets", "--", "-D", "warnings"]), ("release-tests-default", [cargo, "test", "--locked", "--offline", "--release"])]
        for name, command in commands:
            step = run_step(name, command, source, environment, output)
            receipt["steps"].append(step)
            require(step["status"] == "pass", "Scratch check failed: " + name)
            require(builder.tree(source) == before, "Frozen source changed during checks")
        test_log = (output / "release-tests-default.log").read_text()
        for name in ("scratch_ledger_preserves_orientation_duplicates_and_row_bound", "scratch_ledger_zero_completion_byte_cap_and_no_overwrite", "scratch_ledger_observes_all_retention_drop_reasons_before_return"):
            require(name + " ... ok" in test_log, "Missing passing scratch Rust control: " + name)
        receipt["tools_after"] = {name: builder.fingerprint(path) for name, path in tools.items()}
        receipt["cargo_configs_after"] = builder.cargo_configs(source, environment)
        require(receipt["tools_before"] == receipt["tools_after"] and receipt["cargo_configs_before"] == receipt["cargo_configs_after"], "Compiler/configuration changed")
        require(builder.fingerprint(output / "sharkmer") == receipt["binary"], "Exported binary changed during checks")
        receipt["status"] = "pass"
    except Exception as error:
        receipt["error"] = repr(error)
    finally:
        receipt["source_after"] = builder.tree(source)
        receipt["bound_artifacts_after"] = {str(path.resolve()): builder.fingerprint(path.resolve()) for path in dependencies}
        if receipt["source_after"] != before or receipt["bound_artifacts_after"] != bindings:
            receipt.update(status="failed", bookend_error="Frozen source or build/check dependencies changed")
        builder.write_new(output / "rust-controls.json", receipt)
    require(receipt["status"] == "pass", receipt.get("error", "Scratch checks failed"))
    print(json.dumps({"status": "pass", "output": str(output), "binary": receipt["binary"]}))


if __name__ == "__main__":
    main()
