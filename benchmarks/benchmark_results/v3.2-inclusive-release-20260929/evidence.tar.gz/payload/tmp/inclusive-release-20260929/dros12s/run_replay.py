#!/usr/bin/env python3
"""Run one bounded scratch replay after an independently reviewed build."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import yaml

from audit_ledger import audit, fingerprint, require

PREFIX = {"sha256": "b952eb9be7212ae79da85b0548b1c74a0343637d8af400ae9a08968b297638ae", "size_bytes": 267366976}
PANEL_SHA256 = "a28cd3b2d045270b3f6bf3e2e6f9362a4dfb6d55c6adb42d445461ec95a64160"
ADDRESS_SPACE = 40 * 1024**3
TIMEOUT = 1800


def write_new(path, data):
    with Path(path).open("x") as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main():
    parser = argparse.ArgumentParser()
    for name in ("binary", "source", "source-freeze", "control", "control-receipt", "historical", "fastq", "panel", "output", "build-receipt", "rust-controls", "execution-review"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--sample", default="uncertain_SRR31887760")
    parser.add_argument("--cpus", default="auto", help="Exactly two allocated logical CPU IDs, or auto for the first two allocated CPUs")
    args = parser.parse_args()
    cpus = sorted(os.sched_getaffinity(0))[:2] if args.cpus == "auto" else [int(part) for part in args.cpus.split(",")]
    args.cpus = ",".join(map(str, cpus))
    require(len(cpus) == len(set(cpus)) == 2 and set(cpus) <= os.sched_getaffinity(0), "Need two allocated CPUs")
    output = args.output.resolve()
    require(not output.exists(), "Output already exists; preserve previous attempt")
    source = args.source.resolve()
    frozen = json.loads(args.source_freeze.read_text())
    require(frozen["base_commit"] == "ed04bdec5178d055b47cc8085135ee5ae2600998", "Wrong scratch source base")
    for relative, expected in frozen["files"].items():
        actual = fingerprint(source / relative)
        require(all(actual[key] == expected[key] for key in ("sha256", "size_bytes")), "Source freeze mismatch: " + relative)
    read_identity = fingerprint(args.fastq)
    require(all(read_identity[key] == value for key, value in PREFIX.items()), "Wrong complete consumed FASTQ prefix")
    require(fingerprint(args.panel)["sha256"] == PANEL_SHA256, "Wrong 21-target panel bytes")
    control_stats = yaml.safe_load((args.control / f"{args.sample}.stats.yaml").read_text())
    require(control_stats["input_source"] == {"kind": "local_files", "inputs": [str(args.fastq.resolve())], "paired": False, "max_reads": 1000000}, "Control must use identical input path/settings")
    launcher = Path(__file__).with_name("launch_bounded.py")
    bound_paths = [args.binary, args.source_freeze, args.historical, args.fastq, args.panel,
                   args.build_receipt, args.rust_controls, args.control_receipt, launcher,
                   Path(__file__), Path(__file__).with_name("audit_ledger.py"),
                   Path(sys.executable), Path("/usr/bin/prlimit"), Path("/usr/bin/time"), Path("/usr/bin/taskset")]
    bound_paths += [path for path in args.control.iterdir() if path.is_file() and path.suffix != ".lock"]
    review = json.loads(args.execution_review.read_text())
    require(review.get("status") == "pass" and review.get("purpose") == "scratch_completion_ledger_execution_clearance", "Independent execution review has not passed")
    reviewed = {str(Path(row["path"]).resolve()): row for row in review["reviewed_artifacts"].values()}
    for path in bound_paths:
        actual = fingerprint(path)
        expected = reviewed.get(actual["path"], {})
        require(all(actual[key] == expected.get(key) for key in ("path", "sha256", "size_bytes")), "Execution review missing/stale artifact: " + str(path))
    bound_paths.append(args.execution_review)
    before = {str(path.resolve()): fingerprint(path) for path in bound_paths}
    output.mkdir(parents=True)
    argv = [str(args.binary.resolve()), "-k", "19", "-t", "2", "--chunks", "0", "--max-reads", "1000000", "-o", str(output), "-s", args.sample, "--pcr-panel-file", str(args.panel.resolve()), str(args.fastq.resolve())]
    command = ["/usr/bin/prlimit", f"--as={ADDRESS_SPACE}", "--", "/usr/bin/time", "-v", "-o", str(output / "time.txt"), "/usr/bin/taskset", "-c", args.cpus, sys.executable, str(launcher.resolve()), "--receipt", str(output / "process_constraints.json"), "--expected-cpus", args.cpus, "--expected-as", str(ADDRESS_SPACE), "--", *argv]
    environment = dict(os.environ, SHARKMER_SCRATCH_COMPLETION_LEDGER="1")
    receipt = {"schema_version": 1, "status": "failed", "argv": argv, "command": command, "before": before, "source_freeze": frozen, "instrumentation_environment": {"SHARKMER_SCRATCH_COMPLETION_LEDGER": "1"}, "declared_limits": {"address_space_bytes": ADDRESS_SPACE, "timeout_seconds": TIMEOUT, "cpu_affinity": cpus}, "purpose": "diagnostic_replay_not_release_performance_comparison"}
    started = time.monotonic()
    try:
        with (output / "stdout.txt").open("x") as stdout, (output / "stderr.txt").open("x") as stderr:
            process = subprocess.Popen(command, cwd=source, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                receipt["returncode"] = process.wait(timeout=TIMEOUT)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                receipt.update(timed_out=True, returncode=process.returncode)
        receipt["wall_seconds"] = time.monotonic() - started
        require(receipt["returncode"] == 0 and not receipt.get("timed_out"), "Scratch invocation failed")
        constraints = json.loads((output / "process_constraints.json").read_text())
        require(constraints.get("status") == "pass" and constraints.get("affinity") == sorted(cpus) and constraints.get("rlimit_as_soft_hard") == [ADDRESS_SPACE, ADDRESS_SPACE] and constraints.get("command") == argv, "Observed child constraints/argv differ from plan")
        receipt["observed_constraints"] = constraints
        receipt["after"] = {str(path.resolve()): fingerprint(path) for path in bound_paths}
        require(receipt["before"] == receipt["after"], "Input/tool/control bookend mismatch")
        for relative, expected in frozen["files"].items():
            actual = fingerprint(source / relative)
            require(all(actual[key] == expected[key] for key in ("sha256", "size_bytes")), "Source changed during execution: " + relative)
        receipt["audit_inputs_before"] = {path.name: fingerprint(path) for path in output.iterdir() if path.is_file() and path.suffix != ".lock"}
        result = audit(args.control, output, args.sample, args.historical, source)
        receipt["audit_inputs_after"] = {path.name: fingerprint(path) for path in output.iterdir() if path.is_file() and path.suffix != ".lock"}
        require(receipt["audit_inputs_before"] == receipt["audit_inputs_after"], "Observed artifacts changed during audit")
        receipt["after_audit"] = {str(path.resolve()): fingerprint(path) for path in bound_paths}
        require(receipt["before"] == receipt["after_audit"], "Input/tool/control changed during audit")
        for relative, expected in frozen["files"].items():
            actual = fingerprint(source / relative)
            require(all(actual[key] == expected[key] for key in ("sha256", "size_bytes")), "Source changed during audit: " + relative)
        write_new(output / "assessment.json", result)
        receipt["assessment"] = fingerprint(output / "assessment.json")
        receipt["outputs"] = {path.name: fingerprint(path) for path in output.iterdir() if path.is_file() and path.suffix != ".lock"}
        receipt["status"] = "pass"
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        receipt.setdefault("wall_seconds", time.monotonic() - started)
        write_new(output / "replay.receipt.json", receipt)
    print(json.dumps({"status": receipt["status"], "output": str(output)}))


if __name__ == "__main__":
    main()
