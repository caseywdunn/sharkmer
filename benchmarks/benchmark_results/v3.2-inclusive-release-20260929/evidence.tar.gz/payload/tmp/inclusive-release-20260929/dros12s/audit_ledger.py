#!/usr/bin/env python3
"""Strictly audit scratch completion ledgers; never infer biological absence."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
import yaml

ROW_CAP = 4096
BYTE_CAP = 8 * 1024 * 1024
FILE_CAP = 84
DISPOSITIONS = ("retained", "oversize_sequence", "oversize_marker_set", "path_cap", "sequence_base_cap", "marker_cap")
HEX = re.compile(r"^[0-9a-f]{64}$")
COUNTS = ("n_reads_read", "n_bases_read", "n_subreads_ingested", "n_bases_ingested", "n_kmers")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fingerprint(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return {"path": str(path), "sha256": digest.hexdigest(), "size_bytes": path.stat().st_size}


def row_key(row):
    return (row["sequence_sha256"], row["sequence_length"], row["omitted_self_loop_occurrences"], row["cyclic_scc_occurrences"], row["retained_collision_occurrences"])


def validate_ledger(document, sample, gene, search):
    require(all(type(document.get(key)) is int and document[key] >= 0 for key in ("schema_version", "threshold", "row_cap", "byte_cap")), "Invalid ledger schema/context integers")
    require(type(search["threshold"]) is int and search["threshold"] > 0, "Invalid search threshold")
    require(type(search["withheld_candidate_paths"]) is int and search["withheld_candidate_paths"] >= 0, "Invalid original completion count")
    require(document.get("schema_version") == 1, "Wrong ledger schema")
    require(document.get("purpose") == "scratch_pre_retention_completed_repeat_withheld_graph_paths", "Wrong ledger purpose")
    require((document.get("sample"), document.get("gene"), document.get("threshold")) == (sample, gene, search["threshold"]), "Ledger context mismatch")
    require(document.get("row_cap") == ROW_CAP and document.get("byte_cap") == BYTE_CAP, "Ledger limits changed")
    require(document.get("complete") is True, "Incomplete/overflowed ledger")
    ledger = document["ledger"]
    require(all(type(ledger.get(key)) is int and ledger[key] >= 0 for key in ("observed_completions", "omitted_rows")), "Invalid ledger counters")
    require(ledger["omitted_rows"] == 0, "Ledger omitted rows")
    rows = ledger["rows"]
    require(isinstance(rows, list), "Invalid ledger rows")
    require(isinstance(ledger["disposition_counts"], dict) and all(key in DISPOSITIONS and type(value) is int and value >= 0 for key, value in ledger["disposition_counts"].items()), "Invalid disposition counters")
    require(len(rows) == ledger["observed_completions"] == search["withheld_candidate_paths"], "Withheld completion count mismatch")
    require(len(rows) <= ROW_CAP, "Ledger row cap exceeded")
    dispositions = Counter()
    for index, row in enumerate(rows, 1):
        require(type(row["ordinal"]) is int and row["ordinal"] == index, "Noncontiguous completion ordinal")
        require(type(row["sequence_length"]) is int and row["sequence_length"] > 0, "Invalid sequence length")
        require(all(type(row.get(key)) is int and row[key] >= 0 for key in ("omitted_self_loop_occurrences", "cyclic_scc_occurrences", "retained_collision_occurrences")), "Invalid cause counts")
        require(sum(row[key] for key in ("omitted_self_loop_occurrences", "cyclic_scc_occurrences", "retained_collision_occurrences")) > 0, "Non-withheld row")
        require(all(isinstance(row.get(key), str) and HEX.fullmatch(row[key]) for key in ("sequence_sha256", "reverse_complement_sha256")), "Invalid digest")
        require(row["retention_disposition"] in DISPOSITIONS, "Unknown retention disposition")
        dispositions[row["retention_disposition"]] += 1
    require(dict(dispositions) == ledger["disposition_counts"], "Disposition total mismatch")
    retention = search["retention"]
    require(all(type(retention.get(key)) is int and retention[key] >= 0 for key in ("observed_withheld_paths", "retained_paths", "observed_not_retained_paths", *("dropped_" + reason for reason in DISPOSITIONS[1:]))), "Invalid original retention counters")
    require(retention["observed_withheld_paths"] == len(rows), "Original retention observation mismatch")
    require(retention["retained_paths"] == dispositions["retained"], "Original retained count mismatch")
    require(retention["observed_not_retained_paths"] == len(rows) - dispositions["retained"], "Original omission count mismatch")
    for reason in DISPOSITIONS[1:]:
        require(retention["dropped_" + reason] == dispositions[reason], "Original omission reason mismatch: " + reason)
    for aggregate, cause in (("withheld_by_self_loop_node_paths", "omitted_self_loop_occurrences"), ("withheld_by_scc_node_paths", "cyclic_scc_occurrences"), ("withheld_by_collision_edge_paths", "retained_collision_occurrences")):
        require(type(search.get(aggregate)) is int and search[aggregate] >= 0, "Invalid original cause counter")
        require(search[aggregate] == sum(row[cause] > 0 for row in rows), "Original cause path count mismatch: " + aggregate)
    return rows


def historical_matches(rows, historical):
    sequence = historical["sequence"]
    expected = hashlib.sha256(sequence.encode("ascii")).hexdigest()
    require(expected == historical["sequence_sha256"] and len(sequence) == historical["length"], "Historical identity corrupt")
    return [{"threshold": threshold, "ordinal": row["ordinal"], "orientation": "exact_oriented" if row["sequence_sha256"] == expected else "reverse_complement", "retention_disposition": row["retention_disposition"]}
            for threshold, row in rows if row["sequence_length"] == len(sequence) and expected in (row["sequence_sha256"], row["reverse_complement_sha256"])]


def audit(control, observed, sample, historical_file, source):
    sys.path.insert(0, str(Path(source) / "scripts"))
    from sharkmer_validate import runner
    control, observed = Path(control), Path(observed)
    base = runner._parse_stats_yaml(control / f"{sample}.stats.yaml")
    current = runner._parse_stats_yaml(observed / f"{sample}.stats.yaml")
    manifests = [runner._validate_output_manifest(stats, sample, directory) for stats, directory in ((base, control), (current, observed))]
    require(all(manifest["schema_version"] == 2 for manifest in manifests), "Expected current schema-2 transactions")
    # This validates every combined file and all uncertain provenance, including
    # uncertain-only genes, before exposing standard products to a consumer.
    runner.parse_fasta_products(sample, control)
    current_standard = runner.parse_fasta_products(sample, observed)
    standard_hashes = {}
    for item in current_standard:
        standard_hashes[item["gene"]] = set()
        for product in item["products"]:
            sequence = product["sequence"]
            reverse = sequence.translate(str.maketrans("ACGT", "TGCA"))[::-1]
            standard_hashes[item["gene"]].update((hashlib.sha256(value.encode()).hexdigest(), len(value)) for value in (sequence, reverse))
    for key in (*COUNTS, "kmer_length", "chunks", "input_source", "sample", "product_output_schema_version", "product_output_layout", "pcr_results"):
        require(base.get(key) == current.get(key), "Normal result parity mismatch: " + key)
    require(len(current["pcr_results"]) == 21, "Full 21-target panel required")
    for gene in current["pcr_results"]:
        if gene.get("output_file"):
            name = gene["output_file"]
            require((control / name).read_bytes() == (observed / name).read_bytes(), "Normal FASTA parity mismatch: " + name)
    expected_files, ledger_rows, summaries = set(), {}, []
    for gene in current["pcr_results"]:
        name = gene["gene_name"]
        uncertainty = gene["uncertain_products"]
        rows_for_gene = []
        retained_by_threshold = {}
        for search in uncertainty["thresholds"]:
            if not search["path_search_evaluated"]:
                require(search["withheld_candidate_paths"] == 0, "Unsearched threshold has completions")
                continue
            basename = f"completion_ledger_{hashlib.sha256(name.encode()).hexdigest()}_{search['threshold']}.yaml"
            expected_files.add(basename)
            path = observed / basename
            require(path.is_file() and not path.is_symlink() and path.stat().st_size <= BYTE_CAP, "Missing/oversize/linked ledger: " + basename)
            rows = validate_ledger(yaml.safe_load(path.read_text()), sample, name, search)
            rows_for_gene.extend((search["threshold"], row) for row in rows)
            retained_by_threshold[search["threshold"]] = Counter(row_key(row) for row in rows if row["retention_disposition"] == "retained")
            summaries.append({"gene": name, "threshold": search["threshold"], "observed": len(rows), "unique_oriented_hashes": len({row["sequence_sha256"] for row in rows}), "duplicate_occurrences": len(rows) - len({row["sequence_sha256"] for row in rows}), "retained": search["retention"]["retained_paths"], "file": fingerprint(path)})
        for product in uncertainty["products"]:
            require(hashlib.sha256(product["oriented_sequence"].encode()).hexdigest() == product["sequence_sha256"], "Retained sequence hash corrupt")
            reverse = product["oriented_sequence"].translate(str.maketrans("ACGT", "TGCA"))[::-1]
            reverse_hash = hashlib.sha256(reverse.encode()).hexdigest()
            for provenance in product["sources"]:
                threshold = provenance["threshold"]
                key = (product["sequence_sha256"], product["sequence_length"], provenance["omitted_self_loop_marker_occurrences"], provenance["cyclic_scc_marker_occurrences"], provenance["retained_collision_marker_occurrences"])
                require(retained_by_threshold.get(threshold, {}).get(key, 0) > 0, "Retained source missing from observer")
                retained_by_threshold[threshold][key] -= 1
                require(any(t == threshold and row_key(row) == key and row["reverse_complement_sha256"] == reverse_hash for t, row in rows_for_gene), "Retained reverse-complement hash mismatch")
        require(sum(sum(counter.values()) for counter in retained_by_threshold.values()) == uncertainty["excluded_standard_equivalent_path_records"], "Unaccounted retained observer records")
        require(all(key[:2] in standard_hashes.get(name, set()) for counter in retained_by_threshold.values() for key, count in counter.items() if count), "Retained remainder is not standard-equivalent")
        ledger_rows[name] = rows_for_gene
    actual_files = {path.name for path in observed.glob("completion_ledger_*")}
    require(actual_files == expected_files and len(expected_files) <= FILE_CAP, "Unexpected/missing ledger files or run file cap exceeded")
    history = json.loads(Path(historical_file).read_text())["rows"]
    results = []
    for historical in history:
        if historical["accession"] != "SRR31887760":
            continue
        name = "insecta_" + historical["gene"]
        matches = historical_matches(ledger_rows[name], historical)
        results.append({"gene": name, "length": historical["length"], "sequence_sha256": historical["sequence_sha256"], "matches": matches, "interpretation": "observed_actual_bounded_completion" if matches else "not_observed_among_complete_bounded_search_completions"})
    for gene, length in (("insecta_12S", 475), ("insecta_16S_2", 590)):
        require(any(row["gene"] == gene and row["length"] == length and any(match["orientation"] == "exact_oriented" and match["retention_disposition"] == "retained" for match in row["matches"]) for row in results), "Historical positive control failed")
    twelve = [row for row in summaries if row["gene"] == "insecta_12S"]
    require(len(twelve) == 1 and (twelve[0]["threshold"], twelve[0]["observed"], twelve[0]["retained"]) == (2, 26, 3), "Frozen 12S completion control failed")
    require(Counter(row["retention_disposition"] for _, row in ledger_rows["insecta_12S"]) == {"retained": 3, "marker_cap": 23}, "Frozen 12S retention control failed")
    return {"schema_version": 1, "status": "pass", "normal_output_parity": True, "ledger_completeness": True, "historical": results, "thresholds": summaries, "scope": "Actual completions under unchanged bounded search; no graph/biological absence or repeat correctness claim."}


def main():
    parser = argparse.ArgumentParser()
    for name in ("control", "observed", "source", "historical", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--sample", default="uncertain_SRR31887760")
    args = parser.parse_args()
    result = audit(args.control, args.observed, args.sample, args.historical, args.source)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "historical": result["historical"]}))


if __name__ == "__main__":
    main()
