    #[test]
    fn scratch_ledger_observes_all_retention_drop_reasons_before_return() {
        let graph = sequence_graph("ACGTA", 3);
        let nodes: Vec<NodeIndex> = graph.node_indices().collect();
        let path = vec![
            (nodes[0], None),
            (nodes[1], graph.find_edge(nodes[0], nodes[1])),
            (nodes[2], graph.find_edge(nodes[1], nodes[2])),
            (nodes[3], graph.find_edge(nodes[2], nodes[3])),
        ];
        let markers = RepeatMarkers {
            omitted_self_loop_sub_kmers: AHashSet::from_iter([graph[nodes[1]].sub_kmer]),
            cyclic_scc_sub_kmers: AHashSet::new(),
            retained_collision_edges: AHashSet::new(),
        };
        for (limits, expected) in [
            (diagnostic_limits(4, 100, 10), ["retained", "retained"]),
            (diagnostic_limits(0, 100, 10), ["path_cap", "path_cap"]),
            (diagnostic_limits(4, 4, 10), ["oversize_sequence", "oversize_sequence"]),
            (diagnostic_limits(4, 100, 0), ["oversize_marker_set", "oversize_marker_set"]),
            (diagnostic_limits(4, 9, 10), ["retained", "sequence_base_cap"]),
            (diagnostic_limits(4, 100, 1), ["retained", "marker_cap"]),
        ] {
            let mut budget = WithheldDiagnosticBudget::new(limits);
            let mut collector = ThresholdDiagnosticCollector::new(&mut budget, 2);
            for _ in 0..2 {
                collector.observe_withheld_path(&graph, &path, 3, &markers, &path_visit_counts(&path), cause_counts(1, 0, 0));
            }
            let diagnostics = collector.finish();
            let ledger = &diagnostics.completion_ledger;
            assert_eq!(ledger.observed_completions, diagnostics.observed_withheld_paths);
            assert_eq!(ledger.rows.len(), 2);
            assert_eq!(ledger.omitted_rows, 0);
            for (index, row) in ledger.rows.iter().enumerate() {
                assert_eq!(row.ordinal, index + 1);
                assert_eq!(row.sequence_length, 5);
                assert_eq!(row.sequence_sha256, sha256_text("ACGTA"));
                assert_eq!(row.reverse_complement_sha256, sha256_text("TACGT"));
                assert_eq!(row.retention_disposition, expected[index]);
            }
            for retained in &diagnostics.paths {
                assert!(ledger.rows.iter().any(|row| row.retention_disposition == "retained" && row.sequence_sha256 == retained.sequence_sha256));
            }
        }
    }
