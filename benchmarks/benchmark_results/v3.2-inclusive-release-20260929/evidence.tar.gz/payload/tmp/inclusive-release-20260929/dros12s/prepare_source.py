#!/usr/bin/env python3
"""Create a pinned, instrumented scratch source; never edit the checkout."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

PIN = "ed04bde"
HERE = Path(__file__).resolve().parent


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"Expected one hook occurrence, found {text.count(old)}: {old[:90]!r}")
    return text.replace(old, new)


def identity(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    commit = subprocess.check_output(["git", "-C", str(repo), "rev-parse", f"{PIN}^{{commit}}"], text=True).strip()
    names = subprocess.check_output(["git", "-C", str(repo), "ls-tree", "-r", "--name-only", commit, "Cargo.toml", "Cargo.lock", "src", "panels", "tests", "scripts", "schemas", "meta.yaml"], text=True).splitlines()
    output.mkdir(parents=True)
    original = {}
    for name in names:
        data = subprocess.check_output(["git", "-C", str(repo), "show", f"{commit}:{name}"])
        original[name] = identity(data)
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    mod_file = output / "src/pcr/mod.rs"
    text = mod_file.read_text()
    text = replace_once(text, "mod bubble;\n", "mod bubble;\nmod completion_ledger;\n")
    text = replace_once(text, "    pub(crate) paths: Vec<WithheldPathRecord>,\n", "    pub(crate) paths: Vec<WithheldPathRecord>,\n    #[serde(skip)]\n    pub(crate) completion_ledger: completion_ledger::CompletionLedger,\n")
    hook = """    if std::env::var_os("SHARKMER_SCRATCH_COMPLETION_LEDGER").is_some()
        && let Some(payload) = path_search.withheld_path_diagnostics.as_ref()
    {
        payload.completion_ledger.publish(output_directory, sample_name, &params.gene_name, min_count)?;
    }

"""
    text = replace_once(text, "    if path_search.dfs_limit_reached {\n", hook + "    if path_search.dfs_limit_reached {\n")
    mod_file.write_text(text)
    path_file = output / "src/pcr/paths.rs"
    text = path_file.read_text()
    hook = """        // Scratch observation precedes every original retention early return.
        self.payload.completion_ledger.observe(
            &reconstruct_path_sequence(graph, path, kmer_length),
            drop_reason,
            [cause_counts.omitted_self_loop, cause_counts.cyclic_scc, cause_counts.retained_collision],
        );

"""
    text = replace_once(text, "        if let Some(drop_reason) = drop_reason {\n", hook + "        if let Some(drop_reason) = drop_reason {\n")
    controls = (HERE / "path_controls.rs").read_text()
    ending = text.rfind("\n}")
    if ending < 0:
        raise ValueError("Cannot find end of path tests module")
    text = text[:ending] + "\n" + controls + text[ending:]
    path_file.write_text(text)
    (output / "src/pcr/completion_ledger.rs").write_bytes((HERE / "completion_ledger.rs").read_bytes())
    changed = {str(p.relative_to(output)): identity(p.read_bytes()) for p in output.rglob("*") if p.is_file()}
    receipt = {"schema_version": 1, "base_commit": commit, "source": str(output), "original": original, "prepared": changed,
               "changed_paths": [n for n in changed if original.get(n) != changed[n]],
               "generator": identity(Path(__file__).read_bytes()),
               "templates": {n: identity((HERE / n).read_bytes()) for n in ("completion_ledger.rs", "path_controls.rs")}}
    with (output.parent / (output.name + ".preparation.json")).open("x") as stream:
        stream.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"base_commit": commit, "source": str(output), "changed_paths": receipt["changed_paths"]}))


if __name__ == "__main__":
    main()
