# Contributing

### Installation from a specific branch on the repository

This allows you to test pre-release features.

Install sharkmer from a specific branch on the repo:

    cargo install --git https://github.com/caseywdunn/sharkmer.git --branch dev

Re-run the install command to pull and build the latest changes:

    cargo install --git https://github.com/caseywdunn/sharkmer.git --branch dev --force

To remove sharkmer:

    cargo uninstall sharkmer

## Development

After cloning the repo, install the pre-commit hook:

    ln -sf ../../scripts/pre-commit .git/hooks/pre-commit

This runs the same quality gates as CI before every commit: `cargo fmt --all --check`,
`cargo clippy -- -D warnings`, and `cargo test --release`.

Some common rust tasks in development:

    cargo test
    cargo clippy
    cargo clippy --fix
    cargo fmt
    cargo build # Debug
    cargo build --release

### Test data

Integration tests use a 100k-read fixture from ERR571460 (Porites lutea),
stored gzipped at `tests/fixtures/ERR571460_100k_R1.fastq.gz`. No manual
setup is needed — `cargo test` handles it automatically.

## Branching model

### Branches

- `master` — tagged releases only. Never commit directly to master.
- `dev` — active development for the next unreleased version. All feature
  work targets this branch.
- `vN` (e.g. `v2`, `v3`) — release maintenance branches, created from the
  release tag when a major version ships. Used only for patches to released
  versions.
- Issue branches — created from `dev` (or from `vN` for patches), named after
  the issue they address.

### Normal workflow

1. Create an issue branch from `dev` (`git checkout -b issue-NNN dev`)
2. Do the work, ensure it passes quality gates
3. Merge to `dev` and push (`git checkout dev && git merge issue-NNN && git push`)
4. Delete the issue branch
5. When ready to release: merge `dev` to `master`, tag the release, create
   a `vN` branch from the tag

Always merge and push completed issue branches to `dev` before starting the
next issue. This keeps `dev` up to date and avoids dependency tangles when
later issue branches need earlier work.

### Patching a released version

If a bug is found in v2.0 while v3.0 is in development on `dev`:

1. Create an issue branch from `v2`
2. Fix the bug
3. Merge to `v2`, tag `v2.0.1`
4. Merge `v2` to `master`
5. Cherry-pick the fix into `dev` so the next version gets it too

### Quality gates

A branch is considered passing when:

- `cargo test --release` passes
- `cargo clippy -- -D warnings` reports no warnings
- `cargo fmt --all --check` reports no changes needed

## Releasing

These steps assume all work is complete on `dev`, quality gates pass, and
regression benchmarks have been run.

### 1. Run and commit benchmarks

Before preparing the release, run the full regression benchmark suite on `dev`
and commit the results:

    conda activate sharkmer-bench
    python benchmarks/run_benchmark.py

Review the results in `benchmarks/benchmark_results/` and compare the structured
per-product YAML records, classifications, and performance fields with prior
runs. There is no separate comparison script. Investigate regressions before
proceeding. Commit the benchmark results to `dev`:

    git add benchmarks/benchmark_results/
    git commit -m "Add benchmark results for vX.Y.Z release"

### 2. Validate all built-in panels

Run the full panel validation suite to confirm all built-in panels load,
parse, and produce amplicons against their declared validation samples.
On a local machine:

    conda activate sharkmer-bench
    bash scripts/validate_all_panels.sh

On the Bouchet HPC cluster (submits one SLURM job per panel):

    ml Rust GCC
    cargo build --release
    bash scripts/validate_all_panels_slurm.sh

If any panel fails, fix the discrepancy before proceeding. Pass `--no-blast`
to skip BLAST validation if a local BLAST database is unavailable.

### 3. Validate the reference panel

`panels/examples/reference.yaml` is a documentation panel that exercises
every schema v2 feature — multiple primer indices, deprecated entries,
compartment/gene_type/copy_number metadata, and so on. It is not embedded
in the binary but must parse and validate cleanly before every release:

    conda activate sharkmer-bench
    python scripts/validate_panel.py panels/examples/reference.yaml

If the reference panel fails to load or validate, the schema implementation
or documentation is out of sync. Fix the discrepancy before proceeding.

### 4. Prepare the release

- Verify `version` in `Cargo.toml` matches the intended release (e.g. `3.0.0`).
- Verify `CHANGELOG.md` has an entry for this version with the correct date.
- Verify `meta.yaml` version and sha256 are updated (sha256 can only be
  finalized after the GitHub release tarball exists — use `PLACEHOLDER` until
  then).

### 5. Merge to master and push

    git checkout master
    git merge dev
    git push origin master

### 6. Tag the release

    git tag -a vX.Y.Z -m "vX.Y.Z"
    git push origin vX.Y.Z

### 7. Create the GitHub release

Go to <https://github.com/caseywdunn/sharkmer/releases/new>, select the tag
you just pushed, and create a release. Use the CHANGELOG entry as the release
notes.

Alternatively, use the CLI (replace `X.Y.Z` with the version number):

    VERSION=X.Y.Z
    gh release create "v${VERSION}" --title "v${VERSION}" --notes-file - <<< "$(sed -n "/^## \[${VERSION}\]/,/^## \[/{ /^## \[${VERSION}\]/d; /^## \[/d; p; }" CHANGELOG.md)"

### 8. Create the release maintenance branch

    git checkout -b vN vX.Y.Z   # e.g. git checkout -b v3 v3.0.0
    git push origin vN

This branch is used for future patch releases (vX.Y.1, etc.) without
pulling in unreleased work from `dev`.

### 9. Update the bioconda recipe

After the GitHub release is created, get the sha256 of the source tarball:

    curl -sL https://github.com/caseywdunn/sharkmer/archive/refs/tags/vX.Y.Z.tar.gz | sha256sum

Update `meta.yaml` with the real sha256, then follow the bioconda submission
steps in the Bioconda section below.

### 10. Resume development

    git checkout dev

Update `Cargo.toml` version to the next development version (e.g. `3.1.0-dev`)
and add an `[Unreleased]` section to `CHANGELOG.md`.

## Regression benchmarks

A benchmark suite in `benchmarks/` runs sharkmer against 13 real-world SRA
datasets across 6 of the 9 built-in primer panels. Run after each development
phase or before a release to check for regressions.

Set up the benchmark conda environment (first time only):

    conda init zsh      # or bash — writes conda hooks to your shell rc file
    # Restart your shell (or open a new terminal) for the hooks to take effect.
    # In a fresh shell that has not yet been restarted you can source the hooks
    # directly instead:
    #   source /opt/conda/etc/profile.d/conda.sh
    conda env create -f benchmarks/environment.yaml

Then activate it before running benchmarks:

    conda activate sharkmer-bench

    # Run the full benchmark (builds sharkmer, downloads data if needed, runs all samples)
    python benchmarks/run_benchmark.py

    # Run specific samples only
    python benchmarks/run_benchmark.py --samples Porites_lutea Agalma_elegans

    # Run the included offline counting oracle
    python benchmarks/run_benchmark.py --config benchmarks/known_truth.yaml -k 19 --scope counting-only --no-blast

Per-panel YAML and Markdown results and a commit-labelled combined summary are
written to `benchmarks/benchmark_results/`. Compare the structured per-product
records and performance fields between runs; the repository does not currently
provide an automated cross-run comparator.

Dataset roles, offline known-truth commands, and the registration gate for
future held-out data are defined in `benchmarks/DATASETS.md`. Results record
the executable fingerprint and workspace source observation, effective
command, input and reference checksums, cache protocol, stage timings,
throughput, table capacity, allocator peak, peak RSS when available, and final
run-directory size. Unavailable metrics remain null with an availability
statement.

Sample data is cached in `benchmarks/data/` and downloaded from ENA on first
run. The 1M setting is a requested FASTQ-record cap, not a promise that every
input reaches it; four calibration inputs exhaust earlier. The download streams
and truncates early, so it does not fetch full runs. Configuration (samples,
panels, read counts) is in `benchmarks/benchmark.yaml`.

## Bioconda recipe

Bioconda release follows their [contribution workflow](https://bioconda.github.io/contributor/index.html).

The bioconda recipe files are at the repo root (`meta.yaml` and `build.sh`). These are the source of truth and are copied to the [bioconda-recipes](https://github.com/bioconda/bioconda-recipes) repository for releases.

Before submitting a pull request, test the recipe locally with:

    # first time only
    conda create -n bioconda-test -c conda-forge -c bioconda bioconda-utils 

    # each test
    conda activate bioconda-test
    cd bioconda-recipes
    conda build recipes/sharkmer -c conda-forge -c bioconda
