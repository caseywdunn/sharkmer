#!/usr/bin/env python3
"""Build bounded local graph-hypothesis manifests without reading FASTQ data."""

import argparse
import hashlib
import json
from collections import deque
from pathlib import Path


FLANK_BASES = 21
MAX_WALK_BASES = 150
MAX_EXPANSIONS = 1_000_000
MAX_SPELLINGS = 4_096
MAX_ASSAY_ALTERNATIVES = 128
COMPLEMENT = str.maketrans("ACGT", "TGCA")
EXPORT_PHASES = {
    "pre_prune": "pre_prune_after_extension_before_tip_and_reachability_pruning",
    "post_prune": "post_tip_and_reachability_pruning_and_coverage_annotation",
}


def digest_text(value):
    return hashlib.sha256(value.encode("ascii")).hexdigest()


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def literal_sequence(value):
    return isinstance(value, str) and bool(value) and set(value) <= set("ACGT")


def all_positions(sequence, pattern):
    offset = sequence.find(pattern)
    while offset >= 0:
        yield offset
        offset = sequence.find(pattern, offset + 1)


def stable_component_id(node_ids):
    return hashlib.sha256("\n".join(sorted(node_ids)).encode("utf-8")).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def verify_audit_manifest(manifest, candidate, pre_bytes, post_bytes):
    if manifest.get("schema_version") != 1 or manifest.get("status") != "complete":
        raise ValueError("Audit manifest is not a complete schema_version 1 export")
    target = manifest.get("target")
    if not isinstance(target, dict):
        raise ValueError("Audit manifest lacks target identity")
    record = candidate["record"]
    if (target.get("gene") != candidate.get("gene")
            or target.get("kmer_length") != candidate.get("kmer_length")
            or target.get("threshold") != candidate.get("threshold")):
        raise ValueError("Audit manifest target differs from frozen candidate")
    if target.get("historical_product_sha256") != record.get("sequence_sha256"):
        raise ValueError("Audit manifest historical product checksum differs")
    candidate_markers = {(item["identity_sequence"], item["start"], item["end"])
                         for item in record["marker_occurrences"]}
    manifest_markers = {(item.get("oriented_node_sequence"), item.get("historical_path_start"), item.get("historical_path_end"))
                        for item in target.get("expected_path_markers", [])}
    if candidate_markers != manifest_markers:
        raise ValueError("Audit manifest marker identities differ from frozen candidate")
    files = manifest.get("files")
    if not isinstance(files, dict):
        raise ValueError("Audit manifest lacks graph file receipts")
    for file_name, contents in (("pre_prune.json", pre_bytes), ("post_prune.json", post_bytes)):
        receipt = files.get(file_name)
        if not isinstance(receipt, dict) or receipt.get("size_bytes") != len(contents):
            raise ValueError(f"Audit manifest size receipt differs for {file_name}")
        if receipt.get("sha256") != hashlib.sha256(contents).hexdigest():
            raise ValueError(f"Audit manifest checksum differs for {file_name}")
    return target


def verify_graph_target(export, audit_target, expected_stage):
    graph_target = export.get("target")
    if not isinstance(graph_target, dict):
        raise ValueError(f"{expected_stage} graph export lacks target identity")
    for field in ("sample", "gene", "threshold", "kmer_length", "historical_product_sha256"):
        if graph_target.get(field) != audit_target.get(field):
            raise ValueError(f"{expected_stage} graph target differs from audit manifest for {field}")


def validate_graph(export, expected_stage, expected_kmer_length):
    if export.get("schema_version") != 1:
        raise ValueError("Expected graph export schema_version 1")
    graph = export.get("graph")
    expected_phase = EXPORT_PHASES[expected_stage]
    if not isinstance(graph, dict) or graph.get("phase") != expected_phase:
        raise ValueError(f"Expected graph export phase {expected_phase}")
    if export.get("kmer_length") not in (None, expected_kmer_length):
        raise ValueError("Graph k-mer length differs from candidate")
    nodes = graph.get("nodes")
    edges = graph.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list) or not nodes:
        raise ValueError("Graph nodes and edges must be nonempty lists")
    if graph.get("node_count") != len(nodes) or graph.get("edge_count") != len(edges):
        raise ValueError("Graph declared node or edge count differs from serialized topology")
    nodes_by_id = {}
    nodes_by_sequence = {}
    for node in nodes:
        node_id = node.get("node_id")
        sequence = node.get("oriented_sequence")
        if not isinstance(node_id, str) or not literal_sequence(sequence):
            raise ValueError("Graph node id or sequence is invalid")
        if len(sequence) != expected_kmer_length - 1:
            raise ValueError("Graph node sequence length is invalid")
        if node_id in nodes_by_id or sequence in nodes_by_sequence:
            raise ValueError("Graph node identities must be unique by id and oriented sequence")
        nodes_by_id[node_id] = {**node, "sequence": sequence}
        nodes_by_sequence[sequence] = node_id
    outgoing = {node_id: [] for node_id in nodes_by_id}
    edge_ids = set()
    edge_sequences = set()
    edge_endpoints = {}
    for edge in edges:
        edge_id = edge.get("edge_id")
        source_id = edge.get("source_node_id")
        target_id = edge.get("target_node_id")
        if not isinstance(edge_id, str) or edge_id in edge_ids:
            raise ValueError("Graph edge ids must be unique strings")
        if source_id not in nodes_by_id or target_id not in nodes_by_id:
            raise ValueError("Graph edge has an unknown endpoint")
        source_sequence = nodes_by_id[source_id]["sequence"]
        target_sequence = nodes_by_id[target_id]["sequence"]
        if source_sequence[1:] != target_sequence[:-1]:
            raise ValueError("Graph edge does not preserve oriented de Bruijn overlap")
        oriented_sequence = edge.get("oriented_sequence")
        if oriented_sequence != source_sequence + target_sequence[-1]:
            raise ValueError("Graph edge sequence differs from its oriented endpoints")
        if oriented_sequence in edge_sequences:
            raise ValueError("Graph oriented edge identities must be unique")
        edge_ids.add(edge_id)
        edge_sequences.add(oriented_sequence)
        edge_endpoints[edge_id] = (source_id, target_id)
        outgoing[source_id].append((edge_id, target_id))
    for edge_list in outgoing.values():
        edge_list.sort(key=lambda item: (item[1], item[0]))
    supplied_components = graph.get("cyclic_components")
    if not isinstance(supplied_components, list):
        raise ValueError("Graph export lacks cyclic component membership")
    return nodes_by_id, nodes_by_sequence, outgoing, supplied_components, edge_endpoints


def verify_complete_candidate_path(candidate_sequence, kmer_length, nodes_by_sequence, outgoing):
    node_ids = []
    for position in range(len(candidate_sequence) - kmer_length + 2):
        node_sequence = candidate_sequence[position:position + kmer_length - 1]
        node_id = nodes_by_sequence.get(node_sequence)
        if node_id is None:
            raise ValueError(f"Historical candidate node at {position} is absent from graph export")
        node_ids.append(node_id)
    edge_pairs = {(source_id, target_id) for source_id, edges in outgoing.items() for _, target_id in edges}
    for position, (source_id, target_id) in enumerate(zip(node_ids, node_ids[1:])):
        if (source_id, target_id) not in edge_pairs:
            raise ValueError(f"Historical candidate edge at {position} is absent from graph export")
    return node_ids


def cyclic_components(nodes_by_id, outgoing):
    reverse = {node_id: [] for node_id in nodes_by_id}
    for source_id, edges in outgoing.items():
        for _, target_id in edges:
            reverse[target_id].append(source_id)
    for node_ids in reverse.values():
        node_ids.sort()
    visited = set()
    finish = []
    for start_id in sorted(nodes_by_id):
        if start_id in visited:
            continue
        visited.add(start_id)
        stack = [(start_id, 0)]
        while stack:
            node_id, index = stack[-1]
            edges = outgoing[node_id]
            if index >= len(edges):
                finish.append(node_id)
                stack.pop()
                continue
            stack[-1] = (node_id, index + 1)
            target_id = edges[index][1]
            if target_id not in visited:
                visited.add(target_id)
                stack.append((target_id, 0))
    components = []
    assigned = set()
    for start_id in reversed(finish):
        if start_id in assigned:
            continue
        assigned.add(start_id)
        component = []
        stack = [start_id]
        while stack:
            node_id = stack.pop()
            component.append(node_id)
            for source_id in reverse[node_id]:
                if source_id not in assigned:
                    assigned.add(source_id)
                    stack.append(source_id)
        component.sort()
        has_self_loop = any(target_id == component[0] for _, target_id in outgoing[component[0]])
        if len(component) > 1 or has_self_loop:
            components.append(component)
    components.sort(key=lambda component: tuple(component))
    component_by_node = {}
    for component in components:
        component_id = stable_component_id(component)
        for node_id in component:
            component_by_node[node_id] = component_id
    return components, component_by_node


def verify_exported_components(supplied_components, computed_components, edge_endpoints):
    supplied = {}
    for component in supplied_components:
        component_id = component.get("component_id")
        node_ids = component.get("node_ids")
        if not isinstance(component_id, str) or not isinstance(node_ids, list) or not node_ids:
            raise ValueError("Cyclic component identity is invalid")
        key = frozenset(node_ids)
        if key in supplied:
            raise ValueError("Duplicate exported cyclic component membership")
        supplied[key] = component
    computed = {frozenset(component) for component in computed_components}
    if set(supplied) != computed:
        raise ValueError("Exported cyclic components differ from recomputed topology")
    for component_nodes in computed:
        node_set = set(component_nodes)
        component = supplied[frozenset(component_nodes)]
        expected_edges = {
            "internal_edge_ids": {edge_id for edge_id, (source_id, target_id) in edge_endpoints.items()
                                  if source_id in node_set and target_id in node_set},
            "entry_edge_ids": {edge_id for edge_id, (source_id, target_id) in edge_endpoints.items()
                               if source_id not in node_set and target_id in node_set},
            "exit_edge_ids": {edge_id for edge_id, (source_id, target_id) in edge_endpoints.items()
                              if source_id in node_set and target_id not in node_set},
        }
        for field, expected_ids in expected_edges.items():
            exported_ids = component.get(field)
            if not isinstance(exported_ids, list) or len(exported_ids) != len(set(exported_ids)):
                raise ValueError(f"Exported cyclic component {field} is invalid")
            if set(exported_ids) != expected_ids:
                raise ValueError(f"Exported cyclic component {field} differs from graph topology")
    return supplied


def marker_components(candidate, nodes_by_sequence, component_by_node):
    record = candidate["record"]
    sequence = record["oriented_sequence"]
    marked = {}
    for marker in record["marker_occurrences"]:
        if marker.get("cause") != "pre_prune_cyclic_scc_node":
            continue
        start = marker.get("start")
        end = marker.get("end")
        identity = marker.get("identity_sequence")
        if not isinstance(start, int) or not isinstance(end, int) or sequence[start:end] != identity:
            raise ValueError("Candidate marker coordinate or identity differs")
        node_id = nodes_by_sequence.get(identity)
        if node_id is None:
            raise ValueError("Marked candidate node is absent from graph export")
        component_id = component_by_node.get(node_id)
        if component_id is None:
            raise ValueError("Marked candidate node is not in a recomputed cyclic component")
        marked.setdefault(component_id, set()).add(node_id)
    if not marked:
        raise ValueError("No candidate marker matched a cyclic component")
    return marked


def component_spans(candidate_sequence, components, nodes_by_id, marked_components):
    spans = []
    for component in components:
        component_id = stable_component_id(component)
        if component_id not in marked_components:
            continue
        occurrences = []
        for node_id in component:
            node_sequence = nodes_by_id[node_id]["sequence"]
            occurrences.extend(all_positions(candidate_sequence, node_sequence))
        if not occurrences:
            raise ValueError("Marked component has no candidate occurrence")
        start = min(occurrences)
        end = max(position + len(nodes_by_id[node_id]["sequence"])
                  for node_id in component
                  for position in all_positions(candidate_sequence, nodes_by_id[node_id]["sequence"]))
        spans.append({"component_id": component_id, "node_ids": component,
                      "candidate_occurrences": sorted(occurrences), "start": start, "end": end})
    return spans


def merge_regions(spans, candidate_length):
    envelopes = []
    for span in spans:
        start = span["start"] - FLANK_BASES
        end = span["end"] + FLANK_BASES
        envelopes.append({"status": "missing_complete_flanks" if start < 0 or end > candidate_length else "pending",
                          "start": start, "end": end, "components": [span]})
    envelopes.sort(key=lambda item: (item["start"], item["end"]))
    merged = []
    for envelope in envelopes:
        if merged and envelope["start"] <= merged[-1]["end"]:
            merged[-1]["end"] = max(merged[-1]["end"], envelope["end"])
            merged[-1]["components"].extend(envelope["components"])
            if envelope["status"] != "pending":
                merged[-1]["status"] = envelope["status"]
        else:
            merged.append(envelope)
    for index, region in enumerate(merged, 1):
        region["id"] = f"region_{index}"
    return merged


def candidate_node_positions(candidate_sequence, nodes_by_sequence):
    positions = {}
    for sequence, node_id in nodes_by_sequence.items():
        for position in all_positions(candidate_sequence, sequence):
            positions.setdefault(position, node_id)
    return positions


def walk_between_anchors(nodes_by_id, outgoing, left_anchor, right_anchor):
    initial_sequence = nodes_by_id[left_anchor]["sequence"]
    reverse_reachable = {right_anchor}
    reverse_edges = {node_id: [] for node_id in nodes_by_id}
    for source_id, edge_rows in outgoing.items():
        for _, target_id in edge_rows:
            reverse_edges[target_id].append(source_id)
    queue_for_reachability = deque([right_anchor])
    while queue_for_reachability:
        node_id = queue_for_reachability.popleft()
        for source_id in reverse_edges[node_id]:
            if source_id not in reverse_reachable:
                reverse_reachable.add(source_id)
                queue_for_reachability.append(source_id)
    if left_anchor not in reverse_reachable:
        return {"spellings": {}, "expanded_states": 0, "overlength_frontier": 0,
                "dead_ends": 0, "reverse_unreachable_edges_skipped": 0,
                "state_cap_hit": False, "spelling_cap_hit": False,
                "complete_within_bounds": True}
    queue = deque([(left_anchor, initial_sequence, [left_anchor])])
    visited = {(left_anchor, initial_sequence)}
    spellings = {}
    expanded_states = 0
    overlength_frontier = 0
    dead_ends = 0
    reverse_unreachable_edges_skipped = 0
    state_cap_hit = False
    spelling_cap_hit = False
    while queue:
        if expanded_states >= MAX_EXPANSIONS:
            state_cap_hit = True
            break
        node_id, sequence, route = queue.popleft()
        expanded_states += 1
        if node_id == right_anchor:
            if sequence not in spellings and len(spellings) >= MAX_SPELLINGS:
                spelling_cap_hit = True
                break
            spellings.setdefault(sequence, route)
        next_edges = outgoing[node_id]
        if not next_edges:
            dead_ends += 1
        for _, target_id in next_edges:
            if target_id not in reverse_reachable:
                reverse_unreachable_edges_skipped += 1
                continue
            extended = sequence + nodes_by_id[target_id]["sequence"][-1]
            if len(extended) > MAX_WALK_BASES:
                overlength_frontier += 1
                continue
            state_key = (target_id, extended)
            if state_key in visited:
                continue
            visited.add(state_key)
            queue.append((target_id, extended, route + [target_id]))
    return {"spellings": spellings, "expanded_states": expanded_states,
            "overlength_frontier": overlength_frontier, "dead_ends": dead_ends,
            "reverse_unreachable_edges_skipped": reverse_unreachable_edges_skipped,
            "state_cap_hit": state_cap_hit, "spelling_cap_hit": spelling_cap_hit,
            "complete_within_bounds": not state_cap_hit and not spelling_cap_hit}


def stage_regions(candidate, graph, stage, templates=None):
    candidate_sequence = candidate["record"]["oriented_sequence"]
    kmer_length = candidate["kmer_length"]
    nodes_by_id, nodes_by_sequence, outgoing, supplied_components, edge_endpoints = validate_graph(graph, stage, kmer_length)
    verify_complete_candidate_path(candidate_sequence, kmer_length, nodes_by_sequence, outgoing)
    components, component_by_node = cyclic_components(nodes_by_id, outgoing)
    verify_exported_components(supplied_components, components, edge_endpoints)
    if templates is None:
        marked = marker_components(candidate, nodes_by_sequence, component_by_node)
        spans = component_spans(candidate_sequence, components, nodes_by_id, marked)
        regions = merge_regions(spans, len(candidate_sequence))
    else:
        regions = [{"id": item["id"], "start": item["start"], "end": item["end"],
                    "status": item["status"], "components": item.get("components", [])}
                   for item in templates]
    candidate_positions = candidate_node_positions(candidate_sequence, nodes_by_sequence)
    component_nodes = {stable_component_id(component): set(component) for component in components}
    output = []
    for region in regions:
        result = {key: value for key, value in region.items() if key != "components"}
        result["components"] = [item["component_id"] if isinstance(item, dict) else item for item in region["components"]]
        result["candidate_window"] = candidate_sequence[max(0, region["start"]):min(len(candidate_sequence), region["end"])]
        if region["status"] != "pending":
            result["complete_within_bounds"] = False
            output.append(result)
            continue
        left_anchor_position = region["start"]
        right_anchor_position = region["end"] - (kmer_length - 1)
        left_anchor = candidate_positions.get(left_anchor_position)
        right_anchor = candidate_positions.get(right_anchor_position)
        left_anchor_positions = list(all_positions(candidate_sequence, candidate_sequence[left_anchor_position:left_anchor_position + kmer_length - 1]))
        right_anchor_positions = list(all_positions(candidate_sequence, candidate_sequence[right_anchor_position:right_anchor_position + kmer_length - 1]))
        if templates is None:
            region_component_ids = {component["component_id"] if isinstance(component, dict) else component
                                    for component in region["components"]}
        else:
            region_component_ids = {component_by_node[node_id]
                                    for position, node_id in candidate_positions.items()
                                    if position < region["end"] and position + kmer_length - 1 > region["start"]
                                    and node_id in component_by_node}
            result["components"] = sorted(region_component_ids)
        region_component_nodes = set().union(*(component_nodes[component_id] for component_id in region_component_ids)) if region_component_ids else set()
        flank_ranges = ((region["start"], region["start"] + FLANK_BASES),
                        (region["end"] - FLANK_BASES, region["end"]))
        flank_component_overlap = False
        for position, node_id in candidate_positions.items():
            node_end = position + kmer_length - 1
            if node_id in region_component_nodes and any(position < range_end and node_end > range_start for range_start, range_end in flank_ranges):
                flank_component_overlap = True
        anchor_is_cyclic = left_anchor in component_by_node or right_anchor in component_by_node
        repeated_anchor_placement = len(left_anchor_positions) != 1 or len(right_anchor_positions) != 1
        if left_anchor is None or right_anchor is None or flank_component_overlap or anchor_is_cyclic or repeated_anchor_placement:
            result.update({"status": "unresolved_anchor_or_flank", "complete_within_bounds": False,
                           "left_anchor": left_anchor, "right_anchor": right_anchor,
                           "flank_component_overlap": flank_component_overlap,
                           "anchor_is_cyclic": anchor_is_cyclic,
                           "repeated_anchor_placement": repeated_anchor_placement})
            output.append(result)
            continue
        walk_result = walk_between_anchors(nodes_by_id, outgoing, left_anchor, right_anchor)
        focal_left = candidate_sequence[region["start"]:region["start"] + FLANK_BASES]
        focal_right = candidate_sequence[region["end"] - FLANK_BASES:region["end"]]
        spelling_rows = []
        for sequence, route in sorted(walk_result["spellings"].items()):
            spelling_rows.append({"sequence": sequence, "sequence_sha256": digest_text(sequence),
                                  "route_node_ids": route,
                                  "assayable": len(sequence) >= 2 * FLANK_BASES,
                                  "flank_class": "focal_same_flanks" if sequence.startswith(focal_left) and sequence.endswith(focal_right) else "competitor_changed_flank"})
        candidate_window = result["candidate_window"]
        candidate_present = candidate_window in walk_result["spellings"]
        result.update(walk_result)
        result.update({"left_anchor": left_anchor, "right_anchor": right_anchor,
                       "focal_left_flank": focal_left, "focal_right_flank": focal_right,
                       "spelling_rows": spelling_rows, "candidate_window_sha256": digest_text(candidate_window),
                       "candidate_coordinate_map": {"window": [region["start"], region["end"]],
                                                    "left_anchor_node_start": left_anchor_position,
                                                    "right_anchor_node_start": right_anchor_position,
                                                    "flank_bases": FLANK_BASES},
                       "candidate_window_enumerated": candidate_present,
                       "status": "enumerated" if walk_result["complete_within_bounds"] and candidate_present else "unresolved_enumeration"})
        output.append(result)
    return output


def merge_stage_regions(pre_regions, post_regions):
    regions = {}
    for stage, stage_regions_rows in (("pre_prune", pre_regions), ("post_prune", post_regions)):
        for region in stage_regions_rows:
            key = (region["start"], region["end"])
            regions.setdefault(key, {"id": f"region_{len(regions) + 1}", "start": key[0], "end": key[1], "stages": {}})["stages"][stage] = region
    return [regions[key] for key in sorted(regions)]


def local_classes(region):
    classes = {}
    unresolved = []
    for stage, stage_region in sorted(region["stages"].items()):
        if stage_region.get("status") != "enumerated" or not stage_region.get("complete_within_bounds"):
            unresolved.append(f"{stage}:{stage_region.get('status', 'incomplete')}")
            continue
        for spelling in stage_region["spelling_rows"]:
            canonical = min(spelling["sequence"], reverse_complement(spelling["sequence"]))
            class_row = classes.setdefault(canonical, {"sequence": canonical, "sequence_sha256": digest_text(canonical),
                                                       "flank_classes": set(), "members": [], "assayable": False})
            class_row["flank_classes"].add(spelling["flank_class"])
            class_row["assayable"] = class_row["assayable"] or spelling["assayable"]
            if not spelling["assayable"]:
                unresolved.append("unassayable_right_anchor_spelling")
            class_row["members"].append({"stage": stage, "route_node_ids": spelling["route_node_ids"],
                                         "sequence_sha256": spelling["sequence_sha256"],
                                         "flank_class": spelling["flank_class"],
                                         "canonical_orientation": "+" if spelling["sequence"] == canonical else "-",
                                         "assayable": spelling["assayable"]})
    candidate_sequence = region["stages"].get("pre_prune", {}).get("candidate_window")
    candidate_canonical = min(candidate_sequence, reverse_complement(candidate_sequence)) if candidate_sequence else None
    if candidate_canonical and candidate_canonical not in classes:
        classes[candidate_canonical] = {"sequence": candidate_canonical,
                                        "sequence_sha256": digest_text(candidate_canonical),
                                        "flank_classes": {"historical_candidate_unenumerated"},
                                        "assayable": len(candidate_canonical) >= 2 * FLANK_BASES,
                                        "members": [{"stage": "historical_candidate", "route_node_ids": [],
                                                     "sequence_sha256": digest_text(candidate_sequence),
                                                     "flank_class": "historical_candidate_unenumerated",
                                                     "canonical_orientation": "+" if candidate_sequence == candidate_canonical else "-",
                                                     "assayable": len(candidate_sequence) >= 2 * FLANK_BASES}]}
        unresolved.append("historical_candidate_not_enumerated")
    if len(classes) > MAX_ASSAY_ALTERNATIVES:
        unresolved.append("assay_alternative_ceiling")
    candidate_window = region["stages"].get("pre_prune", {}).get("candidate_window")
    class_rows = []
    for index, canonical in enumerate(sorted(classes), 1):
        class_row = classes[canonical]
        if candidate_window == canonical:
            candidate_orientation = "forward"
        elif candidate_window and reverse_complement(candidate_window) == canonical:
            candidate_orientation = "reverse_complement"
        else:
            candidate_orientation = "not_candidate_window"
        class_rows.append({"id": f"{region['id']}_class_{index}", "sequence": class_row["sequence"],
                           "sequence_sha256": class_row["sequence_sha256"],
                           "flank_classes": sorted(class_row["flank_classes"]), "members": class_row["members"],
                           "assayable": class_row["assayable"],
                           "historical_candidate_class": class_row["sequence"] == candidate_canonical,
                           "candidate_coordinate_mapping": {
                               "candidate_full_orientation": "forward",
                               "candidate_window": [region["start"], region["end"]],
                               "canonical_to_candidate_window": candidate_orientation,
                           }})
    historical_class_id = next((item["id"] for item in class_rows if item["historical_candidate_class"]), None)
    return class_rows, sorted(set(unresolved)), historical_class_id


def scanner_manifest(region, classes):
    candidates = [{"id": item["id"], "sequence": item["sequence"], "sequence_sha256": item["sequence_sha256"],
                   "source": {"kind": "graph_local_class", "flank_classes": item["flank_classes"],
                              "members": item["members"], "assayable": item["assayable"]}}
                  for item in classes]
    events = []
    for item in classes:
        if not item["assayable"]:
            continue
        events.append({"id": f"{item['id']}_interior", "candidate_id": item["id"],
                       "comparison_group": region["id"], "start": FLANK_BASES,
                       "end": len(item["sequence"]) - FLANK_BASES,
                       "role": "local_graph_hypothesis", "source": {"region": region["id"],
                       "focal_same_flanks": "focal_same_flanks" in item["flank_classes"],
                       "scope": "local graph hypothesis only; not a full haplotype or biological truth"}})
    return {"schema_version": 1, "candidates": candidates, "events": events}


def build(candidate, pre_graph, post_graph):
    if candidate.get("schema_version") != 1 or candidate.get("kmer_length") != 19:
        raise ValueError("Expected frozen candidate schema_version 1 at k=19")
    record = candidate.get("record", {})
    if not literal_sequence(record.get("oriented_sequence")) or digest_text(record["oriented_sequence"]) != record.get("sequence_sha256"):
        raise ValueError("Candidate sequence or checksum is invalid")
    pre_regions = stage_regions(candidate, pre_graph, "pre_prune")
    templates = [{"id": region["id"], "start": region["start"], "end": region["end"],
                  "status": "pending" if region["status"] == "enumerated" else region["status"],
                  "components": region["components"]} for region in pre_regions]
    post_regions = stage_regions(candidate, post_graph, "post_prune", templates)
    regions = merge_stage_regions(pre_regions, post_regions)
    for region in regions:
        classes, unresolved, historical_class_id = local_classes(region)
        if classes and not any(item["assayable"] for item in classes):
            unresolved.append("no_assayable_local_class")
        region["classes"] = classes
        region["unresolved_reasons"] = unresolved
        region["historical_local_class_id"] = historical_class_id
        region["qualified_for_scanning"] = not unresolved and bool(classes)
        if region["qualified_for_scanning"]:
            region["scanner_manifest"] = scanner_manifest(region, classes)
    return {"schema_version": 1, "purpose": "bounded_local_graph_hypotheses_not_truth",
            "limits": {"flank_bases": FLANK_BASES, "max_walk_bases": MAX_WALK_BASES,
                       "max_expansions": MAX_EXPANSIONS, "max_spellings": MAX_SPELLINGS,
                       "max_assay_alternatives": MAX_ASSAY_ALTERNATIVES}, "regions": regions}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--pre-graph", type=Path, required=True)
    parser.add_argument("--post-graph", type=Path, required=True)
    parser.add_argument("--audit-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.output_dir.exists() or arguments.output_dir.is_symlink():
        raise ValueError("Refusing to overwrite local-assay output")
    builder_path = Path(__file__).resolve()
    builder_bytes = builder_path.read_bytes()
    candidate_bytes = arguments.candidate.read_bytes()
    pre_bytes = arguments.pre_graph.read_bytes()
    post_bytes = arguments.post_graph.read_bytes()
    audit_manifest_bytes = arguments.audit_manifest.read_bytes()
    candidate = json.loads(candidate_bytes)
    pre_graph = json.loads(pre_bytes)
    post_graph = json.loads(post_bytes)
    audit_target = verify_audit_manifest(json.loads(audit_manifest_bytes), candidate, pre_bytes, post_bytes)
    verify_graph_target(pre_graph, audit_target, "pre_prune")
    verify_graph_target(post_graph, audit_target, "post_prune")
    result = build(candidate, pre_graph, post_graph)
    stable_sources = ((arguments.candidate, candidate_bytes), (arguments.pre_graph, pre_bytes),
                      (arguments.post_graph, post_bytes), (arguments.audit_manifest, audit_manifest_bytes),
                      (builder_path, builder_bytes))
    source_freeze_before = {str(path): hashlib.sha256(contents).hexdigest() for path, contents in stable_sources}
    source_freeze_after = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path, _ in stable_sources}
    if source_freeze_after != source_freeze_before:
        raise ValueError("Candidate, graph export, audit manifest, or builder changed during derivation")
    arguments.output_dir.mkdir()
    result["provenance"] = {"candidate_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
                            "pre_graph_sha256": hashlib.sha256(pre_bytes).hexdigest(),
                            "post_graph_sha256": hashlib.sha256(post_bytes).hexdigest(),
                            "audit_manifest_sha256": hashlib.sha256(audit_manifest_bytes).hexdigest(),
                            "builder_sha256": hashlib.sha256(builder_bytes).hexdigest(),
                            "audit_target": audit_target,
                            "source_freeze_before": source_freeze_before,
                            "source_freeze_after": source_freeze_after}
    for region in result["regions"]:
        if region["qualified_for_scanning"]:
            manifest_name = f"{region['id']}.scanner_manifest.json"
            manifest = region.pop("scanner_manifest")
            region["assay_manifest"] = manifest_name
            manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
            region["assay_manifest_sha256"] = hashlib.sha256(manifest_bytes).hexdigest()
            (arguments.output_dir / manifest_name).write_bytes(manifest_bytes)
    (arguments.output_dir / "analysis.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"regions": len(result["regions"]), "qualified_for_scanning": sum(region["qualified_for_scanning"] for region in result["regions"])}))


if __name__ == "__main__":
    main()
