import argparse
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

from verify_frozen_inputs import verify


ROOT = Path(__file__).resolve().parent
REPO = Path('/home/claude/repos/sharkmer')
PREVIOUS = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
ENVIRONMENT_VARIABLE = 'SHARKMER_ITS_AUDIT_DIR'


def digest(path):
    accumulator = hashlib.sha256()
    with path.open('rb') as source:
        while contents := source.read(1024 * 1024):
            accumulator.update(contents)
    return accumulator.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
        output.flush()
        os.fsync(output.fileno())


def load_harness():
    specification = importlib.util.spec_from_file_location('frozen_parity_harness', PREVIOUS / 'run_three_way.py')
    harness = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(harness)
    return harness


def source_receipt(arguments, harness):
    expected = json.loads(arguments.source_snapshot.read_text())['files']
    require(expected and all(digest(Path(path)) == checksum for path, checksum in expected.items()), 'Instrumented compile sources differ')
    build = json.loads(arguments.build_receipt.read_text())
    require(build['returncode'] == 0, 'Instrumented build failed')
    require(build['source_before'] == build['source_after'] == expected, 'Build/source snapshot binding differs')
    require(build['source_snapshot_sha256'] == digest(arguments.source_snapshot), 'Build source snapshot hash differs')
    require(build['binary_sha256'] == digest(arguments.binary), 'Instrumented executable differs from build receipt')
    files = [ROOT / name for name in ('run_graph_capture.py', 'test_run_graph_capture.py', 'freeze_inputs.py', 'verify_frozen_inputs.py')]
    files += list((ROOT / 'inputs').glob('*'))
    files += list((REPO / 'scripts/sharkmer_validate').glob('*.py'))
    files += [arguments.binary, arguments.build_receipt, arguments.source_snapshot,
              ROOT / 'ITS_SCC_AUDIT_PROTOCOL.snapshot.md', PREVIOUS / 'run_three_way.py',
              Path(sys.executable).resolve(), harness.TIME_BINARY, harness.TASKSET_BINARY, harness.PRLIMIT_BINARY]
    require(all(path.is_file() for path in files), 'Required frozen source or protocol snapshot missing')
    return {'files': {str(path): digest(path) for path in sorted(set(files))}, 'compile_sources': expected, 'export_environment_variable': ENVIRONMENT_VARIABLE}


def final_graph_hashes(directory):
    hashes = {}
    errors = []
    try:
        for path in sorted(directory.iterdir()):
            try:
                require(path.is_file(), 'Unexpected non-file graph artifact')
                hashes[path.name] = digest(path)
            except Exception as error:
                errors.append(f'{path.name}: {type(error).__name__}: {error}')
    except Exception as error:
        errors.append(f'graph_directory: {type(error).__name__}: {error}')
    return hashes, errors


def compare_outputs(current, baseline):
    for field in ('n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers'):
        require(current['stats'][field] == baseline['stats'][field], f'Count parity failed: {field}')
    require(current['fasta_records_ordered'] == baseline['fasta_records_ordered'], 'Ordered FASTA parity failed')
    require(current['stats']['pcr_results'] == baseline['stats']['pcr_results'], 'Complete gene/payload parity failed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--source-snapshot', type=Path, required=True)
    parser.add_argument('--build-receipt', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    arguments = parser.parse_args()
    require(arguments.execute, 'No execution without --execute')
    require(not arguments.output.exists(), 'Refusing existing output root')
    require(ENVIRONMENT_VARIABLE not in os.environ, 'Unexpected inherited export environment')
    verify()
    harness = load_harness()
    protocol = json.loads((ROOT / 'inputs/previous_comparison_protocol.json').read_text())
    baseline = json.loads((ROOT / 'inputs/focused_baseline_receipt.json').read_text())
    accession = 'SRR27962769'
    sample = protocol['samples'][accession]
    require(harness.digest(Path(sample['input'])) == sample['full_sha256'], 'Full staged input changed')
    require(harness.inspect_prefix(Path(sample['input']), 1000000) == sample['prefix'], 'Consumed prefix changed')
    require(digest(ROOT / 'inputs/focused_panel.yaml') == '686610b55c1732ca28dfaa2da61aade6b3b16ad1a11ed841b29dc8d42a6a72f2', 'Focused panel changed')
    before = source_receipt(arguments, harness)
    arguments.output.mkdir(parents=True)
    export_directory = arguments.output / 'graphs'
    export_directory.mkdir()
    save(arguments.output / 'source_before.json', before)
    os.environ[ENVIRONMENT_VARIABLE] = str(export_directory.resolve())
    job = {'accession': accession, 'role': 'instrumented_focused', 'binary_role': 'changed_on', 'panel': str(ROOT / 'inputs/focused_panel.yaml'), 'focused_diagnostic_only': True, 'selected_targets': ['CO1_1', 'ITS_2']}
    record = None
    failure = None
    after = None
    try:
        record = harness.run_job(job, protocol, {'changed_on': arguments.binary}, ['--diagnose-withheld-paths'], arguments.output, before)
        save(arguments.output / 'job_receipt.json', record)
        require(record['returncode'] == 0 and record['validated_output'] and not record['timed_out'], 'Instrumented invocation failed')
        compare_outputs(record['outputs'], baseline['outputs'])
        exports = sorted(path.name for path in export_directory.iterdir())
        require(exports == ['audit_manifest.json', 'post_prune.json', 'pre_prune.json'], 'Expected two complete graph exports and completion manifest')
        require(sum((export_directory / name).stat().st_size for name in exports) <= 256 * 1024 * 1024, 'Combined export byte cap exceeded')
        manifest = json.loads((export_directory / 'audit_manifest.json').read_text())
        require(manifest['status'] == 'complete', 'Incomplete graph export')
        require(set(manifest['files']) == {'pre_prune.json', 'post_prune.json'}, 'Unexpected graph manifest inventory')
        target = manifest['target']
        require(target['sample'] == 'withheld_SRR27962769' and target['gene'] == 'insecta_ITS_2' and target['threshold'] == 4 and target['kmer_length'] == 19, 'Export target differs')
        require(target['historical_product_sha256'] == '23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c', 'Export hypothesis identity differs')
        require(manifest['caps'] == {'graph_nodes': 100000, 'graph_edges': 500000, 'serialized_bytes': 256 * 1024 * 1024}, 'Export limits differ')
        for basename, expected in manifest['files'].items():
            graph_path = export_directory / basename
            require(digest(graph_path) == expected['sha256'] and graph_path.stat().st_size == expected['size_bytes'] <= 256 * 1024 * 1024, 'Graph artifact identity or size differs')
            document = json.loads(graph_path.read_text())
            graph = document['graph']
            require(document['schema_version'] == 1 and document['target'] == target and graph['phase'] + '.json' == basename, 'Graph document stage/target differs')
            require(graph['node_count'] == len(graph['nodes']) <= 100000 and graph['edge_count'] == len(graph['edges']) <= 500000, 'Graph counts or caps differ')
        require(harness.digest(Path(sample['input'])) == sample['full_sha256'], 'Full input changed after capture')
        require(harness.inspect_prefix(Path(sample['input']), 1000000) == sample['prefix'], 'Prefix changed after capture')
        after = source_receipt(arguments, harness)
        require(before == after, 'Source drift during capture')
    except Exception as error:
        failure = f'{type(error).__name__}: {error}'
    finally:
        del os.environ[ENVIRONMENT_VARIABLE]
        graph_files, graph_hash_errors = final_graph_hashes(export_directory)
        if graph_hash_errors and failure is None:
            failure = 'Final graph artifact hashing failed'
        save(arguments.output / 'capture_receipt.json', {
            'schema_version': 1, 'baseline_receipt_sha256': before['files'][str(ROOT / 'inputs/focused_baseline_receipt.json')],
            'source_before': before, 'source_after': after, 'source_changed': None if after is None else before != after,
            'failure': failure, 'parity_passed': failure is None, 'job_receipt': record,
            'graph_files': graph_files, 'graph_hash_errors': graph_hash_errors,
            'purpose': 'same_input_diagnostic_capture_not_performance_benchmark',
        })
    require(failure is None, failure)
    print(json.dumps({'parity_passed': True, 'exports': exports}))


if __name__ == '__main__':
    main()
