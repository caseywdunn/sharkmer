#!/usr/bin/env python3
"""Create a deterministic ITS SCC audit evidence archive only when requested."""

import argparse
import gzip
import hashlib
import io
import json
import os
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPOSITORY_ROOT = Path("/home/claude/repos/sharkmer")
EXCLUDED_PARTS = {"__pycache__", "target", "source-pristine"}
EXCLUDED_TOP_LEVEL = {"source-ae9189a.tar"}
BUILD_FILES = {
    "build/build_receipt.json",
    "build/source_snapshot.json",
    "build/cargo_messages.jsonl",
    "build/cargo_stderr.txt",
    "build-v2/build_receipt.json",
    "build-v2/source_snapshot.json",
    "build-v2/cargo_messages.jsonl",
    "build-v2/cargo_stderr.txt",
    "build-v2/cargo_test_stdout.txt",
    "build-v2/cargo_test_stderr.txt",
}
EVIDENCE_DIRECTORIES = ("inputs", "graph_capture", "graph_capture_v2", "local_assays", "read_execution", "review")
OPTIONAL_EVIDENCE_DIRECTORIES = ("final_validation", "final_validation_v2")
INSTRUMENTED_PREFIXES = ("Cargo.toml", "Cargo.lock", "src", "panels")
REPOSITORY_SNAPSHOTS = (
    Path("/home/claude/repos/sharkmer/benchmarks/benchmark_results/v3.2-its-scc-audit-20260913/README.md"),
    Path("/home/claude/repos/sharkmer/dev_docs/ITS_SCC_AUDIT_RESULTS.md"),
    Path("/home/claude/repos/sharkmer/dev_docs/ITS_SCC_AUDIT_PROTOCOL.md"),
    Path("/home/claude/repos/sharkmer/dev_docs/PLAN.md"),
    Path("/home/claude/repos/sharkmer/dev_docs/WITHHELD_PATH_DIAGNOSTICS_RESULTS.md"),
)
EXTERNAL_SOURCE_PATHS = (
    Path("/home/claude/repos/sharkmer/scripts/audit_read_bridges.py"),
    Path("/home/claude/repos/sharkmer/tests/test_read_bridges.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/__init__.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/blast_references.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/primer_analysis.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/reference_provenance.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/reference_targets.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/report.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/results.py"),
    Path("/home/claude/repos/sharkmer/scripts/sharkmer_validate/runner.py"),
    Path("/tmp/sharkmer-withheld-diagnostics-20260913/run_three_way.py"),
)


def digest_bytes(contents):
    return hashlib.sha256(contents).hexdigest()


def read_regular(path):
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Expected a regular file: {path}")
    return path.read_bytes()


def normalized_name(name):
    member = Path(name)
    if member.is_absolute() or ".." in member.parts or member.name in {"", "."}:
        raise ValueError(f"Unsafe archive member name: {name}")
    return member.as_posix()


def scratch_files():
    selected = {}
    for path in sorted(ROOT.iterdir()):
        if path.name in EXCLUDED_TOP_LEVEL or path.name in EXCLUDED_PARTS or path.name.startswith("source-"):
            continue
        if path.is_symlink():
            raise ValueError(f"Refusing symlink in scratch root: {path}")
        if path.is_file() and path.suffix in {".json", ".log", ".md", ".py", ".txt", ".yaml", ".yml", ".patch"}:
            selected[path.relative_to(ROOT).as_posix()] = path
    for directory_name in EVIDENCE_DIRECTORIES + OPTIONAL_EVIDENCE_DIRECTORIES:
        directory = ROOT / directory_name
        if directory_name in OPTIONAL_EVIDENCE_DIRECTORIES and not directory.exists():
            continue
        if not directory.is_dir() or directory.is_symlink():
            raise ValueError(f"Expected regular evidence directory: {directory}")
        for path in sorted(directory.rglob("*")):
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED_PARTS for part in relative.parts):
                continue
            if path.is_symlink():
                raise ValueError(f"Refusing symlink in evidence tree: {path}")
            if path.is_file():
                selected[relative.as_posix()] = path
    for relative_name in BUILD_FILES:
        path = ROOT / relative_name
        selected[relative_name] = path
    source = ROOT / "source-instrumented"
    if not source.is_dir() or source.is_symlink():
        raise ValueError("Instrumented source tree is missing")
    for prefix in INSTRUMENTED_PREFIXES:
        path = source / prefix
        if path.is_file():
            selected[f"instrumented_source/{prefix}"] = path
            continue
        if not path.is_dir() or path.is_symlink():
            raise ValueError(f"Instrumented source subset is missing: {path}")
        for child in sorted(path.rglob("*")):
            if child.is_symlink():
                raise ValueError(f"Refusing symlink in instrumented source: {child}")
            if child.is_file():
                selected[f"instrumented_source/{child.relative_to(source).as_posix()}"] = child
    for path in REPOSITORY_SNAPSHOTS:
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"Repository snapshot is missing or unsafe: {path}")
        selected[f"repository_snapshots/{path.relative_to(REPOSITORY_ROOT).as_posix()}"] = path
    return selected


def expected_external_hashes():
    read_sources = json.loads(read_regular(ROOT / "read_execution" / "source_before.json"))
    graph_sources = json.loads(read_regular(ROOT / "graph_capture_v2" / "source_before.json"))["files"]
    expected = {}
    for mapping in (read_sources, graph_sources):
        for name, checksum in mapping.items():
            if name in expected and expected[name] != checksum:
                raise ValueError(f"Conflicting frozen external source checksum: {name}")
            expected[name] = checksum
    return expected


def external_files():
    expected = expected_external_hashes()
    selected = {}
    records = []
    for source in EXTERNAL_SOURCE_PATHS:
        original = str(source)
        if original not in expected:
            raise ValueError(f"External source is not bound by a frozen receipt: {source}")
        contents = read_regular(source)
        checksum = digest_bytes(contents)
        if checksum != expected[original]:
            raise ValueError(f"External source changed since its frozen receipt: {source}")
        archive_name = normalized_name(f"external_sources/{source.as_posix().lstrip('/').replace('/', '__')}")
        selected[archive_name] = source
        records.append({"original_path": original, "archive_member": archive_name, "sha256": checksum, "size_bytes": len(contents)})
    manifest_name = "external_sources/EXTERNAL_SOURCES.json"
    manifest_bytes = (json.dumps({"schema_version": 1, "sources": records}, indent=2, sort_keys=True) + "\n").encode("utf-8")
    return selected, {manifest_name: manifest_bytes}


def members():
    selected = scratch_files()
    external, generated = external_files()
    for name, path in external.items():
        if name in selected:
            raise ValueError(f"Duplicate archive member: {name}")
        selected[name] = path
    materialized = {}
    for name, path in selected.items():
        name = normalized_name(name)
        if name in materialized:
            raise ValueError(f"Duplicate archive member: {name}")
        materialized[name] = read_regular(path)
    for name, contents in generated.items():
        name = normalized_name(name)
        if name in materialized:
            raise ValueError(f"Duplicate archive member: {name}")
        materialized[name] = contents
    return dict(sorted(materialized.items()))


def contents_manifest(member_bytes):
    return {"schema_version": 1, "archive_format": "tar.gz", "members": [
        {"path": name, "sha256": digest_bytes(contents), "size_bytes": len(contents)}
        for name, contents in member_bytes.items()
    ]}


def add_member(archive, name, contents):
    info = tarfile.TarInfo(normalized_name(name))
    info.size = len(contents)
    info.mode = 0o644
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = 0
    archive.addfile(info, io.BytesIO(contents))


def write_new(path, contents):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(descriptor, "wb") as destination:
        destination.write(contents)
        destination.flush()
        os.fsync(destination.fileno())


def package(destination, member_bytes):
    generated_names = {"evidence.tar.gz", "ARCHIVE_CONTENTS.json", "SHA256SUMS"}
    if destination.is_symlink() or (destination.exists() and not destination.is_dir()):
        raise ValueError(f"Archive destination is unsafe: {destination}")
    if destination.exists():
        unexpected = {path.name for path in destination.iterdir()} - {"README.md"}
        if unexpected:
            raise ValueError(f"Archive destination contains unexpected files: {sorted(unexpected)}")
    else:
        destination.mkdir(parents=True)
    if any((destination / name).exists() or (destination / name).is_symlink() for name in generated_names):
        raise ValueError("Refusing to overwrite a generated archive output")
    archive_path = destination / "evidence.tar.gz"
    with archive_path.open("xb") as raw_archive:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw_archive, mtime=0) as compressed:
            with tarfile.open(mode="w", fileobj=compressed, format=tarfile.PAX_FORMAT) as archive:
                for name, contents in member_bytes.items():
                    add_member(archive, name, contents)
    manifest_bytes = (json.dumps(contents_manifest(member_bytes), indent=2, sort_keys=True) + "\n").encode("utf-8")
    manifest_path = destination / "ARCHIVE_CONTENTS.json"
    write_new(manifest_path, manifest_bytes)
    sums = (f"{digest_bytes(archive_path.read_bytes())}  evidence.tar.gz\n"
            f"{digest_bytes(manifest_bytes)}  ARCHIVE_CONTENTS.json\n").encode("utf-8")
    write_new(destination / "SHA256SUMS", sums)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--package", action="store_true")
    parser.add_argument("--output-dir", type=Path)
    arguments = parser.parse_args()
    if arguments.plan == arguments.package:
        raise ValueError("Choose exactly one of --plan or --package")
    if arguments.package and arguments.output_dir is None:
        raise ValueError("--package requires a fresh --output-dir")
    if arguments.plan and arguments.output_dir is not None:
        raise ValueError("--plan does not write an output directory")
    if arguments.package:
        receipt_path = ROOT / "final_validation_v2" / "receipt.json"
        if not receipt_path.is_file() or receipt_path.is_symlink():
            raise ValueError("Refusing to package before final_validation_v2/receipt.json exists")
        receipt = json.loads(read_regular(receipt_path))
        command_failures = [command for command in receipt.get("commands", []) if command.get("returncode") != 0]
        if receipt.get("status") != "PASS" or receipt.get("sources_unchanged") is not True or command_failures:
            raise ValueError("Refusing to package without a passing final_validation_v2 receipt")
    member_bytes = members()
    manifest = contents_manifest(member_bytes)
    if arguments.plan:
        print(json.dumps({"members": len(manifest["members"]), "bytes": sum(item["size_bytes"] for item in manifest["members"]), "manifest": manifest}, indent=2, sort_keys=True))
        return
    package(arguments.output_dir, member_bytes)
    print(json.dumps({"output_dir": str(arguments.output_dir), "members": len(manifest["members"]), "bytes": sum(item["size_bytes"] for item in manifest["members"])}))


if __name__ == "__main__":
    main()
