# ITS SCC Audit Attempt Lineage

This record distinguishes superseded technical attempts from the accepted
graph-capture and read-assay artifacts. It is an evidence-index aid, not an
interpretation of biological correctness or a release decision.

## Preserved Attempts

1. **Initial instrumented build (`build/`)** — completed with exit status zero
   and a pristine source export, but its receipt retained only the byte hash of
   the logical normalized source snapshot (`0e57cdaa…`) in
   `source_snapshot_sha256`, where later binding required the actual
   `source_snapshot.json` file-byte hash. The copied binary is excluded from the archive;
   the receipt, source map, Cargo logs, and this superseded binding are retained.
2. **Corrected instrumented build (`build-v2/`)** — completed with exit status
   zero and records both the source-snapshot byte hash
   (`bac9db47…`) and logical digest (`0e57cdaa…`). Its executable is excluded;
   build receipt, source map, and Cargo/test logs remain evidence.
3. **Initial graph wrapper (`graph_capture/`)** — the instrumented command did
   produce all three graph bytes, but the wrapper rejected them with
   `ValueError: Graph document stage/target differs` because it expected short
   phase labels. Its receipt reports `parity_passed: false`. The three graph
   hashes are retained and byte-identical to the accepted v2 capture; this does
   not convert the first wrapper attempt into a successful attestation.
   `run_graph_capture.v1.py` is an exact preserved source copy with the old
   receipt’s SHA-256 `f19d9197…`. The old five-test
   `test_run_graph_capture.py` source is unavailable: its recorded SHA-256 is
   `e98b3ff5…`, and removing the later phase-literal regression from the current
   six-test file does not reproduce it. The current six-test file is archived
   only as the accepted-v2 source, never as a replacement for the unavailable
   first-attempt test bytes.
4. **Corrected graph wrapper (`graph_capture_v2/`)** — accepted after binding
   the exporter’s exact verbose phase labels. Its receipt reports
   `parity_passed: true`, `failure: null`, and `source_changed: false`.
5. **Local-assay derivation (`local_assays/`)** — ran the independently reviewed
   builder only over frozen candidate and graph JSON, with no FASTQ input. The
   derivation receipt records exit zero and equal before/after hashes.
6. **Read assay (`read_execution/`)** — separately planned and executed from
   the approved local manifests. Preserve all scanner outputs, per-job receipts,
   source bookends, and independent recount under `review/`; do not infer a
   full ITS haplotype from this local evidence.

## Archive Rules

The later package includes these records, including superseded build/wrapper
attempts, but excludes FASTQ, executable binaries, Cargo target trees, source
archive tarballs, Python bytecode, and nested prior evidence archives. The
package receipt lists every included member’s byte size and SHA-256.

The first build’s driver source was likewise not independently preserved before
the snapshot-hash correction. `build_instrumented.py` is archived as the later
corrected driver only; the initial build receipt and Cargo/source-map artifacts
remain the authoritative record of that attempt.

The preserved `final_validation/` receipt predates the final archive packager
and therefore does not attest to its later bytes. This is a packaging-source
provenance boundary, not a change to the completed graph capture, derivation,
or read-assay producers. Packaging is gated on the separate
`final_validation_v2/` receipt after the packager is frozen.
