#!/usr/bin/env python3
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source-instrumented"
ARCHIVE = ROOT / "source-ae9189a.tar"
PATCH = ROOT / "instrumentation.patch"
BUILD_ROOT = ROOT / "build-v2"
TARGET = BUILD_ROOT / "target"
BINARY = BUILD_ROOT / "sharkmer-its-scc-audit"
RECEIPT = BUILD_ROOT / "build_receipt.json"
SOURCE_SNAPSHOT = BUILD_ROOT / "source_snapshot.json"
EXPECTED_ARCHIVE_SHA256 = "83ebf92cce4401e11a8b9e275b02ee4a5be2de659e97004a8908763243732e69"
COMMIT = "ae9189a7c8013c7160be616bdf3f6c668d5031f8"


def digest(path):
    hasher = hashlib.sha256()
    with path.open("rb") as source:
        while block := source.read(1024 * 1024):
            hasher.update(block)
    return hasher.hexdigest()


def source_files():
    return {
        str(path.resolve()): digest(path)
        for path in sorted(SOURCE.rglob("*"))
        if path.is_file() and "target" not in path.relative_to(SOURCE).parts
    }


def object_digest(value):
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(serialized).hexdigest()


def write_new(path, value):
    serialized = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o664)
    with os.fdopen(descriptor, "wb") as destination:
        destination.write(serialized)
        destination.flush()
        os.fsync(destination.fileno())


def tool_version(command):
    return subprocess.run(command, check=True, text=True, capture_output=True).stdout.strip()


def main():
    if digest(ARCHIVE) != EXPECTED_ARCHIVE_SHA256:
        raise ValueError("Source archive checksum differs")
    if not PATCH.is_file():
        raise ValueError("Instrumentation patch is missing")
    if BUILD_ROOT.exists() or BUILD_ROOT.is_symlink():
        raise ValueError(f"Refusing existing build directory: {BUILD_ROOT}")
    BUILD_ROOT.mkdir()
    source_before = source_files()
    source_snapshot = {"schema_version": 1, "commit": COMMIT, "files": source_before}
    source_snapshot_logical_sha256 = object_digest(source_snapshot)
    write_new(SOURCE_SNAPSHOT, source_snapshot)
    source_snapshot_sha256 = digest(SOURCE_SNAPSHOT)
    command = [
        "cargo",
        "build",
        "--locked",
        "--offline",
        "--release",
        "--message-format=json-render-diagnostics",
    ]
    environment = os.environ.copy()
    environment["CARGO_TARGET_DIR"] = str(TARGET)
    process = subprocess.run(command, cwd=SOURCE, env=environment, text=True, capture_output=True)
    (BUILD_ROOT / "cargo_messages.jsonl").write_text(process.stdout)
    (BUILD_ROOT / "cargo_stderr.txt").write_text(process.stderr)
    test_command = ["cargo", "test", "--locked", "--offline", "--release"]
    test_process = subprocess.run(
        test_command, cwd=SOURCE, env=environment, text=True, capture_output=True
    )
    (BUILD_ROOT / "cargo_test_stdout.txt").write_text(test_process.stdout)
    (BUILD_ROOT / "cargo_test_stderr.txt").write_text(test_process.stderr)
    artifacts = []
    for line in process.stdout.splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if message.get("reason") == "compiler-artifact" and message.get("target", {}).get("name") == "sharkmer" and message.get("executable"):
            artifacts.append(message)
    source_after = source_files()
    artifact = artifacts[0] if len(artifacts) == 1 else None
    receipt = {
        "schema_version": 1,
        "commit": COMMIT,
        "returncode": process.returncode,
        "build_command": command,
        "build_cwd": str(SOURCE),
        "build_environment": {"CARGO_TARGET_DIR": str(TARGET), "offline": True},
        "source_archive": str(ARCHIVE),
        "source_archive_sha256": digest(ARCHIVE),
        "instrumentation_patch": str(PATCH),
        "instrumentation_patch_sha256": digest(PATCH),
        "source_snapshot": source_snapshot,
        "source_snapshot_path": str(SOURCE_SNAPSHOT),
        "source_snapshot_sha256": source_snapshot_sha256,
        "source_snapshot_logical_sha256": source_snapshot_logical_sha256,
        "source_before": source_before,
        "source_after": source_after,
        "source_export_pristine_after_build": source_before == source_after,
        "rustc": tool_version(["rustc", "--version", "--verbose"]),
        "cargo": tool_version(["cargo", "--version", "--verbose"]),
        "cargo_artifact_features": artifact.get("features") if artifact else None,
        "cargo_artifact_executable": artifact.get("executable") if artifact else None,
        "test_command": test_command,
        "test_returncode": test_process.returncode,
        "test_stdout_sha256": digest(BUILD_ROOT / "cargo_test_stdout.txt"),
        "test_stderr_sha256": digest(BUILD_ROOT / "cargo_test_stderr.txt"),
        "binary_path": None,
        "binary_sha256": None,
        "cargo_messages_sha256": digest(BUILD_ROOT / "cargo_messages.jsonl"),
        "cargo_stderr_sha256": digest(BUILD_ROOT / "cargo_stderr.txt"),
    }
    if (
        process.returncode == 0
        and test_process.returncode == 0
        and artifact is not None
        and source_before == source_after
    ):
        shutil.copyfile(artifact["executable"], BINARY)
        BINARY.chmod(0o755)
        receipt["binary_path"] = str(BINARY)
        receipt["binary_sha256"] = digest(BINARY)
    write_new(RECEIPT, receipt)
    if (
        process.returncode != 0
        or test_process.returncode != 0
        or artifact is None
        or source_before != source_after
    ):
        raise SystemExit(1)
    print(json.dumps({"binary_path": str(BINARY), "binary_sha256": digest(BINARY)}))


if __name__ == "__main__":
    main()
