use std::collections::{BTreeMap, BTreeSet};
use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::path::{Path, PathBuf};

use petgraph::Direction;
use petgraph::stable_graph::StableDiGraph;
use petgraph::visit::{EdgeRef, IntoEdgeReferences};
use serde::Serialize;
use sha2::{Digest, Sha256};

use crate::kmer::kmer_to_seq;

use super::graph::{ExtensionRepeatMarkers, reconstruct_edge_kmer};
use super::{DBEdge, DBNode, PCRParams};

const OUTPUT_ENVIRONMENT_VARIABLE: &str = "SHARKMER_ITS_AUDIT_DIR";
const PRE_PRUNE_FILENAME: &str = "pre_prune.json";
const POST_PRUNE_FILENAME: &str = "post_prune.json";
const MANIFEST_FILENAME: &str = "audit_manifest.json";
const TARGET_SAMPLE: &str = "withheld_SRR27962769";
const TARGET_GENE: &str = "insecta_ITS_2";
const TARGET_THRESHOLD: u32 = 4;
const TARGET_KMER_LENGTH: usize = 19;
const TARGET_PRODUCT_SHA256: &str =
    "23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c";
const MAX_GRAPH_NODES: usize = 100_000;
const MAX_GRAPH_EDGES: usize = 500_000;
const MAX_SERIALIZED_BYTES: usize = 256 * 1024 * 1024;
const EXPECTED_MARKERS: [(&str, usize); 5] = [
    ("ACCTCCCGGGAAGTCGCA", 93),
    ("CCTCCCGGGAAGTCGCAC", 94),
    ("CGCTATAGAAAAGGCCGC", 276),
    ("GCTATAGAAAAGGCCGCG", 277),
    ("CTATAGAAAAGGCCGCGC", 278),
];

#[derive(Clone, Serialize)]
struct AuditTarget {
    sample: &'static str,
    gene: &'static str,
    threshold: u32,
    kmer_length: usize,
    historical_product_sha256: &'static str,
    expected_path_markers: Vec<ExpectedMarker>,
}

#[derive(Clone, Serialize)]
struct ExpectedMarker {
    oriented_node_sequence: &'static str,
    historical_path_start: usize,
    historical_path_end: usize,
}

#[derive(Clone, Serialize)]
struct MarkerCauses {
    omitted_self_loop_nodes: Vec<String>,
    cyclic_scc_nodes: Vec<String>,
    retained_collision_edges: Vec<String>,
}

#[derive(Clone, Serialize)]
struct NodeRecord {
    node_id: String,
    oriented_sequence: String,
    is_start: bool,
    is_end: bool,
    incoming_degree: usize,
    outgoing_degree: usize,
    cyclic_scc_id: Option<String>,
}

#[derive(Clone, Serialize)]
struct EdgeRecord {
    edge_id: String,
    oriented_sequence: String,
    source_node_id: String,
    target_node_id: String,
    count: u32,
    source_cyclic_scc_id: Option<String>,
    target_cyclic_scc_id: Option<String>,
}

#[derive(Clone, Serialize)]
struct CyclicComponentRecord {
    component_id: String,
    node_ids: Vec<String>,
    internal_edge_ids: Vec<String>,
    entry_edge_ids: Vec<String>,
    exit_edge_ids: Vec<String>,
}

#[derive(Clone, Serialize)]
struct GraphSnapshot {
    phase: &'static str,
    node_count: usize,
    edge_count: usize,
    canonical_graph_sha256: String,
    nodes: Vec<NodeRecord>,
    edges: Vec<EdgeRecord>,
    cyclic_components: Vec<CyclicComponentRecord>,
    marker_causes_from_pre_prune_detection: MarkerCauses,
}

#[derive(Serialize)]
struct SurvivalRecord {
    pre_prune_node_count: usize,
    surviving_node_count: usize,
    removed_node_ids: Vec<String>,
    pre_prune_edge_count: usize,
    surviving_edge_count: usize,
    removed_edge_ids: Vec<String>,
}

#[derive(Serialize)]
struct CompleteAuditManifest {
    schema_version: u32,
    status: &'static str,
    scope: &'static str,
    graph_identity_contract: &'static str,
    count_semantics: &'static str,
    target: AuditTarget,
    caps: AuditCaps,
    files: BTreeMap<String, GraphFileReceipt>,
    pre_to_post_survival: SurvivalRecord,
}

#[derive(Serialize)]
struct GraphDocument<'a> {
    schema_version: u32,
    target: AuditTarget,
    graph: &'a GraphSnapshot,
}

#[derive(Debug, Serialize)]
struct GraphFileReceipt {
    size_bytes: usize,
    sha256: String,
}

#[derive(Serialize)]
struct AuditCaps {
    graph_nodes: usize,
    graph_edges: usize,
    serialized_bytes: usize,
}

#[derive(Serialize)]
struct IncompleteAudit<'a> {
    schema_version: u32,
    status: &'static str,
    reason: &'a str,
    target: AuditTarget,
    caps: AuditCaps,
}

pub(super) struct AuditCapture {
    output_directory: PathBuf,
    pre_prune_graph: GraphSnapshot,
    stable_markers: MarkerCauses,
}

pub(super) fn capture_pre_prune_graph(
    graph: &StableDiGraph<DBNode, DBEdge>,
    extension_markers: &ExtensionRepeatMarkers,
    threshold: u32,
    kmer_length: usize,
    sample_name: &str,
    params: &PCRParams,
) -> Option<AuditCapture> {
    let output_directory = std::env::var_os(OUTPUT_ENVIRONMENT_VARIABLE).map(PathBuf::from)?;
    if threshold != TARGET_THRESHOLD
        || kmer_length != TARGET_KMER_LENGTH
        || sample_name != TARGET_SAMPLE
        || params.gene_name != TARGET_GENE
    {
        return None;
    }
    if let Err(reason) = prepare_output_directory(&output_directory) {
        eprintln!("ITS SCC audit export failed: {reason}");
        return None;
    }
    match build_pre_prune_capture(graph, extension_markers, output_directory.clone()) {
        Ok(capture) => Some(capture),
        Err(reason) => {
            write_incomplete(&output_directory, &reason);
            None
        }
    }
}

pub(super) fn finish_post_prune_graph(
    capture: Option<AuditCapture>,
    graph: &StableDiGraph<DBNode, DBEdge>,
) {
    let Some(capture) = capture else {
        return;
    };
    let output_directory = capture.output_directory.clone();
    if let Err(reason) = finish_capture(capture, graph) {
        eprintln!("ITS SCC audit export failed: {reason}");
        write_incomplete(&output_directory, &reason);
    }
}

fn build_pre_prune_capture(
    graph: &StableDiGraph<DBNode, DBEdge>,
    extension_markers: &ExtensionRepeatMarkers,
    output_directory: PathBuf,
) -> Result<AuditCapture, String> {
    validate_graph_caps(graph)?;
    let omitted_self_loop_nodes = extension_markers
        .omitted_self_loop_sub_kmers
        .iter()
        .map(|sub_kmer| kmer_to_seq(sub_kmer, &(TARGET_KMER_LENGTH - 1)))
        .collect::<BTreeSet<_>>();
    let retained_collision_edges = extension_markers
        .retained_collision_edges
        .iter()
        .map(|edge_id| {
            graph
                .edge_weight(*edge_id)
                .ok_or_else(|| "Retained collision edge is absent before pruning".to_string())?;
            Ok(kmer_to_seq(
                &reconstruct_edge_kmer(graph, *edge_id),
                &TARGET_KMER_LENGTH,
            ))
        })
        .collect::<Result<BTreeSet<_>, String>>()?;
    let pre_prune_graph = graph_snapshot(
        graph,
        "pre_prune_after_extension_before_tip_and_reachability_pruning",
        omitted_self_loop_nodes,
        retained_collision_edges,
        None,
    )?;
    validate_expected_markers(&pre_prune_graph)?;
    Ok(AuditCapture {
        output_directory,
        stable_markers: pre_prune_graph
            .marker_causes_from_pre_prune_detection
            .clone(),
        pre_prune_graph,
    })
}

fn finish_capture(
    capture: AuditCapture,
    graph: &StableDiGraph<DBNode, DBEdge>,
) -> Result<(), String> {
    validate_graph_caps(graph)?;
    let post_prune_graph = graph_snapshot(
        graph,
        "post_tip_and_reachability_pruning_and_coverage_annotation",
        BTreeSet::new(),
        BTreeSet::new(),
        Some(&capture.stable_markers),
    )?;
    let pre_nodes = capture
        .pre_prune_graph
        .nodes
        .iter()
        .map(|node| node.node_id.clone())
        .collect::<BTreeSet<_>>();
    let post_nodes = post_prune_graph
        .nodes
        .iter()
        .map(|node| node.node_id.clone())
        .collect::<BTreeSet<_>>();
    let pre_edges = capture
        .pre_prune_graph
        .edges
        .iter()
        .map(|edge| edge.edge_id.clone())
        .collect::<BTreeSet<_>>();
    let post_edges = post_prune_graph
        .edges
        .iter()
        .map(|edge| edge.edge_id.clone())
        .collect::<BTreeSet<_>>();
    if !post_nodes.is_subset(&pre_nodes) || !post_edges.is_subset(&pre_edges) {
        return Err("Pruning introduced a stable graph identity".to_string());
    }
    let pre_prune_document = GraphDocument {
        schema_version: 1,
        target: target(),
        graph: &capture.pre_prune_graph,
    };
    let pre_prune_receipt = write_json_new_atomic(
        &capture.output_directory.join(PRE_PRUNE_FILENAME),
        &pre_prune_document,
        MAX_SERIALIZED_BYTES,
    )?;
    let remaining_after_pre = MAX_SERIALIZED_BYTES
        .checked_sub(pre_prune_receipt.size_bytes)
        .ok_or_else(|| "Pre-prune graph exhausted the serialized byte cap".to_string())?;
    let post_prune_document = GraphDocument {
        schema_version: 1,
        target: target(),
        graph: &post_prune_graph,
    };
    let post_prune_receipt = write_json_new_atomic(
        &capture.output_directory.join(POST_PRUNE_FILENAME),
        &post_prune_document,
        remaining_after_pre,
    )?;
    let mut files = BTreeMap::new();
    files.insert(PRE_PRUNE_FILENAME.to_string(), pre_prune_receipt);
    files.insert(POST_PRUNE_FILENAME.to_string(), post_prune_receipt);
    let document = CompleteAuditManifest {
        schema_version: 1,
        status: "complete",
        scope: "audit_only_full_graph_export_no_candidate_admission_or_read_support_inference",
        graph_identity_contract: "oriented_k_minus_one_node_sequence_and_oriented_k_edge_sequence_are_unique_or_export_fails",
        count_semantics: "edge_count_is_the_canonical_kmer_occurrence_count_not_linked_read_support",
        target: target(),
        caps: caps(),
        files,
        pre_to_post_survival: SurvivalRecord {
            pre_prune_node_count: pre_nodes.len(),
            surviving_node_count: post_nodes.len(),
            removed_node_ids: pre_nodes.difference(&post_nodes).cloned().collect(),
            pre_prune_edge_count: pre_edges.len(),
            surviving_edge_count: post_edges.len(),
            removed_edge_ids: pre_edges.difference(&post_edges).cloned().collect(),
        },
    };
    let graph_bytes = document
        .files
        .values()
        .map(|receipt| receipt.size_bytes)
        .sum::<usize>();
    let remaining_for_manifest = MAX_SERIALIZED_BYTES
        .checked_sub(graph_bytes)
        .ok_or_else(|| "Graph files exhausted the serialized byte cap".to_string())?;
    write_json_new_atomic(
        &capture.output_directory.join(MANIFEST_FILENAME),
        &document,
        remaining_for_manifest,
    )?;
    Ok(())
}

fn graph_snapshot(
    graph: &StableDiGraph<DBNode, DBEdge>,
    phase: &'static str,
    omitted_self_loop_nodes: BTreeSet<String>,
    retained_collision_edges: BTreeSet<String>,
    stable_pre_prune_markers: Option<&MarkerCauses>,
) -> Result<GraphSnapshot, String> {
    let mut node_sequences = BTreeMap::new();
    for node_id in graph.node_indices() {
        let sequence = kmer_to_seq(&graph[node_id].sub_kmer, &(TARGET_KMER_LENGTH - 1));
        if node_sequences.insert(sequence.clone(), node_id).is_some() {
            return Err(format!("Duplicate oriented node identity: {sequence}"));
        }
    }
    let components = cyclic_components(graph, &node_sequences)?;
    let node_components = components
        .iter()
        .flat_map(|component| {
            component
                .node_ids
                .iter()
                .map(|node_id| (node_id.clone(), component.component_id.clone()))
        })
        .collect::<BTreeMap<_, _>>();
    let mut nodes = node_sequences
        .iter()
        .map(|(sequence, node_id)| NodeRecord {
            node_id: sequence.clone(),
            oriented_sequence: sequence.clone(),
            is_start: graph[*node_id].is_start,
            is_end: graph[*node_id].is_end,
            incoming_degree: graph
                .neighbors_directed(*node_id, Direction::Incoming)
                .count(),
            outgoing_degree: graph
                .neighbors_directed(*node_id, Direction::Outgoing)
                .count(),
            cyclic_scc_id: node_components.get(sequence).cloned(),
        })
        .collect::<Vec<_>>();
    nodes.sort_by(|left, right| left.node_id.cmp(&right.node_id));
    let mut edges = Vec::with_capacity(graph.edge_count());
    let mut seen_edges = BTreeSet::new();
    for edge in graph.edge_references() {
        let sequence = kmer_to_seq(
            &reconstruct_edge_kmer(graph, edge.id()),
            &TARGET_KMER_LENGTH,
        );
        if !seen_edges.insert(sequence.clone()) {
            return Err(format!("Duplicate oriented edge identity: {sequence}"));
        }
        let source_node_id = kmer_to_seq(&graph[edge.source()].sub_kmer, &(TARGET_KMER_LENGTH - 1));
        let target_node_id = kmer_to_seq(&graph[edge.target()].sub_kmer, &(TARGET_KMER_LENGTH - 1));
        edges.push(EdgeRecord {
            edge_id: sequence.clone(),
            oriented_sequence: sequence,
            source_cyclic_scc_id: node_components.get(&source_node_id).cloned(),
            target_cyclic_scc_id: node_components.get(&target_node_id).cloned(),
            source_node_id,
            target_node_id,
            count: edge.weight().count,
        });
    }
    edges.sort_by(|left, right| left.edge_id.cmp(&right.edge_id));
    let cyclic_scc_nodes = node_components.keys().cloned().collect::<Vec<_>>();
    let marker_causes = if let Some(pre_prune) = stable_pre_prune_markers {
        MarkerCauses {
            omitted_self_loop_nodes: pre_prune
                .omitted_self_loop_nodes
                .iter()
                .filter(|sequence| node_sequences.contains_key(*sequence))
                .cloned()
                .collect(),
            cyclic_scc_nodes: pre_prune
                .cyclic_scc_nodes
                .iter()
                .filter(|sequence| node_sequences.contains_key(*sequence))
                .cloned()
                .collect(),
            retained_collision_edges: pre_prune
                .retained_collision_edges
                .iter()
                .filter(|sequence| seen_edges.contains(*sequence))
                .cloned()
                .collect(),
        }
    } else {
        MarkerCauses {
            omitted_self_loop_nodes: omitted_self_loop_nodes.into_iter().collect(),
            cyclic_scc_nodes,
            retained_collision_edges: retained_collision_edges.into_iter().collect(),
        }
    };
    Ok(GraphSnapshot {
        phase,
        node_count: nodes.len(),
        edge_count: edges.len(),
        canonical_graph_sha256: graph_digest(&nodes, &edges),
        nodes,
        edges,
        cyclic_components: components,
        marker_causes_from_pre_prune_detection: marker_causes,
    })
}

fn cyclic_components(
    graph: &StableDiGraph<DBNode, DBEdge>,
    node_sequences: &BTreeMap<String, petgraph::graph::NodeIndex>,
) -> Result<Vec<CyclicComponentRecord>, String> {
    let inverse = node_sequences
        .iter()
        .map(|(sequence, node_id)| (*node_id, sequence.clone()))
        .collect::<BTreeMap<_, _>>();
    let mut records = Vec::new();
    for component in petgraph::algo::kosaraju_scc(graph) {
        let cyclic = component.len() > 1
            || component
                .first()
                .is_some_and(|node_id| graph.find_edge(*node_id, *node_id).is_some());
        if !cyclic {
            continue;
        }
        let mut node_ids = component
            .iter()
            .map(|node_id| {
                inverse
                    .get(node_id)
                    .cloned()
                    .ok_or_else(|| "SCC node lacks stable identity".to_string())
            })
            .collect::<Result<Vec<_>, _>>()?;
        node_ids.sort();
        let component_id = format!("scc_{}", sha256(node_ids.join("\n").as_bytes()));
        let node_set = component.iter().copied().collect::<BTreeSet<_>>();
        let mut internal_edge_ids = BTreeSet::new();
        let mut entry_edge_ids = BTreeSet::new();
        let mut exit_edge_ids = BTreeSet::new();
        for edge in graph.edge_references() {
            let source_inside = node_set.contains(&edge.source());
            let target_inside = node_set.contains(&edge.target());
            if !source_inside && !target_inside {
                continue;
            }
            let edge_id = kmer_to_seq(
                &reconstruct_edge_kmer(graph, edge.id()),
                &TARGET_KMER_LENGTH,
            );
            match (source_inside, target_inside) {
                (true, true) => {
                    internal_edge_ids.insert(edge_id);
                }
                (false, true) => {
                    entry_edge_ids.insert(edge_id);
                }
                (true, false) => {
                    exit_edge_ids.insert(edge_id);
                }
                (false, false) => {}
            }
        }
        records.push(CyclicComponentRecord {
            component_id,
            node_ids,
            internal_edge_ids: internal_edge_ids.into_iter().collect(),
            entry_edge_ids: entry_edge_ids.into_iter().collect(),
            exit_edge_ids: exit_edge_ids.into_iter().collect(),
        });
    }
    records.sort_by(|left, right| left.component_id.cmp(&right.component_id));
    Ok(records)
}

fn validate_expected_markers(snapshot: &GraphSnapshot) -> Result<(), String> {
    let node_components = snapshot
        .nodes
        .iter()
        .map(|node| (node.node_id.as_str(), node.cyclic_scc_id.as_deref()))
        .collect::<BTreeMap<_, _>>();
    for (sequence, _) in EXPECTED_MARKERS {
        let component = node_components
            .get(sequence)
            .ok_or_else(|| format!("Expected historical marker is absent: {sequence}"))?;
        if component.is_none() {
            return Err(format!(
                "Expected historical marker is not in a cyclic SCC: {sequence}"
            ));
        }
    }
    Ok(())
}

fn validate_graph_caps(graph: &StableDiGraph<DBNode, DBEdge>) -> Result<(), String> {
    if graph.node_count() > MAX_GRAPH_NODES {
        return Err(format!(
            "Graph has {} nodes, exceeding cap {}",
            graph.node_count(),
            MAX_GRAPH_NODES
        ));
    }
    if graph.edge_count() > MAX_GRAPH_EDGES {
        return Err(format!(
            "Graph has {} edges, exceeding cap {}",
            graph.edge_count(),
            MAX_GRAPH_EDGES
        ));
    }
    Ok(())
}

fn graph_digest(nodes: &[NodeRecord], edges: &[EdgeRecord]) -> String {
    let mut hasher = Sha256::new();
    for node in nodes {
        hasher.update(b"node\0");
        hasher.update(node.node_id.as_bytes());
        hasher.update([node.is_start as u8, node.is_end as u8]);
    }
    for edge in edges {
        hasher.update(b"edge\0");
        hasher.update(edge.edge_id.as_bytes());
        hasher.update(edge.source_node_id.as_bytes());
        hasher.update(edge.target_node_id.as_bytes());
        hasher.update(edge.count.to_le_bytes());
    }
    format!("{:x}", hasher.finalize())
}

fn target() -> AuditTarget {
    AuditTarget {
        sample: TARGET_SAMPLE,
        gene: TARGET_GENE,
        threshold: TARGET_THRESHOLD,
        kmer_length: TARGET_KMER_LENGTH,
        historical_product_sha256: TARGET_PRODUCT_SHA256,
        expected_path_markers: EXPECTED_MARKERS
            .iter()
            .map(|(sequence, start)| ExpectedMarker {
                oriented_node_sequence: sequence,
                historical_path_start: *start,
                historical_path_end: *start + TARGET_KMER_LENGTH - 1,
            })
            .collect(),
    }
}

fn caps() -> AuditCaps {
    AuditCaps {
        graph_nodes: MAX_GRAPH_NODES,
        graph_edges: MAX_GRAPH_EDGES,
        serialized_bytes: MAX_SERIALIZED_BYTES,
    }
}

fn prepare_output_directory(output_directory: &Path) -> Result<(), String> {
    if output_directory.is_symlink() {
        return Err(format!(
            "Refusing symlinked audit directory: {}",
            output_directory.display()
        ));
    }
    if output_directory.exists() {
        if !output_directory.is_dir() {
            return Err(format!(
                "Audit output is not a directory: {}",
                output_directory.display()
            ));
        }
        for filename in [PRE_PRUNE_FILENAME, POST_PRUNE_FILENAME, MANIFEST_FILENAME] {
            let path = output_directory.join(filename);
            if path.exists() || path.is_symlink() {
                return Err(format!(
                    "Refusing existing audit output: {}",
                    path.display()
                ));
            }
        }
        return Ok(());
    }
    fs::create_dir_all(output_directory).map_err(|error| {
        format!(
            "Unable to create audit directory {}: {error}",
            output_directory.display()
        )
    })
}

fn write_incomplete(output_directory: &Path, reason: &str) {
    let document = IncompleteAudit {
        schema_version: 1,
        status: "incomplete",
        reason,
        target: target(),
        caps: caps(),
    };
    if let Err(error) = write_json_new_atomic(
        &output_directory.join(MANIFEST_FILENAME),
        &document,
        MAX_SERIALIZED_BYTES,
    ) {
        eprintln!("ITS SCC audit failure receipt could not be written: {error}");
    }
}

fn write_json_new_atomic(
    output_path: &Path,
    document: &impl Serialize,
    byte_cap: usize,
) -> Result<GraphFileReceipt, String> {
    if output_path.exists() || output_path.is_symlink() {
        return Err(format!(
            "Refusing existing audit output: {}",
            output_path.display()
        ));
    }
    let temporary_path = output_path.with_extension(format!("tmp.{}", std::process::id()));
    let output = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temporary_path)
        .map_err(|error| format!("Unable to create {}: {error}", temporary_path.display()))?;
    let mut writer = CappedHashWriter {
        output,
        hasher: Sha256::new(),
        bytes_written: 0,
        byte_cap,
    };
    let write_result = serde_json::to_writer_pretty(&mut writer, document)
        .map_err(|error| io::Error::other(error.to_string()))
        .and_then(|_| writer.write_all(b"\n"))
        .and_then(|_| writer.output.sync_all());
    if let Err(error) = write_result {
        let _ = fs::remove_file(&temporary_path);
        return Err(format!(
            "Unable to write {}: {error}",
            temporary_path.display()
        ));
    }
    let receipt = GraphFileReceipt {
        size_bytes: writer.bytes_written,
        sha256: format!("{:x}", writer.hasher.finalize()),
    };
    fs::rename(&temporary_path, output_path).map_err(|error| {
        let _ = fs::remove_file(&temporary_path);
        format!(
            "Unable to publish {} as {}: {error}",
            temporary_path.display(),
            output_path.display()
        )
    })?;
    Ok(receipt)
}

struct CappedHashWriter {
    output: fs::File,
    hasher: Sha256,
    bytes_written: usize,
    byte_cap: usize,
}

impl Write for CappedHashWriter {
    fn write(&mut self, contents: &[u8]) -> io::Result<usize> {
        let next_size = self
            .bytes_written
            .checked_add(contents.len())
            .ok_or_else(|| io::Error::other("Serialized size overflow"))?;
        if next_size > self.byte_cap {
            return Err(io::Error::other(format!(
                "Serialized audit exceeds remaining byte cap {}",
                self.byte_cap
            )));
        }
        self.output.write_all(contents)?;
        self.hasher.update(contents);
        self.bytes_written = next_size;
        Ok(contents.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        self.output.flush()
    }
}

fn sha256(contents: &[u8]) -> String {
    format!("{:x}", Sha256::digest(contents))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kmer::seq_to_kmer;

    fn node(sequence: &str, is_start: bool, is_end: bool) -> DBNode {
        DBNode {
            sub_kmer: seq_to_kmer(sequence).unwrap(),
            is_start,
            is_end,
        }
    }

    fn edge(count: u32) -> DBEdge {
        DBEdge {
            count,
            coverage_ratio: 0.0,
        }
    }

    #[test]
    fn complete_export_binds_full_graph_components_boundaries_and_files() {
        let mut graph = StableDiGraph::new();
        let start = graph.add_node(node("CAAAAAAAAAAAAAAAAA", true, false));
        let repeat = graph.add_node(node("AAAAAAAAAAAAAAAAAA", false, false));
        let end = graph.add_node(node("AAAAAAAAAAAAAAAAAC", false, true));
        graph.add_edge(start, repeat, edge(10));
        graph.add_edge(repeat, repeat, edge(20));
        graph.add_edge(repeat, end, edge(10));
        let pre_prune_graph = graph_snapshot(
            &graph,
            "pre_prune_after_extension_before_tip_and_reachability_pruning",
            BTreeSet::new(),
            BTreeSet::new(),
            None,
        )
        .unwrap();
        let stable_markers = pre_prune_graph
            .marker_causes_from_pre_prune_detection
            .clone();
        let temporary = tempfile::tempdir().unwrap();
        let output_directory = temporary.path().join("audit");
        prepare_output_directory(&output_directory).unwrap();
        finish_capture(
            AuditCapture {
                output_directory: output_directory.clone(),
                pre_prune_graph,
                stable_markers,
            },
            &graph,
        )
        .unwrap();
        let manifest: serde_json::Value =
            serde_json::from_slice(&fs::read(output_directory.join(MANIFEST_FILENAME)).unwrap())
                .unwrap();
        assert_eq!(manifest["status"], "complete");
        assert_eq!(manifest["files"].as_object().unwrap().len(), 2);
        let pre_prune: serde_json::Value =
            serde_json::from_slice(&fs::read(output_directory.join(PRE_PRUNE_FILENAME)).unwrap())
                .unwrap();
        let component = &pre_prune["graph"]["cyclic_components"][0];
        assert_eq!(
            component["node_ids"],
            serde_json::json!(["AAAAAAAAAAAAAAAAAA"])
        );
        assert_eq!(
            component["internal_edge_ids"],
            serde_json::json!(["AAAAAAAAAAAAAAAAAAA"])
        );
        assert_eq!(
            component["entry_edge_ids"],
            serde_json::json!(["CAAAAAAAAAAAAAAAAAA"])
        );
        assert_eq!(
            component["exit_edge_ids"],
            serde_json::json!(["AAAAAAAAAAAAAAAAAAC"])
        );
        for (filename, receipt) in manifest["files"].as_object().unwrap() {
            let contents = fs::read(output_directory.join(filename)).unwrap();
            assert_eq!(receipt["size_bytes"], contents.len());
            assert_eq!(receipt["sha256"], sha256(&contents));
        }
    }

    #[test]
    fn capped_writer_removes_oversize_temporary_output() {
        let temporary = tempfile::tempdir().unwrap();
        let output_path = temporary.path().join("oversize.json");
        let error = write_json_new_atomic(&output_path, &vec!["ACGT"; 10], 4).unwrap_err();
        assert!(error.contains("byte cap"));
        assert!(!output_path.exists());
        assert_eq!(fs::read_dir(temporary.path()).unwrap().count(), 0);
    }
}
