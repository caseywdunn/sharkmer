#!/usr/bin/env python3
"""Run the frozen local-assay derivation once with durable receipts."""

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BUILDER = ROOT / "build_local_assays.py"
CANDIDATE = ROOT / "inputs" / "candidate.json"
GRAPHS = ROOT / "graph_capture_v2" / "graphs"
PRE_GRAPH = GRAPHS / "pre_prune.json"
POST_GRAPH = GRAPHS / "post_prune.json"
AUDIT_MANIFEST = GRAPHS / "audit_manifest.json"
OUTPUT = ROOT / "local_assays"
RECEIPT = ROOT / "derivation_receipt.json"
STDOUT = ROOT / "derivation.stdout.txt"
STDERR = ROOT / "derivation.stderr.txt"


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as source:
        while contents := source.read(1024 * 1024):
            checksum.update(contents)
    return checksum.hexdigest()


def source_hashes(paths):
    if not all(path.is_file() and not path.is_symlink() for path in paths):
        raise ValueError("Required derivation source is missing or not a regular file")
    return {str(path): digest(path) for path in paths}


def output_hashes(directory):
    if not directory.is_dir() or directory.is_symlink():
        return {}
    return {path.relative_to(directory).as_posix(): digest(path)
            for path in sorted(directory.rglob("*")) if path.is_file() and not path.is_symlink()}


def save(path, value):
    with path.open("x") as destination:
        destination.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
        destination.flush()


def main():
    if OUTPUT.exists() or RECEIPT.exists() or STDOUT.exists() or STDERR.exists():
        raise ValueError("Derivation receipts or output already exist")
    sources = [BUILDER, CANDIDATE, PRE_GRAPH, POST_GRAPH, AUDIT_MANIFEST, Path(__file__).resolve(), Path(sys.executable).resolve()]
    before = source_hashes(sources)
    command = [str(Path(sys.executable).resolve()), str(BUILDER), "--candidate", str(CANDIDATE),
               "--pre-graph", str(PRE_GRAPH), "--post-graph", str(POST_GRAPH),
               "--audit-manifest", str(AUDIT_MANIFEST), "--output-dir", str(OUTPUT)]
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run(command, text=True, capture_output=True)
    finished = datetime.now(timezone.utc).isoformat()
    STDOUT.write_text(process.stdout)
    STDERR.write_text(process.stderr)
    after = source_hashes(sources)
    receipt = {"schema_version": 1, "purpose": "graph_only_local_assay_derivation_no_fastq_read",
               "command": command, "started_at": started, "finished_at": finished,
               "returncode": process.returncode, "source_before": before, "source_after": after,
               "source_changed": before != after, "stdout_sha256": digest(STDOUT), "stderr_sha256": digest(STDERR),
               "output_files": output_hashes(OUTPUT)}
    save(RECEIPT, receipt)
    if process.returncode != 0 or receipt["source_changed"]:
        raise SystemExit(1)
    print(json.dumps({"returncode": process.returncode, "output_files": len(receipt["output_files"])}))


if __name__ == "__main__":
    main()
