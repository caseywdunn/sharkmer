# Gryllus ITS SCC graph export design

## Finding

The built-in `--dump-graph` path cannot answer this audit. `evaluate_threshold_graph` computes cyclic SCC membership from the extended graph, then runs tip pruning and reachability pruning, and only then calls `write_annotated_dot`. The DOT therefore contains post-pruning topology with transient numeric graph indexes, but no pre-pruning component membership, marker causes, phase binding, or pre-to-post survival map.

The frozen withheld-path record establishes that the historical 978 bp sequence with SHA-256 `23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c` was enumerated at k=19 and threshold 4. It traversed five pre-pruning cyclic-SCC node markers at starts 93, 94, 276, 277, and 278. Marker footprints do not establish the complete ambiguity interval, repeat copy number, or read support.

## Isolated instrumentation

The audit source is a clean `git archive` export of commit `ae9189a7c8013c7160be616bdf3f6c668d5031f8` under `source-instrumented/`. Its only execution hook is inside `evaluate_threshold_graph` immediately before repeat-marker calculation and immediately after tip/reachability pruning. It does not mutate the graph, repeat markers, path ordering, admission, search bounds, thresholds, or products.

The hook is active only when all of these conditions match:

- environment variable `SHARKMER_ITS_AUDIT_DIR` is set;
- sample is `withheld_SRR27962769`;
- gene is `insecta_ITS_2`;
- k is 19;
- threshold is 4.

The audit directory may contain wrapper logs, but the exporter refuses pre-existing or symlinked `pre_prune.json`, `post_prune.json`, or `audit_manifest.json`. Graph files are atomically renamed individually and `audit_manifest.json` is written last. A missing or non-`complete` manifest is not a successful export.

## Export contract

`pre_prune.json` and `post_prune.json` each contain the complete graph for that phase, not a clipped marker neighborhood:

- every node, identified by its oriented k-1 sequence;
- every directed edge, identified by its oriented k sequence, source and target node identities, and canonical kmer occurrence count;
- start/end flags and phase-specific incoming/outgoing degree;
- every cyclic SCC with complete member nodes, internal edges, incoming boundary edges, and outgoing boundary edges;
- omitted-self-loop node, cyclic-SCC node, and retained-collision-edge cause identities from pre-pruning detection;
- a canonical graph digest over sorted stable identities and counts.

The post-pruning graph recomputes its own cyclic SCCs. Its pre-pruning marker lists contain only marker identities that survive into the post-pruning graph. The manifest separately records every removed stable node and edge identity.

Node and edge sequence identities are construction invariants because the graph's node lookup is keyed by oriented k-1 sequence and existing directed edges are reused. The exporter independently rejects duplicate oriented node or edge identities rather than emitting ambiguous numeric indexes.

The manifest target binds the historical product SHA-256 and all five expected path marker sequences and zero-based half-open positions. Export fails incomplete if any expected marker is missing or is not a member of a cyclic SCC in the pre-pruning graph.

## Bounds and failure behavior

Each phase is limited to 100,000 nodes and 500,000 edges. The combined graph and manifest JSON stream is limited to 256 MiB. Serialization uses a capped hashing writer, so it does not first allocate an unbounded JSON string. Cap, identity, marker, serialization, or publication failures produce an `incomplete` manifest when possible and never alter pruning or path search.

The edge count is marginal canonical kmer occurrence evidence. It does not show that one read spans an SCC entry, a cycle, and an exit. The stored topology is sufficient for a separately preregistered bounded walk enumerator and read-window scanner, but no graph path becomes admissible and no SCC becomes bridge-ready from this export alone.

## Verification before real capture

The audit build receipt must bind the archive, exact instrumentation patch, full source-file hash map before and after the locked offline build, Cargo/rustc versions, Cargo artifact features, binary SHA-256, and return code. The real wrapper must use the previously frozen 1M-read prefix and focused two-gene panel, then require:

- complete graph manifest and matching file size/hash receipts;
- exact target/k/threshold/product/marker bindings;
- full source and input bookends;
- unchanged kmer/read/base counts, ordered FASTA outputs, full gene outcomes, threshold diagnostics, and withheld-path payload relative to the archived focused run.

Export overhead invalidates timing comparison. Public reference similarity and graph edge counts are not sample haplotype or linked-read truth.
