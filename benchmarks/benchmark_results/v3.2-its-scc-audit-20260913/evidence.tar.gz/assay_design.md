# Gryllus ITS_2 SCC Local-Alternative Read Assay Design

## Scope

This is a proposed descriptive read-evidence assay for the historical Gryllus
`insecta_ITS_2` withheld identity. It does not alter repeat gates, panels,
assemblies, or candidate selection. It asks only whether the fixed first-million
R1 records contain high-quality local windows that distinguish preregistered
graph-hypothesis classes at a specified local locus.

No outcome may be described as a full amplicon, haplotype, copy-number, or
biological-correctness result.

## Frozen historical context

- Historical candidate: `ITS_2`, length 978, SHA256
  `23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c`.
- Historical result receipts: three baseline FASTAs and three candidate no-product
  results are listed in the `SRR27962769` `ITS_2` case in
  `/tmp/sharkmer-read-audit-20260913/candidates/candidate_manifest.json`
  (manifest SHA256 `a8df6371680394dfc37b8aec62cd2aed0e2968306f36420a6858221046b59b4e`).
- Current withheld diagnostics:
  `/tmp/sharkmer-withheld-diagnostics-20260913/withheld_results.json` SHA256
  `307b7798ea111ed8329d8fe40a4ed576638442ec1254f0dc6312811430b4b462`.
  At threshold 4 it records 180 observed withheld paths, 12 retained paths in
  the full-panel allocation, and candidate-local SCC marker-covered runs
  `[93,112)` and `[276,296)` on the historical sequence. It also records that
  retention was truncated. These runs are marker coverage only, not complete
  ambiguity intervals or read-bridge-ready coordinates.
- The historical output has no retained same-gene candidate sequence. The earlier
  all-sequence suspect interval `[0,978)` has no 21-base flanks and is not a
  usable scanner event.

## Fixed read collection

Use only the unpaired R1 prefix already consumed by the frozen benchmark:

- FASTQ: `/tmp/sharkmer-release-comparison/inputs/SRR27962769.fastq`
- Original source segment: `SRR27962769_1.fastq.gz`, records 1 through 1,000,000,
  with mate-1 labels; no R2 stream is part of this assay.
- Expected prefix receipt:
  `/tmp/sharkmer-read-audit-20260913/scan_specs/SRR27962769.expected_prefix.json`
  SHA256 `ad67cd0d405ba6ad76d768361ada1238ac4ea666e41f3d5a45f11d070a586810`.
- Consumed subset: 1,000,000 records, 150,000,000 bases, 365,356,898 bytes,
  SHA256 `6aef48e6ed467e7f1ff25a3cd2a21d51dc2378985bdd855e796b539f0fc0c794`.
- Staged full-file identity: 2,929,733,806 bytes, SHA256
  `d4252f0052d9eaf1753debd1c82eb132666f2300e43d80524ded9275a81081b2`.

The detailed source URL, first/last headers, quality range, input mode, and
benchmark settings are in
`/tmp/sharkmer-read-audit-20260913/inputs/manifest.json` SHA256
`b5e55563052202abb7b32186f0a8ca527f395b944f82679d1730473fffbf40e1`.

## Complete local alternative universe

The scanner can only establish local-window evidence. Before constructing scanner
representations, a graph-to-local-assay builder must identify the competing
universe for one SCC-associated locus as follows:

1. Group every candidate occurrence that touches the same SCC component; marker
   proximity alone does not make `[93,112)` and `[276,296)` independent loci.
   Require every historical 18-mer node and adjacent 19-mer edge in both full
   pre- and post-pruning exports before deriving any local region.
2. Merge overlapping proposed spans after adding their 21-base flanks. Every
   retained flank must be outside the complete competing interval and SCC
   membership, not merely outside one candidate spelling.
3. Enumerate all anchor-to-anchor spellings of length at most 150 bases through
   the entire stored graph, not only the SCC. Do not apply production's
   `max_node_visits = 2`; revisits that fit the local length cap are alternatives.
4. Bound each region/stage at 1,000,000 graph states and 4,096 distinct spellings.
   Persist `complete_within_bounds: false` on either cap. Do not discard an
   over-cap route as a negative result.
5. The declared local universe is complete only relative to the stated stored
   graph, anchors, length cap, and state/spelling caps. It is not a claim that all
   cyclic walks, templates, or biological copies were enumerated.
6. A spelling that reaches the right anchor but is shorter than the required
   42 bases is retained as an unassayable competitor and makes that region
   unresolved. It is never silently omitted or converted into a shortened event.

If no complete-in-bounds local universe is available, a scanner observation may
be reported as a local occurrence only. It must not receive a unique-alternative
or bridge-rescue interpretation.

## Local-class scanner representations

The unchanged scanner determines uniqueness by searching each observed assay
window against every supplied candidate representation. Passing entire candidate
haplotypes would falsely mark a locally shared window non-unique merely because
many full graph paths contain it. Do not supply full paths.

For each complete-in-bounds locus, construct one scanner manifest containing only
that locus's collapsed local classes:

1. A class representation is exactly `left_21 + local_spelling + right_21` in
   the oriented graph direction, using literal A/C/G/T bases. The event is
   `start: 21`, `end: len(sequence) - 21`; a zero-length interior is a valid
   deletion-junction event when both flanks exist.
2. Collapse all full spellings whose complete scanner-window representation is
   identical, including reverse-complement-equivalent representations, into one
   local class. Preserve every contributing graph-hypothesis/spelling identifier
   as provenance. A class means only “indistinguishable by this local assay,” not
   one haplotype.
3. Supply a separate scanner candidate for each distinct local class. Preflight
   must test every observed window against all class spellings and reverse
   complements. More than one placement is locally non-discriminating; report it
   as ambiguous instead of expanding the candidate to full length.
4. Use one `comparison_group` for classes that compete at this same locus. Use a
   new manifest, therefore a new candidate namespace, for each independent
   region. Do not put marginal occurrence controls in a structural group.

This removes ambiguity caused solely by unrelated full-haplotype variation while
retaining genuine ambiguity when the local window itself cannot distinguish the
finite declared classes.

## Scanner requirements and planned calls

- Each event needs 21 complete literal flanks. Missing flanks remain
  `missing_complete_flanks`; they are not shortened or synthesized.
- Run exact and one-substitution sensitivity assays separately from identical
  frozen event and prefix bytes. Never pool the two counts or promote a
  one-substitution observation to exact evidence.
- The unchanged scanner requires Phred+33-compatible records and minimum Q20 in
  every reported match window.
- A local bridge is corroborated only when the scanner's witness has at least
  three distinct read identifiers and three distinct projected footprints. These
  are unpaired R1 observations, not UMI-certified molecules or paired fragments.
- Retain the full ledger: ordinal, header, sequence, quality, strand, observed
  template placements, and projected footprint. No R2 pairing is inferred.
- Independent SCC loci remain unphased: a bridge observation in one local region
  cannot be combined with another region across the ITS distance.

After independent review of a manifest, invoke the unchanged scanner per region
with fresh outputs:

```text
python3 scripts/audit_read_bridges.py --fastq /tmp/sharkmer-release-comparison/inputs/SRR27962769.fastq --events <frozen-region-events.json> --expected-prefix /tmp/sharkmer-read-audit-20260913/scan_specs/SRR27962769.expected_prefix.json --max-substitutions 0 --output <fresh-exact.json>
python3 scripts/audit_read_bridges.py --fastq /tmp/sharkmer-release-comparison/inputs/SRR27962769.fastq --events <frozen-region-events.json> --expected-prefix /tmp/sharkmer-read-audit-20260913/scan_specs/SRR27962769.expected_prefix.json --max-substitutions 1 --output <fresh-one-substitution.json>
```

The scanner to freeze is `scripts/audit_read_bridges.py` SHA256
`f6f1371bb4884c2a8e9475e5c56b99a30b8c429267a294cdeba19905db411983`.
No scanner call was run while preparing this design.

The builder is frozen with the graph-export receipt before any graph capture:

```text
python3 /tmp/sharkmer-its-scc-audit-20260913/build_local_assays.py \
  --candidate /tmp/sharkmer-its-scc-audit-20260913/inputs/candidate.json \
  --pre-graph <pre_prune.json> --post-graph <post_prune.json> \
  --audit-manifest <audit_manifest.json> --output-dir <fresh-local-analysis>
```

It verifies the export file receipts, graph target identity, candidate path, and
its own source bytes before and after derivation. Its analysis records each
canonical class's forward or reverse-complement relationship to the original
candidate coordinates so scanner ledgers can be projected without inventing a
new full-length orientation claim.

## Interpretation limits

- SCC markers and retained paths are graph-diagnostic inputs; they do not prove a
  complete, correctly phased, or biologically correct ITS sequence.
- A non-observation is unresolved under this first-million-R1 bound. A local
  observation does not establish the full 978-base ITS identity.
- The one-substitution assay is less specific and descriptive only.
- This is a read-evidence audit, not a release gate or gate-policy change.
