import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def summarize():
    plan_path = ROOT / 'read_assay_plan.json'
    execution_path = ROOT / 'read_execution/execution.json'
    plan = json.loads(plan_path.read_text())
    execution = json.loads(execution_path.read_text())
    analysis = json.loads(Path(plan['analysis_path']).read_text())
    require(execution['plan_sha256'] == sha(plan_path), 'Execution plan differs')
    require(execution['failure'] is None and execution['source_changed'] is False, 'Failed or source-drifted execution')
    require(execution['source_before'] == execution['source_after'] == plan['sources'], 'Source bookends differ')
    require(all(sha(Path(path)) == checksum for path, checksum in plan['sources'].items()), 'Frozen source bytes differ')
    require([record['job'] for record in execution['jobs']] == plan['jobs'], 'Execution matrix differs')
    expected = [(region['id'], mode) for region in analysis['regions'] if region['qualified_for_scanning'] for mode in (0, 1)] + [('co1_control', mode) for mode in (0, 1)]
    require([(job['region'], job['max_substitutions']) for job in plan['jobs']] == expected, 'Plan omits or duplicates a required assay')
    rows = []
    for record in execution['jobs']:
        job = record['job']
        require(record['returncode'] == 0 and record['validated'] and not record['timed_out'], 'Failed scanner invocation')
        receipt_path = execution_path.parent / f"{job['region']}.substitutions_{job['max_substitutions']}.receipt.json"
        require(json.loads(receipt_path.read_text()) == record, 'Individual receipt differs')
        report_path = execution_path.parent / job['output_basename']
        require(record['output_sha256'] == sha(report_path), 'Scanner output bytes differ')
        report = json.loads(report_path.read_text())
        manifest = json.loads(Path(job['manifest']).read_text())
        require(sha(Path(job['manifest'])) == job['manifest_sha256'], 'Event manifest differs')
        require(report['input_subset'] == plan['input']['prefix'] and report['max_substitutions'] == job['max_substitutions'], 'Consumed prefix or substitution limit differs')
        require(report['minimum_quality'] == 20 and report['flank_bases'] == 21 and report['paired'] is False, 'Read evidence policy differs')
        require([event['id'] for event in report['events']] == [event['id'] for event in manifest['events']], 'Event inventory differs')
        events = {event['id']: event for event in manifest['events']}
        candidates = {candidate['id']: candidate for candidate in manifest['candidates']}
        region = next((region for region in analysis['regions'] if region['id'] == job['region']), None)
        for event in report['events']:
            definition = events[event['id']]
            require(all(event[key] == definition[key] for key in ('candidate_id', 'start', 'end')), 'Assayed coordinates differ')
            candidate = candidates[event['candidate_id']]
            sequence = candidate['sequence']
            window = sequence[event['start'] - 21:event['end'] + 21]
            require(event['window_sequence'] == window, 'Actual assay window differs')
            require(event['local_bridge_status'] == ('corroborated_local_bridge' if len(event['corroboration_witness']) >= 3 else 'unresolved'), 'Local witness status differs')
            rows.append({
                'region': job['region'], 'max_substitutions': job['max_substitutions'],
                'event_id': event['id'], 'class_id': event['candidate_id'], 'window_length': len(window),
                'historical_its_class': region is not None and region['historical_local_class_id'] == event['candidate_id'],
                'candidate_window_coordinates': None if region is None else [region['start'], region['end']],
                'records': event['records'], 'unique_records': event['unique_records'],
                'ambiguous_records': event['ambiguous_records'], 'distinct_ids': event['distinct_ids'],
                'distinct_footprints': event['distinct_footprints'], 'witness_size': len(event['corroboration_witness']),
                'local_bridge_status': event['local_bridge_status'], 'window_sha256': hashlib.sha256(window.encode()).hexdigest(),
                'report_sha256': sha(report_path),
            })
    return {'schema_version': 1, 'plan_sha256': sha(plan_path), 'execution_sha256': sha(execution_path),
            'analysis_sha256': sha(Path(plan['analysis_path'])), 'summarizer_sha256': sha(Path(__file__)),
            'rows': rows, 'biological_correctness': 'full_haplotype_not_established',
            'limitations': 'Local sequence classes within the stored-graph <=150bp universe only; same R1 sample, no long-allele absence or cross-region phase claim.'}


if __name__ == '__main__':
    result = summarize()
    with (ROOT / 'read_summary.json').open('x') as output:
        output.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result['rows'], indent=2))
