# ITS SCC Audit Evidence Archive

This scratch directory holds the reproducibility evidence for the Gryllus
`insecta_ITS_2` stored-graph and local-read assay. It is not a release archive,
a panel update, or proof of a complete 978 bp haplotype.

`package_evidence.py` is intentionally no-op by default. After explicit
authorization, use its `--package --output-dir <fresh-directory>` mode to write
`evidence.tar.gz`, `ARCHIVE_CONTENTS.json`, and `SHA256SUMS`. `--plan` verifies
the selected inputs and prints the deterministic member inventory without
creating an archive.

The selected evidence includes frozen inputs, both graph-capture attempts,
local-assay derivation, all read-assay outputs, independent review/recount,
source/build receipts, the exact instrumentation patch, and minimal
instrumented Rust source (`Cargo.*`, `src/`, and `panels/`). It also copies the
frozen external Python sources used by the capture/read validators and records
their original absolute paths and validated checksums under
`external_sources/`.

It snapshots the approved repository protocol, results, PLAN, and withheld-path
diagnostic result documents at package time under `repository_snapshots/`.
Both the preserved pre-packager `final_validation/` receipt and the required
post-packager `final_validation_v2/` receipt are selected when present. The
package operation itself requires the latter to pass with unchanged sources.

Excluded material includes raw FASTQ input, executables, Cargo target trees,
the large baseline source tarball, Python bytecode, full source worktrees, and
nested prior archives. Historical input receipts preserve the identities of
those excluded inputs without silently treating them as archived data.

See `ATTEMPT_LINEAGE.md` for the preserved failed/superseded build and graph
wrapper attempts. Root-authored protocol, results, PLAN, and review snapshots
added before packaging are included automatically when they are regular
top-level text/JSON/YAML files.
