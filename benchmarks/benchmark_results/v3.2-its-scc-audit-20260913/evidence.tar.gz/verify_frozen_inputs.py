import hashlib
import json
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BENCHMARKS = Path('/home/claude/repos/sharkmer/benchmarks/benchmark_results')
ARCHIVES = {
    'withheld': ('v3.2-withheld-diagnostics-20260913', '04057bf295cf889c7c8db6fec59446923c2439e4be828d6d82b9286262574ae4'),
    'reads': ('v3.2-read-backed-audit-20260913', '54fe073709c27d7cba87ee608641fe778903d06e97ac49715b9868f4b877dfc2'),
}
MEMBERS = {
    'focused_baseline_receipt.json': ('withheld', 'execution/SRR27962769.changed_on_focused.receipt.json'),
    'focused_panel.yaml': ('withheld', 'focused_panels/SRR27962769.insecta.focused.yaml'),
    'previous_comparison_protocol.json': ('withheld', 'protocol.json'),
    'expected_prefix.json': ('reads', 'scan_specs/SRR27962769.expected_prefix.json'),
    'prior_read_manifest.json': ('reads', 'scan_specs/SRR27962769.scanner_manifest.json'),
}


def sha(contents):
    return hashlib.sha256(contents).hexdigest()


def verify():
    receipts = {}
    for key, (directory, expected) in ARCHIVES.items():
        path = BENCHMARKS / directory / 'evidence.tar.gz'
        if sha(path.read_bytes()) != expected:
            raise ValueError('Prior reviewed archive changed')
        with tarfile.open(path) as archive:
            for basename, (archive_key, member) in MEMBERS.items():
                if archive_key != key:
                    continue
                current = (ROOT / 'inputs' / basename).read_bytes()
                if current != archive.extractfile(member).read():
                    raise ValueError(f'Frozen input differs from reviewed archive: {basename}')
                receipts[basename] = {'sha256': sha(current), 'archive_sha256': expected, 'archive_member': member}
            if key == 'withheld':
                analysis = json.load(archive.extractfile('withheld_results.json'))
                original = [row['matches'][0]['record'] for row in analysis['historical_localization'] if row['historical_sha256'] == '23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c']
                candidate = json.loads((ROOT / 'inputs/candidate.json').read_text())
                if len(original) != 2 or any(record != candidate['record'] for record in original):
                    raise ValueError('Candidate differs from reviewed exact hypothesis')
    prior = json.loads((ROOT / 'inputs/prior_read_manifest.json').read_text())
    control = json.loads((ROOT / 'inputs/co1_control_manifest.json').read_text())
    expected_events = [event for event in prior['events'] if 'CO1_1_frozen_alternatives' in event.get('comparison_group', '') and event['role'] in {'supplementary_retained_corresponding_interval', 'primary_complete_placement_union'}]
    if len(expected_events) != 2 or control['events'] != expected_events or control['candidates'] != prior['candidates']:
        raise ValueError('CO1 controls differ from prior definitions or competitors')
    return receipts


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2, sort_keys=True))
