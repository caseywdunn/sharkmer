#!/usr/bin/env python3
"""Run the frozen exact recount once with an outer execution receipt."""

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path("/tmp/sharkmer-its-scc-audit-20260913")
REVIEW = ROOT / "review"
CHECKER = REVIEW / "recount_exact.py"
PLAN = ROOT / "read_assay_plan.json"
SOURCE_RESULTS = ROOT / "read_execution"
OUTPUT = REVIEW / "exact_recount_execution"
INTERPRETER = Path("/tmp/sharkmer-benchmark-env/bin/python3.12")
EXPECTED_SOURCES = {
    str(CHECKER): "01063aec4241966bcd53031a204466f6277ba2f4837740f1506d95d0cae48905",
    str(PLAN): "11b2f4429eef8bbe7f7e0745531c2d30ce46f18f05f7991600a838dba6f86959",
    str(SOURCE_RESULTS / "co1_control.substitutions_0.json"): "343225dc936870478c0e397aa9685728dc24c4f4c00a73bb563a7ba3acd2aaf6",
    str(SOURCE_RESULTS / "region_1.substitutions_0.json"): "2ece98f4a6c44be95b4fc0710a76afd465e10e8245d2e9f60f19431776a9f003",
    str(SOURCE_RESULTS / "region_2.substitutions_0.json"): "d0118b91f7b533526e470019cce75c2ea9c356ec1a7a23e8743f894c84621ebc",
}


def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            checksum.update(chunk)
    return checksum.hexdigest()


def current_sources():
    return {path: digest(path) for path in EXPECTED_SOURCES}


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise ValueError("Refusing to overwrite exact recount execution")
    sources_before = current_sources()
    if sources_before != EXPECTED_SOURCES:
        raise ValueError("Frozen exact recount sources differ before execution")
    interpreter_before = digest(INTERPRETER)
    OUTPUT.mkdir()
    stdout_path = OUTPUT / "stdout.txt"
    stderr_path = OUTPUT / "stderr.txt"
    result_path = OUTPUT / "recount.json"
    command = [
        str(INTERPRETER),
        str(CHECKER),
        "--plan", str(PLAN),
        "--source-results", str(SOURCE_RESULTS),
        "--output", str(result_path),
    ]
    started_at = timestamp()
    returncode = None
    failure = None
    with stdout_path.open("x") as stdout, stderr_path.open("x") as stderr:
        try:
            completed = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=1800, check=False)
            returncode = completed.returncode
        except subprocess.TimeoutExpired:
            failure = "timeout_after_1800_seconds"
    ended_at = timestamp()
    sources_after = current_sources()
    interpreter_after = digest(INTERPRETER)
    sources_unchanged = sources_after == sources_before == EXPECTED_SOURCES
    interpreter_unchanged = interpreter_after == interpreter_before
    result_exists = result_path.is_file() and not result_path.is_symlink()
    status = "complete" if returncode == 0 and failure is None and sources_unchanged and interpreter_unchanged and result_exists else "failed"
    receipt = {
        "schema_version": 1,
        "status": status,
        "purpose": "outer_receipt_for_independent_exact_recount_validation",
        "command": command,
        "returncode": returncode,
        "failure": failure,
        "started_at": started_at,
        "ended_at": ended_at,
        "timeout_seconds": 1800,
        "interpreter": {
            "path": str(INTERPRETER.resolve()),
            "sha256_before": interpreter_before,
            "sha256_after": interpreter_after,
            "unchanged": interpreter_unchanged,
        },
        "sources_before": sources_before,
        "sources_after": sources_after,
        "sources_unchanged": sources_unchanged,
        "files": {
            "stdout.txt": {"sha256": digest(stdout_path), "size_bytes": stdout_path.stat().st_size},
            "stderr.txt": {"sha256": digest(stderr_path), "size_bytes": stderr_path.stat().st_size},
            "recount.json": {"sha256": digest(result_path), "size_bytes": result_path.stat().st_size} if result_exists else None,
        },
    }
    receipt_path = OUTPUT / "execution_receipt.json"
    with receipt_path.open("x") as stream:
        stream.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"receipt": str(receipt_path), "status": status}))
    if status != "complete":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
