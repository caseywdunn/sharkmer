# Independent design review: Gryllus ITS SCC alternatives

Date: 2026-09-13. Reviewer: Astra (`/root/review_129`).
Scope: bounded diagnostic reconstruction and read-evidence experiment only.
No admission/default changes, public-reference promotion, or release approval.
This design precedes new graph/read outcomes; root must freeze the final
protocol, implementation, fixtures and limits before the corresponding runs.

## Established starting point, not an oracle

The previous exact current-run withheld ITS candidate is 978 bp, SHA-256
`23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c`.
At k=19, threshold 4, it has five pre-pruning SCC-node markers starting at
93, 94, 276, 277 and 278, zero-based. Its marker unions `[93,112)` and
`[276,296)` are not assumed complete SCCs or distinguishing intervals.
The candidate does not revisit an oriented 18-mer, but that does not rule out
off-path cycles or competing routes. Its bootstrap origin is not independent
full-length biological truth. Previous marginal read windows are not phasing.

## 1. Reconstruct the actual restriction

- Preserve the frozen consumed Gryllus 1M R1 records, k19, thresholds, primer
  objects, read-threading-off setting, node/DFS/visit/length bounds and current
  production algorithm. A scratch-instrumented executable needs source/build
  fingerprints and a diagnostic-off counterpart. No export-induced pruning,
  search reordering, threshold change, or eligible-quota consumption.
- Match the exact candidate and five marker identities at threshold 4 before
  interpreting the graph. Check emitted sequences, all five count fields,
  complete gene outcomes and pre-existing threshold/search counters against
  the frozen current run. Focused-panel instrumentation is diagnostic-only;
  its selected-target parity must be explicit, not assumed from target names.
- Export complete relevant pre-pruning SCC membership, every internal directed
  edge, and all incoming/outgoing boundary edges. Separately preserve which
  nodes/edges survive pruning. Record actual candidate path placement and
  entry/exit edges. A clipped neighborhood or marker union alone is insufficient.
- Use stable oriented sequence identities and graph-snapshot hashes. Verify
  uniqueness before using an 18-mer as a node key; if duplicated, retain a
  deterministic disambiguator and do not silently merge nodes. Preserve edge
  direction, parallel-edge identity if present, counts and stage. Never use
  unbound NodeIndex/EdgeIndex values as portable identities.
- Recompute SCCs independently from the complete exported topology. Determine
  whether the two candidate marker clusters correspond to distinct components;
  do not infer component boundaries or persistence from marker coordinates.
  Distinguish surviving cycles from membership inherited from a pruned cycle.
- Freeze finite export limits before collection. A reasonable starting ceiling
  is the existing graph budget (100,000 nodes), 400,000 directed edges and
  256 MiB serialized bytes per snapshot; root may choose different explicit
  limits before outcomes. If exceeded, preserve failure/truncation diagnostics
  and declare topology incomplete. Do not rerun with outcome-tuned larger caps.

## 2. Define the finite alternative universe explicitly

A cyclic graph can generate arbitrarily long walks. Therefore, “all
alternatives” is never an unqualified conclusion.

- Derive candidate entry/exit and external anchor positions from complete
  component topology by a frozen deterministic rule, not a convenient
  difference alignment or observed read support. Both full 21 bp flanks must
  lie outside the questioned competing interval. If this requires expanding
  through another component, expand within frozen limits or declare unresolved.
- Include every boundary route capable of reaching the chosen right anchor,
  not only paths following the historical candidate's exit. Preserve routes
  leaving the exported context as an explicit completeness limitation. Export
  enough inter-component/flank context to establish route closure if claiming
  a complete local universe.
- Keep two named universes separate: (a) paths admitted by the original
  production search bounds; (b) all anchor-to-anchor strings that can fit a
  single consumed 150 bp read, including the complete flanks. Do not silently
  impose production max-node-visits=2 as a biological constraint on universe b.
  Repeated walks fitting the length bound are legitimate competing hypotheses.
- Reaching the right anchor emits a candidate walk but must not necessarily
  terminate exploration: a bounded walk can leave and revisit that anchor.
  Freeze the exact anchor-node to full-window coordinate construction. Root's
  proposed whole-stored-graph enumeration is preferable to an SCC-only slice;
  enumerate pre-prune and post-prune graphs separately.
- Suggested fixed offline limits: 100,000 expanded states and 4,096 distinct
  strings per component/anchor problem, with deterministic ordering. Record
  attempted states, distinct spelled strings, length/visit exclusions and
  unfinished frontier. State/output limits mean incomplete enumeration, not
  exhaustion. Longer/unflanked alternatives remain explicitly unresolved even
  when the read-callable finite universe is exhausted.
  Root subsequently proposes 1,000,000 expanded states with the same 4,096
  distinct-string cap; that finite preregistered choice is acceptable. The
  maintained final protocol, not these suggested ceilings, fixes execution.
- Deduplicate identical spelled strings without treating different graph
  walks as independent biological observations. Preserve path equivalence or
  its bounded summary. Use all equally valid entry/exit placements and repeat
  difference placements; do not select a convenient alignment boundary.

## 3. Establish flank and observation discrimination

- Check each flank and full observed window against all frozen candidate and
  enumerated alternative orientations/placements, including alternatives with
  no designated focal assay. Candidate-only uniqueness is inadequate. State
  the comparison universe; absence of another match in an incomplete exported
  graph is not genome-wide uniqueness.
- Preserve short walks with nonmatching 21 bp flank strings as explicitly
  different-context competitors, rather than silently discarding them. In
  sensitivity analysis an observed window may tie or better match such a
  route, even when it is excluded from the same-flank focal alternative set.
  Reaching an anchor with a literal flank mismatch is not evidence that the
  route cannot compete with reads from the intended structure.
- Primary evidence remains a contiguous exact observed window covering the
  complete distinguishing interval plus both 21 bp flanks, all Phred+33 Q20,
  from the same consumed 1M R1 subset. Preserve ordinals, headers, sequences,
  qualities, coordinates, alternative ties and duplicate footprints.
- Maintain the prior three disjoint read-ID/projected-footprint corroboration
  witness rule. This is local corroboration, not certified independent
  molecules. No overlapping k-mer votes, reverse-complement double votes,
  inferred R1 adjacency/mates, unconsumed R2, or minimum-count⇒correctness rule.
- Freeze any sensitivity mode separately. At-most-one-substitution/no-indel
  matching can reuse the prior tested semantics. If bounded indels are added,
  preregister their size, quality, placement and competitive-score semantics;
  do not allow a gap penalty to erase the repeat-copy distinction being tested.
- A read supporting both hypotheses is ambiguous. Zero/low/uncallable support
  is unresolved, not proof of a wrong candidate or absent allele. Positive
  support for competing structures can indicate mixture and must remain visible.
- Bridging each component separately does not phase both components together,
  the intervening sequence, or the entire 978 bp amplicon. Do not concatenate
  marginal read evidence into a full-haplotype claim.

## 4. Minimum preread controls and result labels

Controls must exercise actual export/enumeration/competitive matching, not
only manually listed strings:

1. A simple candidate crossing a real off-path cyclic SCC, with reads that
   positively distinguish it from the competing traversal.
2. A true repeat-copy alternative and a collapsed/recombinant hypothesis;
   collapsed marginal k-mers alone must not earn a complete bridge label.
3. Unequal mixtures, duplicated IDs/footprints, reverse-complement/repeated
   placements, and one-substitution midpoint ties between alternatives.
4. Multiple entry/exit routes, identical strings from different walks, an
   off-context route, long unbridgeable repeats, and intentionally exhausted
   state/output/export budgets. These must retain explicit unresolved states.
5. Two separated locally corroborated components whose joint haplotype is not
   spanned; the system must not invent their full-length phase.

Report topology complete/incomplete, finite-universe enumeration status,
flank/placement ambiguity and read callability independently. Only a complete
discriminating local observation earns local structure corroboration. Any
later proposed gate exception must name the precise restriction it would
remove and demonstrate the relevant evidence, negative controls and fresh
high-copy parity/performance gates separately. This experiment itself changes
no assembly policy.
