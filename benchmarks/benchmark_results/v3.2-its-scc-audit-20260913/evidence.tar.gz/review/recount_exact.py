#!/usr/bin/env python3
"""Independently recount exact local assay windows and compare scanner ledgers."""

import argparse
import hashlib
import json
from pathlib import Path


COMPLEMENT = bytes.maketrans(b"ACGT", b"TGCA")
FLANK_BASES = 21
MIN_QUALITY = 20
MAX_MATCHING_RECORDS_PER_JOB = 100000
EXPECTED_EXACT_JOBS = {
    ("region_1", "region_1.substitutions_0.json"),
    ("region_2", "region_2.substitutions_0.json"),
    ("co1_control", "co1_control.substitutions_0.json"),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest_bytes(contents):
    return hashlib.sha256(contents).hexdigest()


def digest_path(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            checksum.update(chunk)
    return checksum.hexdigest()


def regular_file(path, description):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), f"{description} must be a regular file: {path}")
    return path


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def positions(sequence, pattern):
    offset = sequence.find(pattern)
    while offset >= 0:
        yield offset
        offset = sequence.find(pattern, offset + 1)


def exact_hits(sequence, pattern):
    return list(positions(sequence, pattern))


def load_json_frozen(path, description):
    path = regular_file(path, description)
    contents = path.read_bytes()
    return json.loads(contents), contents


def prepare_manifest(path, expected_sha256, seen_event_ids):
    manifest, contents = load_json_frozen(path, "Event manifest")
    require(digest_bytes(contents) == expected_sha256, "Event manifest checksum differs from plan")
    require(manifest.get("schema_version") == 1, "Expected event manifest schema version 1")
    require(isinstance(manifest.get("candidates"), list) and manifest["candidates"], "Event manifest has no candidates")
    require(isinstance(manifest.get("events"), list) and manifest["events"], "Event manifest has no events")

    candidates = {}
    for candidate in manifest["candidates"]:
        candidate_id = candidate.get("id")
        sequence_text = candidate.get("sequence")
        require(isinstance(candidate_id, str) and candidate_id and candidate_id not in candidates, "Candidate IDs must be unique nonempty strings")
        require(isinstance(sequence_text, str) and sequence_text, "Candidate sequences must be nonempty strings")
        sequence = sequence_text.encode("ascii")
        require(not set(sequence) - set(b"ACGT"), "Candidate sequences must contain only ACGT")
        require(digest_bytes(sequence) == candidate.get("sequence_sha256"), "Candidate sequence checksum differs")
        candidates[candidate_id] = sequence

    events = []
    for source_event in manifest["events"]:
        event_id = source_event.get("id")
        require(isinstance(event_id, str) and event_id and event_id not in seen_event_ids, "Event IDs must be globally unique nonempty strings")
        seen_event_ids.add(event_id)
        candidate_id = source_event.get("candidate_id")
        require(candidate_id in candidates, "Event references an unknown candidate")
        start = source_event.get("start")
        end = source_event.get("end")
        candidate = candidates[candidate_id]
        require(type(start) is int and type(end) is int and 0 <= start <= end <= len(candidate), "Event coordinates are invalid")
        window_start = start - FLANK_BASES
        window_end = end + FLANK_BASES
        require(0 <= window_start < window_end <= len(candidate), "Exact recount requires complete 21-base event flanks")
        pattern = candidate[window_start:window_end]
        template_placements = template_placements_for_window(pattern, candidates)
        events.append({
            **source_event,
            "window_start": window_start,
            "window_end": window_end,
            "window_sequence_sha256": digest_bytes(pattern),
            "patterns": (("+", pattern), ("-", reverse_complement(pattern))),
            "template_placements": template_placements,
        })
    return {"path": str(Path(path).resolve()), "sha256": expected_sha256, "candidates": candidates, "events": events, "contents": contents}


def template_placements_for_window(window, candidates):
    placements = []
    for candidate_id, candidate in candidates.items():
        for strand, oriented in (("+", candidate), ("-", reverse_complement(candidate))):
            for start in exact_hits(oriented, window):
                placements.append({"candidate_id": candidate_id, "strand": strand, "start": start, "substitutions": 0})
    return placements


def prepare_exact_jobs(plan_path):
    plan, plan_contents = load_json_frozen(plan_path, "Read assay plan")
    require(plan.get("schema_version") == 1, "Expected read assay plan schema version 1")
    require(isinstance(plan.get("jobs"), list), "Read assay plan has no jobs")
    sources = plan.get("sources")
    require(isinstance(sources, dict), "Read assay plan has no source receipts")
    exact_jobs = [job for job in plan["jobs"] if job.get("max_substitutions") == 0]
    identities = {(job.get("region"), job.get("output_basename")) for job in exact_jobs}
    require(identities == EXPECTED_EXACT_JOBS and len(exact_jobs) == len(EXPECTED_EXACT_JOBS), "Exact recount requires the frozen region 1, region 2, and CO1 control jobs")

    seen_event_ids = set()
    prepared_jobs = []
    for job in exact_jobs:
        manifest_path = regular_file(job.get("manifest"), "Event manifest")
        expected_manifest_sha256 = job.get("manifest_sha256")
        require(isinstance(expected_manifest_sha256, str) and len(expected_manifest_sha256) == 64, "Job manifest checksum is invalid")
        require(sources.get(str(manifest_path)) == expected_manifest_sha256, "Job manifest is not bound by the plan source receipts")
        prepared_manifest = prepare_manifest(manifest_path, expected_manifest_sha256, seen_event_ids)
        prepared_jobs.append({**job, "prepared_manifest": prepared_manifest})

    expected_prefix_path = regular_file(plan.get("expected_prefix"), "Expected-prefix receipt")
    expected_prefix, expected_prefix_contents = load_json_frozen(expected_prefix_path, "Expected-prefix receipt")
    require(sources.get(str(expected_prefix_path)) == digest_bytes(expected_prefix_contents), "Expected-prefix receipt is not bound by the plan")
    for field in ("records", "bases", "size_bytes"):
        require(type(expected_prefix.get(field)) is int and expected_prefix[field] > 0, f"Expected-prefix {field} must be a positive integer")
    require(isinstance(expected_prefix.get("sha256"), str) and len(expected_prefix["sha256"]) == 64, "Expected-prefix SHA256 is invalid")

    input_record = plan.get("input")
    require(isinstance(input_record, dict), "Read assay plan has no input record")
    input_path = regular_file(input_record.get("input"), "FASTQ input")
    require(input_record.get("prefix") == expected_prefix, "Plan input prefix differs from expected-prefix receipt")
    require(isinstance(input_record.get("full_sha256"), str) and len(input_record["full_sha256"]) == 64, "Full input SHA256 is invalid")
    return {
        "plan": plan,
        "plan_path": str(Path(plan_path).resolve()),
        "plan_contents": plan_contents,
        "input_path": input_path,
        "expected_prefix_path": expected_prefix_path,
        "expected_prefix": expected_prefix,
        "expected_prefix_contents": expected_prefix_contents,
        "jobs": prepared_jobs,
    }


def new_pattern_counts():
    return {
        "raw_records": {"+": 0, "-": 0},
        "raw_matches": {"+": 0, "-": 0},
        "q20_records": {"+": 0, "-": 0},
        "q20_matches": {"+": 0, "-": 0},
    }


def observations_for_read(sequence, quality, events, candidates, pattern_counts=None):
    observations = []
    placement_cache = {}
    for event in events:
        matches = []
        for strand, pattern in event["patterns"]:
            starts = exact_hits(sequence, pattern)
            qualified_starts = []
            for start in starts:
                end = start + len(pattern)
                if min(quality[start:end]) < MIN_QUALITY + 33:
                    continue
                qualified_starts.append(start)
            if pattern_counts is not None:
                event_counts = pattern_counts[event["id"]]
                event_counts["raw_records"][strand] += bool(starts)
                event_counts["raw_matches"][strand] += len(starts)
                event_counts["q20_records"][strand] += bool(qualified_starts)
                event_counts["q20_matches"][strand] += len(qualified_starts)
            for start in qualified_starts:
                end = start + len(pattern)
                oriented_start = start if strand == "+" else len(sequence) - end
                projected_start = event["window_start"] - oriented_start
                observed_window = sequence[start:end]
                if strand == "-":
                    observed_window = reverse_complement(observed_window)
                placements = placement_cache.get(observed_window)
                if placements is None:
                    placements = template_placements_for_window(observed_window, candidates)
                    placement_cache[observed_window] = placements
                matches.append({
                    "strand": strand,
                    "read_start": start,
                    "read_end": end,
                    "substitutions": 0,
                    "projected_footprint": [projected_start, projected_start + len(sequence)],
                    "observed_template_placements": placements,
                })
        if matches:
            observations.append({
                "event_id": event["id"],
                "candidate_id": event["candidate_id"],
                "comparison_group": event.get("comparison_group", event["candidate_id"]),
                "matches": matches,
                "unique": len(matches) == 1 and len(matches[0]["observed_template_placements"]) == 1,
            })

    competing_candidates = {}
    for observation in observations:
        competing_candidates.setdefault(observation["comparison_group"], set()).add(observation["candidate_id"])
    for observation in observations:
        if len(competing_candidates[observation["comparison_group"]]) > 1:
            observation["unique"] = False
    return observations


def new_accumulator():
    return {
        "records": 0,
        "unique_records": 0,
        "ambiguous_records": 0,
        "exact_records": 0,
        "one_substitution_records": 0,
        "ids": set(),
        "sequences": set(),
        "footprints": set(),
        "strands": set(),
    }


def update_accumulator(accumulator, read_id, sequence, observation):
    accumulator["records"] += 1
    accumulator["exact_records"] += 1
    if observation["unique"]:
        accumulator["unique_records"] += 1
        accumulator["ids"].add(read_id)
        accumulator["sequences"].add(digest_bytes(min(sequence, reverse_complement(sequence))))
        match = observation["matches"][0]
        accumulator["footprints"].add(tuple(match["projected_footprint"]))
        accumulator["strands"].add(match["strand"])
    else:
        accumulator["ambiguous_records"] += 1


def scan_prefix(context):
    input_path = context["input_path"]
    expected = context["expected_prefix"]
    before = input_path.stat()
    full_sha256 = digest_path(input_path)
    require(full_sha256 == context["plan"]["input"]["full_sha256"], "Full FASTQ checksum differs before recount")
    job_states = []
    for job in context["jobs"]:
        events = job["prepared_manifest"]["events"]
        job_states.append({
            "job": job,
            "accumulators": {event["id"]: new_accumulator() for event in events},
            "pattern_counts": {event["id"]: new_pattern_counts() for event in events},
            "ledger": [],
        })

    prefix_checksum = hashlib.sha256()
    observed_bases = 0
    observed_size = 0
    with input_path.open("rb") as stream:
        for ordinal in range(1, expected["records"] + 1):
            lines = [stream.readline() for _field in range(4)]
            require(all(lines), f"Truncated FASTQ before consumed record {ordinal}")
            header, sequence, separator, quality = [line.rstrip(b"\r\n") for line in lines]
            require(header.startswith(b"@") and separator.startswith(b"+") and sequence and len(sequence) == len(quality), f"Malformed FASTQ record {ordinal}")
            require(min(quality) >= 33 and max(quality) <= 126, f"Unsupported quality encoding at record {ordinal}")
            prefix_contents = b"".join(lines)
            prefix_checksum.update(prefix_contents)
            observed_size += len(prefix_contents)
            observed_bases += len(sequence)
            sequence = sequence.upper()
            read_id = header.split()[0].decode("ascii")

            for state in job_states:
                prepared_manifest = state["job"]["prepared_manifest"]
                observations = observations_for_read(
                    sequence,
                    quality,
                    prepared_manifest["events"],
                    prepared_manifest["candidates"],
                    state["pattern_counts"],
                )
                if not observations:
                    continue
                require(len(state["ledger"]) < MAX_MATCHING_RECORDS_PER_JOB, "Exact recount matching-record limit exceeded")
                state["ledger"].append({"ordinal": ordinal, "read_id": read_id, "observations": observations})
                for observation in observations:
                    update_accumulator(state["accumulators"][observation["event_id"]], read_id, sequence, observation)

    observed_prefix = {
        "records": expected["records"],
        "bases": observed_bases,
        "size_bytes": observed_size,
        "sha256": prefix_checksum.hexdigest(),
    }
    require(observed_prefix == expected, "Consumed FASTQ prefix differs from frozen receipt")
    after = input_path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "FASTQ changed during recount")
    return full_sha256, observed_prefix, job_states


def event_summaries(state):
    summaries = []
    events = state["job"]["prepared_manifest"]["events"]
    for event in events:
        accumulator = state["accumulators"][event["id"]]
        summaries.append({
            "id": event["id"],
            "candidate_id": event["candidate_id"],
            "comparison_group": event.get("comparison_group", event["candidate_id"]),
            "window_start": event["window_start"],
            "window_end": event["window_end"],
            "window_sequence_sha256": event["window_sequence_sha256"],
            "template_placements": event["template_placements"],
            "literal_pattern_counts": state["pattern_counts"][event["id"]],
            "records": accumulator["records"],
            "unique_records": accumulator["unique_records"],
            "ambiguous_records": accumulator["ambiguous_records"],
            "exact_records": accumulator["exact_records"],
            "one_substitution_records": accumulator["one_substitution_records"],
            "distinct_ids": len(accumulator["ids"]),
            "distinct_sequences": len(accumulator["sequences"]),
            "distinct_footprints": len(accumulator["footprints"]),
            "footprints": [list(footprint) for footprint in sorted(accumulator["footprints"])],
            "strands": sorted(accumulator["strands"]),
        })
    return summaries


def normalize_match(match):
    return {
        "strand": match["strand"],
        "read_start": match["read_start"],
        "read_end": match["read_end"],
        "substitutions": match["substitutions"],
        "projected_footprint": match["projected_footprint"],
        "observed_template_placements": match["observed_template_placements"],
    }


def normalize_observation(observation):
    return {
        "event_id": observation["event_id"],
        "candidate_id": observation["candidate_id"],
        "comparison_group": observation["comparison_group"],
        "unique": observation["unique"],
        "matches": [normalize_match(match) for match in observation["matches"]],
    }


def normalize_source_ledger(source_report):
    ledger = []
    for record in source_report.get("read_evidence", []):
        header = record.get("header")
        require(isinstance(header, str) and header.startswith("@"), "Source ledger header is invalid")
        ledger.append({
            "ordinal": record.get("ordinal"),
            "read_id": header.split()[0],
            "observations": [normalize_observation(observation) for observation in record.get("observations", [])],
        })
    return ledger


def compare_source_report(state, source_report_path, context):
    source_report, contents = load_json_frozen(source_report_path, "Source exact scanner report")
    job = state["job"]
    prepared_manifest = job["prepared_manifest"]
    require(source_report.get("schema_version") == 1 and source_report.get("max_substitutions") == 0, "Source report is not an exact schema version 1 assay")
    require(source_report.get("minimum_quality") == MIN_QUALITY and source_report.get("flank_bases") == FLANK_BASES, "Source report assay settings differ")
    require(source_report.get("paired") is False, "Source report is not the frozen unpaired assay")
    require(Path(source_report.get("input_path", "")).resolve() == context["input_path"].resolve(), "Source report input path differs")
    require(source_report.get("input_subset") == context["expected_prefix"], "Source report input subset differs")
    provenance = source_report.get("provenance", {})
    require(provenance.get("event_manifest_sha256") == prepared_manifest["sha256"], "Source report manifest binding differs")
    require(provenance.get("expected_prefix_manifest_sha256") == digest_bytes(context["expected_prefix_contents"]), "Source report prefix binding differs")

    summaries = event_summaries(state)
    source_summaries = {event.get("id"): event for event in source_report.get("events", [])}
    require(set(source_summaries) == {summary["id"] for summary in summaries}, "Source report event set differs")
    comparable_fields = (
        "records", "unique_records", "ambiguous_records", "exact_records",
        "one_substitution_records", "distinct_ids", "distinct_sequences",
        "distinct_footprints", "footprints", "strands",
    )
    for summary in summaries:
        source_summary = source_summaries[summary["id"]]
        require(
            {field: source_summary.get(field) for field in comparable_fields}
            == {field: summary[field] for field in comparable_fields},
            f"Source event counts or footprints differ for {summary['id']}",
        )

    source_ledger = normalize_source_ledger(source_report)
    normalized_ledger = [
        {
            "ordinal": record["ordinal"],
            "read_id": record["read_id"],
            "observations": [normalize_observation(observation) for observation in record["observations"]],
        }
        for record in state["ledger"]
    ]
    require(source_ledger == normalized_ledger, f"Source exact ledger differs for {job['region']}")
    return {
        "path": str(Path(source_report_path).resolve()),
        "sha256": digest_bytes(contents),
        "comparison_passed": True,
        "event_count": len(summaries),
        "matching_record_count": len(normalized_ledger),
        "ledger_sha256": digest_bytes(json.dumps(normalized_ledger, sort_keys=True, separators=(",", ":")).encode()),
    }, summaries, normalized_ledger, contents


def recount(plan_path, source_results_directory):
    checker_contents = Path(__file__).read_bytes()
    context = prepare_exact_jobs(plan_path)
    source_results_directory = Path(source_results_directory)
    require(source_results_directory.is_dir() and not source_results_directory.is_symlink(), "Source results directory is invalid")
    source_paths = {
        job["region"]: regular_file(source_results_directory / job["output_basename"], "Source exact scanner report")
        for job in context["jobs"]
    }
    source_before = {region: path.read_bytes() for region, path in source_paths.items()}
    full_sha256, observed_prefix, job_states = scan_prefix(context)

    reports = []
    for state in job_states:
        region = state["job"]["region"]
        comparison, summaries, ledger, contents = compare_source_report(state, source_paths[region], context)
        require(contents == source_before[region], "Source report changed during recount")
        reports.append({
            "region": region,
            "manifest_path": state["job"]["prepared_manifest"]["path"],
            "manifest_sha256": state["job"]["prepared_manifest"]["sha256"],
            "source_report": comparison,
            "events": summaries,
            "ledger": ledger,
        })

    require(Path(plan_path).read_bytes() == context["plan_contents"], "Read assay plan changed during recount")
    require(Path(__file__).read_bytes() == checker_contents, "Exact recount checker changed during recount")
    require(context["expected_prefix_path"].read_bytes() == context["expected_prefix_contents"], "Expected-prefix receipt changed during recount")
    for job in context["jobs"]:
        prepared_manifest = job["prepared_manifest"]
        require(Path(prepared_manifest["path"]).read_bytes() == prepared_manifest["contents"], "Event manifest changed during recount")
    require(digest_path(context["input_path"]) == full_sha256, "Full FASTQ checksum differs after recount")
    return {
        "schema_version": 1,
        "status": "complete",
        "purpose": "independent_exact_only_recount_of_frozen_local_assays",
        "scope": {
            "exact_matching_only": True,
            "minimum_quality": MIN_QUALITY,
            "quality_scope": "every_base_in_the_complete_event_window",
            "orientations": ["forward", "reverse_complement"],
            "comparison_group_competition_applied": True,
            "truth_interpretation": "recount_agreement_only_not_new_haplotype_or_gate_truth",
        },
        "provenance": {
            "checker_sha256": digest_bytes(checker_contents),
            "plan_path": context["plan_path"],
            "plan_sha256": digest_bytes(context["plan_contents"]),
            "expected_prefix_path": str(context["expected_prefix_path"].resolve()),
            "expected_prefix_sha256": digest_bytes(context["expected_prefix_contents"]),
            "input_path": str(context["input_path"].resolve()),
            "input_full_sha256": full_sha256,
        },
        "input_subset": observed_prefix,
        "all_source_comparisons_passed": True,
        "reports": reports,
    }


def save_new(path, result):
    path = Path(path)
    require(not path.exists() and not path.is_symlink(), "Refusing to overwrite recount output")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--source-results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    result = recount(arguments.plan, arguments.source_results)
    save_new(arguments.output, result)
    print(json.dumps({"output": str(arguments.output), "reports": len(result["reports"]), "passed": result["all_source_comparisons_passed"]}))


if __name__ == "__main__":
    main()
