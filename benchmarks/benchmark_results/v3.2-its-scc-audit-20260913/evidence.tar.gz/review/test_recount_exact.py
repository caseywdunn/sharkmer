import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


SPECIFICATION = importlib.util.spec_from_file_location("recount_exact", Path(__file__).with_name("recount_exact.py"))
RECOUNT = importlib.util.module_from_spec(SPECIFICATION)
SPECIFICATION.loader.exec_module(RECOUNT)
SCRATCH_ROOT = Path(__file__).resolve().parents[1]


def candidate(identifier, sequence):
    return {"id": identifier, "sequence": sequence, "sequence_sha256": RECOUNT.digest_bytes(sequence.encode())}


def manifest(candidates, events):
    return {"schema_version": 1, "candidates": candidates, "events": events}


def prepared_manifest(contents):
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary) / "manifest.json"
        path.write_text(json.dumps(contents))
        return RECOUNT.prepare_manifest(path, RECOUNT.digest_path(path), set())


class ExactObservationTests(unittest.TestCase):
    def test_reverse_orientation_and_projected_footprint(self):
        window = "AACGTTGCAAGCTTGACGCTA" + "GATTACA" + "TTGCGATCGTAGCTACGATTA"
        prepared = prepared_manifest(manifest(
            [candidate("candidate", window)],
            [{"id": "event", "candidate_id": "candidate", "comparison_group": "group", "start": 21, "end": 28}],
        ))
        read = b"GG" + RECOUNT.reverse_complement(window.encode()) + b"TTT"
        counts = {"event": RECOUNT.new_pattern_counts()}
        observations = RECOUNT.observations_for_read(read, b"I" * len(read), prepared["events"], prepared["candidates"], counts)
        self.assertEqual(len(observations), 1)
        self.assertTrue(observations[0]["unique"])
        self.assertEqual(observations[0]["matches"][0]["strand"], "-")
        self.assertEqual(observations[0]["matches"][0]["projected_footprint"], [-3, len(read) - 3])
        self.assertEqual(counts["event"]["raw_matches"], {"+": 0, "-": 1})
        self.assertEqual(counts["event"]["q20_matches"], {"+": 0, "-": 1})

    def test_low_quality_anywhere_in_full_window_rejects_match(self):
        window = "AACGTTGCAAGCTTGACGCTA" + "GATTACA" + "TTGCGATCGTAGCTACGATTA"
        prepared = prepared_manifest(manifest(
            [candidate("candidate", window)],
            [{"id": "event", "candidate_id": "candidate", "start": 21, "end": 28}],
        ))
        quality = bytearray(b"I" * len(window))
        quality[0] = ord("5") - 1
        counts = {"event": RECOUNT.new_pattern_counts()}
        observations = RECOUNT.observations_for_read(window.encode(), bytes(quality), prepared["events"], prepared["candidates"], counts)
        self.assertEqual(observations, [])
        self.assertEqual(counts["event"]["raw_matches"], {"+": 1, "-": 0})
        self.assertEqual(counts["event"]["q20_matches"], {"+": 0, "-": 0})

    def test_multiple_read_hits_are_ambiguous_and_keep_both_footprints(self):
        window = "AACGTTGCAAGCTTGACGCTA" + "GATTACA" + "TTGCGATCGTAGCTACGATTA"
        prepared = prepared_manifest(manifest(
            [candidate("candidate", window)],
            [{"id": "event", "candidate_id": "candidate", "start": 21, "end": 28}],
        ))
        read = (window + "AAA" + window).encode()
        counts = {"event": RECOUNT.new_pattern_counts()}
        observations = RECOUNT.observations_for_read(read, b"I" * len(read), prepared["events"], prepared["candidates"], counts)
        self.assertEqual(len(observations[0]["matches"]), 2)
        self.assertFalse(observations[0]["unique"])
        self.assertEqual([match["projected_footprint"] for match in observations[0]["matches"]], [[0, len(read)], [-(len(window) + 3), len(window)]])
        self.assertEqual(counts["event"]["raw_matches"], {"+": 2, "-": 0})
        self.assertEqual(counts["event"]["q20_matches"], {"+": 2, "-": 0})

    def test_competing_classes_in_one_group_are_not_unique(self):
        first = "AACGTTGCAAGCTTGACGCTA" + "GATTACA" + "TTGCGATCGTAGCTACGATTA"
        second = "CGTACGTAGCTAGCATCGATC" + "CCGGAAT" + "TACGATGCTAGCATGCTAGCA"
        prepared = prepared_manifest(manifest(
            [candidate("first", first), candidate("second", second)],
            [
                {"id": "first_event", "candidate_id": "first", "comparison_group": "shared", "start": 21, "end": 28},
                {"id": "second_event", "candidate_id": "second", "comparison_group": "shared", "start": 21, "end": 28},
            ],
        ))
        read = (first + "AAA" + second).encode()
        observations = RECOUNT.observations_for_read(read, b"I" * len(read), prepared["events"], prepared["candidates"])
        self.assertEqual([observation["candidate_id"] for observation in observations], ["first", "second"])
        self.assertTrue(all(not observation["unique"] for observation in observations))


class FrozenManifestTests(unittest.TestCase):
    def test_actual_plan_prepares_every_exact_class_and_event(self):
        context = RECOUNT.prepare_exact_jobs(SCRATCH_ROOT / "read_assay_plan.json")
        self.assertEqual({job["region"] for job in context["jobs"]}, {"region_1", "region_2", "co1_control"})
        self.assertEqual(sum(len(job["prepared_manifest"]["events"]) for job in context["jobs"]), 6)
        self.assertEqual(sum(len(job["prepared_manifest"]["candidates"]) for job in context["jobs"]), 9)
        for job in context["jobs"]:
            for event in job["prepared_manifest"]["events"]:
                self.assertEqual([strand for strand, _pattern in event["patterns"]], ["+", "-"])

    def test_duplicate_event_ids_across_jobs_are_rejected(self):
        first = "A" * 21 + "CGT" + "C" * 21
        manifest_data = manifest([candidate("candidate", first)], [{"id": "duplicate", "candidate_id": "candidate", "start": 21, "end": 24}])
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest_path = root / "manifest.json"
            manifest_path.write_text(json.dumps(manifest_data))
            checksum = RECOUNT.digest_path(manifest_path)
            prefix_path = root / "prefix.json"
            prefix_path.write_text(json.dumps({"records": 1, "bases": 1, "size_bytes": 1, "sha256": "0" * 64}))
            fastq_path = root / "reads.fastq"
            fastq_path.write_text("@x\nA\n+\nI\n")
            jobs = [
                {"region": region, "output_basename": basename, "max_substitutions": 0, "manifest": str(manifest_path), "manifest_sha256": checksum}
                for region, basename in sorted(RECOUNT.EXPECTED_EXACT_JOBS)
            ]
            plan = {
                "schema_version": 1,
                "jobs": jobs,
                "expected_prefix": str(prefix_path),
                "input": {"input": str(fastq_path), "full_sha256": RECOUNT.digest_path(fastq_path), "prefix": json.loads(prefix_path.read_text())},
                "sources": {str(manifest_path): checksum, str(prefix_path): RECOUNT.digest_path(prefix_path)},
            }
            plan_path = root / "plan.json"
            plan_path.write_text(json.dumps(plan))
            with self.assertRaisesRegex(ValueError, "globally unique"):
                RECOUNT.prepare_exact_jobs(plan_path)


class RecountIntegrationTests(unittest.TestCase):
    def test_three_exact_reports_match_counts_ids_and_footprints(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            results = root / "results"
            results.mkdir()
            windows = {
                "region_1": "AACGTTGCAAGCTTGACGCTA" + "GATTACA" + "TTGCGATCGTAGCTACGATTA",
                "region_2": "CGTACGTAGCTAGCATCGATC" + "CCGGAAT" + "TACGATGCTAGCATGCTAGCA",
                "co1_control": "TTACCGATGCTAGCTAGGTCA" + "TTAACCG" + "CGATTCGATGCTAGCATCGTA",
            }
            read_sequence = "AAA" + windows["region_1"] + "CCC" + RECOUNT.reverse_complement(windows["region_2"].encode()).decode() + "GGG" + windows["co1_control"]
            fastq_contents = f"@read_1 description\n{read_sequence}\n+\n{'I' * len(read_sequence)}\n"
            fastq_path = root / "reads.fastq"
            fastq_path.write_text(fastq_contents)
            prefix = {
                "records": 1,
                "bases": len(read_sequence),
                "size_bytes": len(fastq_contents),
                "sha256": RECOUNT.digest_path(fastq_path),
            }
            prefix_path = root / "prefix.json"
            prefix_path.write_text(json.dumps(prefix))
            sources = {str(prefix_path): RECOUNT.digest_path(prefix_path)}
            jobs = []
            for region, output_basename in sorted(RECOUNT.EXPECTED_EXACT_JOBS):
                window = windows[region]
                manifest_path = root / f"{region}.json"
                manifest_path.write_text(json.dumps(manifest(
                    [candidate(f"{region}_candidate", window)],
                    [{"id": f"{region}_event", "candidate_id": f"{region}_candidate", "comparison_group": region, "start": 21, "end": 28}],
                )))
                manifest_sha256 = RECOUNT.digest_path(manifest_path)
                sources[str(manifest_path)] = manifest_sha256
                jobs.append({
                    "region": region,
                    "output_basename": output_basename,
                    "max_substitutions": 0,
                    "manifest": str(manifest_path),
                    "manifest_sha256": manifest_sha256,
                })
            plan = {
                "schema_version": 1,
                "jobs": jobs,
                "expected_prefix": str(prefix_path),
                "input": {"input": str(fastq_path), "full_sha256": RECOUNT.digest_path(fastq_path), "prefix": prefix},
                "sources": sources,
            }
            plan_path = root / "plan.json"
            plan_path.write_text(json.dumps(plan))
            context = RECOUNT.prepare_exact_jobs(plan_path)
            _full_sha256, _observed_prefix, states = RECOUNT.scan_prefix(context)
            for state in states:
                region = state["job"]["region"]
                summaries = RECOUNT.event_summaries(state)
                source_events = []
                for summary in summaries:
                    source_events.append({**summary, "one_substitution_records": 0})
                read_evidence = []
                for record in state["ledger"]:
                    read_evidence.append({
                        "ordinal": record["ordinal"],
                        "header": f"{record['read_id']} description",
                        "observations": record["observations"],
                    })
                source_report = {
                    "schema_version": 1,
                    "max_substitutions": 0,
                    "minimum_quality": 20,
                    "flank_bases": 21,
                    "paired": False,
                    "input_path": str(fastq_path.resolve()),
                    "input_subset": prefix,
                    "provenance": {
                        "event_manifest_sha256": state["job"]["manifest_sha256"],
                        "expected_prefix_manifest_sha256": RECOUNT.digest_path(prefix_path),
                    },
                    "events": source_events,
                    "read_evidence": read_evidence,
                }
                (results / state["job"]["output_basename"]).write_text(json.dumps(source_report))

            result = RECOUNT.recount(plan_path, results)
            self.assertTrue(result["all_source_comparisons_passed"])
            self.assertEqual([report["region"] for report in result["reports"]], [job["region"] for job in jobs])
            self.assertEqual([report["ledger"][0]["read_id"] for report in result["reports"]], ["@read_1"] * 3)
            strands = {report["region"]: report["events"][0]["strands"] for report in result["reports"]}
            self.assertEqual(strands, {"co1_control": ["+"], "region_1": ["+"], "region_2": ["-"]})


if __name__ == "__main__":
    unittest.main()
