# Independent exact recount review

Status: PASS. This is a recorded review attestation, not an additional FASTQ scan or an executable audit receipt.

- Reviewed checker: `01063aec4241966bcd53031a204466f6277ba2f4837740f1506d95d0cae48905`; its seven tests independently passed before the one real recount.
- Actual outer receipt: `0b9f27120b70c45c656a4cf2f63d60b966a698ab1ae3929d7aa00b96c630a828`.
- Actual recount result: `dea345d1ea433d4e36fe9ddca573174f6dab91bdc5408f9d7ae7e79c61a81532`.
- Verified successful return code, absent failure, identical source bookends, current source fingerprints, output/log byte hashes and sizes, and unchanged resolved interpreter SHA `4c6454ed410c4e3767e2bded23ef8564597f2289281d4e69bef978cf3497739a`.
- Independently compared all three exact source-report identities, all six event counts/footprints/strand summaries, and every normalized ledger record against the original scanner reports. Frozen full-file and consumed-prefix checksums match the approved plan; no FASTQ was reread during this review.
- All four ITS patterns have zero literal forward and reverse-complement matches both before quality filtering and after full-window Q20 filtering. These exact zeros therefore are not solely caused by Q20 filtering or template-competition demotion.
- Retained CO1: raw forward/reverse counts 9/24; Q20 counts 6/21, yielding 27 records, 27 IDs and 15 projected footprints. Lost CO1: zero raw and Q20 matches in either orientation.

The recount independently reproduces exact matching only. The separate scanner sensitivity results remain zero for all ITS classes, but this recount does not independently replicate one-substitution searches. No literal match in the frozen million-read subset is not a population-absence claim, a complete haplotype verdict, or justification for changing production gates.
