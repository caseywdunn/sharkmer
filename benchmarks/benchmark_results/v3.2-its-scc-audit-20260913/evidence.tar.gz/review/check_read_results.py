import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path('/tmp/sharkmer-its-scc-audit-20260913')
OLD = Path('/tmp/sharkmer-read-audit-20260913/execution_replication_outputs')
SCANNER = Path('/home/claude/repos/sharkmer/scripts/audit_read_bridges.py')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def reverse_complement(sequence):
    return sequence.translate(str.maketrans('ACGT', 'TGCA'))[::-1]


plan = load(ROOT / 'read_assay_plan.json')
execution = load(ROOT / 'read_execution/execution.json')
summary = load(ROOT / 'read_summary.json')
assert execution['failure'] is None and execution['source_changed'] is False
assert execution['source_before'] == execution['source_after'] == plan['sources']
assert execution['plan_sha256'] == digest(ROOT / 'read_assay_plan.json') == summary['plan_sha256']
assert digest(ROOT / 'read_execution/execution.json') == summary['execution_sha256']
assert len(execution['jobs']) == len(plan['jobs']) == 6
for path, expected in plan['sources'].items():
    assert digest(path) == expected, path
specification = importlib.util.spec_from_file_location('reviewed_scanner', SCANNER)
scanner = importlib.util.module_from_spec(specification)
specification.loader.exec_module(scanner)
synthetic_checks = 0
ledger_records = 0
its_rows = []
control_rows = []
for job, planned in zip(execution['jobs'], plan['jobs']):
    assert job['job'] == planned and job['validated'] and job['returncode'] == 0 and not job['timed_out']
    region, mode = planned['region'], planned['max_substitutions']
    basename = f'{region}.substitutions_{mode}'
    assert load(ROOT / 'read_execution' / (basename + '.receipt.json')) == job
    report_path = ROOT / 'read_execution' / (basename + '.json')
    assert digest(report_path) == job['output_sha256']
    report = load(report_path)
    manifest = load(planned['manifest'])
    assert report['input_subset'] == plan['input']['prefix']
    assert report['max_substitutions'] == mode and report['minimum_quality'] == 20 and report['paired'] is False
    assert report['provenance'] == {'event_manifest_sha256': digest(planned['manifest']), 'expected_prefix_manifest_sha256': digest(plan['expected_prefix']), 'scanner_sha256': digest(SCANNER)}
    sequences = {row['id']: row['sequence'] for row in manifest['candidates']}
    declared_events = {row['id']: row for row in manifest['events']}
    prepared = scanner.prepare_events(manifest, mode)
    for event in report['events']:
        declared = declared_events[event['id']]
        sequence = sequences[event['candidate_id']]
        expected_window = sequence[declared['start'] - 21:declared['end'] + 21]
        assert event['window_sequence'] == expected_window
        assert event['callability'] == 'assayed' and not event['longer_than_every_read']
        row = next(row for row in summary['rows'] if row['event_id'] == event['id'] and row['max_substitutions'] == mode)
        assert row['report_sha256'] == digest(report_path)
        for field in ('records', 'unique_records', 'ambiguous_records', 'distinct_ids', 'distinct_footprints', 'local_bridge_status'):
            assert row[field] == event[field]
        assert row['window_length'] == len(expected_window)
        assert row['window_sha256'] == hashlib.sha256(expected_window.encode()).hexdigest()
        assert row['witness_size'] == len(event['corroboration_witness'])
        if region.startswith('region_'):
            assert event['records'] == event['unique_records'] == event['ambiguous_records'] == 0
            assert event['local_bridge_status'] == 'unresolved'
            for oriented in (expected_window, reverse_complement(expected_window)):
                for mutate in (False, True) if mode == 1 else (False,):
                    observed = oriented
                    if mutate:
                        middle = len(observed) // 2
                        replacement = next(base for base in 'ACGT' if base != observed[middle])
                        observed = observed[:middle] + replacement + observed[middle + 1:]
                    hits = scanner.observations_for_read(observed.encode(), b'I' * len(observed), prepared, mode)
                    assert any(hit['event_id'] == event['id'] for hit in hits)
                    synthetic_checks += 1
            its_rows.append({'region': region, 'mode': mode, 'length': len(expected_window), 'records': 0})
    if region.startswith('region_'):
        assert report['read_evidence'] == []
        continue
    old = load(OLD / ('SRR27962769.' + ('exact' if mode == 0 else 'one_substitution') + '.json'))
    relevant = set(declared_events)
    old_ledger = []
    for record in old['read_evidence']:
        observations = [entry for entry in record['observations'] if entry['event_id'] in relevant]
        if observations:
            old_ledger.append({**record, 'observations': observations})
    assert report['read_evidence'] == old_ledger
    for record in report['read_evidence']:
        assert 1 <= record['ordinal'] <= 1000000
        for observation in record['observations']:
            event = next(row for row in report['events'] if row['id'] == observation['event_id'])
            for match in observation['matches']:
                start, end = match['read_start'], match['read_end']
                observed = record['sequence'][start:end]
                if match['strand'] == '-':
                    observed = reverse_complement(observed)
                differences = sum(left != right for left, right in zip(observed, event['window_sequence']))
                assert differences == match['substitutions'] <= mode
                assert min(map(ord, record['quality'][start:end])) >= 53
        ledger_records += 1
    retained = next(event for event in report['events'] if event['records'])
    assert retained['records'] == 27 + mode and retained['distinct_footprints'] == 15
    witness = retained['corroboration_witness']
    assert len(witness) == len({entry['read_id'] for entry in witness}) == len({tuple(entry['footprint']) for entry in witness}) == 3
    control_rows.append({'mode': mode, 'retained_records': retained['records'], 'retained_footprints': 15, 'lost_records': 0})
prior_neighbors = []
for mode, label in ((0, 'exact'), (1, 'one_substitution')):
    old = load(OLD / f'SRR27962769.{label}.json')
    for event in old['events']:
        if '23163ca' in event['candidate_id'] and event['window_start'] in (60, 80, 240, 260):
            assert event['records'] == 0
            prior_neighbors.append({'mode': mode, 'window': [event['window_start'], event['window_end']], 'records': 0})
assert len(prior_neighbors) == 8
receipt = {'status': 'PASS', 'checker_sha256': digest(__file__), 'execution_sha256': digest(ROOT / 'read_execution/execution.json'), 'summary_sha256': digest(ROOT / 'read_summary.json'), 'plan_sha256': digest(ROOT / 'read_assay_plan.json'), 'jobs': 6, 'its_rows': its_rows, 'controls': control_rows, 'actual_manifest_synthetic_orientation_and_substitution_checks': synthetic_checks, 'control_ledger_records_checked': ledger_records, 'prior_neighboring_windows': prior_neighbors, 'scope': 'Rehashed frozen sources and execution/report bindings; independently checked reported observation sequence/Q20/substitution counts and exact identity to previously raw-verified control ledger. Tested actual ITS manifests in both orientations and sensitivity modes. Did not reread the million-read prefix; separate independent full-prefix recount is needed to independently establish absence. Zero qualifying local windows is unresolved, not allele absence or full-haplotype incorrectness.'}
(ROOT / 'review/read_results_review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
