import hashlib
import json
import sys
from pathlib import Path

import yaml


ROOT = Path('/tmp/sharkmer-its-scc-audit-20260913')
sys.setrecursionlimit(20000)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(relative):
    return json.loads((ROOT / relative).read_text())


def reverse_complement(sequence):
    return sequence.translate(str.maketrans('ACGT', 'TGCA'))[::-1]


def components(adjacency):
    indices = {}
    lows = {}
    stack = []
    active = set()
    found = []

    def visit(node):
        indices[node] = lows[node] = len(indices)
        stack.append(node)
        active.add(node)
        for target in adjacency[node]:
            if target not in indices:
                visit(target)
                lows[node] = min(lows[node], lows[target])
            elif target in active:
                lows[node] = min(lows[node], indices[target])
        if lows[node] == indices[node]:
            group = set()
            while True:
                popped = stack.pop()
                active.remove(popped)
                group.add(popped)
                if popped == node:
                    break
            if len(group) > 1 or node in adjacency[node]:
                found.append(group)

    for node in adjacency:
        if node not in indices:
            visit(node)
    return found


capture = read('graph_capture_v2/capture_receipt.json')
assert capture['failure'] is None and capture['parity_passed']
assert capture['source_changed'] is False
assert capture['source_before'] == capture['source_after']
checked_sources = 0
for section in ('files', 'compile_sources'):
    for path, expected in capture['source_before'][section].items():
        assert digest(path) == expected, path
        checked_sources += 1
job = read('graph_capture_v2/job_receipt.json')
assert job == capture['job_receipt']
assert job['returncode'] == 0 and job['validated_output'] and not job['timed_out']
baseline = read('inputs/focused_baseline_receipt.json')
assert digest(ROOT / 'inputs/focused_baseline_receipt.json') == capture['baseline_receipt_sha256']
outputs = job['outputs']
assert digest(outputs['stats_path']) == outputs['stats_sha256']
stats = yaml.safe_load(Path(outputs['stats_path']).read_text())
for field, value in outputs['stats'].items():
    assert stats[field] == value, field
for field in ('n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers', 'pcr_results'):
    assert stats[field] == baseline['outputs']['stats'][field], field
assert outputs['fasta_records_ordered'] == baseline['outputs']['fasta_records_ordered']
for filename, expected in outputs['fasta_files'].items():
    assert digest(Path(job['output_directory']) / filename) == expected
assert stats['input_source'] == {'kind': 'local_files', 'inputs': ['/tmp/sharkmer-release-comparison/inputs/SRR27962769.fastq'], 'paired': False, 'max_reads': 1000000}
assert job['input_prefix_before'] == job['input_prefix_after'] == {'bases': 150000000, 'records': 1000000, 'sha256': '6aef48e6ed467e7f1ff25a3cd2a21d51dc2378985bdd855e796b539f0fc0c794', 'size_bytes': 365356898}
assert stats['kmer_length'] == 19 and stats['chunks'] == 0
candidate = read('inputs/candidate.json')['record']['oriented_sequence']
assert hashlib.sha256(candidate.encode()).hexdigest() == '23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c'
analysis = read('local_assays/analysis.json')
assert digest(ROOT / 'build_local_assays.py') == analysis['provenance']['builder_sha256']
assert analysis['provenance']['source_freeze_before'] == analysis['provenance']['source_freeze_after']
graph_reviews = []
enumeration_reviews = []
for phase in ('pre', 'post'):
    filename = phase + '_prune.json'
    path = ROOT / 'graph_capture_v2/graphs' / filename
    assert digest(path) == capture['graph_files'][filename] == analysis['provenance'][phase + '_graph_sha256']
    graph = json.loads(path.read_text())['graph']
    nodes = {node['node_id']: node for node in graph['nodes']}
    edges = {edge['edge_id']: edge for edge in graph['edges']}
    assert len(nodes) == graph['node_count'] and len(edges) == graph['edge_count']
    adjacency = {node: [] for node in nodes}
    incoming = {node: [] for node in nodes}
    for identity, edge in edges.items():
        source, target = edge['source_node_id'], edge['target_node_id']
        assert identity == edge['oriented_sequence'] == source + target[-1]
        assert source[1:] == target[:-1]
        adjacency[source].append(target)
        incoming[target].append(source)
    for identity, node in nodes.items():
        assert identity == node['oriented_sequence'] and len(identity) == 18
        assert len(adjacency[identity]) == node['outgoing_degree']
        assert len(incoming[identity]) == node['incoming_degree']
    found = components(adjacency)
    assert {frozenset(group) for group in found} == {frozenset(group['node_ids']) for group in graph['cyclic_components']}
    cyclic_nodes = set().union(*found)
    for group in graph['cyclic_components']:
        membership = set(group['node_ids'])
        assert group['component_id'] == 'scc_' + hashlib.sha256('\n'.join(sorted(membership)).encode()).hexdigest()
        for field, source_inside, target_inside in (('internal_edge_ids', True, True), ('entry_edge_ids', False, True), ('exit_edge_ids', True, False)):
            expected = {identity for identity, edge in edges.items() if (edge['source_node_id'] in membership) == source_inside and (edge['target_node_id'] in membership) == target_inside}
            assert set(group[field]) == expected
    for position in range(len(candidate) - 17):
        assert candidate[position:position + 18] in nodes
    for position in range(len(candidate) - 18):
        assert candidate[position:position + 19] in edges
    marked_positions = [position for position in range(len(candidate) - 17) if candidate[position:position + 18] in cyclic_nodes]
    assert marked_positions == [93, 94, 276, 277, 278]
    graph_reviews.append({'phase': phase, 'nodes': len(nodes), 'edges': len(edges), 'cyclic_component_sizes': sorted(map(len, found)), 'candidate_cyclic_node_starts': marked_positions})
    for region in analysis['regions']:
        stage = region['stages'][phase + '_prune']
        left, right = stage['left_anchor'], stage['right_anchor']
        assert left not in cyclic_nodes and right not in cyclic_nodes
        assert candidate.count(left) == candidate.count(right) == 1
        reached = {right}
        todo = [right]
        while todo:
            for source in incoming[todo.pop()]:
                if source not in reached:
                    reached.add(source)
                    todo.append(source)
        spellings = set()
        visits = [0]

        def enumerate_paths(node, sequence):
            visits[0] += 1
            assert visits[0] <= 1000000
            if node == right:
                spellings.add(sequence)
            if len(sequence) == 150:
                return
            for target in adjacency[node]:
                if target in reached:
                    enumerate_paths(target, sequence + target[-1])

        enumerate_paths(left, left)
        assert spellings == {row['sequence'] for row in stage['spelling_rows']}
        assert stage['complete_within_bounds'] and not stage['state_cap_hit'] and not stage['spelling_cap_hit']
        window = candidate[region['start']:region['end']]
        assert window in spellings
        assert all(sequence.startswith(window[:21]) and sequence.endswith(window[-21:]) for sequence in spellings)
        assert {min(sequence, reverse_complement(sequence)) for sequence in spellings} == {row['sequence'] for row in region['classes']}
        enumeration_reviews.append({'phase': phase, 'region': region['id'], 'candidate_window': [region['start'], region['end']], 'spelling_lengths': sorted(map(len, spellings)), 'independent_dfs_states': visits[0], 'finite_universe_complete': True})
plan = read('read_assay_plan.json')
assert len(plan['jobs']) == 6
assert {(job['region'], job['max_substitutions']) for job in plan['jobs']} == {(region, mode) for region in ('region_1', 'region_2', 'co1_control') for mode in (0, 1)}
for path, expected in plan['sources'].items():
    assert digest(path) == expected, path
for job in plan['jobs']:
    assert digest(job['manifest']) == job['manifest_sha256']
for region in analysis['regions']:
    manifest_path = ROOT / 'local_assays' / region['assay_manifest']
    assert digest(manifest_path) == region['assay_manifest_sha256']
    manifest = json.loads(manifest_path.read_text())
    assert {row['sequence'] for row in manifest['candidates']} == {row['sequence'] for row in region['classes']}
    sequences = {row['id']: row['sequence'] for row in manifest['candidates']}
    assert len(manifest['events']) == len(sequences) == 2
    for event in manifest['events']:
        assert event['start'] == 21 and event['end'] == len(sequences[event['candidate_id']]) - 21
receipt = {'status': 'PASS', 'checker_sha256': digest(__file__), 'capture_sha256': digest(ROOT / 'graph_capture_v2/capture_receipt.json'), 'analysis_sha256': digest(ROOT / 'local_assays/analysis.json'), 'read_plan_sha256': digest(ROOT / 'read_assay_plan.json'), 'checked_source_receipts': checked_sources, 'graphs': graph_reviews, 'enumerations': enumeration_reviews, 'planned_scans': 6, 'scope': 'Independent Tarjan SCC and bounded DFS, raw stats/FASTA parity, source and plan hashes. No GB FASTQ rescan; input prefix validation uses reviewed run receipts. Completeness restricted to stored graphs and <=150 bp anchored spellings; longer cyclic walks and full haplotype truth remain unresolved.'}
(ROOT / 'review/graph_derivation_review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
