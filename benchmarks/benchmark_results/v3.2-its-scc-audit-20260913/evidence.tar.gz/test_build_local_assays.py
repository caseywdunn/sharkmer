#!/usr/bin/env python3
"""Regression tests for bounded local graph-assay construction."""

import hashlib
import importlib.util
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


MODULE_PATH = Path(__file__).with_name("build_local_assays.py")
SPECIFICATION = importlib.util.spec_from_file_location("build_local_assays", MODULE_PATH)
BUILDER = importlib.util.module_from_spec(SPECIFICATION)
SPECIFICATION.loader.exec_module(BUILDER)
RUNNER_PATH = Path(__file__).with_name("run_read_assays.py")
RUNNER_SPECIFICATION = importlib.util.spec_from_file_location("run_read_assays", RUNNER_PATH)
RUNNER = importlib.util.module_from_spec(RUNNER_SPECIFICATION)
RUNNER_SPECIFICATION.loader.exec_module(RUNNER)


def digest(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def candidate_sequence():
    generator = random.Random(71)
    prefix = "".join(generator.choice("CGT") for _ in range(30))
    suffix = "".join(generator.choice("CGT") for _ in range(90))
    return prefix + "A" * 30 + suffix


def candidate_data(sequence, marker_start=30):
    marker_sequence = sequence[marker_start:marker_start + 18]
    return {"schema_version": 1, "gene": "insecta_ITS_2", "threshold": 4, "kmer_length": 19,
            "record": {"oriented_sequence": sequence, "sequence_sha256": digest(sequence),
                       "marker_occurrences": [{"cause": "pre_prune_cyclic_scc_node",
                                               "start": marker_start, "end": marker_start + 18,
                                               "identity_sequence": marker_sequence}]}}


def graph_data(sequence, phase, include_cycle=True):
    node_sequences = []
    for position in range(len(sequence) - 17):
        node_sequence = sequence[position:position + 18]
        if node_sequence not in node_sequences:
            node_sequences.append(node_sequence)
    nodes = [{"node_id": node_sequence, "oriented_sequence": node_sequence,
              "is_start": False, "is_end": False, "incoming_degree": 0,
              "outgoing_degree": 0, "cyclic_scc_id": None} for node_sequence in node_sequences]
    edges = []
    existing_edges = set()
    for position in range(len(sequence) - 18):
        source_sequence = sequence[position:position + 18]
        target_sequence = sequence[position + 1:position + 19]
        edge_key = (source_sequence, target_sequence)
        if edge_key in existing_edges:
            continue
        existing_edges.add(edge_key)
        edges.append({"edge_id": f"edge_{len(edges)}", "oriented_sequence": source_sequence + target_sequence[-1],
                      "source_node_id": source_sequence, "target_node_id": target_sequence, "count": 4,
                      "source_cyclic_scc_id": None, "target_cyclic_scc_id": None})
    repeat_node = "A" * 18
    if include_cycle and repeat_node in node_sequences:
        repeat_edge = next((edge for edge in edges
                            if edge["source_node_id"] == repeat_node and edge["target_node_id"] == repeat_node), None)
        if repeat_edge is None:
            repeat_edge = {"edge_id": f"edge_{len(edges)}", "oriented_sequence": "A" * 19,
                           "source_node_id": repeat_node, "target_node_id": repeat_node, "count": 4,
                           "source_cyclic_scc_id": "component_repeat", "target_cyclic_scc_id": "component_repeat"}
            edges.append(repeat_edge)
        else:
            repeat_edge["source_cyclic_scc_id"] = "component_repeat"
            repeat_edge["target_cyclic_scc_id"] = "component_repeat"
        internal_edges = [edge["edge_id"] for edge in edges
                          if edge["source_node_id"] == repeat_node and edge["target_node_id"] == repeat_node]
        entry_edges = [edge["edge_id"] for edge in edges
                       if edge["source_node_id"] != repeat_node and edge["target_node_id"] == repeat_node]
        exit_edges = [edge["edge_id"] for edge in edges
                      if edge["source_node_id"] == repeat_node and edge["target_node_id"] != repeat_node]
        components = [{"component_id": "component_repeat", "node_ids": [repeat_node],
                       "internal_edge_ids": internal_edges, "entry_edge_ids": entry_edges, "exit_edge_ids": exit_edges}]
    else:
        components = []
    return {"schema_version": 1, "target": "insecta_ITS_2", "graph": {"phase": BUILDER.EXPORT_PHASES[phase],
            "node_count": len(nodes), "edge_count": len(edges), "canonical_graph_sha256": "fixture",
            "nodes": nodes, "edges": edges, "cyclic_components": components,
            "marker_causes_from_pre_prune_detection": {"omitted_self_loop_nodes": [],
            "cyclic_scc_nodes": [repeat_node] if include_cycle else [], "retained_collision_edges": []}}}


def audit_manifest(candidate, pre_graph, post_graph):
    pre_bytes = json.dumps(pre_graph, sort_keys=True).encode("utf-8")
    post_bytes = json.dumps(post_graph, sort_keys=True).encode("utf-8")
    record = candidate["record"]
    return {"schema_version": 1, "status": "complete", "target": {
        "sample": "SRR27962769", "gene": candidate["gene"], "threshold": 4,
        "kmer_length": candidate["kmer_length"], "historical_product_sha256": record["sequence_sha256"],
        "expected_path_markers": [{"oriented_node_sequence": item["identity_sequence"],
                                   "historical_path_start": item["start"],
                                   "historical_path_end": item["end"]}
                                  for item in record["marker_occurrences"]]},
            "files": {"pre_prune.json": {"size_bytes": len(pre_bytes), "sha256": hashlib.sha256(pre_bytes).hexdigest()},
                      "post_prune.json": {"size_bytes": len(post_bytes), "sha256": hashlib.sha256(post_bytes).hexdigest()}}}


class LocalAssayBuilderTests(unittest.TestCase):
    def test_groups_same_component_occurrences_and_merges_flanks(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        result = BUILDER.build(candidate, pre_graph, post_graph)
        self.assertEqual(len(result["regions"]), 1)
        region = result["regions"][0]
        self.assertEqual(region["start"], 9)
        self.assertEqual(region["end"], 81)
        self.assertTrue(region["qualified_for_scanning"])
        self.assertTrue(region["historical_local_class_id"])
        self.assertTrue(any(item["flank_classes"] == ["focal_same_flanks"] for item in region["classes"]))

    def test_walk_continues_after_right_anchor_and_allows_many_visits(self):
        nodes = {"left": {"sequence": "ACCC"}, "right": {"sequence": "CCCC"}}
        outgoing = {"left": [("edge_left_right", "right")], "right": [("edge_loop", "right")]}
        previous_flanks = BUILDER.FLANK_BASES
        BUILDER.FLANK_BASES = 2
        try:
            result = BUILDER.walk_between_anchors(nodes, outgoing, "left", "right")
        finally:
            BUILDER.FLANK_BASES = previous_flanks
        self.assertIn("ACCCC", result["spellings"])
        self.assertIn("ACCCCC", result["spellings"])
        self.assertIn("ACCCCCCC", result["spellings"])

    def test_alternate_exit_and_reentry_spellings_are_retained(self):
        nodes = {"left": {"sequence": "ACCC"}, "primary_one": {"sequence": "CCCA"},
                 "primary_two": {"sequence": "CCAA"}, "primary_three": {"sequence": "CAAA"},
                 "alternate_one": {"sequence": "CCCG"}, "alternate_two": {"sequence": "CCGA"},
                 "alternate_three": {"sequence": "CGAA"}, "alternate_four": {"sequence": "GAAA"},
                 "right": {"sequence": "AAAA"}}
        outgoing = {"left": [("edge_primary", "primary_one"), ("edge_alternate", "alternate_one")],
                    "primary_one": [("edge_primary_two", "primary_two")],
                    "primary_two": [("edge_primary_three", "primary_three")],
                    "primary_three": [("edge_primary_right", "right")],
                    "alternate_one": [("edge_alternate_two", "alternate_two")],
                    "alternate_two": [("edge_alternate_three", "alternate_three")],
                    "alternate_three": [("edge_alternate_four", "alternate_four")],
                    "alternate_four": [("edge_alternate_right", "right")], "right": []}
        previous_flanks = BUILDER.FLANK_BASES
        BUILDER.FLANK_BASES = 2
        try:
            result = BUILDER.walk_between_anchors(nodes, outgoing, "left", "right")
        finally:
            BUILDER.FLANK_BASES = previous_flanks
        self.assertIn("ACCCAAAA", result["spellings"])
        self.assertIn("ACCCGAAAA", result["spellings"])

    def test_missing_flank_is_unqualified(self):
        sequence = "A" * 30 + candidate_sequence()[30:]
        candidate = candidate_data(sequence, marker_start=1)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        result = BUILDER.build(candidate, pre_graph, post_graph)
        self.assertFalse(result["regions"][0]["qualified_for_scanning"])
        self.assertIn("pre_prune:missing_complete_flanks", result["regions"][0]["unresolved_reasons"])

    def test_spelling_cap_marks_region_unresolved(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        previous_cap = BUILDER.MAX_SPELLINGS
        BUILDER.MAX_SPELLINGS = 1
        try:
            result = BUILDER.build(candidate, pre_graph, post_graph)
        finally:
            BUILDER.MAX_SPELLINGS = previous_cap
        self.assertFalse(result["regions"][0]["qualified_for_scanning"])
        self.assertIn("pre_prune:unresolved_enumeration", result["regions"][0]["unresolved_reasons"])

    def test_identical_local_classes_from_multiple_stages_deduplicate(self):
        region = {"id": "region_1", "start": 0, "end": 43, "stages": {"pre_prune": {"status": "enumerated", "complete_within_bounds": True,
                  "candidate_window": "A" * 21 + "C" + "G" * 21,
                  "spelling_rows": [{"sequence": "A" * 21 + "C" + "G" * 21, "sequence_sha256": digest("A" * 21 + "C" + "G" * 21),
                                     "route_node_ids": ["pre"], "flank_class": "focal_same_flanks", "assayable": True}]},
                  "post_prune": {"status": "enumerated", "complete_within_bounds": True,
                  "spelling_rows": [{"sequence": "A" * 21 + "C" + "G" * 21, "sequence_sha256": digest("A" * 21 + "C" + "G" * 21),
                                     "route_node_ids": ["post"], "flank_class": "competitor_changed_flank", "assayable": True}]}}}
        classes, unresolved, historical_class_id = BUILDER.local_classes(region)
        self.assertFalse(unresolved)
        self.assertEqual(len(classes), 1)
        self.assertEqual(len(classes[0]["members"]), 2)
        self.assertEqual(classes[0]["id"], historical_class_id)

    def test_changed_flank_competitor_stays_in_manifest(self):
        focal_sequence = "A" * 21 + "C" + "G" * 21
        competitor_sequence = "T" * 21 + "C" + "G" * 21
        region = {"id": "region_1", "start": 0, "end": 43, "stages": {"pre_prune": {"status": "enumerated", "complete_within_bounds": True,
                  "candidate_window": focal_sequence,
                  "spelling_rows": [{"sequence": focal_sequence, "sequence_sha256": digest(focal_sequence),
                                     "route_node_ids": ["focal"], "flank_class": "focal_same_flanks", "assayable": True},
                                    {"sequence": competitor_sequence, "sequence_sha256": digest(competitor_sequence),
                                     "route_node_ids": ["competitor"], "flank_class": "competitor_changed_flank", "assayable": True}]},
                  "post_prune": {"status": "enumerated", "complete_within_bounds": True, "spelling_rows": []}}}
        classes, unresolved, _ = BUILDER.local_classes(region)
        self.assertFalse(unresolved)
        manifest = BUILDER.scanner_manifest(region, classes)
        self.assertEqual(len(manifest["candidates"]), 2)
        self.assertEqual(len(manifest["events"]), 2)
        self.assertEqual(sum(event["source"]["focal_same_flanks"] for event in manifest["events"]), 1)

    def test_state_cap_marks_walk_incomplete(self):
        nodes = {"left": {"sequence": "ACCC"}, "right": {"sequence": "CCCC"}}
        outgoing = {"left": [("edge_left_right", "right")], "right": [("edge_loop", "right")]}
        previous_cap = BUILDER.MAX_EXPANSIONS
        previous_flanks = BUILDER.FLANK_BASES
        BUILDER.MAX_EXPANSIONS = 1
        BUILDER.FLANK_BASES = 2
        try:
            result = BUILDER.walk_between_anchors(nodes, outgoing, "left", "right")
        finally:
            BUILDER.MAX_EXPANSIONS = previous_cap
            BUILDER.FLANK_BASES = previous_flanks
        self.assertTrue(result["state_cap_hit"])
        self.assertFalse(result["complete_within_bounds"])

    def test_candidate_nodes_and_edges_must_be_present_in_both_graphs(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        first_edge = post_graph["graph"]["edges"][0]
        post_graph["graph"]["edges"].remove(first_edge)
        post_graph["graph"]["edge_count"] = len(post_graph["graph"]["edges"])
        with self.assertRaisesRegex(ValueError, "Historical candidate edge"):
            BUILDER.build(candidate, pre_graph, post_graph)

    def test_rejects_legacy_short_phase_name(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        pre_graph["graph"]["phase"] = "pre_prune"
        with self.assertRaisesRegex(ValueError, "pre_prune_after_extension"):
            BUILDER.build(candidate, pre_graph, post_graph)

    def test_reverse_reachability_prunes_irrelevant_branch_and_keeps_anchor_return(self):
        nodes = {"left": {"sequence": "ACCC"}, "right": {"sequence": "CCCC"},
                 "irrelevant": {"sequence": "CCCG"}, "irrelevant_next": {"sequence": "CCGG"}}
        outgoing = {"left": [("left_right", "right"), ("left_irrelevant", "irrelevant")],
                    "right": [("right_return", "right")],
                    "irrelevant": [("irrelevant_next", "irrelevant_next")], "irrelevant_next": []}
        previous_flanks = BUILDER.FLANK_BASES
        BUILDER.FLANK_BASES = 2
        try:
            result = BUILDER.walk_between_anchors(nodes, outgoing, "left", "right")
        finally:
            BUILDER.FLANK_BASES = previous_flanks
        self.assertGreaterEqual(result["reverse_unreachable_edges_skipped"], 1)
        self.assertIn("ACCCC", result["spellings"])
        self.assertIn("ACCCCC", result["spellings"])

    def test_short_right_anchor_spelling_is_retained_but_unassayable(self):
        short_sequence = "A" * 41
        region = {"id": "region_1", "start": 10, "end": 51, "stages": {"pre_prune": {
            "status": "enumerated", "complete_within_bounds": True, "candidate_window": short_sequence,
            "spelling_rows": [{"sequence": short_sequence, "sequence_sha256": digest(short_sequence),
                               "route_node_ids": ["right"], "flank_class": "focal_same_flanks", "assayable": False}]}}}
        classes, unresolved, _ = BUILDER.local_classes(region)
        self.assertEqual(len(classes), 1)
        self.assertFalse(classes[0]["assayable"])
        self.assertIn("unassayable_right_anchor_spelling", unresolved)
        self.assertEqual(BUILDER.scanner_manifest(region, classes)["events"], [])

    def test_canonical_class_records_reverse_complement_coordinate_mapping(self):
        candidate_window = "T" * 42
        region = {"id": "region_1", "start": 4, "end": 46, "stages": {"pre_prune": {
            "status": "enumerated", "complete_within_bounds": True, "candidate_window": candidate_window,
            "spelling_rows": [{"sequence": candidate_window, "sequence_sha256": digest(candidate_window),
                               "route_node_ids": ["forward"], "flank_class": "focal_same_flanks", "assayable": True}]}}}
        classes, unresolved, _ = BUILDER.local_classes(region)
        self.assertFalse(unresolved)
        self.assertEqual(classes[0]["candidate_coordinate_mapping"]["candidate_window"], [4, 46])
        self.assertEqual(classes[0]["candidate_coordinate_mapping"]["canonical_to_candidate_window"], "reverse_complement")

    def test_audit_manifest_receipt_mismatch_fails_closed(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        pre_bytes = json.dumps(pre_graph, sort_keys=True).encode("utf-8")
        post_bytes = json.dumps(post_graph, sort_keys=True).encode("utf-8")
        manifest = audit_manifest(candidate, pre_graph, post_graph)
        manifest["files"]["post_prune.json"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "checksum"):
            BUILDER.verify_audit_manifest(manifest, candidate, pre_bytes, post_bytes)

    def test_cli_binds_audit_manifest_and_freezes_builder_sources(self):
        sequence = candidate_sequence()
        candidate = candidate_data(sequence)
        pre_graph = graph_data(sequence, "pre_prune")
        post_graph = graph_data(sequence, "post_prune")
        target = {"sample": "SRR27962769", "gene": candidate["gene"], "threshold": candidate["threshold"],
                  "kmer_length": candidate["kmer_length"], "historical_product_sha256": candidate["record"]["sequence_sha256"]}
        pre_graph["target"] = target
        post_graph["target"] = target
        pre_bytes = json.dumps(pre_graph, sort_keys=True).encode("utf-8")
        post_bytes = json.dumps(post_graph, sort_keys=True).encode("utf-8")
        manifest = audit_manifest(candidate, pre_graph, post_graph)
        with tempfile.TemporaryDirectory() as directory_name:
            directory = Path(directory_name)
            candidate_path = directory / "candidate.json"
            pre_path = directory / "pre_prune.json"
            post_path = directory / "post_prune.json"
            manifest_path = directory / "audit_manifest.json"
            output_path = directory / "output"
            candidate_path.write_text(json.dumps(candidate, sort_keys=True))
            pre_path.write_bytes(pre_bytes)
            post_path.write_bytes(post_bytes)
            manifest_path.write_text(json.dumps(manifest, sort_keys=True))
            arguments = [str(MODULE_PATH), "--candidate", str(candidate_path), "--pre-graph", str(pre_path),
                         "--post-graph", str(post_path), "--audit-manifest", str(manifest_path),
                         "--output-dir", str(output_path)]
            with mock.patch.object(sys, "argv", arguments):
                BUILDER.main()
            analysis = json.loads((output_path / "analysis.json").read_text())
            selected = RUNNER.selected_manifests(analysis, output_path)
        self.assertEqual(analysis["provenance"]["audit_manifest_sha256"],
                         hashlib.sha256(json.dumps(manifest, sort_keys=True).encode("utf-8")).hexdigest())
        self.assertEqual(analysis["provenance"]["source_freeze_before"], analysis["provenance"]["source_freeze_after"])
        self.assertEqual(len(selected), 1)


if __name__ == "__main__":
    unittest.main()
