from pathlib import Path

import validate_final


validate_final.DESTINATION = Path(__file__).resolve().parent / 'final_validation_v2'
validate_final.main()
