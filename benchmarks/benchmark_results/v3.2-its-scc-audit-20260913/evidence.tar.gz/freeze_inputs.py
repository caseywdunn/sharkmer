import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PREVIOUS = Path('/tmp/sharkmer-withheld-diagnostics-20260913')
AUDIT = Path('/tmp/sharkmer-read-audit-20260913')
REPO = Path('/home/claude/repos/sharkmer')
CANDIDATE_SHA = '23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c'


def sha(contents):
    return hashlib.sha256(contents).hexdigest()


def publish(path, contents):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as destination:
        destination.write(contents)


def main():
    result_path = PREVIOUS / 'withheld_results.json'
    result_bytes = result_path.read_bytes()
    if sha(result_bytes) != '307b7798ea111ed8329d8fe40a4ed576638442ec1254f0dc6312811430b4b462':
        raise ValueError('Prior reviewed analysis changed')
    matches = [row for row in json.loads(result_bytes)['historical_localization'] if row['historical_sha256'] == CANDIDATE_SHA]
    if len(matches) != 2 or any(len(row['matches']) != 1 for row in matches):
        raise ValueError('Expected the two reviewed ITS identity observations')
    records = [row['matches'][0]['record'] for row in matches]
    if records[0] != records[1] or sha(records[0]['oriented_sequence'].encode()) != CANDIDATE_SHA:
        raise ValueError('ITS identity observations differ')
    candidate = {'schema_version': 1, 'purpose': 'historical_graph_hypothesis_not_reference_or_truth', 'gene': 'insecta_ITS_2', 'threshold': 4, 'kmer_length': 19, 'prior_analysis_sha256': sha(result_bytes), 'record': records[0]}
    publish(ROOT / 'inputs/candidate.json', (json.dumps(candidate, indent=2, sort_keys=True) + '\n').encode())
    source_paths = {
        'focused_baseline_receipt.json': PREVIOUS / 'execution/SRR27962769.changed_on_focused.receipt.json',
        'focused_panel.yaml': PREVIOUS / 'focused_panels/SRR27962769.insecta.focused.yaml',
        'expected_prefix.json': AUDIT / 'scan_specs/SRR27962769.expected_prefix.json',
        'prior_read_manifest.json': AUDIT / 'scan_specs/SRR27962769.scanner_manifest.json',
        'previous_comparison_protocol.json': PREVIOUS / 'protocol.json',
    }
    sources = {}
    for name, source in source_paths.items():
        contents = source.read_bytes()
        publish(ROOT / 'inputs' / name, contents)
        sources[name] = {'original_path': str(source), 'sha256': sha(contents)}
    old_manifest = json.loads((ROOT / 'inputs/prior_read_manifest.json').read_bytes())
    selected = [event for event in old_manifest['events'] if 'CO1_1_frozen_alternatives' in event.get('comparison_group', '') and event['role'] in {'supplementary_retained_corresponding_interval', 'primary_complete_placement_union'}]
    if len(selected) != 2:
        raise ValueError('Expected the two unchanged structural CO1 controls')
    control = {**old_manifest, 'events': selected, 'purpose': 'unchanged_CO1_structural_control_recheck_all_original_competitors_retained'}
    publish(ROOT / 'inputs/co1_control_manifest.json', (json.dumps(control, indent=2, sort_keys=True) + '\n').encode())
    sources['candidate.json'] = {'sha256': sha((ROOT / 'inputs/candidate.json').read_bytes()), 'prior_analysis_path': str(result_path)}
    sources['co1_control_manifest.json'] = {'sha256': sha((ROOT / 'inputs/co1_control_manifest.json').read_bytes()), 'derivation': 'exact two historical CO1 structural events; all five original candidate competitors retained'}
    sources['scanner'] = {'path': str(REPO / 'scripts/audit_read_bridges.py'), 'sha256': sha((REPO / 'scripts/audit_read_bridges.py').read_bytes())}
    publish(ROOT / 'inputs/source_manifest.json', (json.dumps(sources, indent=2, sort_keys=True) + '\n').encode())


if __name__ == '__main__':
    main()
