import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path('/home/claude/repos/sharkmer')
DESTINATION = ROOT / 'final_validation'


def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()


def main():
    DESTINATION.mkdir(exist_ok=False)
    commands = [
        ('harness', ROOT, [sys.executable, '-m', 'unittest', '-v', 'test_build_local_assays', 'test_run_graph_capture', 'test_run_read_assays']),
        ('exact_recount_tests', ROOT / 'review', [sys.executable, '-m', 'unittest', '-v', 'test_recount_exact']),
        ('scratch_fmt', ROOT / 'source-instrumented', ['cargo', 'fmt', '--all', '--check']),
        ('scratch_clippy', ROOT / 'source-instrumented', ['cargo', 'clippy', '--locked', '--offline', '--', '-D', 'warnings']),
        ('repository_python', REPOSITORY, [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py']),
        ('repository_references', REPOSITORY, [sys.executable, 'scripts/audit_panel_references.py', '--verify-existing']),
        ('diff_check', REPOSITORY, ['git', 'diff', '--check']),
    ]
    sources = sorted(set(
        list(ROOT.glob('*.py')) + list((ROOT / 'review').glob('*.py'))
        + list((ROOT / 'source-instrumented/src').rglob('*.rs'))
        + list((REPOSITORY / 'scripts').rglob('*.py'))
        + list((REPOSITORY / 'tests').glob('test_*.py'))
    ))
    before = {str(path): digest(path) for path in sources}
    results = []
    for name, working_directory, command in commands:
        environment = os.environ.copy()
        if name.startswith('scratch_'):
            environment['CARGO_TARGET_DIR'] = str(ROOT / 'source-instrumented/target')
        started = datetime.now(timezone.utc).isoformat()
        with (DESTINATION / f'{name}.stdout.txt').open('xb') as stdout, (DESTINATION / f'{name}.stderr.txt').open('xb') as stderr:
            process = subprocess.run(command, cwd=working_directory, env=environment, stdout=stdout, stderr=stderr, timeout=1800)
        results.append({'name': name, 'command': command, 'cwd': str(working_directory), 'started_at': started,
                        'finished_at': datetime.now(timezone.utc).isoformat(), 'returncode': process.returncode,
                        'stdout_sha256': digest(DESTINATION / f'{name}.stdout.txt'),
                        'stderr_sha256': digest(DESTINATION / f'{name}.stderr.txt')})
        print(f'{name}: {process.returncode}', flush=True)
    after = {str(path): digest(path) for path in sources}
    passed = before == after and all(result['returncode'] == 0 for result in results)
    receipt = {'schema_version': 1, 'status': 'PASS' if passed else 'FAIL', 'commands': results,
               'source_before': before, 'source_after': after, 'sources_unchanged': before == after}
    (DESTINATION / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
