import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

from verify_frozen_inputs import verify


ROOT = Path(__file__).resolve().parent
REPO = Path('/home/claude/repos/sharkmer')
SCANNER = REPO / 'scripts/audit_read_bridges.py'
PRLIMIT = Path('/usr/bin/prlimit')


def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as source:
        while contents := source.read(1024 * 1024):
            checksum.update(contents)
    return checksum.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, data):
    with path.open('x') as destination:
        destination.write(json.dumps(data, indent=2, sort_keys=True) + '\n')
        destination.flush()
        os.fsync(destination.fileno())


def source_hashes(paths):
    require(all(Path(path).is_file() for path in paths), 'Required assay source is missing')
    return {str(Path(path).resolve()): digest(Path(path)) for path in sorted(set(paths))}


def selected_manifests(analysis, directory):
    regions = analysis['regions']
    require(len({region['id'] for region in regions}) == len(regions), 'Duplicate region id')
    manifests = []
    for region in regions:
        require(isinstance(region['id'], str) and re.fullmatch(r'region_[1-9][0-9]*', region['id']), 'Unsafe region id')
        if not region['qualified_for_scanning']:
            require(region['unresolved_reasons'], 'Unqualified region lacks an explicit reason')
            continue
        require(not region['unresolved_reasons'] and region['historical_local_class_id'], 'Qualified region is unresolved')
        basename = region['assay_manifest']
        require(Path(basename).name == basename and basename.endswith('.json'), 'Unsafe assay manifest name')
        path = directory / basename
        require(digest(path) == region['assay_manifest_sha256'], 'Derived manifest hash differs')
        manifests.append((region['id'], path))
    return manifests


def expected_jobs(analysis_path):
    analysis = json.loads(analysis_path.read_text())
    manifests = selected_manifests(analysis, analysis_path.parent)
    manifests.append(('co1_control', ROOT / 'inputs/co1_control_manifest.json'))
    return [{'region': region, 'max_substitutions': mode, 'manifest': str(path.resolve()), 'manifest_sha256': digest(path), 'output_basename': f'{region}.substitutions_{mode}.json'} for region, path in manifests for mode in (0, 1)]


def prepare(analysis_path, capture_path, output_path):
    verify()
    require(not output_path.exists(), 'Refusing existing assay plan')
    analysis = json.loads(analysis_path.read_text())
    capture = json.loads(capture_path.read_text())
    require(capture['parity_passed'] and capture['failure'] is None and capture['source_changed'] is False, 'Graph capture did not pass')
    require(analysis['limits'] == {'flank_bases': 21, 'max_walk_bases': 150, 'max_expansions': 1000000, 'max_spellings': 4096, 'max_assay_alternatives': 128}, 'Alternative universe differs')
    for stage in ('pre', 'post'):
        graph = capture_path.parent / 'graphs' / f'{stage}_prune.json'
        require(analysis['provenance'][f'{stage}_graph_sha256'] == digest(graph) == capture['graph_files'][graph.name], 'Analysis graph lineage differs')
    require(analysis['provenance']['candidate_sha256'] == digest(ROOT / 'inputs/candidate.json'), 'Analysis candidate lineage differs')
    require(analysis['provenance']['builder_sha256'] == digest(ROOT / 'build_local_assays.py'), 'Analysis builder lineage differs')
    manifests = selected_manifests(analysis, analysis_path.parent)
    manifests.append(('co1_control', ROOT / 'inputs/co1_control_manifest.json'))
    protocol = json.loads((ROOT / 'inputs/previous_comparison_protocol.json').read_text())
    sample = protocol['samples']['SRR27962769']
    prefix = ROOT / 'inputs/expected_prefix.json'
    jobs = expected_jobs(analysis_path)
    paths = list(ROOT.glob('*.py')) + list((ROOT / 'inputs').glob('*'))
    paths += [SCANNER, PRLIMIT, REPO / 'tests/test_read_bridges.py', ROOT / 'ITS_SCC_AUDIT_PROTOCOL.snapshot.md', Path(sys.executable).resolve(), analysis_path, capture_path]
    paths += [capture_path.parent / 'graphs' / name for name in ('pre_prune.json', 'post_prune.json', 'audit_manifest.json')]
    paths += [path for _, path in manifests]
    save(output_path, {'schema_version': 1, 'purpose': 'local_structure_audit_not_haplotype_truth', 'jobs': jobs, 'input': sample, 'expected_prefix': str(prefix), 'interpreter': str(Path(sys.executable).resolve()), 'sources': source_hashes(paths), 'analysis_path': str(analysis_path.resolve()), 'capture_path': str(capture_path.resolve())})
    print(json.dumps({'planned_scans': len(jobs), 'qualified_regions': len(manifests) - 1}))


def execute(plan_path, output):
    verify()
    require(not output.exists(), 'Refusing existing read-assay output')
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    require(source_hashes(plan['sources']) == plan['sources'], 'Assay sources differ before execution')
    require(plan['jobs'] == expected_jobs(Path(plan['analysis_path'])), 'Scan matrix differs from all qualified regions and control')
    protocol = json.loads((ROOT / 'inputs/previous_comparison_protocol.json').read_text())
    require(plan['input'] == protocol['samples']['SRR27962769'], 'Input protocol differs')
    require(plan['expected_prefix'] == str(ROOT / 'inputs/expected_prefix.json'), 'Prefix manifest path differs')
    require(plan['interpreter'] == str(Path(sys.executable).resolve()), 'Interpreter differs')
    require(digest(Path(plan['input']['input'])) == plan['input']['full_sha256'], 'Full staged input differs')
    output.mkdir(parents=True)
    save(output / 'source_before.json', plan['sources'])
    records = []
    failure = None
    after = None
    for job in plan['jobs']:
        destination = output / job['output_basename']
        command = [str(PRLIMIT), '--as=42949672960', '--', plan['interpreter'], str(SCANNER), '--fastq', plan['input']['input'], '--events', job['manifest'], '--expected-prefix', plan['expected_prefix'], '--max-substitutions', str(job['max_substitutions']), '--output', str(destination)]
        started = time.time()
        receipt = {'job': job, 'command': command, 'started_at_unix': started, 'returncode': None, 'timed_out': False, 'output_sha256': None}
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                stdout, stderr = process.communicate(timeout=1800)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate()
                receipt['timed_out'] = True
            receipt['returncode'] = process.returncode
            (output / f'{job["region"]}.substitutions_{job["max_substitutions"]}.stdout.txt').write_text(stdout)
            (output / f'{job["region"]}.substitutions_{job["max_substitutions"]}.stderr.txt').write_text(stderr)
            require(process.returncode == 0 and not receipt['timed_out'] and destination.is_file(), 'Scanner invocation failed')
            receipt['output_sha256'] = digest(destination)
            report = json.loads(destination.read_text())
            require(report['input_subset'] == plan['input']['prefix'] and report['max_substitutions'] == job['max_substitutions'], 'Scanner input/assay identity differs')
            require(report['provenance'] == {'event_manifest_sha256': job['manifest_sha256'], 'expected_prefix_manifest_sha256': plan['sources'][plan['expected_prefix']], 'scanner_sha256': plan['sources'][str(SCANNER)]}, 'Scanner source bindings differ')
            require(source_hashes(plan['sources']) == plan['sources'], 'Assay source changed during scan')
            receipt['validated'] = True
        except Exception as error:
            receipt['validated'] = False
            failure = f'{type(error).__name__}: {error}'
            receipt['error'] = failure
        receipt['finished_at_unix'] = time.time()
        save(output / f'{job["region"]}.substitutions_{job["max_substitutions"]}.receipt.json', receipt)
        records.append(receipt)
        if failure:
            break
    try:
        require(plan_path.read_bytes() == plan_bytes, 'Assay plan changed')
        after = source_hashes(plan['sources'])
        require(after == plan['sources'], 'Assay sources changed')
        require(digest(Path(plan['input']['input'])) == plan['input']['full_sha256'], 'Full staged input changed after scans')
    except Exception as error:
        if failure is None:
            failure = f'{type(error).__name__}: {error}'
    save(output / 'execution.json', {'schema_version': 1, 'plan_sha256': hashlib.sha256(plan_bytes).hexdigest(), 'source_before': plan['sources'], 'source_after': after, 'source_changed': None if after is None else after != plan['sources'], 'failure': failure, 'jobs': records})
    require(failure is None and len(records) == len(plan['jobs']), failure or 'Incomplete scan matrix')
    print(json.dumps({'completed_scans': len(records)}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--analysis', type=Path)
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    arguments = parser.parse_args()
    require(arguments.prepare != arguments.execute, 'Choose exactly --prepare or --execute')
    if arguments.prepare:
        require(arguments.analysis is not None and arguments.capture is not None, 'Preparation needs analysis and capture receipts')
        prepare(arguments.analysis, arguments.capture, arguments.plan)
    else:
        require(arguments.output is not None, 'Execution needs a fresh output directory')
        execute(arguments.plan, arguments.output)


if __name__ == '__main__':
    main()
