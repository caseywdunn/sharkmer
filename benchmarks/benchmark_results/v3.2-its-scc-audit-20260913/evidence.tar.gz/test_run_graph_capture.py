import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


SPECIFICATION = importlib.util.spec_from_file_location('capture', Path(__file__).with_name('run_graph_capture.py'))
CAPTURE = importlib.util.module_from_spec(SPECIFICATION)
SPECIFICATION.loader.exec_module(CAPTURE)


class ParityTests(unittest.TestCase):
    def setUp(self):
        self.baseline = {'stats': {field: 1 for field in ('n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers')}, 'fasta_records_ordered': [{'header': 'complete header', 'sequence': 'ACGT'}]}
        self.baseline['stats']['pcr_results'] = [{'gene_name': 'insecta_ITS_2', 'status': 'no_product', 'threshold_diagnostics': [{'threshold': 4, 'withheld_path_diagnostics': {'paths': []}}]}]

    def test_unchanged_complete_outputs_pass(self):
        CAPTURE.compare_outputs(copy.deepcopy(self.baseline), self.baseline)

    def test_actual_exporter_stage_literals_and_counts(self):
        phases = {'pre_prune.json': 'pre_prune_after_extension_before_tip_and_reachability_pruning', 'post_prune.json': 'post_tip_and_reachability_pruning_and_coverage_annotation'}
        for basename, phase in phases.items():
            document = {'schema_version': 1, 'target': {'gene': 'insecta_ITS_2'}, 'graph': {'phase': phase, 'node_count': 1, 'nodes': [{'node_id': 'fixture'}], 'edge_count': 0, 'edges': []}}
            CAPTURE.validate_graph_document(document, document['target'], basename)
            document['graph']['phase'] = basename.removesuffix('.json')
            with self.assertRaisesRegex(ValueError, 'stage/target'):
                CAPTURE.validate_graph_document(document, document['target'], basename)
            document['graph']['phase'] = phase
            document['graph']['node_count'] = 0
            with self.assertRaisesRegex(ValueError, 'counts'):
                CAPTURE.validate_graph_document(document, document['target'], basename)

    def test_count_header_sequence_gene_payload_drift_fails(self):
        for field in ('n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers'):
            current = copy.deepcopy(self.baseline)
            current['stats'][field] += 1
            with self.assertRaises(ValueError):
                CAPTURE.compare_outputs(current, self.baseline)
        for field in ('header', 'sequence'):
            current = copy.deepcopy(self.baseline)
            current['fasta_records_ordered'][0][field] += 'changed'
            with self.assertRaises(ValueError):
                CAPTURE.compare_outputs(current, self.baseline)
        current = copy.deepcopy(self.baseline)
        current['stats']['pcr_results'][0]['threshold_diagnostics'][0]['withheld_path_diagnostics']['paths'].append('changed')
        with self.assertRaises(ValueError):
            CAPTURE.compare_outputs(current, self.baseline)


class BindingTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        for name in ('inputs', 'scripts/sharkmer_validate'):
            (self.root / name).mkdir(parents=True)
        self.binary = self.root / 'binary'
        self.binary.write_bytes(b'fixture executable')
        self.source = self.root / 'fixture.rs'
        self.source.write_text('fixture')
        self.snapshot = self.root / 'source_snapshot.json'
        self.snapshot.write_text(json.dumps({'files': {str(self.source): CAPTURE.digest(self.source)}}))
        self.build = self.root / 'build.json'
        self.receipt = {'returncode': 0, 'binary_sha256': CAPTURE.digest(self.binary), 'source_snapshot_sha256': CAPTURE.digest(self.snapshot), 'source_before': json.loads(self.snapshot.read_text())['files'], 'source_after': json.loads(self.snapshot.read_text())['files']}
        self.build.write_text(json.dumps(self.receipt))
        (self.root / 'run_three_way.py').write_text('fixture')
        for name in ('run_graph_capture.py', 'test_run_graph_capture.py', 'freeze_inputs.py', 'verify_frozen_inputs.py'):
            (self.root / name).write_text('fixture')
        (self.root / 'ITS_SCC_AUDIT_PROTOCOL.snapshot.md').write_text('frozen fixture')
        self.arguments = SimpleNamespace(source_snapshot=self.snapshot, build_receipt=self.build, binary=self.binary)
        self.harness = SimpleNamespace(TIME_BINARY=self.binary, TASKSET_BINARY=self.binary, PRLIMIT_BINARY=self.binary)

    def capture(self):
        with patch.object(CAPTURE, 'ROOT', self.root), patch.object(CAPTURE, 'REPO', self.root), patch.object(CAPTURE, 'PREVIOUS', self.root):
            return CAPTURE.source_receipt(self.arguments, self.harness)

    def test_missing_required_snapshot_fails(self):
        self.assertIn('files', self.capture())
        (self.root / 'ITS_SCC_AUDIT_PROTOCOL.snapshot.md').unlink()
        with self.assertRaisesRegex(ValueError, 'Required frozen'):
            self.capture()

    def test_failed_build_or_source_binding_mismatch_fails(self):
        for field, value in (('returncode', 1), ('source_snapshot_sha256', 'bad'), ('source_after', {})):
            changed = {**self.receipt, field: value}
            self.build.write_text(json.dumps(changed))
            with self.assertRaises(ValueError):
                self.capture()

    def test_final_hash_errors_remain_serializable(self):
        with patch.object(CAPTURE, 'digest', side_effect=PermissionError('unreadable fixture')):
            hashes, errors = CAPTURE.final_graph_hashes(self.root)
        self.assertEqual(hashes, {})
        self.assertTrue(errors)
        destination = self.root / 'failure.json'
        CAPTURE.save(destination, {'failure': 'original failure', 'graph_files': hashes, 'graph_hash_errors': errors})
        self.assertEqual(json.loads(destination.read_text())['failure'], 'original failure')


if __name__ == '__main__':
    unittest.main()
