import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


SPECIFICATION = importlib.util.spec_from_file_location('read_runner', Path(__file__).with_name('run_read_assays.py'))
RUNNER = importlib.util.module_from_spec(SPECIFICATION)
SPECIFICATION.loader.exec_module(RUNNER)


class SelectionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        (self.root / 'inputs').mkdir()
        self.manifest = self.root / 'region_1.json'
        self.manifest.write_text('{}')
        (self.root / 'inputs/co1_control_manifest.json').write_text('{}')
        self.analysis = {'regions': [{'id': 'region_1', 'qualified_for_scanning': True, 'unresolved_reasons': [], 'historical_local_class_id': 'class_1', 'assay_manifest': self.manifest.name, 'assay_manifest_sha256': RUNNER.digest(self.manifest)}, {'id': 'region_2', 'qualified_for_scanning': False, 'unresolved_reasons': ['incomplete']}]}

    def test_every_qualified_region_and_control_get_both_modes(self):
        path = self.root / 'analysis.json'
        path.write_text(json.dumps(self.analysis))
        with patch.object(RUNNER, 'ROOT', self.root):
            jobs = RUNNER.expected_jobs(path)
        self.assertEqual([(job['region'], job['max_substitutions']) for job in jobs], [('region_1', 0), ('region_1', 1), ('co1_control', 0), ('co1_control', 1)])

    def test_mutated_manifest_and_duplicate_or_unsafe_region_fail(self):
        changed = copy.deepcopy(self.analysis)
        changed['regions'].append(changed['regions'][0])
        with self.assertRaises(ValueError):
            RUNNER.selected_manifests(changed, self.root)
        changed = copy.deepcopy(self.analysis)
        changed['regions'][0]['assay_manifest'] = '../escape.json'
        with self.assertRaises(ValueError):
            RUNNER.selected_manifests(changed, self.root)
        self.manifest.write_text('changed')
        with self.assertRaises(ValueError):
            RUNNER.selected_manifests(self.analysis, self.root)

    def test_incomplete_regions_are_not_silently_marked_qualified(self):
        self.analysis['regions'][0]['unresolved_reasons'] = ['cap']
        with self.assertRaises(ValueError):
            RUNNER.selected_manifests(self.analysis, self.root)

    def test_missing_source_fails_instead_of_hashing_a_subset(self):
        with self.assertRaises(ValueError):
            RUNNER.source_hashes([self.manifest, self.root / 'missing'])


class ScannerIntegrationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        (self.root / 'inputs').mkdir()
        (self.root / 'capture/graphs').mkdir(parents=True)
        (self.root / 'assays').mkdir()
        window = 'AACGTTGCAAGCTTGACGCTA' + 'GATTACAGATTACAGATTACA' + 'TTGCGATCGTAGCTACGATTA'
        fastq = self.root / 'reads.fastq'
        records = ''.join(f'@read_{index}\n' + 'C' * index + window + '\n+\n' + 'I' * (index + len(window)) + '\n' for index in range(1, 9))
        fastq.write_text(records)
        prefix = {'records': 8, 'bases': sum(len(window) + index for index in range(1, 9)), 'size_bytes': len(records), 'sha256': RUNNER.digest(fastq)}
        (self.root / 'inputs/expected_prefix.json').write_text(json.dumps(prefix))
        sample = {'input': str(fastq), 'full_sha256': RUNNER.digest(fastq), 'prefix': prefix}
        (self.root / 'inputs/previous_comparison_protocol.json').write_text(json.dumps({'samples': {'SRR27962769': sample}}))
        manifest = {'schema_version': 1, 'candidates': [{'id': 'local', 'sequence': window, 'sequence_sha256': RUNNER.hashlib.sha256(window.encode()).hexdigest()}], 'events': [{'id': 'event', 'candidate_id': 'local', 'start': 21, 'end': len(window) - 21}]}
        for destination in (self.root / 'inputs/co1_control_manifest.json', self.root / 'assays/region_1.json'):
            destination.write_text(json.dumps(manifest))
        (self.root / 'inputs/candidate.json').write_text('{}')
        (self.root / 'build_local_assays.py').write_text('synthetic builder fingerprint')
        (self.root / 'ITS_SCC_AUDIT_PROTOCOL.snapshot.md').write_text('synthetic protocol')
        for basename in ('pre_prune.json', 'post_prune.json', 'audit_manifest.json'):
            (self.root / 'capture/graphs' / basename).write_text('{}')
        self.capture = self.root / 'capture/capture_receipt.json'
        self.capture.write_text(json.dumps({'parity_passed': True, 'failure': None, 'source_changed': False, 'graph_files': {name: RUNNER.digest(self.root / 'capture/graphs' / name) for name in ('pre_prune.json', 'post_prune.json')}}))
        self.analysis = self.root / 'assays/analysis.json'
        self.analysis.write_text(json.dumps({'limits': {'flank_bases': 21, 'max_walk_bases': 150, 'max_expansions': 1000000, 'max_spellings': 4096, 'max_assay_alternatives': 128}, 'regions': [{'id': 'region_1', 'qualified_for_scanning': True, 'unresolved_reasons': [], 'historical_local_class_id': 'local', 'assay_manifest': 'region_1.json', 'assay_manifest_sha256': RUNNER.digest(self.root / 'assays/region_1.json')}], 'provenance': {'candidate_sha256': RUNNER.digest(self.root / 'inputs/candidate.json'), 'builder_sha256': RUNNER.digest(self.root / 'build_local_assays.py'), 'pre_graph_sha256': RUNNER.digest(self.root / 'capture/graphs/pre_prune.json'), 'post_graph_sha256': RUNNER.digest(self.root / 'capture/graphs/post_prune.json')}}))
        self.plan = self.root / 'plan.json'

    def test_full_four_scan_pipeline_uses_real_unchanged_scanner(self):
        with patch.object(RUNNER, 'ROOT', self.root), patch.object(RUNNER, 'verify'):
            RUNNER.prepare(self.analysis, self.capture, self.plan)
            RUNNER.execute(self.plan, self.root / 'execution')
        execution = json.loads((self.root / 'execution/execution.json').read_text())
        self.assertIsNone(execution['failure'])
        self.assertEqual(len(execution['jobs']), 4)
        self.assertTrue(all(job['validated'] for job in execution['jobs']))

    def test_launch_failure_still_publishes_durable_receipts(self):
        with patch.object(RUNNER, 'ROOT', self.root), patch.object(RUNNER, 'verify'):
            RUNNER.prepare(self.analysis, self.capture, self.plan)
            with patch.object(RUNNER.subprocess, 'Popen', side_effect=OSError('synthetic launch error')):
                with self.assertRaisesRegex(ValueError, 'synthetic launch error'):
                    RUNNER.execute(self.plan, self.root / 'failed')
        execution = json.loads((self.root / 'failed/execution.json').read_text())
        self.assertIn('synthetic launch error', execution['failure'])
        self.assertFalse(execution['jobs'][0]['validated'])


if __name__ == '__main__':
    unittest.main()
