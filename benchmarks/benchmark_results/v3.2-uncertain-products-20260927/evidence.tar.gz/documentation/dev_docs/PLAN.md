# Development plan: scalable, reliable sPCR

**Updated 2026-09-28 on `experiment/uncertain-products`; see [HANDOFF.md](HANDOFF.md).** It records the
latest reviewed evidence commit, saved artifacts, known limitations, and next
unimplemented integration step. Release remains on hold; dated checkpoints below
must not be mistaken for the latest code or validation totals.

Status: v3.2 implementation and direct release-baseline benchmarking complete;
release remains on hold for user review of substantial output losses and
repeat/search-budget follow-ups. See [BENCHMARK_v3.2_vs_v3.1.md](BENCHMARK_v3.2_vs_v3.1.md)
and the remaining validation/security gates in [REVIEW_v3.2.md](REVIEW_v3.2.md).
Work follows the 2026-09-08 review of
`5a66468` (Sharkmer 3.1.0).
Tracking issue: [#152](https://github.com/caseywdunn/sharkmer/issues/152).

This is the active execution plan. [ROADMAP.md](../ROADMAP.md) describes the
release sequence; [PLAN_v3.md](PLAN_v3.md) preserves the historical v3 plan.
Check items off only when code, validation, documentation, and acceptance
criteria are complete. Issue bodies carry implementation scope and dependencies.

## Release strategy

Ship several independently useful releases rather than hold correctness fixes
until metagenomic inference is finished. Version numbers are planning targets,
not promised dates. Opt-in additions can ship as v4.x minor releases; reassess
the major version if an implementation requires incompatible behavior or formats.

| Release | Primary result | Boundary |
| --- | --- | --- |
| v3.2 | Correct existing sPCR behavior and establish trustworthy validation | No new assembly accuracy claims based only on more FASTA products |
| v4.0 | Faster exact counting and complete bounded-memory ingestion/lookup | Existing standard sPCR remains the biological baseline |
| v4.1 | Read-supported low-coverage nuclear recovery | Explicit partial/ambiguous outcomes; optional local multi-k remains experimental until validated |
| v4.2 | Recovery of supported metagenomic template diversity | Rare-template retention, phase uncertainty, and defensible abundance reporting |
| v5.0+ | Additional targeting modes | Single oligos, restriction sites, UCE probes, reference/profile seeds; separate future scope |

Increasing input capacity in v4.0 should already help some nuclear targets.
The new low-coverage policy and linkage-dependent sensitivity belong in v4.1.
Do not delay v3.2 waiting for a custom counter, unitigs, or a new inference model.

## Incremental k-mer counting decision

**Retain the feature as an isolated legacy analysis path through v4.x.
Remove its machinery from the normal sPCR counting path.**

- Preserve explicit `--chunks > 0` use, existing histogram formats, and the
  existing viewer workflow. Maintenance and correctness fixes continue;
  new rarefaction features are outside this program.
- `--chunks 0` must create one logical exact count store, without chunk
  distribution, incremental histogram snapshots, or copying a sole table.
- Share byte parsing/encoding where useful, but do not require every counter
  backend to support incremental snapshots or legacy chunk merging.
- Preserve combined legacy histogram/PCR invocation through an adapter to the
  finalized counts. Document unsupported new-backend/legacy combinations
  explicitly rather than silently changing their semantics or resource limits.
- A final count histogram is distinct from incremental rarefaction and may be
  supported by the new counter without reintroducing incremental machinery.
- Removing incremental counting entirely is not authorized by this plan.
  Any later removal needs an explicit decision, migration/deprecation plan,
  and treatment of `sharkmer_viewer`.

## Architecture and resource contracts

Agree these contracts in [#139](https://github.com/caseywdunn/sharkmer/issues/139) before independent implementations.

1. **Exact counts and membership.** Preserve canonical identity, all observed
   accepted k-mers, and abundance through ingestion/finalization. Specify the
   maximum exact count and observable overflow behavior. Do not default to
   saturating u8 counts or probabilistic membership. Packed u16 with exact
   overflow storage is a benchmark candidate, not a predetermined winner.
2. **Canonical keys versus oriented identities.** Count keys and directional
   primer/graph identities are separate concepts and should have explicit
   APIs/types. The current graph uses (k-1)-mer nodes and k-mer edges.
3. **One pass over original input.** Counting must support non-replayable
   sources. Optional local spooling/replay for evidence and external counting
   does not violate this contract. Never require a second remote download.
4. **Bounded end-to-end resources.** Budget count-table growth/resizing, queues,
   concurrent target graphs, evidence, and lookup caches together. An external
   counter followed by a full in-memory final table is not a bounded-memory
   solution.
5. **Hardware baseline.** Use a 16 GB laptop as the initial target, reserving
   operating-system headroom; validate larger jobs with disk-backed storage.
   A 32–64 GB machine is an additional benchmark class, not a prerequisite for
   the architecture. Record SSD/temp-space requirements and peak RSS.
6. **Replay and evidence.** Preserve the exact selected read subset, mate
   identity, read orientation, base positions, qualities, and invalid-base
   discontinuities. Stream against bounded batches of target graphs and keep
   compact evidence rather than all reads in RAM.
7. **Target-local graph work.** Benchmark unitigs and neighbor caching on
   target graphs first. Avoid constructing global background topology merely
   to answer a small panel.
8. **Explicit uncertainty.** No-data, contradictory evidence, unresolved
   phase/repeats, partial sequence, and exhausted search are different
   outcomes. Observed k-mers do not prove an observed full-length haplotype.
9. **Reproducible storage and execution.** Persist k, count precision,
   canonicalization, preprocessing, input/subset identity, and schema version.
   Fingerprint tested binaries and record actual parameters.

## v3.2 — Correctness and reliable evaluation

- [ ] [#129](https://github.com/caseywdunn/sharkmer/issues/129) — Make sPCR validation and benchmark provenance trustworthy.
  - [x] Implement per-product validation, executable/input provenance, current-run manifests, benchmark metrics, and offline regression checks; independent Astra review approved on 2026-09-08.
  - [x] Verify 145 Rust unit tests, 22 integration tests, 20 Python regressions, exact fixture counts/sequences, real BLAST ambiguity/split cases, and bounded ENA cache checks.
  - [ ] Register independent biological held-out inputs and truth before assembly-policy tuning. Existing datasets remain calibration/regression data; see [the dataset policy](../benchmarks/DATASETS.md). This acceptance gate keeps the issue open.
  - [x] Audit all 159 built-in/example reference entries against 109 independently acquired public records: 100 exact source regions, 59 source mismatches. Further quarantine two source-exact Xenia 16S/mutS annotation conflicts, retaining 98 old regions plus one independent replacement example (99 active). Preserve all old sequences as regression-only history; pin versions, coordinates/strand, hashes, and source organisms. Add fail-closed offline verification, known annotation-conflict exclusions, CI, and anti-promotion bootstrap guards. See [the full reference contract and audit](REFERENCE_PROVENANCE.md).
  - [x] Separate variation-aware gene support from exact reference provenance, sequence relationship, sample haplotype truth, and unevaluated read support. SNPs/indels and compatible split alignments need not fail support; no new results claim `confirmed_product`. Preserve reference exclusions and catalog receipts in results/reports. This changes evaluation, not assembly gates or k=19.
  - [x] Acquire annotation-reviewed public alternatives for 58 of the 61 quarantined entries (57 newly covered legacy IDs plus the already replaced Hydra example). Shared H3 evidence is one genomic locus, not two sample alleles. Expand Gryllus CO1 and add Heliconius ND1; 156 active references pass exact-source audit against 121 pinned records. Preserve proxy taxa, partial/predicted scope, and public feature receipts. See [replacement findings](PUBLIC_REFERENCE_REPLACEMENTS.md).
  - [ ] Resolve two plant trnV-atpE assay-label/length conflicts under [#156](https://github.com/caseywdunn/sharkmer/issues/156) and the missing independently annotated Agalma ITS source under #129. Do not reintroduce assembled products or misannotated sources to fill these gaps; primers remain unchanged pending separate review.
  - [ ] Review gene annotations separately from public sequence origin; add independent same-sample truth and read-backed assessment of divergent/repeat regions. Cross-individual differences alone are not wrong products. Register held-out data before assembly tuning; provenance cleanup does not close #129/#153 or authorize release.
- [x] [#130](https://github.com/caseywdunn/sharkmer/issues/130) — Read every member of concatenated gzip FASTQ inputs. Terra implementation, Sol review; eight regressions cover ingestion, paired reads, limits, replay, and corrupt-member cache publication.
- [x] [#131](https://github.com/caseywdunn/sharkmer/issues/131) — Continue coverage thresholds until a valid amplicon is recovered. Sol implementation, Terra review; full per-threshold evaluation, authoritative length checks, explicit search limits, and an absolute primer-count floor preserve shared primer backbones without overriding the configured coverage ratio. Independent CLI mixture probe recovers the exact 180 bp target; existing high-copy oracle is unchanged.
- [x] [#132](https://github.com/caseywdunn/sharkmer/issues/132) — Prevent confident amplicon output with collapsed homopolymer lengths. Sol implementation, Terra review; path-local repeat markers survive pruning, iterative SCC detection is stack-safe, and ambiguous products are withheld with explicit reasons. Independent homopolymer/tandem CLI probes pass; short-repeat and existing high-copy controls remain unchanged. Intentional removal of shortened products is documented in README.
- [x] [#133](https://github.com/caseywdunn/sharkmer/issues/133) — Correct read selection, strand handling, and gap continuity in threading. Sol implementation, Terra review; graph-local interior evidence, positioned directional mapping, conservative strand ties, and support counted once per read/paired fragment replace primer-only selection. This does not deduplicate distinct FASTQ records into independent molecules. Twelve targeted regressions and the exact high-copy threading oracle pass; background reads do not allocate paired-evidence entries. Replay remains opt-in and all-read RAM retention is deferred to v4.0.
- [x] [#134](https://github.com/caseywdunn/sharkmer/issues/134) — Publish current-run amplicons and stats without stale FASTA results. Sol Rust implementation, root validator integration, Terra review; sample lifetime leases, staged no-clobber publication, matching run identities, and checksum receipts make completion explicit. Changed panels, failed reruns, legacy/foreign/symlink collisions, partial publication, and a real SIGKILL/restart probe pass. Validators reject incomplete or mismatched generations; histograms/DOT remain outside the transaction.
- [x] [#135](https://github.com/caseywdunn/sharkmer/issues/135) — Bound primer ambiguity and mismatch expansion before allocation. Terra implementation, Sol review; checked distinct-variant, generation-work, and simultaneous-allocation bounds run before input/ENA resolution. Effective trim validation, exact-estimator regressions, all built-in panels, and a 128 MiB fail-fast CLI probe pass; limits are documented in README.
- [x] [#136](https://github.com/caseywdunn/sharkmer/issues/136) — Fix integer median rounding for even-sized k-mer count sets. Overflow-safe floor average, boundary and exhaustive small-pair regressions, caller/documentation audit; Terra review approved.
- [x] [#137](https://github.com/caseywdunn/sharkmer/issues/137) — Make cache publication concurrent-safe and clearing ownership-aware. Terra implementation, Sol review; cache-wide lifetime leases protect replay and serialize cooperating clients. Verified replacements preserve prior data on normal failures; clear preserves foreign, modified, orphaned, and symlink entries with warnings. Twenty-nine focused tests and an independent CLI alias/lease/ownership probe pass. Global serialization and conservative recovery limits are documented.
- [x] [#138](https://github.com/caseywdunn/sharkmer/issues/138) — Align sPCR documentation and diagnostics with current behavior. Terra implementation, Sol review; documented first-valid-threshold search, physical gaps, unresolved phase, per-gene node budgets, legacy record-count fields, allocator versus RSS, and panel compatibility semantics. Fixed missing human benchmark taxon metadata with fail-closed guards. Thirty-nine Python regressions, all nine built-ins plus reference schema validation, and documented CLI dry-runs pass. Legacy issues #121–126 were audited and remain open for their unimplemented acceptance criteria.
- [ ] [#153](https://github.com/caseywdunn/sharkmer/issues/153) — Review direct v3.1.0-to-v3.2 benchmark regressions before release. Evidence is recorded: 114 successful CLI invocations, aggregate-count parity, +0.70% primary median-sum runtime, no meaningful RAM reduction, and 179 -> 71 primary products. Lost products include a Gryllus ITS_2 sequence exactly matching its historical bootstrap reference, not independent accession truth; do not classify all withholding as an accuracy improvement.
  - [ ] High-copy recovery remains under review after #154/#155: the fresh scoped comparison has 71 -> 64 high-copy products. The Gryllus ITS_2 embedded-reference match is now known to use a bootstrap amplicon, not independent full-length accession truth. Audit provenance under #129 and investigate the missing products before approving release; deferred metagenomic/nuclear losses are not blockers. Record the small human runtime regression separately. Stop for user review before broadening assembly policy or releasing.
  - [x] Complete the preregistered k=19/23/27/31 comparison: all 72 discovery invocations pass count/stability checks and independent Astra review. No longer k restores any of the seven exact losses; none qualifies, so the conditional 42 confirmation invocations are not run. Higher k adds reference-confirmed CO2_1/28S products and lowers runtime but loses two other k19 dev sequences, including other-taxon-supported ND4. k27 between-version parity is shared loss, not rescue. Protocol and findings: [longer-k sweep](BENCHMARK_high_copy_followups.md#longer-k-results). Keep k19 default and #153 open; user review precedes policy changes or release.
  - [x] Isolate the Gryllus ITS_2 loss with identical real input immediately before/after #132 and current production code: the 978 bp embedded sequence is recovered only before #132, with all five count fields unchanged. Independent Terra and Astra audits confirm causal removal, but public-record verification finds AK281180.1 is only 256 bp and the panel entry is a bootstrap amplicon. Exact panel agreement is circular as full-length biological confirmation. See [the accessioned-reference assessment](BENCHMARK_reference_gates.md); preserve known collapsed-repeat controls and separate regression oracles from independent sequence truth.
  - [x] Test 23 hydrozoa generating templates at k19/k31 before/after #132/current, with 22 independently corroborated as exact deposited regions. All reconstruct exactly in every version; the remaining EU293971 template has a one-base panel discrepancy. The Gryllus bootstrap template also reconstructs from clean reads, while a known A40 collapsed product is withheld correctly. All 150 synthetic invocations pass count/execution checks. This does not demonstrate over-conservative rejection of known-correct templates or prove the missing real-data products wrong; the native-endpoint cohort is not production hydrozoa-panel recovery.
  - [x] Reclassify 60 immutable saved invocations against provenance-verified public regions after the full reference audit: both versions retain the same 30 gene-supported product identities. The seven known high-copy losses remain unresolved with limited references; even retained CO1 fails the query-coverage gate against a short 304 bp region. Four fresh k19/k31 before/after smoke runs preserve all counts and sequences. Independent Astra artifact review approved; no new timing or biological-truth claim, and no repeat-gate changes. See [the variation-aware assessment](REFERENCE_PROVENANCE.md#reclassification-and-unchanged-assembly-checks).
  - [x] Repeat saved-output assessment after independent public replacements and scoped gene-index handling: the same 51 gene-supported identities in each version (38 expected-taxon, 13 other-taxon), including retained Gryllus CO1. Seven high-copy losses remain unresolved, with partial CO1/ND1 support; no evidence that all losses were wrong sequences. This is better evaluation coverage, not new assembly recovery or timing. See [the expanded-reference assessment](PUBLIC_REFERENCE_REPLACEMENTS.md#reassessment-of-saved-products).
  - [x] Complete the [preregistered read-backed audit](READ_BACKED_AUDIT_PROTOCOL.md): six unchanged-assay replication commands pass with frozen sources and exact consumed R1 prefixes. Retained Gryllus CO1 has 27 exact / 28 sensitivity bridge records over 15 footprints; the lost 373 bp structure has zero. ITS/ND1 have substantial marginal read evidence but unlocalized graph intervals; Drosophila losses have no qualifying diagnostic windows and unresolved longer structural intervals. These are not seven proven incorrect products or full-haplotype truth. See [the read-backed findings](READ_BACKED_AUDIT_RESULTS.md); no assembly gate or performance claim changes.
  - [ ] User review of the seven-loss disposition remains required. Complete SCC-interval/alternative analysis and read-supported reconstruction remain under #148, following the bounded diagnostic slice below and quality-aware replay/batching prerequisites #145/#116. Do not silently turn this audit into a gate exception; any policy change needs positive evidence for the actual restrictions removed, regression controls, and a fresh high-copy comparison. #129, held-out/all-panel/dependency gates, and release authorization remain open.
  - [x] Implement the user-approved diagnostic-only slice of #148: hidden opt-in bounded retention of actual withheld sequences and marker positions, without changing gates or FASTA recovery. Sol implementation and Astra review pass; all [twelve preregistered compatibility/localization runs](WITHHELD_PATH_DIAGNOSTICS_RESULTS.md) preserve products, counts, and existing gene/threshold diagnostics. Five of seven historical losses are exactly localized; two Drosophila 12S identities remain unobserved under retention/search bounds. Gryllus ITS is a priority for complete SCC-interval/read-evidence analysis, not an authorized gate exception. This does not implement read-backed reconstruction or close #148/#153.
  - [x] Complete the user-approved [Gryllus ITS SCC/read audit](ITS_SCC_AUDIT_PROTOCOL.md): scratch pre/post graphs preserve production outputs and retain both relevant cyclic components. Both historical local traversals and both read-length extra-cycle alternatives have zero exact/one-substitution Q20 bridges; an independent exact recount also finds zero before quality filtering. Retained CO1 reproduces 27/28 records. [Findings](ITS_SCC_AUDIT_RESULTS.md) do not establish incorrectness or justify relaxing gates. A separately frozen variation-aware read-recruitment diagnostic is the next investigation, not an admission exception; #148/#153/#129 and release review remain open.
  - [x] Complete the [frozen variation-aware recruitment diagnostic](ITS_READ_RECRUITMENT_PROTOCOL.md) on an isolated branch from `956e771`: 27/28 ITS1/ITS2 recruited records, one low-quality ITS1 extra-cycle alignment, and two Q20 ITS2 extra-cycle alignments whose complete read sequences/placements are identical. The latter are one observed sequence pattern with tied indel tracebacks; one Q20 span also excludes a low-quality endpoint through a terminal deletion. Both historical classes remain unobserved. Original CO1 controls reproduce 27/28 retained and zero lost records. [Findings](ITS_READ_RECRUITMENT_RESULTS.md) do not justify gate relaxation or full-product claims. Standalone diagnostic only; actual production threading/reconstruction remains a separate proposal and comparison, and #148/#153/#129 stay open.
  - [x] Implement and evaluate the [ordered read-history prototype](READ_HISTORY_EXPERIMENT.md) on the isolated branch: 25 tests, 861 independent checks, 20 wrapper tests, and both frozen million-read graph scans pass. Ordered histories distinguish synthetic repeat/phase mixtures with identical aggregate edge/local-pair counts. Actual pre/post graphs retain 773/284 graph-matching records; all four classes remain represented with zero literal/Q20 witnesses. The three known spanning records have identical histories at both stages, exposing exact-walk gaps already present before pruning. [Findings](READ_HISTORY_RESULTS.md) describe representation and sensitivity, not biological absence or admission evidence. Complete independent prefix/ledger review is archived; production code and the 71-to-64 release comparison remain unchanged.
  - [x] Implement and evaluate the user-requested [#157](https://github.com/caseywdunn/sharkmer/issues/157) opt-in output on `experiment/uncertain-products`: bounded actual graph-path hypotheses appear in separate labelled FASTA and stats, preserving standard admission and threshold stopping. All nine [preregistered](UNCERTAIN_PRODUCTS.md) baseline/off/on runs complete with identical standard sequences/counts: 11 Gryllus, 9 Drosophila and 6 Heliconius products. Uncertain counts are 17/4/13. Five of seven exact historical hypotheses are re-emitted (Gryllus CO1_1 373 bp and ITS_2 978 bp; Heliconius ND1 263 bp; Drosophila 12S 475 bp and 16S_2 590 bp); Drosophila 12S 487/499 bp remain unobserved under search/retention bounds. Both hash backends pass 246 unit and 26 integration tests, formatting and Clippy; Python runs 184 tests with one existing skip, and all 156 references verify across ten panels. [Results](UNCERTAIN_PRODUCTS_RESULTS.md) concern separate sequence availability, not validated repeat structure or restored standard recovery.
  - [ ] Obtain the user's #157 integration decision using the independently reviewed results and evidence bundle. Keep `dev` fixed at `956e771` and the experiment unmerged; emitting five historical hypotheses does not close #148/#153/#129 or authorize release.
  - [ ] Deferred while the uncertainty-output integration decision remains open: integrate bounded quality-preserving replay and positioned histories under #145/#116 behind an experimental opt-in path, with feature-off compatibility against `956e771`. Separately specify ambiguity-preserving variant-aware mapping before reconstructing observed alternatives; do not repair missing edges or relax repeat gates from marginal coverage. Any admission change still needs cause-specific positive evidence, repeat/mixture controls, and fresh released-v3.1.0 high-copy comparison.
- [x] [#154](https://github.com/caseywdunn/sharkmer/issues/154) — Keep repeat-rejected candidates from exhausting the valid-product path budget, with bounded search and a clean-route regression.
  - [x] Sol implementation and independent Astra review: reject complete repeat-tainted candidates before quota accounting; 32 higher-ranked rejected routes no longer hide a clean route. Both hash backends pass 216 unit and 22 integration tests plus Clippy; existing repeat controls remain conservative.
  - [x] Six affected insect invocations preserve all 26 sequences/classifications and aggregate counts versus pre-fix development code; runtime sum 202.61 -> 202.56 seconds with no meaningful RSS change. Single-pair measurements are descriptive, not proof of statistical equivalence. The Gryllus ITS_2 release-baseline loss remains open under #155/#153; see [follow-up evidence](BENCHMARK_high_copy_followups.md).
- [x] [#155](https://github.com/caseywdunn/sharkmer/issues/155) — Audit repeat-marker scope and preserve cause, threshold, and search-exhaustion diagnostics without restoring unsupported repeat-copy claims.
  - [x] Sol implementation, independent Astra review: retained high-coverage collisions mark traversed edges rather than both endpoints; omitted self-loops and pre-pruning cyclic SCC nodes remain conservative. Bounded per-threshold diagnostics survive successful/failed searches. Both backends pass 221 unit and 22 integration tests, formatting, and Clippy; 39 Python regressions also pass.
  - [x] All 13 independent control invocations and 60 fresh released-v3.1/candidate comparisons complete. Candidate sequences remain unchanged from pre-fix dev: high-copy products 71 -> 64 versus release, including the Gryllus ITS_2 bootstrap-reference match (not independent truth). Runtime median-sum is 1.81% lower; human is 0.05 s slower and RSS is effectively unchanged. Independent Astra evidence review agrees the high-copy release gate remains open under #153; see [the full scoped report](BENCHMARK_high_copy_followups.md).

### 2026-09-11 release-scope clarification

The current release decision must protect observed recovery of abundant
organelle and rRNA targets on the frozen calibration inputs, including the
historically reference-matched Gryllus ITS_2 loss (the embedded reference is
now known to be a bootstrap product, not independent truth), and must not regress measured runtime
or RAM under the scoped comparison protocol. Panel `copy_number` and
`compartment` annotations describe targets; they do not prove abundance or
read support. Continue to withhold unsupported repeat-copy claims
conservatively rather than treating every withheld product as an improvement.
Metagenomic diversity and single-copy nuclear recovery regressions are deferred
to v4.1/v4.2 and are not additional v3.2 release blockers. This does not waive
the independent held-out registration or all-panel biological-validation gates.

The development package is `3.2.0-dev`, not a published release. Stop before
merging to `master`, tagging, or publishing. Independent held-out registration
under #129 remains open; calibration results do not close that gate.

Earlier implementation checkpoint: `03c0fc6`. Both hash backends pass 213 unit and 22
integration tests, with 39 Python regressions. All 13 historical samples at a
one-million-record cap preserve read/kmer totals and all 71 product hashes
against the repaired warm baseline; both pinned fixture oracles pass. This is
not a comparison against released v3.1.0 or held-out biological validation.
The subsequent [direct release comparison](BENCHMARK_v3.2_vs_v3.1.md) covers
all configured 1M/2M/4M/8M cells with clean release/candidate builds and finds
substantial losses not visible against that repaired intermediate baseline.
Resolve or explicitly disposition #153–155 before release; all-nine-panel
biological validation and independent held-out registration still remain open.

Start with the benchmark/provenance issue and independent correctness fixes.
For homopolymers, v3.2 can conservatively withhold a falsely complete product;
full read-supported repeat reconstruction is a v4.1 task.

### Review evidence to preserve

The existing suite passed: 145 unit tests and 22 integration tests. Additional
temporary probes found gaps that must become durable regression fixtures:

| Case | Observed at review | Required behavior |
| --- | --- | --- |
| Two concatenated gzip members, one record each | One read counted, exit success | Both records counted |
| Shared primer ends; 400 bp at count 100 plus 180 bp at count 4; allowed 170–210 bp | No valid product; rare target succeeds alone | Recover the supported in-range target |
| 160 bp error-free target containing a long A run, k=19 | 137 bp product reported | Supported length or explicit uncertainty |
| Oriented primer seed TTTGA, k=5 | Its matching read rejected by canonical filter | Orientation-independent membership |
| AACGATTCCG versus reverse complement CGGAATCGTT | Different phasing evidence | Equivalent oriented graph evidence |
| AACGANACGAT on adjacent AACGA/ACGAT graph edges | False link across N | No continuity across the gap |
| Successful run followed by failed rerun at same output prefix | Old FASTA remains | Current-run manifest cannot report stale success |
| Counts [3,5] | Integer median 3 | Median 4 |

The fixture-only counting measurement was 100,000 reads, 10,698,337 distinct
k-mers, 1.4 s ingestion, 1.1 s redundant consolidation, 2.52 s total, and
562,688 KiB peak RSS on the review environment. Treat this as motivation,
not a portable performance target or a measured improvement.

### Release gate

- Direct release-baseline output/performance regressions have been reviewed;
  repeat/path-budget follow-ups #154–155 are resolved or explicitly dispositioned
  under #153. A reference match is not repeat-copy truth, but lost supported
  products cannot be dismissed without investigation.
- All reproduced correctness failures have regression coverage.
- Validate all products, including negative controls and whole-product
  alignment coverage; wrong-gene/short-fragment matches cannot validate a
  product.
- Existing high-copy recovery remains correct; intentional removal of
  previously incorrect products is documented rather than scored as a loss
  to undo.
- CLI examples, stats, failure reasons, cache ownership, and rerun semantics
  agree with the executable.

## v4.0 — Scalable exact counting and replay

- [ ] [#139](https://github.com/caseywdunn/sharkmer/issues/139) — Define exact count-store, replay-source, and assembly evidence interfaces.
- [ ] [#140](https://github.com/caseywdunn/sharkmer/issues/140) — Remove redundant table consolidation and per-read allocations from sPCR counting.
- [ ] [#141](https://github.com/caseywdunn/sharkmer/issues/141) — Parallelize ingestion with bounded queues and measured shard ownership.
- [ ] [#142](https://github.com/caseywdunn/sharkmer/issues/142) — Benchmark packed k-mer tables while retaining exact abundance.
- [ ] [#143](https://github.com/caseywdunn/sharkmer/issues/143) — Count non-replayable datasets exactly within a memory budget.
- [ ] [#144](https://github.com/caseywdunn/sharkmer/issues/144) — Provide exact bounded-memory random lookup over external k-mer counts.
- [ ] [#145](https://github.com/caseywdunn/sharkmer/issues/145) — Add bounded replay/spooling with consistent paired input semantics.

Sequence: contracts → simple counter → bounded parallelism → packed-table
evaluation. External counting and replay can progress independently after their
declared prerequisites. Final disk lookup depends on external counts.
The packed-table experiment is not a dependency of the first external backend.

Compare existing ahash/Fx configurations, owner-managed shards, bounded local
aggregation, and a specialized shared table on representative workloads.
Do not allocate a complete per-thread map without measuring duplication.
Jellyfish is a relevant exact-counting comparator; KMC is a relevant external
counter. Their existence does not prescribe Sharkmer's internal design.

Start external storage with the simplest measured design. Minimizer/signature
partitioning and super-k-mers are candidates for reducing temporary I/O;
partition skew, exact global counts, and final random access remain required.

### Release gate

- Exact count and product agreement across supported threads and backends.
- Standard `--chunks 0` has no incremental counting overhead; legacy
  histogram/combined-PCR compatibility remains tested separately.
- Record stage throughput, table bytes per distinct k-mer, resize/finalization
  peaks, RSS, disk use, and lookup latency. Freeze quantitative performance
  gates against the repaired baseline before choosing production designs.
- Demonstrate a one-shot dataset whose global count store exceeds the chosen
  RAM budget completing counting **and sPCR**, using disk-backed lookup.
- Verify limits, paired selection, malformed gzip, interruption, and disk-full
  behavior without losing previously accepted counts or exposing partial files.
- Standard sPCR accuracy does not regress while counting implementation changes.

## v4.1 — Read evidence and low-coverage nuclear recovery

- [ ] [#146](https://github.com/caseywdunn/sharkmer/issues/146) — Batch primer discovery without combinatorial variant enumeration.
- [ ] [#147](https://github.com/caseywdunn/sharkmer/issues/147) — Build length-bounded target graphs and compact nonbranching paths.
- [ ] [#148](https://github.com/caseywdunn/sharkmer/issues/148) — Use read-spanning branch histories to resolve repeats and constrain paths.
- [ ] [#149](https://github.com/caseywdunn/sharkmer/issues/149) — Add evidence-based low-coverage nuclear recovery and partial outcomes.
- [ ] [#116](https://github.com/caseywdunn/sharkmer/issues/116) — Stream reads through bounded batches of target graphs; replace the
  old per-gene full-input scan proposal and all-read RAM vector.
- [ ] [#101](https://github.com/caseywdunn/sharkmer/issues/101) — Apply mate orientation and insert-size constraints to paths.
- [ ] [#99](https://github.com/caseywdunn/sharkmer/issues/99) — Use conservative evidence-aware pruning; lack of evidence is not
  automatically evidence of an erroneous edge.
- [ ] [#106](https://github.com/caseywdunn/sharkmer/issues/106) — Add explicit primer alternatives with current CLI/schema semantics
  and selection that does not erase minority alternatives.
- [ ] [#127](https://github.com/caseywdunn/sharkmer/issues/127) — Expose suggested-k guidance without silently switching global k.
- [ ] [#114](https://github.com/caseywdunn/sharkmer/issues/114) — Re-profile the proposed scoring optimization; implement only if
  it remains material after graph changes.

Dependency order: seeding/target graphs and replay → [#116](https://github.com/caseywdunn/sharkmer/issues/116) and [#101](https://github.com/caseywdunn/sharkmer/issues/101) →
linked-path evidence → low-coverage policy and [#99](https://github.com/caseywdunn/sharkmer/issues/99). [#106](https://github.com/caseywdunn/sharkmer/issues/106) and [#127](https://github.com/caseywdunn/sharkmer/issues/127) support
primer usability; [#114](https://github.com/caseywdunn/sharkmer/issues/114) is an optional measured optimization.

Maintain an explicit standard policy and add an opt-in low-coverage policy.
Use per-target/per-haplotype coverage, realistic intron spans, and
paralog/orthology evaluation. Admit singletons only under a specified evidence
model, not by globally relaxing all pruning. Return partial assemblies where
useful, with an explicit distinction from complete amplicons.

Evaluate local multi-k assembly on recruited/replayed reads after single-k
behavior is validated. Smaller k can restore overlap and larger k can resolve
some repeats; neither establishes unobserved bases or unsupported phase.
Do not make this experiment a requirement for shipping proven v4.1 gains.

### Release gate

- Interior reads and both strands contribute equivalent valid evidence.
- Evidence buffering is independent of total input length, with graph batch
  size and retained links bounded or spilled explicitly.
- Repeat lengths require read/fragment evidence; insufficient linkage yields
  ambiguity rather than a fabricated complete product.
- Publish held-out callable recall and sequence precision across nuclear depth,
  heterozygosity, intron length, and paralog similarity.
- Demonstrate that singleton rescue improves recall without an unreviewed
  increase in false products; physical gaps remain partial/unknown.
- Standard high-copy behavior remains a protected benchmark class.

## v4.2 — Metagenomic diversity

- [ ] [#150](https://github.com/caseywdunn/sharkmer/issues/150) — Preserve rare templates through sPCR seed, threshold, and path search.
- [ ] [#151](https://github.com/caseywdunn/sharkmer/issues/151) — Report supported haplotypes, uncertainty, and defensible target abundance.
- [ ] [#68](https://github.com/caseywdunn/sharkmer/issues/68) — Document downstream classifier/workflow integration using current
  flags and explicit limitations on marker resolution and organism abundance.

Add an explicit diversity policy. Explore plausible components and coverage
levels after a dominant product is found. Preserve exact distinct sequences by
default; optional similarity clustering is separate from assembly.

Use branch histories and mate constraints to preserve supported linkage.
If two distant variants have no distinguishing read/fragment evidence, report
phase blocks or ambiguity instead of enumerating possible combinations as
observed haplotypes. Estimate abundance from discriminating sequence and
compatible reads; do not equate shared marker coverage with organism counts.

### Release gate

- Recover both supported products in the 100:4 mixture with common primer ends.
- Evaluate 1 bp differences, indels, multiple similar templates, >40 seed
  candidates, and >20 genuine products under configured limits.
- Publish precision, rare-template recall, chimera rate, phasing accuracy, and
  abundance error stratified by target coverage and divergence.
- Every product carries evidence/completeness information; truncation is visible.
- No confident organism count or full haplotype is claimed when the marker or
  linkage is uninformative.

## Benchmark matrix and acceptance policy

Keep calibration and held-out evaluation separate. Freeze fixture identities,
truth, and target-specific tolerances before parameter sweeps.

- Existing rRNA/organelle successes, repetitive/AT-rich targets, and known
  failures; compare whole products rather than FASTA counts.
- Nuclear per-target/per-haplotype depths such as 1, 2, 3, 5, 10, 20, and 40x,
  including heterozygosity, introns, paralogs, and absent targets.
- Known metagenomic mixtures spanning abundance ratios and sequence divergence;
  vary absolute minority depth separately from abundance ratio.
- Error-free controls, realistic quality/error profiles, primer mismatches,
  physical gaps, and deliberately unresolvable repeat/phase cases.
- Plain/gzip/multi-member gzip, paired/interleaved/single-end, local/replayed/
  one-shot inputs; multiple k values and 1/2/4/8 threads where supported.
- Small exact-oracle tests, the included fixture, approximately 1M-read common
  workloads, and deep datasets that exceed the in-memory budget.

Record decompression/parsing, emission, table updates, merge/finalization,
seed discovery, graph building, threading, search, total wall time, peak RSS,
allocator heap separately, disk usage, and count-store lookup performance.
Benchmark without graph dumps for ordinary runtime; measure diagnostics
separately. Do not promise a speedup before the relevant measurements exist.

Required correctness gates are absolute. Biological improvements need reviewed
precision/recall thresholds on callable truth sets; sequencing depth alone
cannot guarantee complete recovery. Performance changes require reproducible
end-to-end improvement, not just a faster isolated hash benchmark.

## Implementation handoff

- Begin with v3.2 evaluation/correctness issues. Do not launch a whole rewrite
  before regression fixtures and interface decisions exist.
- An issue is complete only when its acceptance criteria, focused tests,
  affected documentation, and release benchmark evidence are satisfied.
- Follow [CONTRIBUTING.md](../CONTRIBUTING.md) for implementation branches,
  commits, quality gates, and release process.
- Update this plan and the associated issue in the same implementation change.
  Do not infer completion from a similarly named historical closed issue.
- Existing [#121](https://github.com/caseywdunn/sharkmer/issues/121)–[#127](https://github.com/caseywdunn/sharkmer/issues/127) and [#76](https://github.com/caseywdunn/sharkmer/issues/76) include stale or overlapping status; audit them
  against code before closing or duplicating panel/cleanup work.
- This program does not remove incremental counting or implement v5 targeting.

## Design references

These are comparison/design references, not dependencies on their software.

- [Jellyfish: exact parallel counting with a specialized shared table](https://pmc.ncbi.nlm.nih.gov/articles/PMC3051319/).
- [KMC 3: counting and manipulating k-mer statistics](https://academic.oup.com/bioinformatics/article/33/17/2759/3796399).
- [Linked de Bruijn graphs: retaining read-scale connectivity](https://pubmed.ncbi.nlm.nih.gov/29554215/).
- [Bifrost: compacted graph construction and indexing](https://pmc.ncbi.nlm.nih.gov/articles/PMC7499882/).
- [metaSPAdes: local coverage and metagenomic assembly challenges](https://pmc.ncbi.nlm.nih.gov/articles/PMC5411777/).
