#!/usr/bin/env python3
"""Plan or publish the final #157 evidence archive; no biological scans.

Run `plan` first. Only run `create` after final result/documentation review.
The output directory must be new and outside every selected evidence tree.
"""

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = ROOT / "tmp/uncertain-products-20260927"
BUNDLE = ROOT / "benchmarks/benchmark_results/v3.2-uncertain-products-20260927"
GENERATED_PANEL_DIRS = {"validation_runs", "validation_results", "validation_reports"}
EXCLUDED_OUTPUT_NAMES = {"evidence.tar.gz", "ARCHIVE_CONTENTS.json", "ARCHIVE_RECEIPT.json", "ARCHIVE_PLAN.json"}
DOCS = ["README.md", "CHANGELOG.md", "dev_docs/UNCERTAIN_PRODUCTS.md", "dev_docs/HANDOFF.md", "dev_docs/PLAN.md", "dev_docs/REVIEW_v3.2.md"]


def fingerprint(path):
    path = Path(path).absolute()
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f"Not a regular file: {path}")
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    digest = hashlib.sha256()
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as stream:
        if identity(os.fstat(stream.fileno())) != identity(before):
            raise ValueError(f"Changed while opening: {path}")
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
        if identity(os.fstat(stream.fileno())) != identity(before):
            raise ValueError(f"Changed while hashing: {path}")
    if identity(path.lstat()) != identity(before):
        raise ValueError(f"Changed after hashing: {path}")
    return {"path": str(path), "size_bytes": before.st_size, "sha256": digest.hexdigest()}


def load(path):
    return json.loads(Path(path).read_text())


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def workspace_path(path):
    """Resolve existing evidence without accepting symlinked ancestors."""
    absolute = Path(os.path.abspath(path))
    resolved = absolute.resolve(strict=True)
    if absolute != resolved:
        raise ValueError(f"Symlinked evidence path refused: {absolute}")
    if not resolved.is_relative_to(ROOT):
        raise ValueError(f"Evidence outside workspace: {resolved}")
    return resolved


def validate_output(plan, output):
    output = Path(os.path.abspath(output))
    if output.resolve(strict=False) != output:
        raise ValueError(f"Symlinked output path refused: {output}")
    roots = set(plan.get("evidence_roots", []))
    roots.update(row["path"] for row in plan["members"].values())
    for value in roots:
        root = Path(value)
        if output.is_relative_to(root) or root.is_relative_to(output):
            raise ValueError(f"Output overlaps selected evidence root: {root}")
    return output


def verify_results_review(review, mandatory):
    rows = review.get("reviewed_artifacts")
    if review.get("status") != "pass" or not isinstance(rows, dict) or not rows:
        raise ValueError("Final results review requires pass and nonempty reviewed_artifacts")
    verified = {}
    for row in rows.values():
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            raise ValueError("Malformed reviewed artifact identity")
        path = workspace_path(row["path"])
        if str(path) in verified:
            raise ValueError(f"Duplicate reviewed artifact identity: {path}")
        actual = fingerprint(path)
        if actual != row:
            raise ValueError(f"Final results review artifact changed: {path}")
        verified[str(path)] = actual
    missing = {str(workspace_path(path)) for path in mandatory} - set(verified)
    if missing:
        raise ValueError(f"Final results review omits selected artifacts: {sorted(missing)}")
    return verified


def walk(base):
    for directory, subdirs, names in os.walk(base, followlinks=False):
        for name in subdirs:
            if (Path(directory) / name).is_symlink():
                raise ValueError(f"Symlink directory refused: {Path(directory) / name}")
        subdirs[:] = sorted(name for name in subdirs if name not in {"__pycache__", "target"} and not (Path(directory).name == "panels" and name in GENERATED_PANEL_DIRS))
        for name in sorted(names):
            if name.endswith(".pyc") or name in EXCLUDED_OUTPUT_NAMES:
                continue
            yield Path(directory) / name


def prepare(args):
    selected = {}
    by_original = {}
    omitted = []
    evidence_roots = set()
    for name in ("baseline_build", "candidate_build", "checks", "final_review", "comparison_dir"):
        setattr(args, name, workspace_path(getattr(args, name)))
    args.extra_doc = [workspace_path(path) for path in args.extra_doc]
    args.attempt_dir = [workspace_path(path) for path in args.attempt_dir]

    def add(path, member):
        path = workspace_path(path)
        if Path(member).is_absolute() or ".." in Path(member).parts:
            raise ValueError(f"Unsafe member: {member}")
        if str(path) in by_original:
            return
        if member in selected:
            raise ValueError(f"Duplicate member: {member}")
        selected[member] = fingerprint(path)
        by_original[str(path)] = member

    def add_tree(base, prefix):
        base = workspace_path(base)
        if not base.is_dir() or base.is_symlink():
            raise ValueError(f"Missing or symlink evidence directory: {base}")
        evidence_roots.add(str(base))
        for path in walk(base):
            add(path, f"{prefix}/{path.relative_to(base).as_posix()}")

    add_tree(BUNDLE, "bundle")
    for path in sorted(SCRATCH.iterdir()):
        if path.is_dir() and (path.name.startswith("checks-") or "probe" in path.name or path.name == "slurm"):
            add_tree(path, f"attempts/{path.name}")
    for build in sorted((SCRATCH / "builds").iterdir()):
        if not build.is_dir() or build.is_symlink():
            raise ValueError(f"Unexpected build entry: {build}")
        evidence_roots.add(str(workspace_path(build)))
        # Retain all failed/successful attempt receipts, not their trees/caches.
        for path in sorted(build.iterdir()):
            if path.is_file() and path.name != "sharkmer" and path.name != "source.tar":
                add(path, f"attempts/builds/{build.name}/{path.name}")

    candidate_dir = args.candidate_build.absolute().parent
    baseline_dir = args.baseline_build.absolute().parent
    candidate = load(args.candidate_build)
    baseline = load(args.baseline_build)
    candidate_snapshot = load(candidate_dir / "snapshot.json")
    baseline_snapshot = load(baseline_dir / "snapshot.json")
    checks = load(args.checks)
    review = load(args.final_review)
    execution = load(args.comparison_dir / "runs/execution.json")
    assessment = load(args.comparison_dir / "runs/assessment.json")
    orchestration = load(args.comparison_dir / "orchestration.json")
    for label, value, expected in [
        ("candidate build", candidate, "complete"),
        ("baseline build", baseline, "complete"),
        ("compiled checks", checks, "pass"),
        ("final review", review, "pass"),
        ("comparison execution", execution, "complete"),
        ("comparison assessment", assessment, "pass"),
        ("comparison orchestration", orchestration, "complete"),
    ]:
        if value.get("status") != expected:
            raise ValueError(f"{label} is not {expected}")
    if candidate_snapshot.get("role") != "candidate" or baseline_snapshot.get("role") != "baseline":
        raise ValueError("Selected build roles differ")
    if candidate.get("source_before") != candidate.get("source_after") or candidate.get("source_before") != candidate_snapshot["files"]:
        raise ValueError("Candidate build source bookends differ")
    checked_sources = checks.get("sources_before")
    if not isinstance(checked_sources, dict) or not checked_sources or checked_sources != checks.get("sources_after"):
        raise ValueError("Compiled-check source bookends are missing or differ")
    for original, row in checked_sources.items():
        path = workspace_path(row["path"])
        if original != str(path) or fingerprint(path) != row:
            raise ValueError(f"Checked source changed or identity key differs: {path}")

    mandatory = {args.checks, args.baseline_build, args.candidate_build, baseline_dir / "snapshot.json", candidate_dir / "snapshot.json", BUNDLE / "README.md", *(ROOT / name for name in DOCS), *args.extra_doc}
    mandatory.update(Path(row["path"]) for row in checked_sources.values())
    mandatory.update(args.comparison_dir / name for name in ("freeze.json", "runs/execution.json", "runs/assessment.json", "orchestration.json"))
    jobs = execution.get("jobs", [])
    if len(jobs) != 9 or len({job.get("id") for job in jobs}) != 9:
        raise ValueError("Final comparison must have nine unique job receipts")
    for job in jobs:
        if job.get("status") != "complete" or fingerprint(workspace_path(job["receipt"]["path"])) != job["receipt"]:
            raise ValueError("Final comparison job receipt is incomplete or changed")
        receipt_path = workspace_path(job["receipt"]["path"])
        mandatory.add(receipt_path)
        receipt = load(receipt_path)
        if receipt.get("status") != "complete":
            raise ValueError("Final comparison job did not complete")
        for row in receipt["outputs"]["files"].values():
            path = workspace_path(row["path"])
            if fingerprint(path) != row:
                raise ValueError(f"Final comparison output changed: {path}")
            mandatory.add(path)
    reviewed = verify_results_review(review, mandatory)
    # The compiled snapshot omits Python runtime/validation modules. Retain
    # every exact source used by the passing checks, including those modules
    # and their local dependencies, rather than retaining only their hashes.
    checked_source_members = {}
    for original, row in sorted(checked_sources.items()):
        path = workspace_path(original)
        add(path, f"checked_source/{path.relative_to(ROOT).as_posix()}")
        member = by_original[original]
        if selected[member] != row:
            raise ValueError(f"Checked source changed while selecting payload: {path}")
        checked_source_members[original] = member
    source = workspace_path(candidate_snapshot["source"])
    actual_source = {path.relative_to(source).as_posix(): fingerprint(path) for path in walk(source)}
    if actual_source != candidate_snapshot["files"]:
        raise ValueError("Candidate source differs from compiled snapshot")
    add_tree(source, "candidate_source")
    if fingerprint(candidate["binary"]["path"]) != candidate["binary"]:
        raise ValueError("Candidate binary differs from build receipt")
    add_tree(args.comparison_dir, "comparison")
    for index, path in enumerate(args.attempt_dir):
        if path == args.comparison_dir:
            raise ValueError("Prior attempt duplicates selected comparison directory")
        add_tree(path, f"prior_comparison_attempts/{index}_{path.name}")
    for role, build_path, directory in (("baseline", args.baseline_build, baseline_dir), ("candidate", args.candidate_build, candidate_dir)):
        evidence_roots.add(str(directory))
        add(build_path, f"selected/{role}/build.json")
        add(directory / "snapshot.json", f"selected/{role}/snapshot.json")
    add(args.checks, "selected/checks.json")
    add(args.final_review, "selected/final_review.json")
    for name in DOCS:
        add(ROOT / name, f"documentation/{name}")
    for path in args.extra_doc:
        add(path, f"documentation/{Path(path).absolute().relative_to(ROOT).as_posix()}")
    add(__file__, "packaging/package_evidence.py")
    for path in [SCRATCH / "test_package_evidence.py", *sorted(SCRATCH.glob("packaging_controls*.json")), *sorted(SCRATCH.glob("packaging_controls*.log"))]:
        if path.is_file():
            add(path, f"packaging/{path.name}")
    activation = SCRATCH / "toolchain/activate.sh"
    if activation.is_file():
        add(activation, "packaging/original_toolchain_activation.sh")

    for label, receipt in [("baseline_binary", baseline.get("binary")), ("candidate_binary", candidate.get("binary")), ("baseline_source_archive", baseline_snapshot["provenance"].get("archive"))]:
        omitted.append({"category": label, "recorded_identity": receipt, "identity_basis": "preserved selected build/snapshot receipt; omitted payload not rehashed by packaging"})
    for role, build in [("baseline", baseline), ("candidate", candidate)]:
        for name in ("cargo", "rustc"):
            omitted.append({"category": f"{role}_{name}_executable", "recorded_identity": build.get(name), "identity_basis": "preserved build receipt"})
    omissions = {
        "external_biological_fastq_prefixes": "Excluded tmp/reads and every external FASTQ input. Prefix hashes, read/base/byte counts, source URLs and restoration receipts remain in bundle/inputs and comparison/freeze.json.",
        "committed_integration_fixture": "Included in candidate_source/tests/fixtures; this small committed fixture is distinct from the external million-read biological prefixes.",
        "baseline_source_tree_and_archive": "Excluded to avoid nested historical benchmark archives. Recreate the exact recorded source archive with git archive --format=tar BASELINE_COMMIT; verify its recorded SHA-256 before extracting.",
        "baseline_binary": "Excluded; rebuild recorded baseline commit with Cargo.lock, compiler/profile/features/command/environment from preserved build receipt. Exact baseline binary hash is retained.",
        "candidate_binary": "Excluded; exact candidate compiled source and committed integration fixture are included. Rebuild using Cargo.lock and the selected build receipt's compiler/profile/features/command/environment. Candidate binary hash is verified when packaging and retained in receipts.",
        "checked_runtime_sources": "All passing-check source payloads are included, including Python validator modules and local dependencies omitted from the compiled Rust snapshot. checked_source_members maps every checked original path to its archived member; files already present in bundle are not duplicated.",
        "compiler_and_dependency_caches": "Excluded toolchain binaries, Cargo registries, target trees and caches. Installation and build receipts retain versions, hashes and commands; network/cache availability is required to reproduce installation/builds.",
        "generated_panel_reports": "Excluded directories validation_runs, validation_results, validation_reports.",
        "older_benchmark_archives": "Excluded complete previous benchmark trees/archives. Only explicitly imported historical evidence under bundle/inputs/historical is included.",
    }
    plan = {
        "schema_version": 1,
        "purpose": "issue_157_uncertain_product_implementation_and_frozen_comparison_evidence",
        "repository_root_original": str(ROOT),
        "baseline_commit": baseline_snapshot["provenance"]["commit"],
        "candidate_repository_head_at_export": candidate_snapshot["provenance"].get("repository_head"),
        "selected_original_paths": {"baseline_build": str(args.baseline_build.absolute()), "candidate_build": str(args.candidate_build.absolute()), "checks": str(args.checks.absolute()), "final_review": str(args.final_review.absolute()), "comparison_dir": str(args.comparison_dir.absolute())},
        "prior_comparison_attempts": [str(path) for path in args.attempt_dir],
        "evidence_roots": sorted(evidence_roots),
        "verified_final_results_review_artifacts": reviewed,
        "required_final_results_review_artifacts": sorted(str(path) for path in mandatory),
        "checked_source_count": len(checked_sources),
        "checked_source_members": checked_source_members,
        "members": dict(sorted(selected.items())),
        "original_path_to_member": dict(sorted(by_original.items())),
        "member_count": len(selected),
        "uncompressed_payload_bytes": sum(row["size_bytes"] for row in selected.values()),
        "omitted_payloads_with_recorded_identities": omitted,
        "omission_and_rebuild_notes": omissions,
        "interpretation": "Includes failed attempts as audit history. Their presence is not evidence of a pass; use the selected successful check/build/comparison receipts and final review. Original absolute paths are provenance, not portable execution instructions.",
    }
    return plan


def write_member(archive, name, raw, mode=0o644):
    info = tarfile.TarInfo(name)
    info.size = len(raw)
    info.mode = mode
    info.mtime = 0
    archive.addfile(info, io.BytesIO(raw))


def create(plan, output):
    output = validate_output(plan, output)
    output.mkdir(parents=True, exist_ok=False)
    plan_raw = encode(plan)
    (output / "ARCHIVE_PLAN.json").write_bytes(plan_raw)
    contents = {name: {"sha256": row["sha256"], "size_bytes": row["size_bytes"], "original_path": row["path"]} for name, row in plan["members"].items()}
    contents["ARCHIVE_PLAN.json"] = {"sha256": hashlib.sha256(plan_raw).hexdigest(), "size_bytes": len(plan_raw), "original_path": None}
    contents_raw = encode(contents)
    (output / "ARCHIVE_CONTENTS.json").write_bytes(contents_raw)
    temporary = output / "evidence.tar.gz.partial"
    with temporary.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
                write_member(archive, "ARCHIVE_PLAN.json", plan_raw)
                write_member(archive, "ARCHIVE_CONTENTS.json", contents_raw)
                for member, expected in plan["members"].items():
                    path = Path(expected["path"])
                    if fingerprint(path) != expected:
                        raise ValueError(f"Evidence changed before archive: {path}")
                    data = path.read_bytes()
                    if len(data) != expected["size_bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
                        raise ValueError(f"Evidence changed during archive: {path}")
                    write_member(archive, member, data)
        raw.flush()
        os.fsync(raw.fileno())
    expected_members = set(contents) | {"ARCHIVE_CONTENTS.json"}
    observed = set()
    with tarfile.open(temporary, "r:gz") as archive:
        for member in archive:
            if not member.isfile() or member.name in observed or member.name not in expected_members:
                raise ValueError(f"Unexpected archive member: {member.name}")
            observed.add(member.name)
            data = archive.extractfile(member).read()
            if member.name == "ARCHIVE_CONTENTS.json":
                if data != contents_raw:
                    raise ValueError("Archived inventory differs")
            elif len(data) != contents[member.name]["size_bytes"] or hashlib.sha256(data).hexdigest() != contents[member.name]["sha256"]:
                raise ValueError(f"Archived member differs: {member.name}")
    if observed != expected_members:
        raise ValueError("Archive member set differs")
    for expected in plan["members"].values():
        if fingerprint(expected["path"]) != expected:
            raise ValueError(f"Evidence changed after archive: {expected['path']}")
    final = output / "evidence.tar.gz"
    os.link(temporary, final)
    temporary.unlink()
    receipt = {"schema_version": 1, "status": "verified", "archive": fingerprint(final), "member_inventory": fingerprint(output / "ARCHIVE_CONTENTS.json"), "plan": fingerprint(output / "ARCHIVE_PLAN.json"), "verified_member_count": len(observed), "all_selected_source_bookends_equal": True}
    (output / "ARCHIVE_RECEIPT.json").write_bytes(encode(receipt))
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["plan", "create"])
    parser.add_argument("--baseline-build", type=Path, required=True)
    parser.add_argument("--candidate-build", type=Path, required=True)
    parser.add_argument("--checks", type=Path, required=True)
    parser.add_argument("--final-review", type=Path, required=True)
    parser.add_argument("--comparison-dir", type=Path, required=True)
    parser.add_argument("--attempt-dir", type=Path, action="append", default=[], help="Prior failed comparison attempt to preserve (repeatable)")
    parser.add_argument("--extra-doc", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True, help="New plan file for plan, or new directory for create")
    args = parser.parse_args()
    plan = prepare(args)
    args.output = validate_output(plan, args.output)
    if args.action == "plan":
        with args.output.open("xb") as stream:
            stream.write(encode(plan))
        print(json.dumps({"status": "planned_only", "member_count": plan["member_count"], "uncompressed_payload_bytes": plan["uncompressed_payload_bytes"], "plan": fingerprint(args.output)}))
    else:
        print(json.dumps(create(plan, args.output)))


if __name__ == "__main__":
    main()
