#!/usr/bin/env python3
"""Small file-publication controls; never package the biological experiment."""

import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


SOURCE = Path(__file__).with_name("package_evidence.py")
SPEC = importlib.util.spec_from_file_location("package_evidence", SOURCE)
package = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(package)


class PackagingControls(unittest.TestCase):
    def synthetic_final_evidence(self, root):
        scratch = root / "scratch"
        bundle = root / "bundle"
        (scratch / "builds").mkdir(parents=True)
        bundle.mkdir()

        def write(path, data):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(package.encode(data) if isinstance(data, dict) else data)
            return path

        docs = [write(root / "docs/result.md", b"final interpretation\n"), write(bundle / "README.md", b"protocol\n")]
        extra_doc = write(root / "docs/extra.md", b"extra final result\n")
        helper = write(scratch / "package_evidence.py", b"synthetic packaging helper\n")
        # Deliberately outside scratch/builds: selected receipt inclusion must
        # not rely on discovering the usual build-directory layout.
        candidate = root / "selected/candidate"
        source = candidate / "source"
        write(source / "src/main.rs", b"fn main() {}\n")
        write(source / "tests/fixtures/committed.fastq.gz", b"small committed fixture\n")
        files = {path.relative_to(source).as_posix(): package.fingerprint(path) for path in package.walk(source)}
        binary = write(candidate / "sharkmer", b"synthetic executable identity\n")
        candidate_snapshot = write(candidate / "snapshot.json", {"role": "candidate", "source": str(source), "files": files, "provenance": {"repository_head": "candidate-head"}})
        candidate_build = write(candidate / "build.json", {"status": "complete", "source_before": files, "source_after": files, "binary": package.fingerprint(binary)})
        baseline = root / "selected/baseline"
        baseline_snapshot = write(baseline / "snapshot.json", {"role": "baseline", "provenance": {"commit": "baseline-head", "archive": {"sha256": "archived-hash"}}})
        baseline_build = write(baseline / "build.json", {"status": "complete"})
        checked_paths = [write(root / "scripts/sharkmer_validate/runner.py", b"from .uncertain import validate\n"), write(root / "scripts/sharkmer_validate/uncertain.py", b"def validate(): pass\n"), write(root / "scripts/sharkmer_validate/results.py", b"class Result: pass\n")]
        checked_sources = {str(path): package.fingerprint(path) for path in checked_paths}
        checks = write(root / "selected/checks.json", {"status": "pass", "sources_before": checked_sources, "sources_after": checked_sources})
        comparison = root / "comparison"
        artifacts = [*docs, extra_doc, candidate_build, candidate_snapshot, baseline_build, baseline_snapshot, checks, *checked_paths]
        artifacts.append(write(comparison / "freeze.json", {"status": "frozen"}))
        artifacts.append(write(comparison / "orchestration.json", {"status": "complete"}))
        artifacts.append(write(comparison / "runs/assessment.json", {"status": "pass"}))
        jobs = []
        for index in range(9):
            output = write(comparison / f"runs/job{index}/output.yaml", b"output\n")
            receipt = write(comparison / f"runs/job{index}.receipt.json", {"status": "complete", "outputs": {"files": {"output": package.fingerprint(output)}}})
            artifacts.extend([receipt, output])
            jobs.append({"id": f"job{index}", "status": "complete", "receipt": package.fingerprint(receipt)})
        artifacts.append(write(comparison / "runs/execution.json", {"status": "complete", "jobs": jobs}))
        review = write(bundle / "FINAL_RESULTS_REVIEW.json", {"status": "pass", "reviewed_artifacts": {path.relative_to(root).as_posix(): package.fingerprint(path) for path in artifacts}})
        failed_attempt = root / "failed_comparison"
        write(failed_attempt / "orchestration.json", {"status": "failed", "comparison_started": False})
        args = SimpleNamespace(candidate_build=candidate_build, baseline_build=baseline_build, checks=checks, final_review=review, comparison_dir=comparison, extra_doc=[extra_doc], attempt_dir=[failed_attempt])
        patches = {"ROOT": root, "SCRATCH": scratch, "BUNDLE": bundle, "DOCS": ["docs/result.md"], "__file__": str(helper)}
        return args, patches

    def test_prepare_requires_bound_final_artifacts_and_retains_selected_receipts(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            args, patches = self.synthetic_final_evidence(root)
            with patch.multiple(package, **patches):
                plan = package.prepare(args)
                for path in [args.baseline_build, args.candidate_build, args.candidate_build.parent / "snapshot.json", args.attempt_dir[0] / "orchestration.json", args.extra_doc[0]]:
                    self.assertIn(str(path), plan["original_path_to_member"])
                self.assertIn("candidate_source/tests/fixtures/committed.fastq.gz", plan["members"])
                review = json.loads(args.final_review.read_text())
                original_review = package.encode(review)
                del review["reviewed_artifacts"]["docs/extra.md"]
                args.final_review.write_bytes(package.encode(review))
                with self.assertRaisesRegex(ValueError, "omits selected artifacts"):
                    package.prepare(args)
                args.final_review.write_bytes(original_review)
                args.extra_doc[0].write_text("changed after review")
                with self.assertRaisesRegex(ValueError, "review artifact changed"):
                    package.prepare(args)
                args.final_review.write_bytes(package.encode({"status": "pass"}))
                with self.assertRaisesRegex(ValueError, "nonempty reviewed_artifacts"):
                    package.prepare(args)

    def test_checked_runtime_source_payloads_are_archived_and_bound(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            args, patches = self.synthetic_final_evidence(root)
            with patch.multiple(package, **patches):
                plan = package.prepare(args)
                checked = json.loads(args.checks.read_text())["sources_before"]
                self.assertEqual(plan["checked_source_count"], len(checked))
                self.assertEqual(set(plan["checked_source_members"]), set(checked))
                for original, expected in checked.items():
                    member = plan["checked_source_members"][original]
                    self.assertEqual(member, "checked_source/" + Path(original).relative_to(root).as_posix())
                    self.assertEqual(plan["members"][member], expected)
                output = root / "archive"
                package.create(plan, output)
                with package.tarfile.open(output / "evidence.tar.gz", "r:gz") as archive:
                    for original in checked:
                        payload = archive.extractfile(plan["checked_source_members"][original]).read()
                        self.assertEqual(payload, Path(original).read_bytes())
                review = json.loads(args.final_review.read_text())
                original_review = package.encode(review)
                del review["reviewed_artifacts"]["scripts/sharkmer_validate/uncertain.py"]
                args.final_review.write_bytes(package.encode(review))
                with self.assertRaisesRegex(ValueError, "omits selected artifacts"):
                    package.prepare(args)
                args.final_review.write_bytes(original_review)
                changed_source = root / "scripts/sharkmer_validate/uncertain.py"
                changed_source.write_text("changed since compiled checks")
                with self.assertRaisesRegex(ValueError, "Checked source changed"):
                    package.prepare(args)

    def test_checked_source_bookends_must_match(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            args, patches = self.synthetic_final_evidence(root)
            with patch.multiple(package, **patches):
                checks = json.loads(args.checks.read_text())
                checks["sources_after"] = {}
                args.checks.write_bytes(package.encode(checks))
                with self.assertRaisesRegex(ValueError, "source bookends are missing or differ"):
                    package.prepare(args)

    def test_output_must_be_disjoint_from_prepared_evidence_roots(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            args, patches = self.synthetic_final_evidence(root)
            with patch.multiple(package, **patches):
                plan = package.prepare(args)
                for forbidden in [root, patches["BUNDLE"] / "new_archive", args.comparison_dir / "new_archive", args.candidate_build.parent / "new_archive"]:
                    with self.assertRaisesRegex(ValueError, "overlaps selected evidence"):
                        package.create(plan, forbidden)
                self.assertEqual(package.validate_output(plan, root / "disjoint_archive"), root / "disjoint_archive")

    def test_prepare_rejects_failed_assessment_and_symlinked_explicit_evidence(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            args, patches = self.synthetic_final_evidence(root)
            with patch.multiple(package, **patches):
                assessment = args.comparison_dir / "runs/assessment.json"
                assessment.write_bytes(package.encode({"status": "fail"}))
                with self.assertRaisesRegex(ValueError, "assessment is not pass"):
                    package.prepare(args)
                alias = root / "docs_alias"
                alias.symlink_to(root / "docs", target_is_directory=True)
                args.extra_doc = [alias / "extra.md"]
                with self.assertRaisesRegex(ValueError, "Symlinked evidence path"):
                    package.prepare(args)

    def test_roundtrip_no_clobber_and_changed_source(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            source = root / "example.txt"
            source.write_bytes(b"exact evidence\n")
            plan = {"schema_version": 1, "members": {"controls/example.txt": package.fingerprint(source)}}
            receipt = package.create(plan, root / "archive")
            self.assertEqual(receipt["status"], "verified")
            self.assertEqual(receipt["verified_member_count"], 3)
            with self.assertRaises(FileExistsError):
                package.create(plan, root / "archive")
            source.write_bytes(b"changed evidence\n")
            with self.assertRaisesRegex(ValueError, "changed before archive"):
                package.create(plan, root / "changed")

    def test_report_pruning_is_limited_to_panels(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            for name in ["panels/validation_results/generated.txt", "tests/validation_results/fixture.txt", "target/binary", "src/main.rs"]:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(name)
            self.assertEqual({path.relative_to(root).as_posix() for path in package.walk(root)}, {"tests/validation_results/fixture.txt", "src/main.rs"})

    def test_symlink_evidence_is_refused(self):
        with tempfile.TemporaryDirectory(prefix="uncertain-packager-control-") as directory:
            root = Path(directory)
            source = root / "source"
            source.write_text("evidence")
            link = root / "link"
            link.symlink_to(source)
            with self.assertRaisesRegex(ValueError, "Not a regular file"):
                package.fingerprint(link)


if __name__ == "__main__":
    unittest.main()
