#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import yaml


WORKSPACE = Path("/tmp/sharkmer-reference-gates-20260913")
BUILD_MANIFEST = WORKSPACE / "builds/builds.json"
CURRENT_BUILD_MANIFEST = Path("/tmp/sharkmer-high-copy-20260911/final-builds.json")
PRODUCTION_SOURCE = Path("/tmp/sharkmer-high-copy-20260911/issue155-build/sources/candidate")
PANELS = {
    "hydrozoa": PRODUCTION_SOURCE / "panels/hydrozoa.yaml",
    "insecta": PRODUCTION_SOURCE / "panels/insecta.yaml",
}
EXPECTED_BUILDS = {
    "pre132": {
        "commit": "928491610822ffdb236d0326b32c8dd19fecf66a",
        "binary_sha256": "63d25e7858387aaa0fb7beb7f6d93f16d02194c06d2bde88e85a933ff67451e7",
    },
    "post132": {
        "commit": "b728f14219945567b3d78f3602590864a256c809",
        "binary_sha256": "70acbf1be0334f29f5d157e288dc2d509a5864cc17cf61a9e7e9ab6c7b8a31f1",
    },
    "current": {
        "commit": "0c38d6a051082cc2a1eb961b4206837f82948fda",
        "binary_sha256": "469065d8416d38f25993d537ee2956d88fdd2ba24a9461e356807c5bf4957a81",
    },
}
GENERATOR = {
    "read_length": 150,
    "flank_length": 149,
    "flank_method": "sha256_counter_2bit_acgt_v1",
    "orientations": ["forward", "reverse_complement"],
    "quality_character": "I",
    "copies_per_window_per_orientation": 1,
}
IUPAC = {
    "A": frozenset("A"),
    "C": frozenset("C"),
    "G": frozenset("G"),
    "T": frozenset("T"),
    "R": frozenset("AG"),
    "Y": frozenset("CT"),
    "S": frozenset("CG"),
    "W": frozenset("AT"),
    "K": frozenset("GT"),
    "M": frozenset("AC"),
    "B": frozenset("CGT"),
    "D": frozenset("AGT"),
    "H": frozenset("ACT"),
    "V": frozenset("ACG"),
    "N": frozenset("ACGT"),
}
COMPLEMENT = {
    "A": "T",
    "C": "G",
    "G": "C",
    "T": "A",
    "R": "Y",
    "Y": "R",
    "S": "S",
    "W": "W",
    "K": "M",
    "M": "K",
    "B": "V",
    "D": "H",
    "H": "D",
    "V": "B",
    "N": "N",
}
CONTROL_INPUTS = {
    "clean_positive_a18": {
        "path": Path("/tmp/sharkmer-high-copy-20260911/final-controls/synthetic_inputs/repeat-a18.fastq"),
        "sha256": "a37f8033eea7befe85a894ac0b0e0cf6a23ff491983d677ecc6d543d212ae348",
        "primer": "name=target,forward=AGTTAAAAACGTGTG,reverse=TAGGCTGGGATGGCG,trim=15,mismatches=0,min-length=100,max-length=220,dedup-edit-threshold=0",
        "expected": "exact_product",
        "truth_length": 138,
        "truth_sha256": "d2c29f5b39989a5e52beb0ff03014ddde3a723146892db8108d0609bd4ca5567",
    },
    "collapsed_negative_a40": {
        "path": Path("/tmp/sharkmer-high-copy-20260911/final-controls/synthetic_inputs/repeat-a40.fastq"),
        "sha256": "89ac804b36acfd6d8e168e88f2de8f6e61cc258a1e127aef70702bb4915d0597",
        "primer": "name=target,forward=AGTTAAAAACGTGTG,reverse=TAGGCTGGGATGGCG,trim=15,mismatches=0,min-length=100,max-length=220,dedup-edit-threshold=0",
        "expected": "known_collapsed_control",
        "truth_length": 160,
        "truth_sha256": "bf07890a32bc5af3e1fec651ad833cd477048be1a813867a3580f0e0361e4d7e",
        "known_wrong_length": 138,
        "known_wrong_sha256": "d2c29f5b39989a5e52beb0ff03014ddde3a723146892db8108d0609bd4ca5567",
    },
}
KNOWN_PARTIAL_REFERENCES = {
    "KP776745.1": "published panel reference lacks the native forward-primer binding region",
    "JQ410732.1": "published panel reference lacks the native reverse-primer binding region",
    "EU272542.1": "published panel reference is shorter than the configured 28S minimum product length",
}
KNOWN_REFERENCE_CAVEATS = {
    "AK281180": (
        "panel sequence is a prior Sharkmer bootstrap amplicon; public AK281180.1 is a "
        "256 bp internal match, not an independent deposited 978 bp full-length oracle"
    ),
}


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as input_stream:
        for block in iter(lambda: input_stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_text(value):
    return hashlib.sha256(value.encode()).hexdigest()


def atomic_write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def load_json(path):
    with Path(path).open() as input_stream:
        value = json.load(input_stream)
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def file_receipt(path):
    path = Path(path).resolve()
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Expected regular file: {path}")
    return {
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def normalized_gene(primer):
    gene = primer["gene"]
    return f"{gene}_{primer['index']}" if primer.get("index") is not None else gene


def reverse_complement(sequence):
    try:
        return "".join(COMPLEMENT[base] for base in reversed(sequence.upper()))
    except KeyError as error:
        raise ValueError(f"Invalid IUPAC base: {error.args[0]}") from error


def find_sites(sequence, primer):
    sequence = sequence.upper()
    primer = primer.upper()
    sites = []
    for start in range(0, len(sequence) - len(primer) + 1):
        observed = sequence[start : start + len(primer)]
        if any(base not in "ACGT" for base in observed):
            continue
        mismatches = sum(base not in IUPAC[expected] for base, expected in zip(observed, primer))
        sites.append(
            {
                "start": start,
                "end": start + len(primer),
                "mismatches": mismatches,
                "sequence": observed,
            }
        )
    return sites


def reference_binding_analysis(sequence, primer, selected_k):
    trim = min(primer["trim"], selected_k - 1)
    forward_query = primer["forward_seq"].upper()[-trim:]
    reverse_primer = primer["reverse_seq"].upper()[-trim:]
    reverse_query = reverse_complement(reverse_primer)
    forward_sites = [
        site
        for site in find_sites(sequence, forward_query)
        if site["mismatches"] <= primer["mismatches"]
    ]
    reverse_sites = [
        site
        for site in find_sites(sequence, reverse_query)
        if site["mismatches"] <= primer["mismatches"]
    ]
    pairs = []
    for forward in forward_sites:
        for reverse in reverse_sites:
            if reverse["start"] <= forward["start"]:
                continue
            length = reverse["end"] - forward["start"]
            if primer["min_length"] <= length <= primer["max_length"]:
                amplicon = sequence[forward["start"] : reverse["end"]]
                pairs.append(
                    {
                        "forward": forward,
                        "reverse": reverse,
                        "start": forward["start"],
                        "end": reverse["end"],
                        "length": length,
                        "sha256": sha256_text(amplicon),
                    }
                )
    unique_pairs = {
        (pair["start"], pair["end"], pair["sha256"]): pair for pair in pairs
    }
    selected = list(unique_pairs.values())
    non_acgt = sorted({base for base in sequence.upper() if base not in "ACGT"})
    if non_acgt:
        category = "uncallable_non_acgt_reference"
        reason = f"reference contains non-ACGT bases: {''.join(non_acgt)}"
        truth = None
    elif len(selected) == 1:
        truth = selected[0]
        category = (
            "callable_full_reference_exact"
            if truth["start"] == 0 and truth["end"] == len(sequence)
            else "callable_primer_bounded_substring_exact"
        )
        reason = None
    elif len(selected) > 1:
        category = "uncallable_ambiguous_primer_bounded_products"
        reason = f"{len(selected)} distinct valid primer-bounded products"
        truth = None
    elif not forward_sites and not reverse_sites:
        category = "uncallable_both_primers"
        reason = "no permitted forward or reverse trimmed-primer site"
        truth = None
    elif not forward_sites:
        category = "uncallable_forward_primer"
        reason = "no permitted forward trimmed-primer site"
        truth = None
    elif not reverse_sites:
        category = "uncallable_reverse_primer"
        reason = "no permitted reverse trimmed-primer site"
        truth = None
    else:
        category = "uncallable_length_or_orientation"
        reason = "primer sites exist but no forward-to-reverse pair satisfies original length bounds"
        truth = None
    return {
        "k": selected_k,
        "effective_trim": trim,
        "forward_query": forward_query,
        "reverse_primer_query": reverse_primer,
        "reverse_reference_query": reverse_query,
        "forward_sites": forward_sites,
        "reverse_sites": reverse_sites,
        "valid_pairs": selected,
        "category": category,
        "reason": reason,
        "truth": truth,
    }


def load_panel(path):
    path = Path(path)
    data = yaml.safe_load(path.read_text())
    if not isinstance(data, dict) or not isinstance(data.get("primers"), list):
        raise ValueError(f"Invalid panel: {path}")
    return data


def inventory_document():
    panel_data = {name: load_panel(path) for name, path in PANELS.items()}
    primer_maps = {
        name: {normalized_gene(primer): primer for primer in data["primers"]}
        for name, data in panel_data.items()
    }
    cases = []
    for panel_name, selected_gene in (("hydrozoa", None), ("insecta", "ITS_2")):
        data = panel_data[panel_name]
        for reference_group in data.get("references", []):
            gene = reference_group["gene"]
            if selected_gene is not None and gene != selected_gene:
                continue
            primer = primer_maps[panel_name].get(gene)
            if primer is None:
                raise ValueError(f"Reference gene has no primer: {panel_name}/{gene}")
            primer_parameters = {
                key: primer[key]
                for key in (
                    "gene",
                    "forward_seq",
                    "reverse_seq",
                    "min_length",
                    "max_length",
                    "min_count",
                    "mismatches",
                    "trim",
                )
            }
            if primer.get("index") is not None:
                primer_parameters["index"] = primer["index"]
            for reference in reference_group["sequences"]:
                if panel_name == "insecta" and reference["taxon"] != "Gryllus bimaculatus":
                    continue
                sequence = reference["sequence"].upper()
                case_id = f"{panel_name}-{gene}-{reference['accession']}".replace(".", "_")
                cases.append(
                    {
                        "case_id": case_id,
                        "panel": panel_name,
                        "gene": gene,
                        "taxon": reference["taxon"],
                        "accession": reference["accession"],
                        "reference_length": len(sequence),
                        "reference_sha256": sha256_text(sequence),
                        "reference_scope": (
                            {
                                "status": "known_partial",
                                "reason": KNOWN_PARTIAL_REFERENCES[reference["accession"]],
                            }
                            if reference["accession"] in KNOWN_PARTIAL_REFERENCES
                            else {
                                "status": (
                                    "panel_bootstrap_sequence_not_full_deposited_accession"
                                    if reference["accession"] in KNOWN_REFERENCE_CAVEATS
                                    else "panel_sequence_as_configured"
                                ),
                                "reason": KNOWN_REFERENCE_CAVEATS.get(reference["accession"]),
                            }
                        ),
                        "primer_parameters": primer_parameters,
                        "binding_analysis": {
                            str(selected_k): reference_binding_analysis(sequence, primer, selected_k)
                            for selected_k in (19, 31)
                        },
                    }
                )
    if len(cases) != 30:
        raise ValueError(f"Expected 30 panel-reference cases, found {len(cases)}")
    return {
        "schema_version": 1,
        "scope": "29 hydrozoa panel references plus Gryllus bimaculatus ITS_2",
        "panels": {name: file_receipt(path) for name, path in PANELS.items()},
        "k_values": [19, 31],
        "cases": cases,
        "category_semantics": {
            "callable_full_reference_exact": "one valid product equals the complete unchanged panel-embedded reference sequence",
            "callable_primer_bounded_substring_exact": "one valid product is a wholly internal unchanged panel-embedded reference substring",
            "uncallable": "no exact product oracle is asserted; the reason is recorded separately from repeat rejection",
        },
    }


def diagnostic_parameters(case, sequence):
    return {
        "gene": "target",
        "forward_seq": sequence[:15],
        "reverse_seq": reverse_complement(sequence[-15:]),
        "min_length": 100,
        "max_length": len(sequence) + 500,
        "min_count": case["primer_parameters"]["min_count"],
        "mismatches": 0,
        "trim": 15,
        "dedup_edit_threshold": "command_default",
    }


def protocol_template(inventory, inventory_path):
    diagnostic_cases = []
    for case in inventory["cases"]:
        if case["panel"] != "hydrozoa":
            continue
        sequence = locate_reference(case)
        if any(base not in "ACGT" for base in sequence):
            continue
        parameters = diagnostic_parameters(case, sequence)
        for selected_k in (19, 31):
            analysis = reference_binding_analysis(sequence, parameters, selected_k)
            if not any(
                pair["start"] == 0
                and pair["end"] == len(sequence)
                and pair["sha256"] == case["reference_sha256"]
                for pair in analysis["valid_pairs"]
            ):
                raise ValueError(f"Diagnostic endpoints do not span source: {case['case_id']}")
        diagnostic_cases.append(
            {
                "case_id": case["case_id"],
                "panel": case["panel"],
                "source_gene": case["gene"],
                "taxon": case["taxon"],
                "accession": case["accession"],
                "reference_length": case["reference_length"],
                "reference_sha256": case["reference_sha256"],
                "reference_scope": case["reference_scope"],
                "diagnostic_parameters": parameters,
                "truth": {
                    "start": 0,
                    "end": len(sequence),
                    "length": len(sequence),
                    "sha256": case["reference_sha256"],
                },
            }
        )
    if len(diagnostic_cases) != 23:
        raise ValueError(f"Expected 23 ACGT-only hydrozoa diagnostics, found {len(diagnostic_cases)}")
    primary = [
        case
        for case in inventory["cases"]
        if case["case_id"] == "insecta-ITS_2-AK281180"
    ]
    if len(primary) != 1:
        raise ValueError("Gryllus primary oracle is missing")
    return {
        "schema_version": 1,
        "purpose": "Panel-reference exact-sequence repeat-gate assessment; no production or release change",
        "inventory_sha256": sha256_file(inventory_path),
        "panels": inventory["panels"],
        "builds": EXPECTED_BUILDS,
        "k_values": [19, 31],
        "generator": GENERATOR,
        "cases": inventory["cases"],
        "primary_case_ids": [primary[0]["case_id"]],
        "diagnostic_cases": diagnostic_cases,
        "controls": {
            name: {key: value for key, value in control.items() if key != "path"}
            | {"path": str(control["path"])}
            for name, control in CONTROL_INPUTS.items()
        },
        "cohort_semantics": {
            "primary": "unchanged insecta panel primers and bounds; exact known generating-template truth from the configured panel sequence, not an independent deposited full-length oracle",
            "diagnostic": "first and last 15 native reference bases used as synthetic primers with mismatches 0 and bounds 100..reference_length+500; exact source recovery test, not hydrozoa panel recovery",
            "controls": "frozen pre-existing clean and known-collapsed synthetic sources",
        },
        "limitations": [
            "Calibration fixtures are derived from panel references and are not independent held-out data.",
            "Zero-error exhaustive tiling does not estimate sensitivity on biological sequencing reads.",
            "Native-endpoint diagnostic primers and bounds differ from the hydrozoa panel and cannot support a panel-recovery claim.",
            "An exact panel-embedded sequence is a fixture truth oracle, not proof that every biological sample has one haplotype or repeat copy count.",
            "The 978 bp Gryllus panel sequence labeled AK281180 is a prior Sharkmer bootstrap amplicon; public AK281180.1 is only a 256 bp internal match and does not independently certify the full template.",
            "No runtime or memory comparison is intended from these small correctness runs.",
        ],
    }


def deterministic_flank(case_id, side, length):
    bases = "ACGT"
    sequence = []
    counter = 0
    while len(sequence) < length:
        block = hashlib.sha256(f"{case_id}\0{side}\0{counter}".encode()).digest()
        for byte in block:
            for shift in (6, 4, 2, 0):
                sequence.append(bases[(byte >> shift) & 3])
                if len(sequence) == length:
                    return "".join(sequence)
        counter += 1
    return "".join(sequence)


def locate_reference(case):
    panel = load_panel(PANELS[case["panel"]])
    for group in panel["references"]:
        if group["gene"] != case["gene"]:
            continue
        for reference in group["sequences"]:
            if reference["accession"] == case["accession"] and reference["taxon"] == case["taxon"]:
                sequence = reference["sequence"].upper()
                if sha256_text(sequence) != case["reference_sha256"]:
                    raise ValueError(f"Reference changed: {case['case_id']}")
                return sequence
    raise ValueError(f"Reference not found: {case['case_id']}")


def validate_no_flank_binding(case, padded_sequence, reference_start):
    primer = case["primer_parameters"]
    reference_end = reference_start + case["reference_length"]
    for selected_k in (19, 31):
        analysis = reference_binding_analysis(padded_sequence, primer, selected_k)
        for pair in analysis["valid_pairs"]:
            if pair["start"] < reference_start or pair["end"] > reference_end:
                raise ValueError(
                    f"Deterministic flank creates an eligible product: {case['case_id']} k={selected_k}"
                )


def fastq_records(case, sequence):
    read_length = GENERATOR["read_length"]
    flank_length = GENERATOR["flank_length"]
    left = deterministic_flank(case["case_id"], "left", flank_length)
    right = deterministic_flank(case["case_id"], "right", flank_length)
    padded = left + sequence + right
    validate_no_flank_binding(case, padded, flank_length)
    records = []
    window_count = len(padded) - read_length + 1
    quality = GENERATOR["quality_character"] * read_length
    for start in range(window_count):
        window = padded[start : start + read_length]
        records.append((f"{case['case_id']}:{start}:forward", window, quality))
        records.append(
            (f"{case['case_id']}:{start}:reverse_complement", reverse_complement(window), quality)
        )
    return records, {
        "reference_start": flank_length,
        "reference_end": flank_length + len(sequence),
        "left_flank_sha256": sha256_text(left),
        "right_flank_sha256": sha256_text(right),
        "padded_sequence_sha256": sha256_text(padded),
        "window_count": window_count,
        "read_count": len(records),
        "base_count": len(records) * read_length,
        "per_occurrence_canonical_kmer_support": {
            str(selected_k): 2 * (read_length - selected_k + 1) for selected_k in (19, 31)
        },
    }


def write_fastq(path, records):
    with Path(path).open("x") as output_stream:
        for name, sequence, quality in records:
            output_stream.write(f"@{name}\n{sequence}\n+\n{quality}\n")


def inspect_fastq(path):
    lines = Path(path).read_text().splitlines()
    if len(lines) % 4 != 0:
        raise ValueError(f"FASTQ record is incomplete: {path}")
    sequences = []
    for offset in range(0, len(lines), 4):
        name, sequence, separator, quality = lines[offset : offset + 4]
        if not name.startswith("@") or separator != "+" or len(sequence) != len(quality):
            raise ValueError(f"FASTQ record is malformed: {path}")
        if any(base not in "ACGT" for base in sequence.upper()):
            raise ValueError(f"FASTQ contains a non-ACGT base: {path}")
        sequences.append(sequence.upper())
    return {
        "read_count": len(sequences),
        "base_count": sum(len(sequence) for sequence in sequences),
        "sequences": sequences,
    }


def validate_protocol(protocol, inventory, inventory_path):
    if protocol.get("schema_version") != 1 or protocol.get("k_values") != [19, 31]:
        raise ValueError("Protocol schema or k values differ from reviewed scope")
    if protocol.get("generator") != GENERATOR:
        raise ValueError("Fixture generator settings differ from reviewed scope")
    if protocol.get("inventory_sha256") != sha256_file(inventory_path):
        raise ValueError("Protocol does not bind the inventory")
    if protocol.get("panels") != inventory["panels"]:
        raise ValueError("Protocol panel receipts differ from inventory")
    inventory_cases = {case["case_id"]: case for case in inventory["cases"]}
    cases = protocol.get("cases")
    if not isinstance(cases, list) or len(cases) != 30:
        raise ValueError("Protocol must register all 30 panel-reference cases")
    for registered in cases:
        expected = inventory_cases.get(registered.get("case_id"))
        if expected is None or registered != expected:
            raise ValueError("Protocol case differs from the immutable inventory")
    expected_template = protocol_template(inventory, inventory_path)
    if protocol.get("primary_case_ids") != expected_template["primary_case_ids"]:
        raise ValueError("Primary oracle cases differ from the reviewed scope")
    if protocol.get("diagnostic_cases") != expected_template["diagnostic_cases"]:
        raise ValueError("Native-endpoint diagnostic cases differ from the reviewed scope")
    if protocol.get("builds") != EXPECTED_BUILDS:
        raise ValueError("Protocol build identities differ from reviewed builds")
    if protocol.get("controls") != {
        name: {key: value for key, value in control.items() if key != "path"}
        | {"path": str(control["path"])}
        for name, control in CONTROL_INPUTS.items()
    }:
        raise ValueError("Protocol controls differ from frozen known-source controls")
    limitations = protocol.get("limitations")
    if not isinstance(limitations, list) or not limitations:
        raise ValueError("Protocol limitations are required")


def generate_fixtures(protocol_path, inventory_path, output_root):
    if output_root.exists():
        raise ValueError("Fixture output exists; preserve prior receipts")
    protocol = load_json(protocol_path)
    inventory = load_json(inventory_path)
    validate_protocol(protocol, inventory, inventory_path)
    output_root.mkdir(parents=True)
    inventory_cases = {case["case_id"]: case for case in protocol["cases"]}
    runnable = []
    for case_id in protocol["primary_case_ids"]:
        case = copy_case(inventory_cases[case_id])
        runnable.append(
            {
                "fixture_id": f"primary-{case_id}",
                "cohort": "primary",
                "case": case,
                "truth_by_k": {
                    selected_k: case["binding_analysis"][selected_k]["truth"]
                    for selected_k in ("19", "31")
                },
            }
        )
    for diagnostic in protocol["diagnostic_cases"]:
        source_case = copy_case(inventory_cases[diagnostic["case_id"]])
        source_case["case_id"] = f"diagnostic-{diagnostic['case_id']}"
        source_case["primer_parameters"] = diagnostic["diagnostic_parameters"]
        runnable.append(
            {
                "fixture_id": source_case["case_id"],
                "cohort": "diagnostic",
                "case": source_case,
                "source_case_id": diagnostic["case_id"],
                "truth_by_k": {"19": diagnostic["truth"], "31": diagnostic["truth"]},
            }
        )
    fixture_records = []
    for runnable_case in runnable:
        case = runnable_case["case"]
        source_case = inventory_cases.get(runnable_case.get("source_case_id", case["case_id"]))
        sequence = locate_reference(source_case)
        records, derivation = fastq_records(case, sequence)
        path = output_root / f"{runnable_case['fixture_id']}.fastq"
        write_fastq(path, records)
        fixture_records.append(
            {
                "fixture_id": runnable_case["fixture_id"],
                "case_id": runnable_case.get("source_case_id", case["case_id"]),
                "cohort": runnable_case["cohort"],
                "status": "generated",
                "fastq": file_receipt(path),
                "derivation": derivation,
                "primer_parameters": case["primer_parameters"],
                "truth_by_k": runnable_case["truth_by_k"],
            }
        )
    controls = {}
    for name, control in CONTROL_INPUTS.items():
        if sha256_file(control["path"]) != control["sha256"]:
            raise ValueError(f"Known-source control changed: {name}")
        source = inspect_fastq(control["path"])
        unique_sequences = set(source["sequences"])
        if len(unique_sequences) != 1:
            raise ValueError(f"Known-source control reads differ: {name}")
        truth_sequence = unique_sequences.pop()
        if len(truth_sequence) != control["truth_length"]:
            raise ValueError(f"Known-source control length differs: {name}")
        if sha256_text(truth_sequence) != control["truth_sha256"]:
            raise ValueError(f"Known-source control truth differs: {name}")
        destination = output_root / f"control-{name}.fastq"
        shutil.copyfile(control["path"], destination)
        controls[name] = {
            "fastq": file_receipt(destination),
            "derivation": {
                "read_count": source["read_count"],
                "base_count": source["base_count"],
                "source_sequence_length": len(truth_sequence),
                "source_sequence_sha256": sha256_text(truth_sequence),
            },
        }
    manifest = {
        "schema_version": 1,
        "protocol": file_receipt(protocol_path),
        "inventory": file_receipt(inventory_path),
        "generator": GENERATOR,
        "fixtures": fixture_records,
        "controls": controls,
    }
    atomic_write_json(output_root / "fixtures.json", manifest)
    return manifest


def copy_case(case):
    return json.loads(json.dumps(case))


def resolve_builds(protocol):
    historical = load_json(BUILD_MANIFEST)["versions"]
    current = load_json(CURRENT_BUILD_MANIFEST)["versions"]["candidate"]
    builds = {
        "pre132": historical["pre_fix"],
        "post132": historical["candidate"],
        "current": current,
    }
    for name, expected in protocol["builds"].items():
        build = builds[name]
        if build["commit"] != expected["commit"] or build["binary_sha256"] != expected["binary_sha256"]:
            raise ValueError(f"Build identity differs for {name}")
        if sha256_file(build["binary_path"]) != expected["binary_sha256"]:
            raise ValueError(f"Binary changed for {name}")
    return builds


def parse_fasta(path):
    products = []
    header = None
    sequence = []
    for line in Path(path).read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                products.append({"header": header, "sequence": "".join(sequence)})
            header = line[1:]
            sequence = []
        elif header is None:
            raise ValueError(f"FASTA sequence precedes header: {path}")
        else:
            sequence.append(line.strip().upper())
    if header is not None:
        products.append({"header": header, "sequence": "".join(sequence)})
    for product in products:
        product["length"] = len(product["sequence"])
        product["sha256"] = sha256_text(product["sequence"])
        fields = {
            key: value
            for token in product["header"].split()
            if "=" in token
            for key, value in [token.split("=", 1)]
        }
        if fields.get("length") != str(product["length"]) or not fields.get("product", "").isdigit():
            raise ValueError(f"FASTA header disagrees with sequence: {path}")
        product["product_index"] = int(fields["product"])
    if len({product["product_index"] for product in products}) != len(products):
        raise ValueError(f"FASTA has duplicate product indices: {path}")
    return products


def validate_stats_and_outputs(output_dir, command, sample, selected_k, expected_reads, expected_bases):
    stats_path = output_dir / f"{sample}.stats.yaml"
    stats = yaml.safe_load(stats_path.read_text())
    if not isinstance(stats, dict):
        raise ValueError("Stats is not a mapping")
    expected = {
        "sample": sample,
        "kmer_length": selected_k,
        "command": " ".join(command),
        "n_reads_read": expected_reads,
        "n_bases_read": expected_bases,
    }
    for field, value in expected.items():
        if stats.get(field) != value:
            raise ValueError(f"Stats {field} differs from invocation")
    pcr_results = stats.get("pcr_results")
    if not isinstance(pcr_results, list) or not pcr_results:
        raise ValueError("Stats PCR results are missing")
    products = []
    expected_fastas = set()
    for gene_result in pcr_results:
        if gene_result.get("status") != "success":
            if gene_result.get("n_products") != 0:
                raise ValueError("Failed gene reports products")
            continue
        output_file = gene_result.get("output_file") or f"{sample}_{gene_result['gene_name']}.fasta"
        if Path(output_file).name != output_file:
            raise ValueError("Unsafe output filename")
        expected_fastas.add(output_file)
        parsed = parse_fasta(output_dir / output_file)
        if len(parsed) != gene_result.get("n_products") or [item["length"] for item in parsed] != gene_result.get("product_lengths"):
            raise ValueError("FASTA disagrees with stats")
        for product in parsed:
            product["gene_name"] = gene_result["gene_name"]
            products.append(product)
    observed_fastas = {path.name for path in output_dir.glob("*.fasta")}
    if observed_fastas != expected_fastas:
        raise ValueError("FASTA file set differs from stats")
    observed_entries = set()
    for path in output_dir.iterdir():
        if path.is_symlink() or not path.is_file():
            raise ValueError("Output contains a symlink or non-file entry")
        observed_entries.add(path.name)
    expected_entries = {stats_path.name, *expected_fastas}
    if "run_id" in stats or "output_manifest" in stats or "run_status" in stats:
        manifest_name = stats.get("output_manifest")
        if Path(str(manifest_name)).name != manifest_name:
            raise ValueError("Current output manifest name is unsafe")
        manifest = yaml.safe_load((output_dir / manifest_name).read_text())
        if (
            not isinstance(manifest, dict)
            or manifest.get("status") != "complete"
            or stats.get("run_status") != "complete"
            or manifest.get("run_id") != stats.get("run_id")
            or manifest.get("sample") != sample
        ):
            raise ValueError("Current output manifest identity is invalid")
        receipts = manifest.get("files")
        if not isinstance(receipts, list):
            raise ValueError("Current output manifest receipts are missing")
        received_names = set()
        for receipt in receipts:
            name = receipt.get("path") if isinstance(receipt, dict) else None
            if Path(str(name)).name != name or name in received_names:
                raise ValueError("Current output manifest receipt name is invalid")
            received_names.add(name)
            if sha256_file(output_dir / name) != receipt.get("sha256"):
                raise ValueError("Current output manifest receipt hash differs")
        if received_names != expected_entries:
            raise ValueError("Current output manifest receipt set differs from stats")
        expected_entries.update({manifest_name, f"{sample}.lock"})
    if observed_entries != expected_entries:
        raise ValueError("Output file set contains unexpected or missing entries")
    return stats, products


def inline_primer_string(parameters):
    values = [
        ("name", parameters["gene"]),
        ("forward", parameters["forward_seq"]),
        ("reverse", parameters["reverse_seq"]),
        ("trim", parameters["trim"]),
        ("mismatches", parameters["mismatches"]),
        ("min-length", parameters["min_length"]),
        ("max-length", parameters["max_length"]),
        ("min-count", parameters["min_count"]),
    ]
    if parameters.get("dedup_edit_threshold") != "command_default":
        values.append(("dedup-edit-threshold", parameters["dedup_edit_threshold"]))
    return ",".join(f"{key}={value}" for key, value in values)


def classify_product(sequence, reference, padded):
    reverse_reference = reverse_complement(reference)
    if sequence == reference:
        return "full_reference_exact"
    if sequence == reverse_reference:
        return "full_reference_reverse_complement_exact"
    if sequence in reference or sequence in reverse_reference:
        return "internal_exact_substring"
    if sequence in padded or sequence in reverse_complement(padded):
        return "flank_dependent_contiguous"
    return "noncontiguous_or_collapsed"


def pcr_result_summary(stats):
    fields = (
        "gene_name",
        "status",
        "n_products",
        "product_lengths",
        "failure_reason",
        "threshold_diagnostics",
    )
    return [
        {field: gene_result.get(field) for field in fields if field in gene_result}
        for gene_result in stats["pcr_results"]
    ]


def run_one(build, selected_k, identity, fixture, output_root, panel_path=None, primer=None):
    attempt = output_root / "attempts" / identity
    command_output = attempt / "output"
    command_output.mkdir(parents=True)
    sample = identity.replace(".", "_")
    command = [
        build["binary_path"],
        "-k",
        str(selected_k),
        "-t",
        "2",
        "--chunks",
        "0",
        "-s",
        sample,
        "-o",
        str(command_output) + "/",
    ]
    if panel_path is not None:
        command.extend(["--pcr-panel-file", str(panel_path)])
    else:
        command.extend(["--pcr-primers", primer])
    command.append(fixture["fastq"]["path"])
    binary_before = sha256_file(build["binary_path"])
    fixture_before = sha256_file(fixture["fastq"]["path"])
    panel_before = sha256_file(panel_path) if panel_path is not None else None
    if binary_before != build["binary_sha256"]:
        raise ValueError(f"Binary changed before run: {identity}")
    if fixture_before != fixture["fastq"]["sha256"]:
        raise ValueError(f"Fixture changed before run: {identity}")
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=180)
        returncode = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
    except subprocess.TimeoutExpired as error:
        returncode = None
        stdout = error.stdout or ""
        stderr = error.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        stderr += "\nHarness timeout after 180 seconds\n"
    (attempt / "stdout.log").write_text(stdout)
    (attempt / "stderr.log").write_text(stderr)
    binary_after = sha256_file(build["binary_path"])
    fixture_after = sha256_file(fixture["fastq"]["path"])
    panel_after = sha256_file(panel_path) if panel_path is not None else None
    result = {
        "identity": identity,
        "k": selected_k,
        "command": command,
        "returncode": returncode,
        "binary_sha256_before": binary_before,
        "binary_sha256_after": binary_after,
        "fixture_sha256_before": fixture_before,
        "fixture_sha256_after": fixture_after,
        "panel_sha256_before": panel_before,
        "panel_sha256_after": panel_after,
        "logs": {
            "stdout": file_receipt(attempt / "stdout.log"),
            "stderr": file_receipt(attempt / "stderr.log"),
        },
    }
    integrity_errors = []
    if binary_after != binary_before:
        integrity_errors.append("binary changed during invocation")
    if fixture_after != fixture_before:
        integrity_errors.append("fixture changed during invocation")
    if panel_after != panel_before:
        integrity_errors.append("panel changed during invocation")
    if integrity_errors:
        result["status"] = "integrity_failure"
        result["errors"] = integrity_errors
        return result
    if returncode != 0:
        result["status"] = "timeout" if returncode is None else "run_failed"
        return result
    try:
        stats, products = validate_stats_and_outputs(
            command_output,
            command,
            sample,
            selected_k,
            fixture["derivation"]["read_count"],
            fixture["derivation"]["base_count"],
        )
    except (KeyError, OSError, TypeError, ValueError, yaml.YAMLError) as error:
        result["status"] = "invalid_output"
        result["validation_error"] = str(error)
        result["raw_outputs"] = [
            file_receipt(path)
            for path in sorted(command_output.iterdir())
            if path.is_file() and not path.is_symlink()
        ]
        return result
    result.update(
        {
            "status": "complete",
            "stats": file_receipt(command_output / f"{sample}.stats.yaml"),
            "counts": {
                field: stats.get(field)
                for field in (
                    "n_reads_read",
                    "n_bases_read",
                    "n_subreads_ingested",
                    "n_bases_ingested",
                    "n_kmers",
                )
            },
            "products": products,
            "pcr_results": pcr_result_summary(stats),
            "raw_outputs": [file_receipt(path) for path in sorted(command_output.iterdir())],
        }
    )
    return result


def freeze_execution_receipts(output_root, sources):
    receipts_root = output_root / "receipts"
    receipts_root.mkdir()
    frozen = {}
    for label, source in sources.items():
        source = Path(source).resolve()
        before = file_receipt(source)
        destination = receipts_root / f"{label}{source.suffix}"
        with source.open("rb") as input_stream, destination.open("xb") as output_stream:
            shutil.copyfileobj(input_stream, output_stream, 1024 * 1024)
        copied = file_receipt(destination)
        if copied["sha256"] != before["sha256"] or copied["size_bytes"] != before["size_bytes"]:
            raise ValueError(f"Frozen execution receipt differs: {label}")
        frozen[label] = {"source": before, "frozen": copied}
    atomic_write_json(receipts_root / "receipts.json", frozen)
    return frozen


def validate_fixture_manifest(fixtures, protocol_path, inventory_path):
    if fixtures.get("schema_version") != 1 or fixtures.get("generator") != GENERATOR:
        raise ValueError("Fixture manifest schema or generator differs")
    if fixtures.get("protocol") != file_receipt(protocol_path):
        raise ValueError("Fixtures do not bind the exact protocol")
    if fixtures.get("inventory") != file_receipt(inventory_path):
        raise ValueError("Fixtures do not bind the exact inventory")
    records = fixtures.get("fixtures")
    if not isinstance(records, list) or len(records) != 24:
        raise ValueError("Expected one primary and 23 diagnostic fixtures")
    if len({record.get("fixture_id") for record in records}) != len(records):
        raise ValueError("Fixture IDs are missing or duplicated")
    for record in records:
        if record.get("status") != "generated":
            raise ValueError("Fixture is not generated")
        if file_receipt(record["fastq"]["path"]) != record["fastq"]:
            raise ValueError(f"Fixture receipt differs: {record.get('fixture_id')}")
    controls = fixtures.get("controls")
    if not isinstance(controls, dict) or set(controls) != set(CONTROL_INPUTS):
        raise ValueError("Fixture controls differ from protocol")
    for name, record in controls.items():
        if file_receipt(record["fastq"]["path"]) != record["fastq"]:
            raise ValueError(f"Control fixture receipt differs: {name}")


def padded_sequence(case_id, reference):
    return (
        deterministic_flank(case_id, "left", GENERATOR["flank_length"])
        + reference
        + deterministic_flank(case_id, "right", GENERATOR["flank_length"])
    )


def finalize_result(result, reference, padded, expected_gene, truth, known_wrong_sha256=None):
    for product in result.get("products", []):
        product["reference_classification"] = classify_product(
            product["sequence"], reference, padded
        )
    result["truth"] = truth
    result["expected_gene"] = expected_gene
    result["truth_present"] = result.get("status") == "complete" and any(
        product["gene_name"] == expected_gene and product["sha256"] == truth["sha256"]
        for product in result.get("products", [])
    )
    if known_wrong_sha256 is not None:
        result["known_wrong_present"] = result.get("status") == "complete" and any(
            product["gene_name"] == expected_gene
            and product["sha256"] == known_wrong_sha256
            for product in result.get("products", [])
        )
    for product in result.get("products", []):
        product.pop("sequence")
    return result


def count_parity(results):
    groups = {}
    for result in results:
        if result.get("cohort") == "assessment_only":
            continue
        key = (result["fixture_id"], result["k"])
        groups.setdefault(key, []).append(result)
    parity = []
    for (fixture_id, selected_k), group in sorted(groups.items()):
        complete = [result for result in group if result.get("status") == "complete"]
        count_sets = {
            tuple(result["counts"].get(field) for field in (
                "n_reads_read",
                "n_bases_read",
                "n_subreads_ingested",
                "n_bases_ingested",
                "n_kmers",
            ))
            for result in complete
        }
        parity.append(
            {
                "fixture_id": fixture_id,
                "k": selected_k,
                "versions_complete": sorted(result["version"] for result in complete),
                "all_versions_complete": len(complete) == 3,
                "counts_equal": len(complete) == 3 and len(count_sets) == 1,
                "counts": {result["version"]: result.get("counts") for result in group},
            }
        )
    return parity


def run_experiment(protocol_path, inventory_path, fixtures_path, output_root):
    if output_root.exists():
        raise ValueError("Experiment output exists; preserve prior results")
    protocol = load_json(protocol_path)
    inventory = load_json(inventory_path)
    validate_protocol(protocol, inventory, inventory_path)
    fixtures = load_json(fixtures_path)
    validate_fixture_manifest(fixtures, protocol_path, inventory_path)
    builds = resolve_builds(protocol)
    output_root.mkdir(parents=True)
    frozen_sources = freeze_execution_receipts(
        output_root,
        {
            "harness": Path(__file__),
            "protocol": protocol_path,
            "inventory": inventory_path,
            "fixtures": fixtures_path,
            "historical_builds": BUILD_MANIFEST,
            "current_builds": CURRENT_BUILD_MANIFEST,
            "hydrozoa_panel": PANELS["hydrozoa"],
            "insecta_panel": PANELS["insecta"],
        },
    )
    fixture_map = {record["fixture_id"]: record for record in fixtures["fixtures"]}
    inventory_cases = {case["case_id"]: case for case in protocol["cases"]}
    results = []
    primary_case_ids = set(protocol["primary_case_ids"])
    for case in protocol["cases"]:
        if case["case_id"] not in primary_case_ids:
            results.append({
                "fixture_id": f"assessment-{case['case_id']}",
                "case_id": case["case_id"],
                "cohort": "assessment_only",
                "status": "not_run_no_unambiguous_unchanged_parameter_oracle",
                "binding_analysis": case["binding_analysis"],
                "reference_scope": case["reference_scope"],
            })
    for case_id in protocol["primary_case_ids"]:
        case = inventory_cases[case_id]
        fixture_id = f"primary-{case_id}"
        fixture = fixture_map[fixture_id]
        reference = locate_reference(case)
        padded = padded_sequence(case["case_id"], reference)
        for selected_k in protocol["k_values"]:
            truth = fixture["truth_by_k"][str(selected_k)]
            for version, build in builds.items():
                identity = f"{fixture_id}-k{selected_k}-{version}"
                result = run_one(
                    build, selected_k, identity, fixture, output_root, panel_path=PANELS["insecta"]
                )
                result.update({"fixture_id": fixture_id, "case_id": case_id, "cohort": "primary", "version": version})
                finalize_result(result, reference, padded, "insecta_ITS_2", truth)
                atomic_write_json(output_root / "results" / f"{identity}.json", result)
                results.append(result)
    for diagnostic in protocol["diagnostic_cases"]:
        fixture_id = f"diagnostic-{diagnostic['case_id']}"
        fixture = fixture_map[fixture_id]
        reference = locate_reference(inventory_cases[diagnostic["case_id"]])
        padded = padded_sequence(fixture_id, reference)
        primer = inline_primer_string(diagnostic["diagnostic_parameters"])
        for selected_k in protocol["k_values"]:
            truth = fixture["truth_by_k"][str(selected_k)]
            for version, build in builds.items():
                identity = f"{fixture_id}-k{selected_k}-{version}"
                result = run_one(build, selected_k, identity, fixture, output_root, primer=primer)
                result.update({"fixture_id": fixture_id, "case_id": diagnostic["case_id"], "cohort": "diagnostic", "version": version})
                finalize_result(result, reference, padded, "target", truth)
                atomic_write_json(output_root / "results" / f"{identity}.json", result)
                results.append(result)
    for control_name, control in CONTROL_INPUTS.items():
        fixture_id = f"control-{control_name}"
        fixture_record = fixtures["controls"][control_name]
        fixture = {"fastq": fixture_record["fastq"], "derivation": fixture_record["derivation"]}
        source = inspect_fastq(fixture["fastq"]["path"])
        reference = source["sequences"][0]
        truth = {
            "start": 0,
            "end": len(reference),
            "length": control["truth_length"],
            "sha256": control["truth_sha256"],
        }
        for version, build in builds.items():
            identity = f"{fixture_id}-k19-{version}"
            result = run_one(build, 19, identity, fixture, output_root, primer=control["primer"])
            result.update({"fixture_id": fixture_id, "case_id": None, "cohort": "control", "version": version})
            finalize_result(
                result,
                reference,
                reference,
                "target",
                truth,
                control.get("known_wrong_sha256"),
            )
            atomic_write_json(output_root / "results" / f"{identity}.json", result)
            results.append(result)
    parity = count_parity(results)
    source_integrity = {}
    for label, receipt in frozen_sources.items():
        source_integrity[label] = {
            "expected_sha256": receipt["source"]["sha256"],
            "source_sha256_after": sha256_file(receipt["source"]["path"]),
            "frozen_sha256_after": sha256_file(receipt["frozen"]["path"]),
        }
    summary = {
        "schema_version": 1,
        "protocol": file_receipt(protocol_path),
        "inventory": file_receipt(inventory_path),
        "fixtures": file_receipt(fixtures_path),
        "build_manifests": {
            "historical": file_receipt(BUILD_MANIFEST),
            "current": file_receipt(CURRENT_BUILD_MANIFEST),
        },
        "frozen_execution_receipts": file_receipt(output_root / "receipts" / "receipts.json"),
        "source_integrity_after": source_integrity,
        "count_parity": parity,
        "results": results,
        "experiment_valid": all(
            result.get("status") == "complete"
            for result in results
            if result.get("cohort") != "assessment_only"
        )
        and all(item["counts_equal"] for item in parity)
        and all(
            value["expected_sha256"] == value["source_sha256_after"] == value["frozen_sha256_after"]
            for value in source_integrity.values()
        ),
        "limitations": protocol["limitations"],
    }
    atomic_write_json(output_root / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description="Reference-derived repeat-gate assessment")
    commands = parser.add_subparsers(dest="command", required=True)
    inventory = commands.add_parser("inventory")
    inventory.add_argument("--output", type=Path, required=True)
    protocol = commands.add_parser("protocol-template")
    protocol.add_argument("--inventory", type=Path, required=True)
    protocol.add_argument("--output", type=Path, required=True)
    generate = commands.add_parser("generate")
    generate.add_argument("--protocol", type=Path, required=True)
    generate.add_argument("--inventory", type=Path, required=True)
    generate.add_argument("--output", type=Path, required=True)
    run = commands.add_parser("run")
    run.add_argument("--protocol", type=Path, required=True)
    run.add_argument("--inventory", type=Path, required=True)
    run.add_argument("--fixtures", type=Path, required=True)
    run.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.command == "inventory":
        if arguments.output.exists():
            raise ValueError("Inventory output exists")
        atomic_write_json(arguments.output, inventory_document())
    elif arguments.command == "protocol-template":
        if arguments.output.exists():
            raise ValueError("Protocol output exists")
        inventory_data = load_json(arguments.inventory)
        atomic_write_json(
            arguments.output,
            protocol_template(inventory_data, arguments.inventory),
        )
    elif arguments.command == "generate":
        generate_fixtures(arguments.protocol, arguments.inventory, arguments.output)
    else:
        run_experiment(
            arguments.protocol,
            arguments.inventory,
            arguments.fixtures,
            arguments.output,
        )


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    main()
