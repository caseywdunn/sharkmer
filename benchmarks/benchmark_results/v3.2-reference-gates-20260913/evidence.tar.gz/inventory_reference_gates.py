#!/usr/bin/env python3
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import yaml


IUPAC = set("ACGTRYSWKMBDHVN")
BASES = set("ACGT")
IUPAC_BASES = {
    "A": "A", "C": "C", "G": "G", "T": "T", "R": "AG", "Y": "CT",
    "S": "GC", "W": "AT", "K": "GT", "M": "AC", "B": "CGT", "D": "AGT",
    "H": "ACT", "V": "ACG", "N": "ACGT",
}


def sha256_bytes(contents):
    return hashlib.sha256(contents).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    value = json.loads(Path(path).read_text())
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def load_yaml(path):
    value = yaml.safe_load(Path(path).read_text())
    if not isinstance(value, dict):
        raise ValueError(f"Expected YAML object: {path}")
    return value


def write_json(path, value, overwrite):
    with Path(path).open("w" if overwrite else "x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def derived_gene_name(primer):
    gene, region, index = primer.get("gene"), primer.get("region"), primer.get("index")
    if not isinstance(gene, str) or not gene:
        raise ValueError("Primer lacks gene")
    if region is not None and not isinstance(region, str):
        raise ValueError(f"Primer {gene} has invalid region")
    if index is not None and type(index) is not int:
        raise ValueError(f"Primer {gene} has invalid index")
    value = gene if region is None else f"{gene}-{region}"
    return value if index is None else f"{value}_{index}"


def sequence_metrics(sequence):
    normalized = sequence.upper()
    characters = set(normalized)
    return {
        "length": len(normalized),
        "acgt_bases": sum(base in BASES for base in normalized),
        "ambiguity_bases": sum(base in IUPAC - BASES for base in normalized),
        "invalid_bases": sum(base not in IUPAC for base in normalized),
        "alphabet": "".join(sorted(characters)),
        "sha256": sha256_bytes(normalized.encode()),
    }


def reverse_complement(sequence):
    translation = str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN")
    return sequence.upper().translate(translation)[::-1]


def iupac_positions(primer, sequence):
    positions = []
    normalized = sequence.upper()
    for start in range(len(normalized) - len(primer) + 1):
        segment = normalized[start:start + len(primer)]
        if all(base in BASES and base in IUPAC_BASES[pattern] for pattern, base in zip(primer, segment)):
            positions.append(start)
    return positions


def configured_amplicons(primer, sequence):
    metrics = sequence_metrics(sequence)
    if metrics["ambiguity_bases"] or metrics["invalid_bases"]:
        return {"status": "full_primer_scan_skipped_ambiguous_reference", "amplicons": []}
    forward = primer.get("forward_seq")
    reverse = primer.get("reverse_seq")
    if not isinstance(forward, str) or not isinstance(reverse, str):
        return {"status": "full_primer_scan_missing_primer_sequence", "amplicons": []}
    reverse_binding = reverse_complement(reverse)
    candidates = []
    for orientation, oriented in (("same_strand", sequence.upper()), ("reverse_complement", reverse_complement(sequence))):
        for forward_start in iupac_positions(forward.upper(), oriented):
            for reverse_start in iupac_positions(reverse_binding, oriented):
                if reverse_start < forward_start + len(forward):
                    continue
                length = reverse_start + len(reverse_binding) - forward_start
                if primer.get("min_length") <= length <= primer.get("max_length"):
                    candidates.append({
                        "orientation": orientation,
                        "forward_start": forward_start,
                        "reverse_start": reverse_start,
                        "length": length,
                        "sequence": oriented[forward_start:reverse_start + len(reverse_binding)],
                    })
    return {
        "status": "full_primer_pair_found" if candidates else "full_primer_pair_not_found",
        "amplicons": candidates,
    }


def accession_parts(accession):
    if not isinstance(accession, str) or not accession:
        return None, None
    prefix, separator, version = accession.rpartition(".")
    return (prefix, version) if separator and version.isdigit() else (accession, None)


def parse_fasta(path):
    records, header, parts = [], None, []
    for raw_line in Path(path).read_text().splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if header is not None:
                records.append((header, "".join(parts).upper()))
            header, parts = line[1:], []
        else:
            if header is None:
                raise ValueError(f"FASTA sequence before header: {path}")
            parts.append(line)
    if header is not None:
        records.append((header, "".join(parts).upper()))
    return records


def load_panels(repo):
    panel_paths = sorted((Path(repo) / "panels").glob("*.yaml"))
    panels, references, targets = [], [], []
    for path in panel_paths:
        if path.parent.name != "panels" or path.name == "reference.yaml":
            continue
        contents = path.read_bytes()
        panel = load_yaml(path)
        panel_name = panel.get("name")
        if not isinstance(panel_name, str):
            raise ValueError(f"Panel lacks name: {path}")
        primer_records, derived_to_logical = [], {}
        for primer in panel.get("primers", []):
            derived = derived_gene_name(primer)
            if derived in derived_to_logical:
                raise ValueError(f"Duplicate derived primer name: {panel_name}/{derived}")
            logical = primer["gene"]
            derived_to_logical[derived] = logical
            record = {
                "derived_gene": derived,
                "logical_gene": logical,
                "region": primer.get("region"),
                "index": primer.get("index"),
                "copy_number": primer.get("copy_number"),
                "gene_type": primer.get("gene_type"),
                "compartment": primer.get("compartment"),
                "trim": primer.get("trim"),
                "min_length": primer.get("min_length"),
                "max_length": primer.get("max_length"),
                "forward_seq": primer.get("forward_seq"),
                "reverse_seq": primer.get("reverse_seq"),
                "mismatches": primer.get("mismatches"),
            }
            primer_records.append(record)
            if primer.get("copy_number") == "high_copy":
                targets.append({"panel": panel_name, **record})
        reference_records = []
        for reference_group in panel.get("references", []) or []:
            reference_gene = reference_group.get("gene")
            if not isinstance(reference_gene, str):
                raise ValueError(f"Reference group lacks gene: {panel_name}")
            logical_gene = derived_to_logical.get(reference_gene, reference_gene)
            for entry in reference_group.get("sequences", []):
                sequence = entry.get("sequence")
                if not isinstance(sequence, str):
                    raise ValueError(f"Reference lacks sequence: {panel_name}/{reference_gene}")
                accession, version = accession_parts(entry.get("accession"))
                record = {
                    "panel": panel_name,
                    "panel_path": str(path),
                    "panel_sha256": sha256_bytes(contents),
                    "panel_version": panel.get("panel_version"),
                    "reference_gene": reference_gene,
                    "logical_gene": logical_gene,
                    "taxon": entry.get("taxon"),
                    "accession": entry.get("accession"),
                    "accession_base": accession,
                    "accession_version": version,
                    "sequence": sequence.upper(),
                    **sequence_metrics(sequence),
                }
                primer = next((entry for entry in primer_records if entry["derived_gene"] == reference_gene), None)
                if primer is not None:
                    callability = configured_amplicons(primer, sequence)
                    record["strict_full_primer_scan"] = {
                        "status": callability["status"],
                        "reference_length_within_configured_range": primer["min_length"] <= len(sequence) <= primer["max_length"],
                        "reference_length_reason": (
                            "within_configured_range"
                            if primer["min_length"] <= len(sequence) <= primer["max_length"]
                            else "reference_shorter_than_configured_minimum"
                            if len(sequence) < primer["min_length"]
                            else "reference_longer_than_configured_maximum"
                        ),
                        "amplicon_count": len(callability["amplicons"]),
                        "amplicons": [{key: value for key, value in candidate.items() if key != "sequence"} for candidate in callability["amplicons"]],
                    }
                else:
                    record["strict_full_primer_scan"] = {"status": "unmapped_reference_gene", "amplicon_count": 0, "amplicons": []}
                references.append(record)
                reference_records.append({key: value for key, value in record.items() if key != "sequence"})
        panels.append({
            "name": panel_name,
            "path": str(path),
            "sha256": sha256_bytes(contents),
            "panel_version": panel.get("panel_version"),
            "primer_mappings": primer_records,
            "reference_count": len(reference_records),
            "references": reference_records,
        })
    return panels, references, targets


def baseline_sequences(execution):
    by_digest = defaultdict(list)
    for result_path in sorted((Path(execution) / "results").glob("*.json")):
        result = load_json(result_path)
        invocation = result.get("signature", {}).get("invocation", {})
        if invocation.get("version") != "baseline":
            continue
        attempt = Path(result.get("attempt_dir", "")) / "output"
        for receipt in result.get("raw_output_files", []):
            relative = receipt.get("path") if isinstance(receipt, dict) else None
            if not isinstance(relative, str) or not relative.endswith(".fasta"):
                continue
            fasta = attempt / relative
            expected = receipt.get("sha256")
            if not fasta.is_file() or fasta.is_symlink() or sha256_file(fasta) != expected:
                raise ValueError(f"Raw FASTA receipt mismatch: {fasta}")
            for header, sequence in parse_fasta(fasta):
                digest = sha256_bytes(sequence.encode())
                by_digest[digest].append({
                    "path": str(fasta),
                    "file_sha256": expected,
                    "header": header,
                    "sequence": sequence,
                    **sequence_metrics(sequence),
                })
    return by_digest


def exact_relationship(query, reference):
    reverse = reverse_complement(reference)
    if query == reference:
        return "exact_same_strand"
    if query == reverse:
        return "exact_reverse_complement"
    if query in reference:
        return "query_subsequence_same_strand"
    if query in reverse:
        return "query_subsequence_reverse_complement"
    if reference in query:
        return "reference_subsequence_same_strand"
    if reverse in query:
        return "reference_subsequence_reverse_complement"
    return None


def compare_lost_products(audit, raw_sequences, references, panels):
    panel_by_name = {panel["name"]: panel for panel in panels}
    insecta = panel_by_name.get("insecta")
    if insecta is None:
        raise ValueError("Insecta panel missing")
    logical_by_derived = {
        primer["derived_gene"]: primer["logical_gene"]
        for primer in insecta["primer_mappings"]
    }
    primer_by_derived = {primer["derived_gene"]: primer for primer in insecta["primer_mappings"]}
    audits = audit.get("high_copy_lost_gene_audits")
    if not isinstance(audits, list):
        raise ValueError("Diagnostic audit lacks high-copy lost products")
    findings = []
    for gene_audit in audits:
        gene = gene_audit.get("gene")
        logical_gene = logical_by_derived.get(gene)
        if logical_gene is None:
            raise ValueError(f"Lost gene has no insecta primer mapping: {gene}")
        for product in gene_audit.get("lost_products", []):
            digest = product.get("sha256")
            sequence_records = raw_sequences.get(digest, [])
            if not sequence_records:
                raise ValueError(f"Lost product {digest} has no verified raw FASTA record")
            if len({record["sequence"] for record in sequence_records}) != 1:
                raise ValueError(f"Lost product {digest} has non-identical verified raw FASTA records")
            raw = sequence_records[0]
            comparisons = []
            source_primer = primer_by_derived[gene]
            for reference in references:
                if reference["logical_gene"] != logical_gene:
                    continue
                relationship = exact_relationship(raw["sequence"], reference["sequence"])
                bounded = configured_amplicons(source_primer, reference["sequence"])
                bounded_relationships = []
                for amplicon in bounded["amplicons"]:
                    if raw["sequence"] == amplicon["sequence"]:
                        bounded_relationships.append({
                            "relationship": "strict_full_primer_bounded_exact_same_strand",
                            "orientation": amplicon["orientation"],
                            "forward_start": amplicon["forward_start"],
                            "reverse_start": amplicon["reverse_start"],
                            "length": amplicon["length"],
                        })
                    elif raw["sequence"] == reverse_complement(amplicon["sequence"]):
                        bounded_relationships.append({
                            "relationship": "strict_full_primer_bounded_exact_reverse_complement",
                            "orientation": amplicon["orientation"],
                            "forward_start": amplicon["forward_start"],
                            "reverse_start": amplicon["reverse_start"],
                            "length": amplicon["length"],
                        })
                comparisons.append({
                    "relationship": relationship,
                    "strict_full_primer_scan_status": bounded["status"],
                    "strict_full_primer_bounded_exact_matches": bounded_relationships,
                    "same_derived_gene": reference["panel"] == "insecta" and reference["reference_gene"] == gene,
                    "same_logical_gene_other_index_or_panel": not (reference["panel"] == "insecta" and reference["reference_gene"] == gene),
                    **{key: value for key, value in reference.items() if key != "sequence"},
                })
            exact = [comparison for comparison in comparisons if comparison["relationship"] in {"exact_same_strand", "exact_reverse_complement"}]
            subsequence = [comparison for comparison in comparisons if comparison["relationship"] and comparison not in exact]
            findings.append({
                "cell": gene_audit.get("cell"),
                "derived_gene": gene,
                "logical_gene": logical_gene,
                "lost_product": {key: value for key, value in product.items() if key != "sequence"},
                "raw_fasta": {key: value for key, value in raw.items() if key != "sequence"},
                "raw_fasta_verified_occurrences": [
                    {key: value for key, value in record.items() if key != "sequence"}
                    for record in sequence_records
                ],
                "same_logical_gene_reference_count": len(comparisons),
                "exact_reference_matches": exact,
                "exact_subsequence_matches": subsequence,
                "all_same_logical_gene_references": comparisons,
            })
    return findings


def summarize_references(references, targets, panels):
    all_lengths = [reference["length"] for reference in references]
    with_accession = sum(isinstance(reference["accession"], str) and bool(reference["accession"]) for reference in references)
    eligible = []
    for target in targets:
        matches = [
            reference
            for reference in references
            if reference["panel"] == target["panel"] and reference["reference_gene"] == target["derived_gene"]
        ]
        eligible.append({
            **target,
            "reference_count": len(matches),
            "accessions": [reference["accession"] for reference in matches],
        })
    return {
        "builtin_panel_count": len(panels),
        "embedded_reference_count": len(references),
        "references_with_accession": with_accession,
        "reference_bases": sum(all_lengths),
        "reference_acgt_bases": sum(reference["acgt_bases"] for reference in references),
        "reference_ambiguity_bases": sum(reference["ambiguity_bases"] for reference in references),
        "reference_invalid_bases": sum(reference["invalid_bases"] for reference in references),
        "minimum_reference_length": min(all_lengths) if all_lengths else None,
        "maximum_reference_length": max(all_lengths) if all_lengths else None,
        "eligible_high_copy_targets": eligible,
    }


def main():
    parser = argparse.ArgumentParser(description="Inventory embedded panel references and exact lost-product evidence")
    parser.add_argument("--repo", type=Path, default=Path("/home/claude/repos/sharkmer"))
    parser.add_argument("--audit", type=Path, default=Path("/tmp/sharkmer-high-copy-20260911/final-analysis/diagnostic-audit.json"))
    parser.add_argument("--execution", type=Path, default=Path("/tmp/sharkmer-high-copy-20260911/final-execution"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    arguments = parser.parse_args()
    if arguments.output.exists() and not arguments.overwrite:
        raise SystemExit(f"Output already exists: {arguments.output}")
    panels, references, targets = load_panels(arguments.repo)
    evidence = {
        "schema_version": 1,
        "panel_inventory": summarize_references(references, targets, panels),
        "panels": panels,
        "lost_product_reference_evidence": compare_lost_products(
            load_json(arguments.audit), baseline_sequences(arguments.execution), references, panels
        ),
        "interpretation": [
            "Exact same-strand or reverse-complement equality to an accessioned panel reference is sequence-oracle evidence for that emitted sequence; it does not by itself establish read phase, abundance, or copy count.",
            "Logical marker comparisons retain primer index and panel provenance. A different primer index is not treated as a different biological marker merely because the output identifier differs.",
            "Subsequence matches are reported separately from exact equality and do not establish a complete amplicon reference match.",
            "The strict full-primer scan is diagnostic only. Production seeds retained 3-prime primer suffixes of min(trim, k-1) and permits configured mismatch handling, so a missing full-primer pair never makes a reference or product uncallable.",
            "This offline inventory performs no alignment, download, Sharkmer run, or repeat-gate decision.",
        ],
    }
    write_json(arguments.output, evidence, arguments.overwrite)
    print(arguments.output)


if __name__ == "__main__":
    main()
