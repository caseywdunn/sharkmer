import copy
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest


HARNESS_PATH = Path(__file__).with_name("harness.py")


def load_harness():
    specification = importlib.util.spec_from_file_location("reference_gate_harness", HARNESS_PATH)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.harness = load_harness()

    def primer(self, minimum=10, maximum=100):
        return {
            "gene": "target",
            "forward_seq": "GGGACGT",
            "reverse_seq": "CCCTGCA",
            "min_length": minimum,
            "max_length": maximum,
            "min_count": 2,
            "mismatches": 0,
            "trim": 4,
        }

    def test_reverse_complement_supports_iupac(self):
        self.assertEqual(self.harness.reverse_complement("ARYKMBVDHN"), "NDHBVKMRYT")

    def test_unique_internal_primer_bounded_truth_is_explicit(self):
        sequence = "TTTT" + "ACGT" + "G" * 12 + "TGCA" + "AAAA"
        analysis = self.harness.reference_binding_analysis(sequence, self.primer(), 19)
        self.assertEqual(analysis["category"], "callable_primer_bounded_substring_exact")
        self.assertEqual(analysis["truth"]["start"], 4)
        self.assertEqual(analysis["truth"]["end"], 24)
        self.assertEqual(analysis["truth"]["length"], 20)

    def test_full_reference_and_length_uncallable_are_distinct(self):
        sequence = "ACGT" + "G" * 12 + "TGCA"
        full = self.harness.reference_binding_analysis(sequence, self.primer(), 19)
        self.assertEqual(full["category"], "callable_full_reference_exact")
        too_short = self.harness.reference_binding_analysis(
            sequence, self.primer(minimum=30), 19
        )
        self.assertEqual(too_short["category"], "uncallable_length_or_orientation")

    def test_ambiguous_reference_is_not_claimed_as_exact_truth(self):
        sequence = "ACGT" + "G" * 5 + "N" + "G" * 6 + "TGCA"
        analysis = self.harness.reference_binding_analysis(sequence, self.primer(), 19)
        self.assertEqual(analysis["category"], "uncallable_non_acgt_reference")
        self.assertIsNone(analysis["truth"])

    def test_deterministic_tiling_has_uniform_per_occurrence_support(self):
        case = {
            "case_id": "fixture",
            "reference_length": 20,
            "primer_parameters": self.primer(),
        }
        sequence = "ACGT" + "G" * 12 + "TGCA"
        records, derivation = self.harness.fastq_records(case, sequence)
        self.assertEqual(derivation["window_count"], len(sequence) + 149)
        self.assertEqual(derivation["read_count"], 2 * (len(sequence) + 149))
        self.assertEqual(derivation["per_occurrence_canonical_kmer_support"]["19"], 264)
        self.assertEqual(derivation["per_occurrence_canonical_kmer_support"]["31"], 240)
        self.assertTrue(all(len(sequence_value) == 150 for unused_name, sequence_value, unused_quality in records))

    def test_flank_created_product_is_rejected(self):
        case = {
            "case_id": "fixture",
            "reference_length": 20,
            "primer_parameters": self.primer(),
        }
        sequence = "ACGT" + "G" * 12 + "TGCA"
        padded = "ACGT" + "G" * 12 + "TGCA" + sequence
        with self.assertRaisesRegex(ValueError, "flank creates"):
            self.harness.validate_no_flank_binding(case, padded, 20)

    def test_inventory_is_exactly_29_hydrozoa_plus_gryllus(self):
        inventory = self.harness.inventory_document()
        self.assertEqual(len(inventory["cases"]), 30)
        self.assertEqual(
            sum(case["panel"] == "hydrozoa" for case in inventory["cases"]), 29
        )
        gryllus = [case for case in inventory["cases"] if case["panel"] == "insecta"]
        self.assertEqual(len(gryllus), 1)
        self.assertEqual(gryllus[0]["accession"], "AK281180")
        self.assertEqual(
            gryllus[0]["reference_scope"]["status"],
            "panel_bootstrap_sequence_not_full_deposited_accession",
        )
        self.assertIn("256 bp internal match", gryllus[0]["reference_scope"]["reason"])

    def test_partial_reference_scope_is_explicit(self):
        inventory = self.harness.inventory_document()
        cases = {case["accession"]: case for case in inventory["cases"]}
        for accession in ("KP776745.1", "JQ410732.1", "EU272542.1"):
            self.assertEqual(cases[accession]["reference_scope"]["status"], "known_partial")
            self.assertTrue(cases[accession]["reference_scope"]["reason"])

    def test_protocol_registers_exact_native_diagnostic_cohort(self):
        with TemporaryDirectory() as temporary:
            inventory_path = Path(temporary) / "inventory.json"
            inventory = self.harness.inventory_document()
            self.harness.atomic_write_json(inventory_path, inventory)
            protocol = self.harness.protocol_template(inventory, inventory_path)
            self.assertEqual(len(protocol["diagnostic_cases"]), 23)
            self.assertEqual(protocol["primary_case_ids"], ["insecta-ITS_2-AK281180"])
            for diagnostic in protocol["diagnostic_cases"]:
                source_case = next(
                    case for case in inventory["cases"] if case["case_id"] == diagnostic["case_id"]
                )
                sequence = self.harness.locate_reference(source_case)
                parameters = diagnostic["diagnostic_parameters"]
                self.assertEqual(parameters["forward_seq"], sequence[:15])
                self.assertEqual(parameters["reverse_seq"], self.harness.reverse_complement(sequence[-15:]))
                self.assertEqual(parameters["mismatches"], 0)
                self.assertEqual(parameters["trim"], 15)
                self.assertEqual(parameters["min_length"], 100)
                self.assertEqual(parameters["max_length"], len(sequence) + 500)

    def test_product_classification_preserves_all_outcomes(self):
        reference = "AACCGGTTAGTCCGTA"
        padded = "TTTT" + reference + "GGGG"
        self.assertEqual(
            self.harness.classify_product(reference, reference, padded),
            "full_reference_exact",
        )
        self.assertEqual(
            self.harness.classify_product(self.harness.reverse_complement(reference), reference, padded),
            "full_reference_reverse_complement_exact",
        )
        self.assertEqual(
            self.harness.classify_product(reference[2:-2], reference, padded),
            "internal_exact_substring",
        )
        self.assertEqual(
            self.harness.classify_product(padded[:8], reference, padded),
            "flank_dependent_contiguous",
        )
        self.assertEqual(
            self.harness.classify_product("ACACACAC", reference, padded),
            "noncontiguous_or_collapsed",
        )

    def test_control_truth_lengths_and_hashes_are_frozen(self):
        expected_lengths = {"clean_positive_a18": 138, "collapsed_negative_a40": 160}
        for name, expected_length in expected_lengths.items():
            control = self.harness.CONTROL_INPUTS[name]
            inspected = self.harness.inspect_fastq(control["path"])
            self.assertEqual(set(map(len, inspected["sequences"])), {expected_length})
            self.assertEqual(
                {self.harness.sha256_text(sequence) for sequence in inspected["sequences"]},
                {control["truth_sha256"]},
            )

    def test_build_receipts_match_clean_binaries(self):
        protocol = {"builds": copy.deepcopy(self.harness.EXPECTED_BUILDS)}
        builds = self.harness.resolve_builds(protocol)
        self.assertEqual(set(builds), {"pre132", "post132", "current"})
        for name, build in builds.items():
            self.assertEqual(
                self.harness.sha256_file(build["binary_path"]),
                self.harness.EXPECTED_BUILDS[name]["binary_sha256"],
            )

    def test_fastq_writer_preserves_forward_and_reverse_records(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "reads.fastq"
            records = [("forward", "ACGT", "IIII"), ("reverse", "ACGT", "IIII")]
            self.harness.write_fastq(path, records)
            self.assertEqual(path.read_text().count("\n"), 8)


if __name__ == "__main__":
    unittest.main()
