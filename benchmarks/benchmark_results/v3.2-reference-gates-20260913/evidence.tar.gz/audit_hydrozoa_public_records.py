#!/usr/bin/env python3
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml


WORKSPACE = Path("/tmp/sharkmer-reference-gates-20260913")
PUBLIC_RECORDS = WORKSPACE / "public-records"
PANEL_PATH = Path("/tmp/sharkmer-high-copy-20260911/issue155-build/sources/candidate/panels/hydrozoa.yaml")
METADATA_PATH = PUBLIC_RECORDS / "hydrozoa_metadata.json"
FASTA_PATH = PUBLIC_RECORDS / "hydrozoa_29.fasta"
MAX_FASTA_BYTES = 20 * 1024 * 1024
FASTA_REQUEST_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=<29 registered hydrozoa accessions>&rettype=fasta&retmode=text"
METADATA_REQUEST_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=nuccore&id=<29 registered hydrozoa accessions>&retmode=json"
FASTA_RETRIEVED_AT = "2026-09-13T12:16:17.381933+00:00"
METADATA_RETRIEVED_AT = "2026-09-13T12:15:57.071052+00:00"
COMPLEMENT = str.maketrans("ACGT", "TGCA")


def sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha256_text(value):
    return sha256_bytes(value.encode())


def file_receipt(path):
    regular_path = Path(path).resolve()
    if not regular_path.is_file() or regular_path.is_symlink():
        raise ValueError(f"Expected regular file: {regular_path}")
    contents = regular_path.read_bytes()
    return {
        "path": str(regular_path),
        "size_bytes": len(contents),
        "sha256": sha256_bytes(contents),
    }


def read_fasta_records(path):
    records = {}
    header = None
    sequence_parts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                accession_version = header.split(maxsplit=1)[0]
                if accession_version in records:
                    raise ValueError(f"Duplicate public FASTA accession: {accession_version}")
                records[accession_version] = (header, "".join(sequence_parts).upper())
            header = line[1:]
            sequence_parts = []
        elif line.strip():
            sequence_parts.append(line.strip())
    if header is None:
        raise ValueError("Missing public FASTA records")
    accession_version = header.split(maxsplit=1)[0]
    if accession_version in records:
        raise ValueError(f"Duplicate public FASTA accession: {accession_version}")
    records[accession_version] = (header, "".join(sequence_parts).upper())
    return records


def reverse_complement(sequence):
    if any(base not in "ACGT" for base in sequence):
        raise ValueError("Reverse-complement comparison only supports ACGT panel references")
    return sequence.translate(COMPLEMENT)[::-1]


def all_positions(haystack, needle):
    positions = []
    start_index = 0
    while True:
        position = haystack.find(needle, start_index)
        if position < 0:
            return positions
        positions.append(position)
        start_index = position + 1


def longest_exact_blocks(query_sequence, subject_sequence):
    subject_positions = {}
    for subject_index in range(len(subject_sequence) - 14):
        subject_positions.setdefault(subject_sequence[subject_index : subject_index + 15], []).append(subject_index)
    best_length = 0
    best_blocks = set()
    for query_index in range(len(query_sequence) - 14):
        query_seed = query_sequence[query_index : query_index + 15]
        for subject_index in subject_positions.get(query_seed, []):
            match_length = 15
            while (
                query_index + match_length < len(query_sequence)
                and subject_index + match_length < len(subject_sequence)
                and query_sequence[query_index + match_length] == subject_sequence[subject_index + match_length]
            ):
                match_length += 1
            if match_length > best_length:
                best_length = match_length
                best_blocks = {(query_index, subject_index, match_length)}
            elif match_length == best_length:
                best_blocks.add((query_index, subject_index, match_length))
    return [
        {"panel_start": query_index, "public_start": subject_index, "length": match_length}
        for query_index, subject_index, match_length in sorted(best_blocks)
    ]


def panel_references():
    panel = yaml.safe_load(PANEL_PATH.read_text())
    if not isinstance(panel, dict) or not isinstance(panel.get("references"), list):
        raise ValueError("Invalid hydrozoa panel")
    records = []
    for group in panel["references"]:
        for reference in group["sequences"]:
            sequence = reference["sequence"].upper()
            records.append({
                "gene": group["gene"],
                "taxon": reference["taxon"],
                "accession": reference["accession"],
                "sequence": sequence,
                "length": len(sequence),
                "sha256": sha256_text(sequence),
                "non_acgt_bases": "".join(sorted({base for base in sequence if base not in "ACGT"})),
            })
    if len(records) != 29:
        raise ValueError(f"Expected 29 hydrozoa panel references, found {len(records)}")
    return records


def metadata_by_version():
    metadata = json.loads(METADATA_PATH.read_text())
    result = metadata.get("result", {})
    records = {}
    for identifier in result.get("uids", []):
        record = result.get(identifier)
        if not isinstance(record, dict):
            raise ValueError(f"Missing public metadata record {identifier}")
        accession_version = record.get("accessionversion")
        if not isinstance(accession_version, str):
            raise ValueError(f"Missing accession version for {identifier}")
        records[accession_version] = record
    if len(records) != 29:
        raise ValueError(f"Expected 29 metadata records, found {len(records)}")
    return records


def audit_document():
    fasta_receipt = file_receipt(FASTA_PATH)
    if fasta_receipt["size_bytes"] > MAX_FASTA_BYTES:
        raise ValueError(f"Public FASTA exceeds {MAX_FASTA_BYTES} byte cap")
    public_fasta = read_fasta_records(FASTA_PATH)
    public_metadata = metadata_by_version()
    references = panel_references()
    cases = []
    for reference in references:
        expected_version = reference["accession"]
        if expected_version not in public_fasta or expected_version not in public_metadata:
            raise ValueError(f"Public response missing {expected_version}")
        header, public_sequence = public_fasta[expected_version]
        metadata = public_metadata[expected_version]
        if len(public_sequence) != metadata.get("slen"):
            raise ValueError(f"Public sequence length differs from metadata for {expected_version}")
        same_orientation_positions = all_positions(public_sequence, reference["sequence"])
        reverse_positions = []
        if not reference["non_acgt_bases"]:
            reverse_positions = all_positions(public_sequence, reverse_complement(reference["sequence"]))
        relationship = (
            "exact_full_same_orientation" if reference["sequence"] == public_sequence else
            "same_orientation_subsequence" if same_orientation_positions else
            "reverse_complement_subsequence" if reverse_positions else
            "not_compared_non_acgt_panel_reference" if reference["non_acgt_bases"] else
            "no_exact_acgt_subsequence_match"
        )
        cases.append({
            key: value for key, value in reference.items() if key != "sequence"
        } | {
            "public_header": header,
            "public_accession_version": metadata["accessionversion"],
            "public_organism": metadata["organism"],
            "public_taxid": metadata["taxid"],
            "public_sequence_length": len(public_sequence),
            "public_sequence_sha256": sha256_text(public_sequence),
            "same_orientation_positions": same_orientation_positions,
            "reverse_complement_positions": reverse_positions,
            "longest_same_orientation_blocks": longest_exact_blocks(reference["sequence"], public_sequence),
            "relationship": relationship,
        })
    acgt_cases = [case for case in cases if not case["non_acgt_bases"]]
    ambiguous_cases = [case for case in cases if case["non_acgt_bases"]]
    corroborated_acgt_cases = [
        case for case in acgt_cases
        if case["same_orientation_positions"] or case["reverse_complement_positions"]
    ]
    return {
        "schema_version": 1,
        "purpose": "Post-hoc public-record provenance validation for frozen hydrozoa source templates; no fixture, panel, or production change.",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_receipts": {
            "frozen_hydrozoa_panel": file_receipt(PANEL_PATH),
            "ncbi_metadata": {**file_receipt(METADATA_PATH), "request_url": METADATA_REQUEST_URL, "retrieved_at": METADATA_RETRIEVED_AT},
            "ncbi_fasta": {**fasta_receipt, "request_url": FASTA_REQUEST_URL, "retrieved_at": FASTA_RETRIEVED_AT, "max_size_bytes": MAX_FASTA_BYTES},
        },
        "summary": {
            "panel_references": len(cases),
            "public_records": len(public_fasta),
            "acgt_panel_references": len(acgt_cases),
            "ambiguous_panel_references_excluded_from_acgt_oracle": len(ambiguous_cases),
            "acgt_exact_or_reverse_complement_substring_matches": len(corroborated_acgt_cases),
            "acgt_unmatched_case_ids": [
                f"{case['gene']}/{case['accession']}" for case in acgt_cases
                if not case["same_orientation_positions"] and not case["reverse_complement_positions"]
            ],
            "ambiguous_case_ids": [f"{case['gene']}/{case['accession']}" for case in ambiguous_cases],
        },
        "cases": cases,
        "limitations": [
            "Non-ACGT panel references are retained in the receipt but excluded from the no-error ACGT fixture oracle.",
            "Public-record containment establishes source-template provenance only; it does not establish read phasing, graph resolution, or biological copy count.",
            "The native endpoint diagnostic remains a source-derived fixture check and is not hydrozoa-panel recovery evidence.",
        ],
    }


def main():
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--output", type=Path, default=PUBLIC_RECORDS / "hydrozoa_public_provenance_final.json")
    arguments = argument_parser.parse_args()
    if arguments.output.exists():
        raise ValueError(f"Output exists: {arguments.output}")
    document = audit_document()
    arguments.output.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n")
    print(json.dumps(document["summary"], sort_keys=True))


if __name__ == "__main__":
    main()
