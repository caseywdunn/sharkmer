#!/usr/bin/env python3
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import yaml


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def reverse_complement(sequence):
    return sequence.translate(str.maketrans("ACGT", "TGCA"))[::-1]


def occurrences(sequence, node_length):
    values = defaultdict(list)
    for position in range(len(sequence) - node_length + 1):
        values[sequence[position:position + node_length]].append(position)
    return values


def reference_sequence(panel_path, accession, gene):
    panel = yaml.safe_load(Path(panel_path).read_text())
    for group in panel.get("references", []):
        if group.get("gene") != gene:
            continue
        for entry in group.get("sequences", []):
            if entry.get("accession") == accession:
                sequence = entry.get("sequence")
                if isinstance(sequence, str) and set(sequence.upper()) <= set("ACGT"):
                    return panel, sequence.upper()
    raise ValueError(f"No unambiguous {gene}/{accession} reference in {panel_path}")


def probe(sequence, kmer_length):
    node_length = kmer_length - 1
    forward = occurrences(sequence, node_length)
    reverse_sequence = reverse_complement(sequence)
    reverse = occurrences(reverse_sequence, node_length)
    forward_repeats = {motif: positions for motif, positions in forward.items() if len(positions) > 1}
    reverse_repeats = {motif: positions for motif, positions in reverse.items() if len(positions) > 1}
    shared = []
    for motif in sorted(set(forward) & set(reverse)):
        reverse_positions = reverse[motif]
        shared.append({
            "motif": motif,
            "forward_positions": forward[motif],
            "reverse_complement_positions": reverse_positions,
            "original_reference_positions_for_reverse_orientation": [
                len(sequence) - node_length - position for position in reverse_positions
            ],
        })
    return {
        "k": kmer_length,
        "node_length": node_length,
        "forward_distinct_nodes": len(forward),
        "reverse_complement_distinct_nodes": len(reverse),
        "forward_repeated_nodes": [
            {"motif": motif, "positions": positions} for motif, positions in sorted(forward_repeats.items())
        ],
        "reverse_complement_repeated_nodes": [
            {"motif": motif, "positions": positions} for motif, positions in sorted(reverse_repeats.items())
        ],
        "forward_reverse_shared_nodes": shared,
    }


def main():
    parser = argparse.ArgumentParser(description="Offline orientation motif audit for one accessioned reference")
    parser.add_argument("--panel", type=Path, default=Path("/home/claude/repos/sharkmer/panels/insecta.yaml"))
    parser.add_argument("--gene", default="ITS_2")
    parser.add_argument("--accession", default="AK281180")
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.output.exists():
        raise SystemExit(f"Output already exists: {arguments.output}")
    panel, sequence = reference_sequence(arguments.panel, arguments.accession, arguments.gene)
    result = {
        "schema_version": 1,
        "purpose": "Offline motif receipt for sense and reverse-complement reference orientations; not graph execution or read evidence.",
        "reference": {
            "panel_path": str(arguments.panel),
            "panel_sha256": sha256_file(arguments.panel),
            "panel_name": panel.get("name"),
            "panel_version": panel.get("panel_version"),
            "gene": arguments.gene,
            "accession": arguments.accession,
            "length": len(sequence),
            "sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest(),
        },
        "probes": [probe(sequence, kmer_length) for kmer_length in (19, 31)],
        "interpretation": [
            "A shared node means the same (k-1)-mer occurs in the sense reference and its reverse-complement orientation. It is a structural motif receipt, not proof that Sharkmer creates a graph cycle from one template.",
            "Absent within-orientation repeats or sense/reverse shared nodes does not exclude graph cycles caused by additional reads, coverage, sequencing errors, canonicalization, seed handling, or extension edges.",
            "No inference about repeat-gate correctness, read phase, abundance, or copy count is made here.",
        ],
    }
    with arguments.output.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(arguments.output)


if __name__ == "__main__":
    main()
