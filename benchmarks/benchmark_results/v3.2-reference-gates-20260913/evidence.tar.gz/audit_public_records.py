#!/usr/bin/env python3
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml


WORKSPACE = Path("/tmp/sharkmer-reference-gates-20260913")
EVIDENCE_PATH = WORKSPACE / "reference_gate_evidence_v3.json"
PUBLIC_RECORDS = WORKSPACE / "public-records"
RECORDS = {
    "AK281180": {
        "fasta": PUBLIC_RECORDS / "AK281180.fasta",
        "request_url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=AK281180&rettype=fasta&retmode=text",
        "retrieved_at": "2026-09-13T12:10:53.930710+00:00",
        "relevant_genes": {"ITS_2"},
    },
    "PP230540": {
        "fasta": PUBLIC_RECORDS / "PP230540.fasta",
        "request_url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=PP230540&rettype=fasta&retmode=text",
        "retrieved_at": "2026-09-13T12:11:09.318623+00:00",
        "relevant_genes": {"ND1", "CO1_1", "12S", "16S_2"},
    },
}
METADATA_PATH = PUBLIC_RECORDS / "metadata.json"
METADATA_REQUEST_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=nuccore&id=AK281180%2CPP230540&retmode=json"
METADATA_RETRIEVED_AT = "2026-09-13T12:11:22.824175+00:00"
INSECTA_PANEL = Path("/tmp/sharkmer-high-copy-20260911/issue155-build/sources/candidate/panels/insecta.yaml")
COMPLEMENT = str.maketrans("ACGT", "TGCA")


def sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha256_text(value):
    return sha256_bytes(value.encode())


def file_receipt(path):
    regular_path = Path(path).resolve()
    if not regular_path.is_file() or regular_path.is_symlink():
        raise ValueError(f"Expected regular file: {regular_path}")
    contents = regular_path.read_bytes()
    return {
        "path": str(regular_path),
        "size_bytes": len(contents),
        "sha256": sha256_bytes(contents),
    }


def read_fasta_records(path):
    records = []
    header = None
    sequence_parts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                records.append((header, "".join(sequence_parts)))
            header = line[1:]
            sequence_parts = []
        elif line.strip():
            sequence_parts.append(line.strip().upper())
    if header is None:
        raise ValueError(f"Missing FASTA header: {path}")
    records.append((header, "".join(sequence_parts)))
    for record_header, sequence in records:
        if not sequence or any(base not in "ACGT" for base in sequence):
            raise ValueError(f"Expected nonempty ACGT FASTA sequence: {path}")
    return records


def read_single_fasta(path):
    records = read_fasta_records(path)
    if len(records) != 1:
        raise ValueError(f"Expected exactly one FASTA record: {path}")
    return records[0]


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def all_positions(haystack, needle):
    positions = []
    start_index = 0
    while True:
        position = haystack.find(needle, start_index)
        if position < 0:
            return positions
        positions.append(position)
        start_index = position + 1


def parse_product(path, expected_sha256):
    matching_records = [
        (header, sequence)
        for header, sequence in read_fasta_records(path)
        if sha256_text(sequence) == expected_sha256
    ]
    if len(matching_records) != 1:
        raise ValueError(f"Expected one checksum-registered product record: {path}")
    header, sequence = matching_records[0]
    return {"header": header, "sequence": sequence, "receipt": file_receipt(path)}


def metadata_by_accession():
    data = json.loads(METADATA_PATH.read_text())
    records = data.get("result", {})
    output = {}
    for identifier in records.get("uids", []):
        record = records.get(identifier)
        if not isinstance(record, dict):
            raise ValueError(f"Missing NCBI summary for uid {identifier}")
        accession = record.get("caption")
        if accession in RECORDS:
            output[accession] = record
    if set(output) != set(RECORDS):
        raise ValueError("NCBI summary did not contain both requested accessions")
    return output


def comparison(product_sequence, record_sequence):
    reverse_product = reverse_complement(product_sequence)
    return {
        "exact_same_orientation": product_sequence == record_sequence,
        "exact_reverse_complement": reverse_product == record_sequence,
        "same_orientation_subsequence_starts": all_positions(record_sequence, product_sequence),
        "reverse_complement_subsequence_starts": all_positions(record_sequence, reverse_product),
        "record_subsequence_of_product_starts": all_positions(product_sequence, record_sequence),
        "record_reverse_complement_subsequence_of_product_starts": all_positions(product_sequence, reverse_complement(record_sequence)),
    }


def longest_exact_blocks(query_sequence, subject_sequence):
    subject_positions = {}
    for subject_index in range(len(subject_sequence)):
        subject_positions.setdefault(subject_sequence[subject_index : subject_index + 15], []).append(subject_index)
    best_length = 0
    best_blocks = set()
    for query_index in range(len(query_sequence) - 14):
        for subject_index in subject_positions.get(query_sequence[query_index : query_index + 15], []):
            length = 15
            while (
                query_index + length < len(query_sequence)
                and subject_index + length < len(subject_sequence)
                and query_sequence[query_index + length] == subject_sequence[subject_index + length]
            ):
                length += 1
            if length > best_length:
                best_length = length
                best_blocks = {(query_index, subject_index, length)}
            elif length == best_length:
                best_blocks.add((query_index, subject_index, length))
    return [
        {"query_start": query_index, "subject_start": subject_index, "length": length}
        for query_index, subject_index, length in sorted(best_blocks)
    ]


def panel_pp230540_references():
    panel = yaml.safe_load(INSECTA_PANEL.read_text())
    if not isinstance(panel, dict):
        raise ValueError("Invalid insecta panel")
    records = []
    for group in panel.get("references", []):
        for reference in group.get("sequences", []):
            if reference.get("accession") != "PP230540":
                continue
            sequence = reference["sequence"].upper()
            records.append({
                "gene": group["gene"],
                "taxon": reference["taxon"],
                "length": len(sequence),
                "sha256": sha256_text(sequence),
                "sequence": sequence,
            })
    if not records:
        raise ValueError("Expected PP230540 references in insecta panel")
    return records


def audit_document():
    evidence = json.loads(EVIDENCE_PATH.read_text())
    lost_items = evidence.get("lost_product_reference_evidence")
    if not isinstance(lost_items, list) or len(lost_items) != 7:
        raise ValueError("Expected seven registered old lost products")
    summary_records = metadata_by_accession()
    external_records = {}
    for accession, record_config in RECORDS.items():
        header, sequence = read_single_fasta(record_config["fasta"])
        summary = summary_records[accession]
        if summary.get("accessionversion") != f"{accession}.1":
            raise ValueError(f"Unexpected accession version for {accession}")
        if summary.get("organism") != "Gryllus bimaculatus":
            raise ValueError(f"Unexpected organism for {accession}")
        external_records[accession] = {
            "fasta_receipt": file_receipt(record_config["fasta"]),
            "request_url": record_config["request_url"],
            "retrieved_at": record_config["retrieved_at"],
            "header": header,
            "accession_version": summary["accessionversion"],
            "organism": summary["organism"],
            "taxid": summary["taxid"],
            "title": summary["title"],
            "sequence_length": len(sequence),
            "sequence_sha256": sha256_text(sequence),
            "sequence": sequence,
        }
    comparisons = []
    for item in lost_items:
        lost_product = item["lost_product"]
        raw_fasta = item["raw_fasta"]
        parsed = parse_product(raw_fasta["path"], lost_product["sha256"])
        product_record = {
            "cell": item["cell"],
            "gene": lost_product["gene"],
            "length": lost_product["length"],
            "sha256": lost_product["sha256"],
            "raw_fasta": parsed["receipt"],
            "raw_header": parsed["header"],
            "external_record_comparisons": {},
        }
        for accession, external in external_records.items():
            product_record["external_record_comparisons"][accession] = {
                "gene_marked_relevant": lost_product["gene"] in RECORDS[accession]["relevant_genes"],
                **comparison(parsed["sequence"], external["sequence"]),
            }
        comparisons.append(product_record)
    pp230540_sequence = external_records["PP230540"]["sequence"]
    panel_reference_comparisons = []
    for reference in panel_pp230540_references():
        comparison_result = comparison(reference["sequence"], pp230540_sequence)
        comparison_result["longest_same_orientation_blocks"] = longest_exact_blocks(reference["sequence"], pp230540_sequence)
        comparison_result["longest_reverse_complement_blocks"] = longest_exact_blocks(
            reverse_complement(reference["sequence"]), pp230540_sequence
        )
        panel_reference_comparisons.append({
            key: value for key, value in reference.items() if key != "sequence"
        } | comparison_result)
    for product_record in comparisons:
        pp_comparison = product_record["external_record_comparisons"]["PP230540"]
        product_sequence = parse_product(
            product_record["raw_fasta"]["path"], product_record["sha256"]
        )["sequence"]
        pp_comparison["longest_same_orientation_blocks"] = longest_exact_blocks(product_sequence, pp230540_sequence)
        pp_comparison["longest_reverse_complement_blocks"] = longest_exact_blocks(
            reverse_complement(product_sequence), pp230540_sequence
        )
    ak_product = [item for item in comparisons if item["gene"] == "ITS_2"]
    if len(ak_product) != 1:
        raise ValueError("Expected one ITS_2 lost product")
    ak_comparison = ak_product[0]["external_record_comparisons"]["AK281180"]
    conclusion = {
        "ak281180_embedded_978_is_not_a_complete_public_record": True,
        "ak281180_public_fragment_relation": {
            "relationship": "reverse_complement(public AK281180.1) is an exact substring of the embedded/historical 978-bp ITS_2 sequence",
            "embedded_start": ak_comparison["record_reverse_complement_subsequence_of_product_starts"],
            "public_record_length": external_records["AK281180"]["sequence_length"],
        },
        "reason": "The fetched AK281180.1 sequence is 256 bp, while the embedded/past-product ITS_2 sequence is 978 bp. The public record is a reverse-complement exact fragment at the recorded embedded coordinate, not a complete 978-bp public-record oracle.",
        "pp230540_exact_oriented_substring_matches": [
            {"cell": item["cell"], "gene": item["gene"], "comparison": item["external_record_comparisons"]["PP230540"]}
            for item in comparisons
            if item["external_record_comparisons"]["PP230540"]["same_orientation_subsequence_starts"]
            or item["external_record_comparisons"]["PP230540"]["reverse_complement_subsequence_starts"]
        ],
    }
    return {
        "schema_version": 1,
        "purpose": "Post-hoc external accession corroboration; this does not modify frozen panel references, fixtures, or synthetic cohort selection.",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_evidence_receipt": file_receipt(EVIDENCE_PATH),
        "metadata_receipt": {
            **file_receipt(METADATA_PATH),
            "request_url": METADATA_REQUEST_URL,
            "retrieved_at": METADATA_RETRIEVED_AT,
        },
        "external_records": external_records,
        "frozen_insecta_panel_receipt": file_receipt(INSECTA_PANEL),
        "pp230540_panel_reference_comparisons": panel_reference_comparisons,
        "lost_product_comparisons": comparisons,
        "conclusion": conclusion,
        "limitations": [
            "This checks only two requested public records and is not a broad database search.",
            "Exact sequence identity to an accession is an external sequence oracle, not proof of graph resolution, read phasing, or biological copy count.",
            "Absence from these two records is not evidence that a product is incorrect.",
        ],
    }


def main():
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--output", type=Path, default=PUBLIC_RECORDS / "external_corroboration_final.json")
    arguments = argument_parser.parse_args()
    if arguments.output.exists():
        raise ValueError(f"Output exists: {arguments.output}")
    document = audit_document()
    arguments.output.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n")
    print(json.dumps(document["conclusion"], sort_keys=True))


if __name__ == "__main__":
    main()
