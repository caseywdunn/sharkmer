#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path

import yaml


EXPECTED_COMMITS = {
    "pre132": "928491610822ffdb236d0326b32c8dd19fecf66a",
    "post132": "b728f14219945567b3d78f3602590864a256c809",
    "current": "0c38d6a051082cc2a1eb961b4206837f82948fda",
}
COUNT_FIELDS = ("n_reads_read", "n_bases_read", "n_subreads_ingested", "n_bases_ingested", "n_kmers")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    value = json.loads(Path(path).read_text())
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def parse_fasta(path):
    records, header, parts = [], None, []
    for raw_line in Path(path).read_text().splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if header is not None:
                records.append({"header": header, "sequence": "".join(parts).upper()})
            header, parts = line[1:], []
        elif header is None:
            raise ValueError(f"FASTA content before header: {path}")
        else:
            parts.append(line)
    if header is not None:
        records.append({"header": header, "sequence": "".join(parts).upper()})
    return records


def receipt_inventory(root):
    return {
        str(path.relative_to(root.parent)): sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path.name != "result.json"
    }


def checked_builds(protocol):
    builds = {}
    for role, expected_commit in EXPECTED_COMMITS.items():
        build = protocol.get("versions", {}).get(role)
        if not isinstance(build, dict) or build.get("commit") != expected_commit:
            raise ValueError(f"Unexpected source commit for {role}")
        archive = Path(build.get("source_archive", ""))
        expected_archive = build.get("source_archive_sha256")
        if not archive.is_file() or sha256_file(archive) != expected_archive:
            raise ValueError(f"Source archive receipt mismatch for {role}")
        if build.get("source_export_pristine_after_build") is not True:
            raise ValueError(f"Source export was not pristine for {role}")
        if build.get("source_tree_sha256_before_build") != build.get("source_tree_sha256_after_build"):
            raise ValueError(f"Source tree changed during build for {role}")
        binary = Path(build.get("binary_path", ""))
        if not binary.is_file() or sha256_file(binary) != build.get("binary_sha256"):
            raise ValueError(f"Binary receipt mismatch for {role}")
        builds[role] = {
            "commit": build["commit"],
            "binary_sha256": build["binary_sha256"],
            "source_archive": str(archive),
            "source_archive_sha256": expected_archive,
            "source_export": build.get("source_export"),
            "source_tree_sha256": build.get("source_tree_sha256_after_build"),
        }
    return builds


def expected_command(protocol, role):
    command = list(protocol["template_command"])
    command[0] = protocol["versions"][role]["binary_path"]
    output_index = command.index("-o") + 1
    command[output_index] = str(Path(protocol["_root"]) / role / "output") + "/"
    return command


def validate_stats_and_fastas(protocol, role, result):
    root = Path(protocol["_root"])
    output = root / role / "output"
    command = result.get("command")
    if command != expected_command(protocol, role):
        raise ValueError(f"Actual argv differs from frozen invocation for {role}")
    for flag, expected in (("-k", "19"), ("-t", "2"), ("--chunks", "0"), ("--max-reads", "1000000"), ("-s", "insecta_SRR27962769_1000000")):
        index = command.index(flag)
        if command[index + 1] != expected:
            raise ValueError(f"Actual argv has wrong {flag} for {role}")
    panel_index = command.index("--pcr-panel-file") + 1
    if command[panel_index] != protocol["panel_path"] or command[-1] != protocol["input_path"]:
        raise ValueError(f"Actual panel or input path differs for {role}")
    stats_path = output / "insecta_SRR27962769_1000000.stats.yaml"
    stats = yaml.safe_load(stats_path.read_text())
    if not isinstance(stats, dict):
        raise ValueError(f"Stats is malformed for {role}")
    expected_stats = {
        "sample": "insecta_SRR27962769_1000000",
        "command": " ".join(command),
        "kmer_length": 19,
        "chunks": 0,
        "n_reads_read": protocol["prefix"]["records"],
        "n_bases_read": protocol["prefix"]["bases"],
    }
    for key, expected in expected_stats.items():
        if stats.get(key) != expected:
            raise ValueError(f"Stats {key} differs for {role}")
    pcr_results = stats.get("pcr_results")
    if not isinstance(pcr_results, list):
        raise ValueError(f"Stats has no PCR result list for {role}")
    gene_summary, expected_fastas = [], set()
    for gene_result in pcr_results:
        if not isinstance(gene_result, dict) or not isinstance(gene_result.get("gene_name"), str):
            raise ValueError(f"Malformed PCR result for {role}")
        status, products = gene_result.get("status"), gene_result.get("n_products")
        if status == "success":
            output_file = gene_result.get("output_file") or f"{stats['sample']}_{gene_result['gene_name']}.fasta"
            if Path(output_file).name != output_file:
                raise ValueError(f"Unsafe output file in stats for {role}")
            expected_fastas.add(output_file)
            fasta_records = parse_fasta(output / output_file)
            lengths = [len(record["sequence"]) for record in fasta_records]
            if len(fasta_records) != products or lengths != gene_result.get("product_lengths"):
                raise ValueError(f"Stats/FASTA disagreement for {role}/{gene_result['gene_name']}")
            gene_summary.append({
                "gene_name": gene_result["gene_name"],
                "status": status,
                "n_products": products,
                "product_lengths": lengths,
                "output_file": output_file,
                "failure_reason": gene_result.get("failure_reason"),
                "threshold_diagnostics": gene_result.get("threshold_diagnostics"),
                "products": [
                    {"length": len(record["sequence"]), "sha256": hashlib.sha256(record["sequence"].encode()).hexdigest()}
                    for record in fasta_records
                ],
            })
        elif products != 0:
            raise ValueError(f"Failed gene reports products for {role}/{gene_result['gene_name']}")
        else:
            gene_summary.append({
                "gene_name": gene_result["gene_name"],
                "status": status,
                "n_products": 0,
                "failure_reason": gene_result.get("failure_reason"),
                "threshold_diagnostics": gene_result.get("threshold_diagnostics"),
            })
    observed_fastas = {path.name for path in output.glob("*.fasta")}
    if observed_fastas != expected_fastas:
        raise ValueError(f"FASTA set differs from stats for {role}")
    counts = {key: stats.get(key) for key in COUNT_FIELDS}
    if counts != result.get("counts"):
        raise ValueError(f"Result count summary differs from stats for {role}")
    return stats, gene_summary


def validate_current_transaction(protocol, stats):
    root = Path(protocol["_root"])
    output = root / "current" / "output"
    expected_input = {
        "kind": "local_files",
        "inputs": [protocol["input_path"]],
        "paired": False,
        "max_reads": protocol["prefix"]["records"],
    }
    if stats.get("input_source") != expected_input:
        raise ValueError("Current stats input_source differs from frozen local prefix")
    manifest_name = f"{stats['sample']}.manifest.yaml"
    if stats.get("output_manifest") != manifest_name or stats.get("run_status") != "complete":
        raise ValueError("Current stats lacks complete output manifest status")
    manifest_path = output / manifest_name
    manifest = yaml.safe_load(manifest_path.read_text())
    if not isinstance(manifest, dict) or manifest.get("schema_version") != 1 or manifest.get("producer") != "sharkmer":
        raise ValueError("Current output manifest identity differs")
    if manifest.get("sample") != stats["sample"] or manifest.get("run_id") != stats.get("run_id") or manifest.get("status") != "complete":
        raise ValueError("Current output manifest completion differs")
    receipts = manifest.get("files")
    if not isinstance(receipts, list):
        raise ValueError("Current output manifest lacks file receipts")
    recorded = {receipt.get("path"): receipt.get("sha256") for receipt in receipts if isinstance(receipt, dict)}
    if len(recorded) != len(receipts) or f"{stats['sample']}.stats.yaml" not in recorded:
        raise ValueError("Current output manifest has malformed receipts")
    published = {path.name for path in output.glob("*.fasta")} | {f"{stats['sample']}.stats.yaml"}
    if set(recorded) != published:
        raise ValueError("Current manifest receipts differ from published outputs")
    for name, digest in recorded.items():
        path = output / name
        if not path.is_file() or path.is_symlink() or sha256_file(path) != digest:
            raise ValueError(f"Current manifest checksum differs: {name}")
    return {"manifest": manifest_name, "run_id": manifest["run_id"], "receipt_count": len(recorded)}


def main():
    parser = argparse.ArgumentParser(description="Posthoc receipt audit for real reference-gate counterfactual")
    parser.add_argument("--root", type=Path, default=Path("/tmp/sharkmer-reference-gates-20260913/real-counterfactual"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    arguments = parser.parse_args()
    if arguments.output.exists() and not arguments.overwrite:
        raise SystemExit(f"Output already exists: {arguments.output}")
    root = arguments.root
    protocol = load_json(root / "protocol.json")
    protocol["_root"] = str(root)
    comparison = load_json(root / "comparison.json")
    builds = checked_builds(protocol)
    results = {}
    for role in EXPECTED_COMMITS:
        result = load_json(root / role / "result.json")
        if comparison.get("versions", {}).get(role) != result:
            raise ValueError(f"Comparison does not preserve {role} raw result")
        if result.get("returncode") != 0 or result.get("version") != role:
            raise ValueError(f"Counterfactual run did not complete: {role}")
        inventory = receipt_inventory(root / role)
        if inventory != result.get("files"):
            raise ValueError(f"Counterfactual file inventory differs: {role}")
        stats, genes = validate_stats_and_fastas(protocol, role, result)
        its2 = next((gene for gene in genes if gene["gene_name"] == "insecta_ITS_2"), None)
        if its2 is None:
            raise ValueError(f"ITS_2 stats entry missing for {role}")
        if its2["status"] == "success":
            exact_target = any(product["sha256"] == protocol["target_sequence_sha256"] for product in its2["products"])
        elif its2["n_products"] == 0:
            exact_target = False
        else:
            raise ValueError(f"ITS_2 has invalid failure state for {role}")
        if exact_target != result.get("target_exact_present"):
            raise ValueError(f"Broad target predicate differs from insecta_ITS_2 evidence: {role}")
        results[role] = {
            "counts": result["counts"],
            "stats_version": stats.get("sharkmer_version"),
            "genes": genes,
            "insecta_ITS_2_exact_target_present": exact_target,
            "insecta_ITS_2_products": its2.get("products", []),
        }
        if role == "current":
            results[role]["transaction"] = validate_current_transaction(protocol, stats)
    if len({json.dumps(result["counts"], sort_keys=True) for result in results.values()}) != 1:
        raise ValueError("Counterfactual count metrics differ across versions")
    audit = {
        "schema_version": 1,
        "purpose": "Posthoc receipt audit; it does not rerun Sharkmer or alter counterfactual outputs.",
        "protocol_sha256": sha256_file(root / "protocol.json"),
        "comparison_sha256": sha256_file(root / "comparison.json"),
        "builds": builds,
        "results": results,
        "comparison_flags": {
            "immediate_gate_loses_exact_reference": comparison.get("immediate_gate_loses_exact_reference"),
            "current_loses_exact_reference": comparison.get("current_loses_exact_reference"),
            "counts_identical": comparison.get("counts_identical"),
        },
    }
    with arguments.output.open("w" if arguments.overwrite else "x") as stream:
        json.dump(audit, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(arguments.output)


if __name__ == "__main__":
    main()
