#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path

import yaml


WORKSPACE = Path("/tmp/sharkmer-reference-gates-20260913")
PRODUCTION_SOURCE = Path("/tmp/sharkmer-high-copy-20260911/issue155-build/sources/candidate")
PANEL_PATHS = {
    "hydrozoa": PRODUCTION_SOURCE / "panels/hydrozoa.yaml",
    "insecta": PRODUCTION_SOURCE / "panels/insecta.yaml",
}
IUPAC = {
    "A": frozenset("A"), "C": frozenset("C"), "G": frozenset("G"), "T": frozenset("T"),
    "R": frozenset("AG"), "Y": frozenset("CT"), "S": frozenset("CG"), "W": frozenset("AT"),
    "K": frozenset("GT"), "M": frozenset("AC"), "B": frozenset("CGT"), "D": frozenset("AGT"),
    "H": frozenset("ACT"), "V": frozenset("ACG"), "N": frozenset("ACGT"),
}
COMPLEMENT = {
    "A": "T", "C": "G", "G": "C", "T": "A", "R": "Y", "Y": "R", "S": "S", "W": "W",
    "K": "M", "M": "K", "B": "V", "V": "B", "D": "H", "H": "D", "N": "N",
}
K_VALUES = (19, 31)


def sha256_text(value):
    return hashlib.sha256(value.encode()).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as input_stream:
        for block in iter(lambda: input_stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def reverse_complement(sequence):
    return "".join(COMPLEMENT[base] for base in reversed(sequence.upper()))


def normalized_gene(primer):
    return f"{primer['gene']}_{primer['index']}" if primer.get("index") is not None else primer["gene"]


def file_receipt(path):
    regular_path = Path(path).resolve()
    if not regular_path.is_file() or regular_path.is_symlink():
        raise ValueError(f"Expected a regular source file: {regular_path}")
    return {"path": str(regular_path), "sha256": sha256_file(regular_path), "size_bytes": regular_path.stat().st_size}


def load_panel(path):
    panel = yaml.safe_load(Path(path).read_text())
    if not isinstance(panel, dict) or not isinstance(panel.get("primers"), list):
        raise ValueError(f"Invalid panel: {path}")
    return panel


def scan_sites(sequence, query, mismatch_limit):
    eligible_sites = []
    for start_index in range(len(sequence) - len(query) + 1):
        observed = sequence[start_index : start_index + len(query)]
        if any(base not in "ACGT" for base in observed):
            continue
        mismatch_count = sum(
            observed_base not in IUPAC[expected_base]
            for observed_base, expected_base in zip(observed, query)
        )
        if mismatch_count <= mismatch_limit:
            eligible_sites.append(
                {"start": start_index, "end": start_index + len(query), "mismatches": mismatch_count, "sequence": observed}
            )
    return eligible_sites


def evaluate_binding(sequence, primer, selected_k):
    effective_trim = min(primer["trim"], selected_k - 1)
    if effective_trim <= 0:
        raise ValueError(f"Nonpositive effective trim for k={selected_k}")
    forward_query = primer["forward_seq"].upper()[-effective_trim:]
    reverse_primer_query = primer["reverse_seq"].upper()[-effective_trim:]
    reverse_reference_query = reverse_complement(reverse_primer_query)
    forward_sites = scan_sites(sequence, forward_query, primer["mismatches"])
    reverse_sites = scan_sites(sequence, reverse_reference_query, primer["mismatches"])
    products = {}
    for forward_site in forward_sites:
        for reverse_site in reverse_sites:
            if reverse_site["start"] <= forward_site["start"]:
                continue
            product_length = reverse_site["end"] - forward_site["start"]
            if not primer["min_length"] <= product_length <= primer["max_length"]:
                continue
            product_sequence = sequence[forward_site["start"] : reverse_site["end"]]
            product_sha256 = sha256_text(product_sequence)
            products[(forward_site["start"], reverse_site["end"], product_sha256)] = {
                "start": forward_site["start"], "end": reverse_site["end"], "length": product_length,
                "sha256": product_sha256, "forward": forward_site, "reverse": reverse_site,
            }
    non_acgt_bases = "".join(sorted({base for base in sequence if base not in "ACGT"}))
    return {
        "effective_trim": effective_trim,
        "forward_query": forward_query,
        "reverse_primer_query": reverse_primer_query,
        "reverse_reference_query": reverse_reference_query,
        "forward_sites": forward_sites,
        "reverse_sites": reverse_sites,
        "valid_pairs": list(products.values()),
        "reference_non_acgt_bases": non_acgt_bases,
    }


def case_records():
    panel_data = {panel_name: load_panel(panel_path) for panel_name, panel_path in PANEL_PATHS.items()}
    records = []
    for panel_name, selected_gene, selected_taxon in (
        ("hydrozoa", None, None),
        ("insecta", "ITS_2", "Gryllus bimaculatus"),
    ):
        primer_by_gene = {normalized_gene(primer): primer for primer in panel_data[panel_name]["primers"]}
        for group in panel_data[panel_name].get("references", []):
            if selected_gene is not None and group["gene"] != selected_gene:
                continue
            primer = primer_by_gene.get(group["gene"])
            if primer is None:
                raise ValueError(f"No primer for {panel_name}/{group['gene']}")
            for reference in group["sequences"]:
                if selected_taxon is not None and reference["taxon"] != selected_taxon:
                    continue
                sequence = reference["sequence"].upper()
                records.append({
                    "case_id": f"{panel_name}-{group['gene']}-{reference['accession']}".replace(".", "_"),
                    "panel": panel_name,
                    "gene": group["gene"],
                    "taxon": reference["taxon"],
                    "accession": reference["accession"],
                    "sequence": sequence,
                    "reference_length": len(sequence),
                    "reference_sha256": sha256_text(sequence),
                    "primer": {key: primer[key] for key in ("forward_seq", "reverse_seq", "min_length", "max_length", "mismatches", "trim")},
                })
    if len(records) != 30:
        raise ValueError(f"Expected 30 reference cases, found {len(records)}")
    return records


def native_endpoint_analysis(case, selected_k):
    sequence = case["sequence"]
    endpoint_primer = {
        "forward_seq": sequence[:15],
        "reverse_seq": reverse_complement(sequence[-15:]),
        "min_length": 100,
        "max_length": len(sequence) + 500,
        "mismatches": 0,
        "trim": 15,
    }
    analysis = evaluate_binding(sequence, endpoint_primer, selected_k)
    full_reference_pairs = [
        pair for pair in analysis["valid_pairs"]
        if pair["start"] == 0 and pair["end"] == len(sequence) and pair["sha256"] == case["reference_sha256"]
    ]
    return {
        "endpoint_derivation": {
            "forward_seq": endpoint_primer["forward_seq"],
            "reverse_seq": endpoint_primer["reverse_seq"],
            "reverse_reference_query": sequence[-15:],
            "derivation": "forward=first 15 stored bases; reverse=reverse-complement(last 15 stored bases)",
        },
        "effective_trim": analysis["effective_trim"],
        "full_reference_pair_count": len(full_reference_pairs),
        "full_reference_pair": full_reference_pairs[0] if len(full_reference_pairs) == 1 else None,
        "valid_pair_count": len(analysis["valid_pairs"]),
    }


def audit_document():
    records = case_records()
    audited_cases = []
    core_counts = {"hydrozoa": {str(selected_k): 0 for selected_k in K_VALUES}, "gryllus": {str(selected_k): 0 for selected_k in K_VALUES}}
    ambiguous_pair_cases = []
    native_complete_counts = {str(selected_k): 0 for selected_k in K_VALUES}
    for case in records:
        orientation_results = {}
        for orientation_name, oriented_sequence in (
            ("stored", case["sequence"]),
            ("reverse_complement", reverse_complement(case["sequence"])),
        ):
            orientation_results[orientation_name] = {
                str(selected_k): evaluate_binding(oriented_sequence, case["primer"], selected_k)
                for selected_k in K_VALUES
            }
        native_endpoints = {
            str(selected_k): native_endpoint_analysis(case, selected_k) for selected_k in K_VALUES
        }
        acgt_only = not any(base not in "ACGT" for base in case["sequence"])
        core_results = {}
        for selected_k in K_VALUES:
            valid_pair_count = len(orientation_results["stored"][str(selected_k)]["valid_pairs"])
            reverse_valid_pair_count = len(orientation_results["reverse_complement"][str(selected_k)]["valid_pairs"])
            core_eligible = acgt_only and valid_pair_count == 1
            core_results[str(selected_k)] = {
                "stored_valid_pair_count": valid_pair_count,
                "reverse_complement_valid_pair_count": reverse_valid_pair_count,
                "core_eligible_stored_orientation": core_eligible,
                "core_exclusion": None if core_eligible else (
                    "non_acgt_reference" if not acgt_only else "not_exactly_one_stored_orientation_product"
                ),
            }
            if core_eligible:
                bucket = "hydrozoa" if case["panel"] == "hydrozoa" else "gryllus"
                core_counts[bucket][str(selected_k)] += 1
            if case["panel"] == "hydrozoa" and acgt_only:
                endpoint_result = native_endpoints[str(selected_k)]
                if endpoint_result["full_reference_pair_count"] == 1:
                    native_complete_counts[str(selected_k)] += 1
                else:
                    raise ValueError(f"Native endpoints fail to span {case['case_id']} at k={selected_k}")
        if not acgt_only and any(
            len(orientation_results["stored"][str(selected_k)]["valid_pairs"]) > 0 for selected_k in K_VALUES
        ):
            ambiguous_pair_cases.append(case["case_id"])
        audited_cases.append({
            key: value for key, value in case.items() if key != "sequence"
        } | {
            "acgt_only": acgt_only,
            "stored_sequence_sha256": case["reference_sha256"],
            "orientation_binding": orientation_results,
            "core_results": core_results,
            "native_endpoints": native_endpoints if case["panel"] == "hydrozoa" and acgt_only else None,
        })
    hydrozoa_acgt_cases = sum(case["panel"] == "hydrozoa" and case["acgt_only"] for case in audited_cases)
    hydrozoa_non_acgt_cases = sum(case["panel"] == "hydrozoa" and not case["acgt_only"] for case in audited_cases)
    if hydrozoa_acgt_cases != 23 or hydrozoa_non_acgt_cases != 6:
        raise ValueError("Unexpected hydrozoa ACGT partition")
    if core_counts != {"hydrozoa": {"19": 0, "31": 0}, "gryllus": {"19": 1, "31": 1}}:
        raise ValueError(f"Unexpected core eligibility: {core_counts}")
    if native_complete_counts != {"19": 23, "31": 23}:
        raise ValueError(f"Unexpected native endpoint completeness: {native_complete_counts}")
    return {
        "schema_version": 1,
        "purpose": "Independent retained-suffix reference binding receipt; no production change or graph conclusion",
        "source_receipts": {panel_name: file_receipt(panel_path) for panel_name, panel_path in PANEL_PATHS.items()},
        "matcher_semantics": {
            "production_rule": "3-prime suffix length min(configured trim, k-1), with configured IUPAC mismatch allowance",
            "orientation_check": "The same production-direction retained-suffix matcher is applied independently to stored and reverse-complement reference strings.",
            "not_full_primer": "No full-primer absence or mismatch is used to declare a reference uncallable.",
            "core_eligibility": "ACGT-only stored reference with exactly one stored-orientation product under original panel bounds; reverse-complement scan is an additional diagnostic only.",
        },
        "k_values": list(K_VALUES),
        "summary": {
            "total_cases": len(audited_cases),
            "hydrozoa_cases": 29,
            "hydrozoa_acgt_only_cases": hydrozoa_acgt_cases,
            "hydrozoa_non_acgt_excluded_cases": hydrozoa_non_acgt_cases,
            "core_eligible_counts": core_counts,
            "native_endpoint_full_reference_counts": native_complete_counts,
            "non_acgt_cases_with_stored_valid_pair": ambiguous_pair_cases,
            "non_acgt_cases_with_stored_valid_pair_count": len(ambiguous_pair_cases),
        },
        "cases": audited_cases,
        "limitations": [
            "Reference-only binding evidence does not prove graph connectivity, repeat copy count, read phasing, or biological recovery.",
            "The native endpoint diagnostics change hydrozoa primers and length bounds; they only verify exact source-sequence fixture derivation.",
            "A non-ACGT reference remains excluded from the no-error ACGT core even when locally scannable retained-suffix sites form a pair.",
        ],
    }


def main():
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--output", type=Path, default=WORKSPACE / "retained_suffix_oracle_audit.json")
    arguments = argument_parser.parse_args()
    if arguments.output.exists():
        raise ValueError(f"Output exists: {arguments.output}")
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    document = audit_document()
    arguments.output.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n")
    print(json.dumps(document["summary"], sort_keys=True))


if __name__ == "__main__":
    main()
