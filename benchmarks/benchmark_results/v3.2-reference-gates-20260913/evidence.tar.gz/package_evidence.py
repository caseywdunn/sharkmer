import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


WORKSPACE = Path('/tmp/sharkmer-reference-gates-20260913')
REPOSITORY = Path('/home/claude/repos/sharkmer')
DESTINATION = REPOSITORY / 'benchmarks/benchmark_results/v3.2-reference-gates-20260913'


def main():
    DESTINATION.mkdir(parents=True, exist_ok=True)
    selected = {}
    excluded = {
        'reference_gate_evidence.json', 'reference_gate_evidence_v2.json',
        'inventory.json', 'inventory-v2.json', 'protocol-template.json',
        'external_corroboration.json', 'external_corroboration_public_records.json',
        'hydrozoa_public_provenance.json',
    }
    for path in sorted(WORKSPACE.rglob('*')):
        relative = path.relative_to(WORKSPACE)
        if not path.is_file() or path.is_symlink():
            continue
        if '__pycache__' in relative.parts or path.name in excluded:
            continue
        if relative.parts[0] == 'builds':
            if len(relative.parts) != 2 or path.suffix == '.tar':
                continue
        if path.suffix in {'.fastq', '.fasta', '.json', '.py', '.yaml', '.txt', '.log', '.jsonl', '.md', '.stderr', '.lock'}:
            selected[str(relative)] = path
    for path in sorted((REPOSITORY / 'panels').glob('*.yaml')):
        selected['frozen-panels/' + path.name] = path
    selected['provenance/current-builds.json'] = Path('/tmp/sharkmer-high-copy-20260911/final-builds.json')
    selected['provenance/real-inputs.json'] = Path('/tmp/sharkmer-release-comparison/inputs.json')
    selected['provenance/build.py'] = Path('/tmp/sharkmer-high-copy-20260911/build.py')
    selected['provenance/build_versions.py'] = Path('/tmp/sharkmer-release-comparison/build_versions.py')
    manifest = []
    with (DESTINATION / 'evidence.tar.gz').open('xb') as destination:
        with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for name, path in sorted(selected.items()):
                    content = path.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(content)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(content))
                    manifest.append({'path': name, 'size_bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
    with (DESTINATION / 'ARCHIVE_CONTENTS.json').open('x') as stream:
        json.dump({'schema_version': 1, 'files': manifest}, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'files': len(manifest), 'uncompressed_bytes': sum(item['size_bytes'] for item in manifest), 'archive_bytes': (DESTINATION / 'evidence.tar.gz').stat().st_size}))


if __name__ == '__main__':
    main()
