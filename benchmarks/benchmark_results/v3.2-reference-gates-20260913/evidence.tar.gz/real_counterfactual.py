import hashlib
import json
import os
import resource
import signal
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import yaml


WORKSPACE = Path('/tmp/sharkmer-reference-gates-20260913')
TARGET_SHA = '23163ca76f97f5d1685f0fcf4bda6ffc798bdf58c63953416833e78a480af68c'


def digest(path, limit=None):
    hasher = hashlib.sha256()
    remaining = limit
    with Path(path).open('rb') as stream:
        while remaining is None or remaining > 0:
            block = stream.read(1048576 if remaining is None else min(remaining, 1048576))
            if not block:
                break
            hasher.update(block)
            if remaining is not None:
                remaining -= len(block)
    if remaining not in (None, 0):
        raise ValueError('Truncated input')
    return hasher.hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def records(path):
    header = None
    sequence = []
    for line in path.read_text().splitlines():
        if line.startswith('>'):
            if header is not None:
                yield header, ''.join(sequence)
            header, sequence = line[1:], []
        else:
            sequence.append(line.strip())
    if header is not None:
        yield header, ''.join(sequence)


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (40 * 1024**3, 40 * 1024**3))
    os.sched_setaffinity(0, {0, 1})


def main():
    historical = json.loads((WORKSPACE / 'builds/builds.json').read_text())['versions']
    current = json.loads(Path('/tmp/sharkmer-high-copy-20260911/final-builds.json').read_text())['versions']['candidate']
    versions = {'pre132': historical['pre_fix'], 'post132': historical['candidate'], 'current': current}
    results = Path('/tmp/sharkmer-high-copy-20260911/final-execution/results')
    old_receipt = json.loads(next(results.glob('*SRR27962769*pair1_candidate.json')).read_text())
    inputs = json.loads(Path('/tmp/sharkmer-release-comparison/inputs.json').read_text())['inputs']
    input_record = next(item for item in inputs if item['id'] == 'SRR27962769')
    input_path = Path(input_record['path'])
    panel_path = Path(old_receipt['binary_command'][-2])
    panel_sha = '043a4d224f8186d58459287c54bec7935d5f4921a5087c14a2136cfac42df874'
    assert digest(panel_path) == panel_sha
    assert digest(input_path) == input_record['sha256']
    prefix = input_record['prefixes']['1000000']
    assert digest(input_path, prefix['size_bytes']) == prefix['sha256']
    run_root = WORKSPACE / 'real-counterfactual'
    run_root.mkdir(exist_ok=False)
    protocol = {
        'created_at': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Sequence correctness and immediate #132 causal contrast, not performance measurement',
        'sample': 'SRR27962769', 'panel_path': str(panel_path), 'panel_sha256': panel_sha,
        'input_path': str(input_path), 'input_sha256': input_record['sha256'], 'prefix': prefix,
        'versions': versions, 'target_sequence_sha256': TARGET_SHA, 'target_accession': 'AK281180',
        'template_command': old_receipt['binary_command'],
        'parameter_changes': 'Only binary and isolated output path; sample name/options/panel/input unchanged',
        'affinity': [0, 1], 'timeout_seconds': 1800, 'address_space_limit_bytes': 40 * 1024**3,
        'harness_sha256': digest(__file__),
    }
    write_json(run_root / 'protocol.json', protocol)
    all_results = {}
    for version, build in versions.items():
        assert digest(build['binary_path']) == build['binary_sha256']
        assert digest(panel_path) == panel_sha
        assert digest(input_path, prefix['size_bytes']) == prefix['sha256']
        destination = run_root / version
        destination.mkdir()
        output = destination / 'output'
        output.mkdir()
        command = list(old_receipt['binary_command'])
        command[0] = build['binary_path']
        command[command.index('-o') + 1] = str(output) + '/'
        started = datetime.now(timezone.utc).isoformat()
        print(f'Starting {version}: {command}', flush=True)
        with (destination / 'stdout.txt').open('xb') as stdout, (destination / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=limits, env={**os.environ, 'LC_ALL': 'C'})
            try:
                returncode = process.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
        assert returncode == 0, (version, returncode)
        assert digest(build['binary_path']) == build['binary_sha256']
        assert digest(panel_path) == panel_sha
        assert digest(input_path, prefix['size_bytes']) == prefix['sha256']
        stats_path = next(output.glob('*.stats.yaml'))
        stats = yaml.safe_load(stats_path.read_text())
        assert stats['kmer_length'] == 19 and stats['n_reads_read'] == 1000000
        assert stats['n_bases_read'] == 150000000
        products = []
        for fasta in sorted(output.glob('*.fasta')):
            for header, sequence in records(fasta):
                products.append({'file': str(fasta.relative_to(run_root)), 'header': header,
                                 'length': len(sequence), 'sha256': hashlib.sha256(sequence.encode()).hexdigest()})
        result = {
            'version': version, 'command': command, 'started_at': started,
            'finished_at': datetime.now(timezone.utc).isoformat(), 'returncode': returncode,
            'products': products, 'target_exact_present': any(item['sha256'] == TARGET_SHA for item in products),
            'counts': {key: stats.get(key) for key in ['n_reads_read', 'n_bases_read', 'n_subreads_ingested', 'n_bases_ingested', 'n_kmers']},
            'its2_result': [item for item in stats.get('pcr_results', []) if item.get('gene_name') == 'insecta_ITS_2'],
            'files': {str(path.relative_to(run_root)): digest(path) for path in sorted(destination.rglob('*')) if path.is_file()},
        }
        write_json(destination / 'result.json', result)
        all_results[version] = result
        print(f'{version}: exact target present={result["target_exact_present"]}; counts={result["counts"]}', flush=True)
    assert all(result['counts'] == all_results['pre132']['counts'] for result in all_results.values())
    write_json(run_root / 'comparison.json', {
        'versions': all_results, 'counts_identical': True,
        'immediate_gate_loses_exact_reference': all_results['pre132']['target_exact_present'] and not all_results['post132']['target_exact_present'],
        'current_loses_exact_reference': all_results['pre132']['target_exact_present'] and not all_results['current']['target_exact_present'],
    })


if __name__ == '__main__':
    main()
