#!/usr/bin/env python3
import argparse
import difflib
import hashlib
import json
from pathlib import Path


WORKSPACE = Path("/tmp/sharkmer-reference-gates-20260913")
PUBLIC_RECORD = WORKSPACE / "public-records/PP230540.fasta"
PRE132_FASTA = WORKSPACE / "real-counterfactual/pre132/output/insecta_SRR27962769_1000000_insecta_CO1_1.fasta"
CURRENT_FASTA = WORKSPACE / "real-counterfactual/current/output/insecta_SRR27962769_1000000_insecta_CO1_1.fasta"
POST132_FASTA = WORKSPACE / "real-counterfactual/post132/output/insecta_SRR27962769_1000000_insecta_CO1_1.fasta"
COMPLEMENT = str.maketrans("ACGT", "TGCA")


def sha256_text(value):
    return hashlib.sha256(value.encode()).hexdigest()


def file_receipt(path):
    regular_path = Path(path).resolve()
    contents = regular_path.read_bytes()
    return {"path": str(regular_path), "size_bytes": len(contents), "sha256": hashlib.sha256(contents).hexdigest()}


def read_fasta(path):
    records = []
    header = None
    sequence_parts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith(">"):
            if header is not None:
                records.append((header, "".join(sequence_parts).upper()))
            header = line[1:]
            sequence_parts = []
        elif line.strip():
            sequence_parts.append(line.strip())
    if header is None:
        raise ValueError(f"Missing FASTA record: {path}")
    records.append((header, "".join(sequence_parts).upper()))
    return records


def single_sequence(path):
    records = read_fasta(path)
    if len(records) != 1:
        raise ValueError(f"Expected one FASTA record: {path}")
    return records[0]


def by_length(path, expected_length):
    matching = [(header, sequence) for header, sequence in read_fasta(path) if len(sequence) == expected_length]
    if len(matching) != 1:
        raise ValueError(f"Expected one {expected_length}-bp record: {path}")
    return matching[0]


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def exact_blocks(query_sequence, subject_sequence, minimum_length=20):
    matcher = difflib.SequenceMatcher(None, query_sequence, subject_sequence, autojunk=False)
    return [
        {"query_start": block.a, "subject_start": block.b, "length": block.size}
        for block in matcher.get_matching_blocks()
        if block.size >= minimum_length
    ]


def all_positions(sequence, needle):
    positions = []
    start_index = 0
    while True:
        position = sequence.find(needle, start_index)
        if position < 0:
            return positions
        positions.append(position)
        start_index = position + 1


def relationship(sequence, public_sequence):
    return {
        "same_orientation_full_subsequence_starts": all_positions(public_sequence, sequence),
        "reverse_complement_full_subsequence_starts": all_positions(public_sequence, reverse_complement(sequence)),
        "same_orientation_exact_blocks": exact_blocks(sequence, public_sequence),
        "reverse_complement_exact_blocks": exact_blocks(reverse_complement(sequence), public_sequence),
    }


def audit_document():
    old_header, old_sequence = by_length(PRE132_FASTA, 373)
    new_header, new_sequence = single_sequence(CURRENT_FASTA)
    post_header, post_sequence = single_sequence(POST132_FASTA)
    public_header, public_sequence = single_sequence(PUBLIC_RECORD)
    if len(new_sequence) != 352 or post_sequence != new_sequence:
        raise ValueError("Expected identical 352-bp current and post-132 retained products")
    old_new_blocks = exact_blocks(new_sequence, old_sequence)
    insertion_start = old_new_blocks[0]["subject_start"] + old_new_blocks[0]["length"]
    insertion_end = old_new_blocks[1]["subject_start"]
    insertion_sequence = old_sequence[insertion_start:insertion_end]
    if len(insertion_sequence) != 21:
        raise ValueError("Expected a 21-bp old-only insertion block")
    return {
        "schema_version": 1,
        "purpose": "Offline exact-block comparison of retained and historical Gryllus CO1_1 products against saved PP230540.1; no biological or graph conclusion.",
        "source_receipts": {
            "pre132_output": file_receipt(PRE132_FASTA),
            "post132_output": file_receipt(POST132_FASTA),
            "current_output": file_receipt(CURRENT_FASTA),
            "public_pp230540": file_receipt(PUBLIC_RECORD),
        },
        "products": {
            "old_pre132_373": {"header": old_header, "length": len(old_sequence), "sha256": sha256_text(old_sequence)},
            "retained_current_352": {"header": new_header, "length": len(new_sequence), "sha256": sha256_text(new_sequence)},
            "post132_352": {"header": post_header, "length": len(post_sequence), "sha256": sha256_text(post_sequence)},
            "public_pp230540_1": {"header": public_header, "length": len(public_sequence), "sha256": sha256_text(public_sequence)},
        },
        "old_vs_retained_exact_blocks": old_new_blocks,
        "old_only_insertion": {
            "old_start": insertion_start,
            "old_end": insertion_end,
            "length": len(insertion_sequence),
            "sequence": insertion_sequence,
            "occurrences_in_old": all_positions(old_sequence, insertion_sequence),
            "occurrences_in_retained": all_positions(new_sequence, insertion_sequence),
            "occurrences_in_public": all_positions(public_sequence, insertion_sequence),
        },
        "public_relationships": {
            "old_pre132_373": relationship(old_sequence, public_sequence),
            "retained_current_352": relationship(new_sequence, public_sequence),
        },
        "limitations": [
            "Exact sequence blocks alone do not establish whether either emitted product is correct for the original sample.",
            "No read-level, graph, or biological-copy interpretation is made by this receipt.",
        ],
    }


def main():
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--output", type=Path, default=WORKSPACE / "public-records/gry_co1_public_alignment_final.json")
    arguments = argument_parser.parse_args()
    if arguments.output.exists():
        raise ValueError(f"Output exists: {arguments.output}")
    document = audit_document()
    arguments.output.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"old_only_insertion": document["old_only_insertion"], "public_relationships": document["public_relationships"]}, sort_keys=True))


if __name__ == "__main__":
    main()
