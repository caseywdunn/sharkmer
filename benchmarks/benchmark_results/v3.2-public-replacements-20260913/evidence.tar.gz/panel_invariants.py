#!/usr/bin/env python3
"""Verify that public-reference migration did not alter panel behavior."""
from __future__ import annotations

import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import jsonschema
import yaml


REPO = Path('/home/claude/repos/sharkmer')
BASE = '66704f9'
PANELS = [
    'angiospermae.yaml', 'bacteria.yaml', 'c_elegans.yaml', 'cnidaria.yaml',
    'human.yaml', 'hydrozoa.yaml', 'insecta.yaml', 'metazoa.yaml',
    'teleostei.yaml', 'examples/reference.yaml',
]
MIGRATED = {'angiospermae.yaml', 'c_elegans.yaml', 'cnidaria.yaml', 'hydrozoa.yaml', 'insecta.yaml', 'teleostei.yaml'}
ALLOWED_TOP_LEVEL_CHANGES = {'references', 'panel_version', 'changelog'}
OUTPUT = Path('/tmp/sharkmer-public-replacements-20260913/panel_invariants.json')


def normalize(value):
    if isinstance(value, dict):
        return {str(key): normalize(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, (datetime.date, datetime.datetime)):
        return value.isoformat()
    return value


def load_current(relative: str):
    return normalize(yaml.safe_load((REPO / 'panels' / relative).read_text()))


def load_base(relative: str):
    content = subprocess.check_output(['git', 'show', f'{BASE}:panels/{relative}'], cwd=REPO, text=True)
    return normalize(yaml.safe_load(content))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    schema = json.loads((REPO / 'schemas/panel/v2.json').read_text())
    rows = []
    failures = []
    for relative in PANELS:
        current = load_current(relative)
        try:
            jsonschema.validate(current, schema)
            schema_valid = True
            schema_error = None
        except jsonschema.ValidationError as error:
            schema_valid = False
            schema_error = error.message
            failures.append(f'{relative}: schema: {error.message}')
        row = {'panel': relative, 'schema_valid': schema_valid, 'schema_error': schema_error}
        if relative in MIGRATED:
            base = load_base(relative)
            row['primers_identical'] = current.get('primers') == base.get('primers')
            row['validation_identical'] = current.get('validation') == base.get('validation')
            changed = {key for key in set(base) | set(current) if base.get(key) != current.get(key)}
            row['changed_top_level_keys'] = sorted(changed)
            row['only_allowed_top_level_changes'] = changed <= ALLOWED_TOP_LEVEL_CHANGES
            for name in ('primers_identical', 'validation_identical', 'only_allowed_top_level_changes'):
                if not row[name]:
                    failures.append(f'{relative}: {name} is false')
        rows.append(row)
    output = {
        'schema_version': 1,
        'base_commit': BASE,
        'schema_sha256': digest(REPO / 'schemas/panel/v2.json'),
        'valid': not failures,
        'failures': failures,
        'panels': rows,
    }
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'valid': output['valid'], 'schema_panels': len(PANELS), 'migrated_panels': len(MIGRATED), 'failures': failures}, sort_keys=True))
    return 0 if output['valid'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
