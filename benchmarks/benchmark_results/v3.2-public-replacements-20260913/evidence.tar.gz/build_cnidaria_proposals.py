import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parent
COMPLEMENT = str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN")


def digest(sequence):
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def features(record):
    return [
        {
            "feature_type": feature.findtext("GBFeature_key"),
            "location": feature.findtext("GBFeature_location"),
            "qualifiers": [
                {"name": qualifier.findtext("GBQualifier_name"), "value": qualifier.findtext("GBQualifier_value")}
                for qualifier in feature.findall("./GBFeature_quals/GBQualifier")
            ],
        }
        for feature in record.findall("./GBSeq_feature-table/GBFeature")
    ]


def main():
    records = {}
    for filename, receipt_name in [
        ("public_records.xml", "root_batch_receipt.json"),
        ("extra_records.xml", "root_extra_receipt.json"),
        ("haliclystus_features.xml", "haliclystus_features_receipt.json"),
    ]:
        raw_path = ROOT / "cnidaria_other" / filename
        receipt = json.loads((ROOT / receipt_name).read_text())
        retrieved_at = receipt["sources"][0]["retrieved_at"]
        if not retrieved_at:
            raise ValueError(f"Missing retrieval date in {receipt_name}")
        for record in ET.parse(raw_path).getroot().findall(".//GBSeq"):
            accession = record.findtext("GBSeq_accession-version")
            sequence = record.findtext("GBSeq_sequence").upper()
            annotation = features(record)
            taxids = [
                qualifier["value"].split(":")[1]
                for feature in annotation if feature["feature_type"] == "source"
                for qualifier in feature["qualifiers"]
                if qualifier["name"] == "db_xref" and qualifier["value"].startswith("taxon:")
            ]
            assert len(taxids) == 1
            source = {
                "accession_version": accession,
                "sequence": sequence,
                "sequence_sha256": digest(sequence),
                "organism": record.findtext("GBSeq_organism"),
                "taxid": int(taxids[0]),
                "topology": record.findtext("GBSeq_topology"),
                "title": record.findtext("GBSeq_definition"),
                "url": f"https://www.ncbi.nlm.nih.gov/nuccore/{accession}",
                "retrieved_at": retrieved_at,
            }
            if accession in records:
                assert records[accession][0]["sequence"] == sequence
            records[accession] = source, annotation, raw_path
    legacy = {
        entry["entry_id"]: entry
        for entry in json.loads(Path("/tmp/sharkmer-reference-audit-20260913/legacy_references.json").read_text())["entries"]
    }
    specifications = [
        ("cnidaria:0:1", "KU257501.1", 0, 581, "+", False, "same_species", "partial_16S"),
        ("cnidaria:0:3", "NC_035741.1", 14008, 15687, "-", False, "same_species", "complete_16S_rrnl"),
        ("cnidaria:0:4", "LC467070.1", 0, 698, "+", False, "related_taxon", "partial_16S; independent Xenia sp. isolate, not Carnegie strain"),
        ("cnidaria:1:3", "NC_035741.1", 15807, 1542, "-", True, "same_species", "complete_COX1_origin_spanning"),
        ("cnidaria:1:4", "HG999760.1", 0, 880, "+", False, "related_taxon", "partial_COI_gene; contiguous gene feature, not anomalous joined CDS"),
        ("cnidaria:2:0", "AY937313.1", 0, 1755, "+", False, "same_species", "partial_18S"),
        ("cnidaria:2:1", "AY845346.1", 0, 1755, "+", False, "same_species", "partial_18S"),
        ("cnidaria:2:2", "GQ849083.1", 0, 1733, "+", False, "related_taxon", "partial_18S; M. virulenta is not asserted to be sample Morbakka sp."),
        ("cnidaria:2:4", "XR_006952126.1", 0, 1823, "+", False, "same_named_strain", "predicted_18S_rRNA; public cmsearch annotation"),
        ("cnidaria:3:0", "EU272542.1", 0, 2403, "+", False, "same_species", "partial_28S"),
        ("cnidaria:3:1", "KU308592.1", 0, 3166, "+", False, "same_species", "partial_28S"),
        ("cnidaria:3:2", "GQ849060.1", 0, 2859, "+", False, "related_taxon", "partial_28S; M. virulenta is not asserted to be sample Morbakka sp."),
        ("cnidaria:3:4", "XR_006952137.1", 0, 3589, "+", False, "same_named_strain", "predicted_28S_rRNA; public cmsearch annotation"),
        ("cnidaria:4:0", "EU272542.1", 0, 2403, "+", False, "same_species", "partial_28S"),
        ("cnidaria:4:1", "KU308592.1", 0, 3166, "+", False, "same_species", "partial_28S"),
        ("cnidaria:4:2", "GQ849060.1", 0, 2859, "+", False, "related_taxon", "partial_28S; M. virulenta is not asserted to be sample Morbakka sp."),
        ("cnidaria:5:1", "KU308625.1", 0, 653, "+", False, "same_species", "annotated_ITS1_5.8S_ITS2_cluster_with_partial_18S_28S_flanks"),
        ("cnidaria:5:2", "KC864852.1", 0, 951, "+", False, "related_taxon", "annotated_ITS1_5.8S_ITS2_cluster_with_partial_18S_28S_flanks; distinct Xenia sp. isolate"),
        ("cnidaria:6:0", "KU308625.1", 0, 653, "+", False, "same_species", "annotated_ITS1_5.8S_ITS2_cluster_with_partial_18S_28S_flanks"),
        ("cnidaria:6:1", "KR338966.1", 0, 813, "+", False, "same_species", "partial_ITS1_5.8S_ITS2_cluster; no complete primer flanks"),
        ("cnidaria:6:2", "KY442629.1", 0, 935, "+", False, "related_taxon", "annotated_ITS1_5.8S_ITS2_cluster_with_partial_18S_28S_flanks; distinct Xenia sp. isolate"),
        ("hydrozoa:0:1", "EU293971.1", 0, 539, "+", False, "same_species_archive_spelling", "partial_16S; archive spells species sowerbii"),
        ("teleostei:0:0", "XR_010033285.1", 0, 1857, "+", False, "same_species", "predicted_18S_rRNA; public cmsearch annotation"),
        ("reference:0:0", "LC467070.1", 0, 698, "+", False, "related_taxon", "partial_16S; documentation example, independent Xenia sp. isolate"),
    ]
    proposals = []
    for identifier, accession, start, end, strand, wraps, relation, scope in specifications:
        source, annotation, raw_path = records[accession]
        sequence = source["sequence"][start:] + source["sequence"][:end] if wraps else source["sequence"][start:end]
        if strand == "-":
            sequence = sequence.translate(COMPLEMENT)[::-1]
        assert sequence and len(sequence) <= len(source["sequence"])
        proposals.append({
            "legacy_entry_id": identifier,
            "disposition": "proposed_public_region",
            "reason": "Extracted from independently annotated public record; no legacy product used to infer or fill sequence.",
            "reference": {
                "gene_name": legacy[identifier]["gene"], "taxon": source["organism"],
                "accession": accession, "sequence": sequence,
                "provenance": {
                    "schema_version": 1, "kind": "public_record_region", "accession_version": accession,
                    "source_length": len(source["sequence"]), "source_sequence_sha256": source["sequence_sha256"],
                    "start": start, "end": end, "strand": strand, "wraps_origin": wraps,
                    "sequence_sha256": digest(sequence),
                },
            },
            "annotation": {
                "raw_file": str(raw_path), "raw_sha256": hashlib.sha256(raw_path.read_bytes()).hexdigest(),
                "feature_type": "public_feature_or_annotated_rDNA_locus",
                "features": [feature for feature in annotation if feature["feature_type"] != "source"],
                "scope": scope, "taxon_relation": relation,
                "primer_region_support": "not_established", "sample_haplotype_truth": "not_established",
            },
            "source_record": source,
        })
    proposals.append({
        "legacy_entry_id": "cnidaria:5:0", "disposition": "unresolved", "reference": None,
        "reason": "Existing AY937313.1 is annotated 18S, not ITS. Targeted Agalma public nucleotide/rRNA searches found no independently annotated ITS replacement; absence from this bounded search is not gene absence.",
        "annotation": {"scope": "unresolved_gene_annotation", "raw_file": str(ROOT / "cnidaria_other" / "agalma_search.json")},
    })
    output = ROOT / "cnidaria_other" / "proposals.json"
    output.write_text(json.dumps({"schema_version": 1, "purpose": "Independent public-region replacement proposals, not sample haplotype truth", "records": proposals}, indent=2, sort_keys=True) + "\n")
    print(f"{len(proposals)} decisions; {len(specifications)} public proposals; {output}")


if __name__ == "__main__":
    main()
