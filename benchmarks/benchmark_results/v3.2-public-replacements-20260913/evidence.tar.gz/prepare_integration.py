import copy
import difflib
import gzip
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path("/home/claude/repos/sharkmer")


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    legacy = {
        entry["entry_id"]: entry
        for entry in json.loads(Path("/tmp/sharkmer-reference-audit-20260913/legacy_references.json").read_text())["entries"]
    }
    quarantine = {identifier for identifier, entry in legacy.items() if entry["disposition"].startswith("quarantined_")}
    proposals = []
    manifests = []
    for group in ("insecta", "plants_nematode", "cnidaria_other"):
        path = ROOT / group / "proposals.json"
        data = json.loads(path.read_text())
        manifests.append({"path": str(path), "sha256": digest(path.read_bytes())})
        proposals.extend(copy.deepcopy(data.get("proposals", data.get("records", []))))
    heliconius_source = next(proposal["source_record"] for proposal in proposals if (proposal.get("reference") or {}).get("accession") == "NC_024741.1")
    nd1_sequence = heliconius_source["sequence"][11661:12600].translate(str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN"))[::-1]
    assert digest(nd1_sequence.encode()) == "a918e9f4e74e1d0faf64a3b2caa58a85dc297e5f473e54c1a814729e73f48647"
    proposals.append({
        "legacy_entry_id": "extra:Heliconius_ND1", "panel_path": "panels/insecta.yaml",
        "disposition": "additional_public_gene_reference",
        "reason": "Independent complete ND1 feature broadens evidence for the high-copy benchmark; not selected or trimmed from a product.",
        "source_record": heliconius_source,
        "annotation": {"raw_file": "insecta/raw/quarantined_records.gb.xml", "raw_sha256": "da7cd3dbfc3637762196a6208a6c4543ba7b7a7e8c0a11098f7111e36ba1e2d3", "feature_type": "gene_and_CDS", "location": "complement(11662..12600)", "qualifiers": {"gene": "ND1", "product": "NADH dehydrogenase subunit 1", "protein_id": "YP_009054343.1"}, "scope": "complete_annotated_ND1", "taxon_relation": "same_species"},
        "reference": {"gene_name": "ND1", "taxon": heliconius_source["organism"], "accession": "NC_024741.1", "sequence": nd1_sequence,
            "provenance": {"schema_version": 1, "kind": "public_record_region", "accession_version": "NC_024741.1", "source_length": len(heliconius_source["sequence"]), "source_sequence_sha256": heliconius_source["sequence_sha256"], "start": 11661, "end": 12600, "strand": "-", "wraps_origin": False, "sequence_sha256": digest(nd1_sequence.encode())}},
    })
    identifiers = [proposal["legacy_entry_id"] for proposal in proposals]
    assert len(identifiers) == len(set(identifiers))
    assert quarantine <= set(identifiers), sorted(quarantine - set(identifiers))
    before = ROOT / "frozen_before"
    after = ROOT / "proposed_after"
    old_catalog_path = before / "panels/reference_sources.json.gz"
    if not old_catalog_path.exists():
        old_catalog_path = REPOSITORY / "panels/reference_sources.json.gz"
    old_catalog_bytes = old_catalog_path.read_bytes()
    catalog = json.loads(gzip.decompress(old_catalog_bytes))
    panels = {}
    decisions = []
    for proposal in proposals:
        identifier = proposal["legacy_entry_id"]
        if identifier in legacy:
            entry = legacy[identifier]
            panel_path = entry["panel_path"]
        else:
            panel_path = proposal["panel_path"]
        if panel_path not in panels:
            path = before / panel_path
            if not path.exists():
                path = REPOSITORY / panel_path
            panels[panel_path] = yaml.safe_load(path.read_text())
            destination = before / panel_path
            destination.parent.mkdir(parents=True, exist_ok=True)
            if not destination.exists():
                destination.write_bytes(path.read_bytes())
        panel = panels[panel_path]
        reference = proposal.get("reference")
        decision = {key: value for key, value in proposal.items() if key not in {"source_record", "reference"}}
        decision.update({"panel_path": panel_path, "quarantined_legacy_entry": identifier in quarantine})
        if reference is None:
            decision["integration_action"] = "unresolved_no_reference_added"
            decisions.append(decision)
            continue
        if identifier == "reference:0:0":
            reference = copy.deepcopy(panel["references"][0]["sequences"][0])
            decision.update({
                "integration_action": "retain_existing_independent_Hydra_example",
                "gene_name": "16S", "reference": {key: value for key, value in reference.items() if key != "sequence"},
                "reference_length": len(reference["sequence"]),
                "reason": "The previous audit already replaced the Xenia/mutS example with public Hydra16S; keep Hydra consistent with this documentation panel's Hydrozoa clade. New Xenia16S proposal is used only in cnidaria.",
                "annotation": {"scope": "existing_independent_Hydra_16S_example", "taxon_relation": "different_taxon_documentation_example", "evidence": "v3.2-reference-provenance-20260913; sourceclean audit at66704f9"},
            })
            decisions.append(decision)
            continue
        gene_name = reference.pop("gene_name")
        if identifier in {"insecta:9:1", "insecta:9:2"}:
            assert gene_name == "ND2"
            gene_name = "NADH"
            decision["reviewed_target_scope"] = "Legacy NADH assay independently maps tRNA-Met into ND2; this reference is annotated ND2, not asserted full primer interval."
            decision["primer_mapping_receipt"] = "insecta/nadh_primer_mapping.json"
        source = proposal["source_record"]
        accession = source["accession_version"]
        assert accession == reference["accession"]
        if accession in catalog["records"]:
            existing = catalog["records"][accession]
            for key in ("sequence", "sequence_sha256", "organism", "taxid", "topology"):
                assert existing[key] == source[key], (accession, key, existing[key] if key != "sequence" else "sequence differs")
        else:
            catalog["records"][accession] = source
        if identifier == "reference:0:0":
            panel["references"] = []
        group = next((group for group in panel["references"] if group["gene"] == gene_name), None)
        if group is None:
            group = {"gene": gene_name, "sequences": []}
            panel["references"].append(group)
        if identifier == "insecta:2:1":
            old_reference = next(item for item in group["sequences"] if item["accession"] == accession)
            assert old_reference["sequence"] in reference["sequence"]
            group["sequences"].remove(old_reference)
            action = "expand_existing_public_gene_reference"
        elif identifier == "reference:0:0":
            action = "replace_independent_example_with_public_Xenia"
        else:
            action = "add_public_reference"
        if reference in group["sequences"]:
            action = "share_existing_public_reference"
        else:
            group["sequences"].append(reference)
        decision.update({
            "integration_action": action,
            "gene_name": gene_name,
            "reference": {key: value for key, value in reference.items() if key != "sequence"},
            "reference_length": len(reference["sequence"]),
        })
        decisions.append(decision)
    patch = ["*** Begin Patch\n"]
    for panel_path, panel in sorted(panels.items()):
        original = (before / panel_path).read_text()
        before_panel = yaml.safe_load(original)
        if panel["references"] == before_panel["references"]:
            continue
        version_parts = panel["panel_version"].split(".")
        version_parts[-1] = str(int(version_parts[-1]) + 1)
        new_version = ".".join(version_parts)
        old_version = panel["panel_version"]
        note = "Add independently annotated public reference regions with exact-source provenance; source taxa and partial/homologous scope remain explicit. Primers and validation samples unchanged."
        prefix = original.split("\nreferences:", 1)[0]
        prefix = re.sub(r"(?m)^panel_version: [^\s]+", f"panel_version: {new_version}", prefix, count=1)
        indentation = re.search(r"changelog:\n( *)- ", prefix).group(1)
        prefix = prefix.replace("changelog:\n", f"changelog:\n{indentation}- panel_version: {new_version}\n{indentation}  date: 2026-09-13\n{indentation}  sharkmer_version: \"3.2.0-dev\"\n{indentation}  changes: \"{note}\"\n", 1)
        updated = prefix + "\n" + yaml.safe_dump({"references": panel["references"]}, sort_keys=False, width=1000000, allow_unicode=True)
        actual = yaml.safe_load(updated)
        for key, value in before_panel.items():
            if key not in {"references", "panel_version", "changelog"}:
                assert actual[key] == value, (panel_path, key)
        path = after / panel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(updated)
        patch.append(f"*** Update File: {panel_path}\n")
        diff = list(difflib.unified_diff(original.splitlines(True), updated.splitlines(True), n=3))
        for line in diff[2:]:
            patch.append("@@\n" if line.startswith("@@") else line)
    patch.append("*** End Patch\n")
    (ROOT / "integration.patch").write_text("".join(patch))
    (before / "panels/reference_sources.json.gz").write_bytes(old_catalog_bytes)
    catalog["replacement_acquisition"] = {
        "date": "2026-09-13", "proposal_manifests": manifests,
        "scope": "Reviewed public-region additions; original entries and source_archive remain historical initial-audit metadata, not current active inventory.",
    }
    catalog_bytes = gzip.compress((json.dumps(catalog, sort_keys=True, separators=(",", ":")) + "\n").encode(), mtime=0)
    (after / "panels/reference_sources.json.gz").write_bytes(catalog_bytes)
    receipt = {
        "schema_version": 1,
        "source_commit": "66704f95d8a36ce9fcdee1cf1371eae67d8b3e6a",
        "proposal_manifests": manifests,
        "before_catalog_sha256": digest(old_catalog_bytes),
        "after_catalog_sha256": digest(catalog_bytes),
        "catalog_record_count": len(catalog["records"]),
        "decisions": decisions,
        "quarantined_legacy_count": len(quarantine),
        "quarantined_with_public_replacement": sum(item["quarantined_legacy_entry"] and "reference" in item for item in decisions),
        "integration_actions": dict(Counter(item["integration_action"] for item in decisions)),
        "panel_invariants": "Only references, panel patch versions and changelogs differ; primer definitions, sample taxa and assembly settings are unchanged.",
    }
    (ROOT / "integration_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key not in {"decisions", "proposal_manifests"}}, indent=2))


if __name__ == "__main__":
    main()
