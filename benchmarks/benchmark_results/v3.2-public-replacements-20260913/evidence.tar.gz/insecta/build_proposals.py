#!/usr/bin/env python3

import hashlib
import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LEGACY_PATH = Path("/tmp/sharkmer-reference-audit-20260913/legacy_references.json")
RAW_FILES = {
    "quarantined_records.gb.xml": "2026-09-13T14:22:59.955028+00:00",
    "replacement_records.gb.xml": "2026-09-13T14:28:51.975852+00:00",
}
SOURCE_REQUESTS = [
    {
        "endpoint": "efetch",
        "params": {
            "db": "nuccore",
            "id": "EU494495.1,KP073314.1,OM754561.1,KM252505.1,MK659833.1,PP230540.1,BK006341.1,NC_026564.1,NC_005780.1,KM252239.1,KP074829.1,KM252494.1,KM252368.1,AC007928.7,AY183920.1,AK281049.1,XR_006246778.1,K01281.1,NC_024741.1,NC_024864.1,AK281180.1",
            "rettype": "gbwithparts",
            "retmode": "xml",
        },
        "raw_file": "raw/quarantined_records.gb.xml",
        "retrieved_at": RAW_FILES["quarantined_records.gb.xml"],
    },
    {
        "endpoint": "efetch",
        "params": {
            "db": "nuccore",
            "id": "HQ170726.1,HQ171031.1,L14423.1,NR_133562.1,KM508879.1,KR270069.1,MK441842.1",
            "rettype": "gbwithparts",
            "retmode": "xml",
        },
        "raw_file": "raw/replacement_records.gb.xml",
        "retrieved_at": RAW_FILES["replacement_records.gb.xml"],
    },
]
COMPLEMENT = str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN")


SELECTIONS = [
    {
        "legacy_entry_id": "insecta:0:0",
        "accession": "EU494495.1",
        "feature_type": "rRNA",
        "location": "complement(257..>697)",
        "gene_name": "12S",
        "scope": "annotated partial 12S rRNA feature",
    },
    {
        "legacy_entry_id": "insecta:1:3",
        "accession": "NC_024741.1",
        "feature_type": "rRNA",
        "location": "complement(12669..14048)",
        "gene_name": "16S_1",
        "scope": "complete annotated mitochondrial 16S rRNA feature",
    },
    {
        "legacy_entry_id": "insecta:2:0",
        "accession": "OM754561.1",
        "feature_type": "gene",
        "location": "<1..>650",
        "gene_name": "CO1_1",
        "scope": "annotated partial COX1 record",
    },
    {
        "legacy_entry_id": "insecta:3:1",
        "accession": "HQ170726.1",
        "feature_type": "gene",
        "location": "1..>688",
        "gene_name": "CO2_1",
        "scope": "annotated partial COII record",
    },
    {
        "legacy_entry_id": "insecta:5:0",
        "accession": "MK659833.1",
        "feature_type": "gene",
        "location": "complement(8268..9606)",
        "gene_name": "ND4",
        "scope": "complete annotated mitochondrial ND4 feature",
    },
    {
        "legacy_entry_id": "insecta:5:1",
        "accession": "PP230540.1",
        "feature_type": "gene",
        "location": "complement(8067..9410)",
        "gene_name": "ND4",
        "scope": "complete annotated mitochondrial ND4 feature",
    },
    {
        "legacy_entry_id": "insecta:6:1",
        "accession": "HQ171031.1",
        "feature_type": "rRNA",
        "location": "<1..>383",
        "gene_name": "16S_2",
        "scope": "annotated partial 16S rRNA record",
    },
    {
        "legacy_entry_id": "insecta:6:2",
        "accession": "PP230540.1",
        "feature_type": "rRNA",
        "location": "complement(12591..13903)",
        "gene_name": "16S_2",
        "scope": "complete annotated mitochondrial 16S rRNA feature",
    },
    {
        "legacy_entry_id": "insecta:6:3",
        "accession": "NC_024741.1",
        "feature_type": "rRNA",
        "location": "complement(12669..14048)",
        "gene_name": "16S_2",
        "scope": "complete annotated mitochondrial 16S rRNA feature",
    },
    {
        "legacy_entry_id": "insecta:7:1",
        "accession": "NC_005780.1",
        "feature_type": "gene",
        "location": "<1476..3012",
        "gene_name": "CO1_2",
        "scope": "annotated mitochondrial COX1 feature with uncertain start",
    },
    {
        "legacy_entry_id": "insecta:7:2",
        "accession": "OM754561.1",
        "feature_type": "gene",
        "location": "<1..>650",
        "gene_name": "CO1_2",
        "scope": "annotated partial COX1 record",
    },
    {
        "legacy_entry_id": "insecta:7:3",
        "accession": "KP074829.1",
        "feature_type": "gene",
        "location": "<1..1521",
        "gene_name": "CO1_2",
        "scope": "annotated mitochondrial COI feature with uncertain start",
    },
    {
        "legacy_entry_id": "insecta:8:2",
        "accession": "HQ170726.1",
        "feature_type": "gene",
        "location": "1..>688",
        "gene_name": "CO2_2",
        "scope": "annotated partial COII record",
    },
    {
        "legacy_entry_id": "insecta:9:1",
        "accession": "KM252368.1",
        "feature_type": "gene",
        "location": "32..>520",
        "gene_name": "ND2",
        "scope": "annotated partial mitochondrial ND2 feature",
        "requires_target_relabel": True,
    },
    {
        "legacy_entry_id": "insecta:9:2",
        "accession": "PP230540.1",
        "feature_type": "gene",
        "location": "205..1221",
        "gene_name": "ND2",
        "scope": "complete annotated mitochondrial ND2 feature",
        "requires_target_relabel": True,
    },
    {
        "legacy_entry_id": "insecta:10:0",
        "accession": "L14423.1",
        "feature_type": "gene",
        "location": "1..1114",
        "gene_name": "Yp2",
        "scope": "contiguous partial genomic Yp2 locus containing two partial exons and intervening intron",
    },
    {
        "legacy_entry_id": "insecta:12:0",
        "accession": "NR_133562.1",
        "feature_type": "rRNA",
        "location": "1..3970",
        "gene_name": "28S",
        "scope": "complete RefSeq 28S rRNA record",
    },
    {
        "legacy_entry_id": "insecta:12:1",
        "accession": "KM508879.1",
        "feature_type": "rRNA",
        "location": "<1..>1266",
        "gene_name": "28S",
        "scope": "annotated partial 28S rRNA record",
    },
    {
        "legacy_entry_id": "insecta:13:2",
        "accession": "XR_006246778.1",
        "feature_type": "rRNA",
        "location": "1..1994",
        "gene_name": "18S_2",
        "scope": "predicted complete small-subunit rRNA record",
    },
    {
        "legacy_entry_id": "insecta:14:0",
        "accession": "KR270069.1",
        "feature_type": "misc_RNA",
        "location": "<1..>558",
        "gene_name": "ITS_1",
        "scope": "annotated partial locus containing ITS1 and 5.8S rRNA",
    },
    {
        "legacy_entry_id": "insecta:15:0",
        "accession": "PP230540.1",
        "feature_type": "gene",
        "location": "10362..11498",
        "gene_name": "CytB",
        "scope": "complete annotated mitochondrial cytochrome-b feature",
    },
    {
        "legacy_entry_id": "insecta:15:1",
        "accession": "NC_024741.1",
        "feature_type": "gene",
        "location": "10433..11581",
        "gene_name": "CytB",
        "scope": "complete annotated mitochondrial cytochrome-b feature",
    },
    {
        "legacy_entry_id": "insecta:16:0",
        "accession": "NC_024741.1",
        "feature_type": "gene",
        "location": "complement(6333..8066)",
        "gene_name": "ND5",
        "scope": "complete annotated mitochondrial ND5 feature",
    },
    {
        "legacy_entry_id": "insecta:17:0",
        "accession": "MK441842.1",
        "feature_type": "misc_RNA",
        "location": "<1..>664",
        "gene_name": "ITS_2",
        "scope": "annotated partial ITS2 record",
    },
    {
        "legacy_entry_id": "insecta:2:1",
        "accession": "PP230540.1",
        "feature_type": "gene",
        "location": "<1409..2939",
        "gene_name": "CO1_1",
        "scope": "annotated COX1 feature with uncertain start, expanding the retained 304-base public subregion",
        "expansion": True,
    },
]


def sha256_bytes(content):
    return hashlib.sha256(content).hexdigest()


def parse_records():
    records = {}
    for name, retrieved_at in RAW_FILES.items():
        raw_path = ROOT / "raw" / name
        root = ET.parse(raw_path).getroot()
        for element in root.findall(".//GBSeq"):
            accession = element.findtext("GBSeq_accession-version")
            source_qualifiers = qualifiers(element.find("./GBSeq_feature-table/GBFeature"))
            taxon_values = source_qualifiers.get("db_xref", [])
            taxon = next(value for value in taxon_values if value.startswith("taxon:"))
            records[accession] = {
                "element": element,
                "raw_path": raw_path,
                "retrieved_at": retrieved_at,
                "source_record": {
                    "accession_version": accession,
                    "sequence": element.findtext("GBSeq_sequence").upper(),
                    "organism": element.findtext("GBSeq_organism"),
                    "taxid": int(taxon.split(":", 1)[1]),
                    "title": element.findtext("GBSeq_definition"),
                    "topology": element.findtext("GBSeq_topology").lower(),
                    "url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&rettype=gbwithparts&retmode=xml",
                    "retrieved_at": retrieved_at,
                },
            }
            source = records[accession]["source_record"]
            source["sequence_sha256"] = sha256_bytes(source["sequence"].encode("ascii"))
    return records


def qualifiers(feature):
    values = {}
    if feature is None:
        return values
    for qualifier in feature.findall("./GBFeature_quals/GBQualifier"):
        name = qualifier.findtext("GBQualifier_name")
        value = qualifier.findtext("GBQualifier_value") or ""
        values.setdefault(name, []).append(value)
    return values


def find_feature(record, feature_type, location):
    matches = [
        feature
        for feature in record["element"].findall("./GBSeq_feature-table/GBFeature")
        if feature.findtext("GBFeature_key") == feature_type
        and feature.findtext("GBFeature_location") == location
    ]
    if len(matches) != 1:
        raise ValueError(f"Expected one {feature_type} {location}, found {len(matches)}")
    return matches[0]


def extract_location(source, location):
    complement = location.startswith("complement(")
    normalized = location.removeprefix("complement(").removesuffix(")")
    if normalized.startswith("join(") or "," in normalized:
        raise ValueError(f"Joined feature is not represented as contiguous: {location}")
    match = re.fullmatch(r"[<>]?(\d+)\.\.[<>]?(\d+)", normalized)
    if match is None:
        raise ValueError(f"Unsupported feature location: {location}")
    start = int(match.group(1)) - 1
    end = int(match.group(2))
    sequence = source[start:end]
    if complement:
        sequence = sequence.translate(COMPLEMENT)[::-1]
    return sequence, start, end, "-" if complement else "+"


def build_proposal(selection, legacy_by_id, records):
    record = records[selection["accession"]]
    source_record = record["source_record"]
    feature = find_feature(record, selection["feature_type"], selection["location"])
    sequence, start, end, strand = extract_location(
        source_record["sequence"], selection["location"]
    )
    legacy = legacy_by_id[selection["legacy_entry_id"]]
    legacy_taxon = legacy["original_reference"]["taxon"]
    same_taxon = legacy_taxon == source_record["organism"]
    if selection.get("expansion"):
        disposition = "proposed_expansion_of_retained_public_reference"
    elif selection.get("requires_target_relabel"):
        disposition = "proposed_public_replacement_requires_NADH_to_ND2_review"
    elif same_taxon:
        disposition = "proposed_public_replacement_same_species"
    else:
        disposition = "proposed_public_replacement_related_taxon"
    if selection.get("requires_target_relabel"):
        reason = (
            "Independent GenBank feature annotation identifies the legacy NADH target as ND2; "
            "primer-to-locus compatibility remains to be evaluated before panel migration."
        )
    elif selection.get("expansion"):
        reason = (
            "Expands the retained 304-base public subregion to the annotated COX1 feature whose "
            "start is marked uncertain; "
            "this does not establish sample haplotype or primer-region support."
        )
    elif same_taxon:
        reason = (
            "Uses an independently annotated public feature from the same named species; "
            "this does not establish sample haplotype or primer-region support."
        )
    else:
        reason = (
            f"No suitable annotated same-species record was selected; this public feature is from "
            f"related taxon {source_record['organism']} and must be labeled as such."
        )
    provenance = {
        "schema_version": 1,
        "kind": "public_record_region",
        "accession_version": source_record["accession_version"],
        "source_length": len(source_record["sequence"]),
        "source_sequence_sha256": source_record["sequence_sha256"],
        "start": start,
        "end": end,
        "strand": strand,
        "wraps_origin": False,
        "sequence_sha256": sha256_bytes(sequence.encode("ascii")),
    }
    return {
        "legacy_entry_id": selection["legacy_entry_id"],
        "disposition": disposition,
        "reference": {
            "gene_name": selection["gene_name"],
            "taxon": source_record["organism"],
            "accession": source_record["accession_version"],
            "sequence": sequence,
            "provenance": provenance,
        },
        "annotation": {
            "raw_file": str(record["raw_path"].relative_to(ROOT)),
            "feature_type": selection["feature_type"],
            "location": selection["location"],
            "qualifiers": qualifiers(feature),
            "scope": selection["scope"],
            "taxon_relation": "same_species" if same_taxon else "related_taxon",
            "legacy_taxon": legacy_taxon,
        },
        "reason": reason,
        "source_record": source_record,
    }


def raw_receipts():
    receipts = []
    for path in sorted((ROOT / "raw").iterdir()):
        if not path.is_file():
            continue
        content = path.read_bytes()
        receipts.append(
            {
                "path": str(path.relative_to(ROOT)),
                "size_bytes": len(content),
                "sha256": sha256_bytes(content),
            }
        )
    return receipts


def main():
    legacy = json.loads(LEGACY_PATH.read_text())
    legacy_by_id = {entry["entry_id"]: entry for entry in legacy["entries"]}
    records = parse_records()
    proposals = [build_proposal(selection, legacy_by_id, records) for selection in SELECTIONS]
    requests = []
    for request in SOURCE_REQUESTS:
        raw_path = ROOT / request["raw_file"]
        requests.append(
            {
                **request,
                "raw_sha256": sha256_bytes(raw_path.read_bytes()),
                "tool": "ncbi-entrez-skill/scripts/ncbi_entrez.py",
            }
        )
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "Public annotated replacement proposals; no panel migration or sample-haplotype claim",
        "legacy_manifest": {
            "path": str(LEGACY_PATH),
            "sha256": sha256_bytes(LEGACY_PATH.read_bytes()),
        },
        "source_acquisition": {
            "tool": "ncbi-entrez-skill/scripts/ncbi_entrez.py",
            "database": "nuccore",
            "source_requests": requests,
            "raw_receipts": raw_receipts(),
            "retrieval_scope": "GenBank XML plus NCBI search/summary responses",
        },
        "limitations": [
            "Public feature provenance does not establish the sequenced sample haplotype.",
            "Primer binding and expected amplicon-region coverage were not evaluated here.",
            "Related-taxon proposals remain explicitly labeled and are not same-species substitutes.",
            "ND2 relabel proposals require panel target and primer review before use.",
        ],
        "proposals": proposals,
    }
    output = ROOT / "proposals.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(output)
    print(sha256_bytes(output.read_bytes()))


if __name__ == "__main__":
    main()
