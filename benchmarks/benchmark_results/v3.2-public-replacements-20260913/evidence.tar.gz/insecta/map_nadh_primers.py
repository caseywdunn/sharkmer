#!/usr/bin/env python3

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent
REPO = Path("/home/claude/repos/sharkmer")
PANEL_PATH = REPO / "panels" / "insecta.yaml"
PROPOSALS_PATH = ROOT / "proposals.json"
COMPLEMENT = str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN")
IUPAC = {
    "A": set("A"),
    "C": set("C"),
    "G": set("G"),
    "T": set("T"),
    "R": set("AG"),
    "Y": set("CT"),
    "S": set("GC"),
    "W": set("AT"),
    "K": set("GT"),
    "M": set("AC"),
    "B": set("CGT"),
    "D": set("AGT"),
    "H": set("ACT"),
    "V": set("ACG"),
    "N": set("ACGT"),
}


TARGETS = [
    {
        "name": "KM252368.1_annotated_ND2_partial",
        "accession": "KM252368.1",
        "gene": "ND2",
        "location": "1..520",
        "annotated_features": [
            {"type": "gene", "location": "32..>520", "gene": "ND2"},
        ],
        "source": "proposal",
    },
    {
        "name": "PP230540.1_tRNA-Met_to_annotated_ND2",
        "accession": "PP230540.1",
        "gene": "ND2",
        "location": "136..1221",
        "annotated_features": [
            {"type": "tRNA", "location": "136..204", "gene": "tRNA-Met"},
            {"type": "gene", "location": "205..1221", "gene": "ND2"},
        ],
        "source": "proposal",
    },
    {
        "name": "NC_005780.1_tRNA-Met_to_annotated_ND2",
        "accession": "NC_005780.1",
        "gene": "ND2",
        "location": "173..1265",
        "annotated_features": [
            {"type": "tRNA", "location": "173..241", "gene": "tRNA-Met"},
            {"type": "gene", "location": "242..1265", "gene": "ND2"},
        ],
        "source": "raw_source",
    },
    {
        "name": "NC_005780.1_retained_legacy_NADH_region",
        "accession": "NC_005780.1",
        "gene": "legacy_NADH_reference_region",
        "location": "196..745",
        "annotated_features": [
            {"type": "tRNA", "location": "173..241", "gene": "tRNA-Met"},
            {"type": "gene", "location": "242..1265", "gene": "ND2"},
        ],
        "source": "panel_reference",
    },
]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reverse_complement(sequence):
    return sequence.translate(COMPLEMENT)[::-1]


def mismatch_details(pattern, observed):
    positions = [
        index
        for index, (expected, nucleotide) in enumerate(zip(pattern, observed))
        if nucleotide not in IUPAC[expected]
    ]
    return len(positions), positions


def scan(pattern, sequence, allowed_mismatches):
    all_hits = []
    for start in range(len(sequence) - len(pattern) + 1):
        observed = sequence[start : start + len(pattern)]
        mismatch_count, mismatch_positions = mismatch_details(pattern, observed)
        all_hits.append(
            {
                "start": start,
                "end": start + len(pattern),
                "observed": observed,
                "mismatch_count": mismatch_count,
                "mismatch_positions_zero_based": mismatch_positions,
            }
        )
    minimum = min((hit["mismatch_count"] for hit in all_hits), default=None)
    nearest = [hit for hit in all_hits if hit["mismatch_count"] == minimum]
    return {
        "eligible_hits": [
            hit for hit in all_hits if hit["mismatch_count"] <= allowed_mismatches
        ],
        "minimum_mismatches": minimum,
        "nearest_hit_count": len(nearest),
        "nearest_hits": nearest[:20],
    }


def assess_sequence(sequence, primer):
    trim = primer["trim"]
    allowed_mismatches = primer["mismatches"]
    forward_effective = primer["forward_seq"][-trim:]
    reverse_effective = primer["reverse_seq"][-trim:]
    reverse_binding = reverse_complement(reverse_effective)
    orientations = []
    for orientation, oriented in (("forward", sequence), ("reverse_complement", reverse_complement(sequence))):
        forward_scan = scan(forward_effective, oriented, allowed_mismatches)
        reverse_scan = scan(reverse_binding, oriented, allowed_mismatches)
        pairs = []
        for forward_hit in forward_scan["eligible_hits"]:
            for reverse_hit in reverse_scan["eligible_hits"]:
                if reverse_hit["start"] < forward_hit["end"]:
                    continue
                product_length = reverse_hit["end"] - forward_hit["start"]
                pairs.append(
                    {
                        "start": forward_hit["start"],
                        "end": reverse_hit["end"],
                        "length": product_length,
                        "within_configured_length": (
                            primer["min_length"] <= product_length <= primer["max_length"]
                        ),
                        "forward_mismatches": forward_hit["mismatch_count"],
                        "reverse_mismatches": reverse_hit["mismatch_count"],
                    }
                )
        orientations.append(
            {
                "orientation": orientation,
                "forward_effective_scan": forward_scan,
                "reverse_effective_binding_scan": reverse_scan,
                "eligible_primer_pairs": pairs,
                "eligible_length_primer_pairs": [
                    pair for pair in pairs if pair["within_configured_length"]
                ],
            }
        )
    return {
        "length": len(sequence),
        "effective_forward_primer": forward_effective,
        "effective_reverse_primer": reverse_effective,
        "effective_reverse_binding_sequence": reverse_binding,
        "full_forward_scan": scan(primer["forward_seq"], sequence, allowed_mismatches),
        "full_reverse_binding_scan": scan(
            reverse_complement(primer["reverse_seq"]), sequence, allowed_mismatches
        ),
        "orientations": orientations,
    }


def source_interval(local_start, local_end, orientation, provenance):
    if orientation == "forward":
        return provenance["start"] + local_start, provenance["start"] + local_end
    return provenance["end"] - local_end, provenance["end"] - local_start


def add_source_coordinates(mapping, provenance):
    for orientation in mapping["orientations"]:
        orientation_name = orientation["orientation"]
        for scan_name in ("forward_effective_scan", "reverse_effective_binding_scan"):
            scan_result = orientation[scan_name]
            for collection_name in ("eligible_hits", "nearest_hits"):
                for hit in scan_result[collection_name]:
                    source_start, source_end = source_interval(
                        hit["start"], hit["end"], orientation_name, provenance
                    )
                    hit["source_start"] = source_start
                    hit["source_end"] = source_end
        for collection_name in ("eligible_primer_pairs", "eligible_length_primer_pairs"):
            for pair in orientation[collection_name]:
                source_start, source_end = source_interval(
                    pair["start"], pair["end"], orientation_name, provenance
                )
                pair["source_start"] = source_start
                pair["source_end"] = source_end


def load_source_records():
    proposals = json.loads(PROPOSALS_PATH.read_text())
    return {
        proposal["source_record"]["accession_version"]: proposal["source_record"]
        for proposal in proposals["proposals"]
    }


def target_sequence(target, source_records, panel):
    if target["source"] == "panel_reference":
        reference_group = next(group for group in panel["references"] if group["gene"] == "NADH")
        reference = next(
            item for item in reference_group["sequences"] if item["accession"] == target["accession"]
        )
        return reference["sequence"], reference["provenance"]
    source_record = source_records[target["accession"]]
    normalized = target["location"].replace("<", "").replace(">", "")
    start_text, end_text = normalized.split("..")
    start = int(start_text) - 1
    end = int(end_text)
    sequence = source_record["sequence"][start:end]
    return sequence, {
        "schema_version": 1,
        "kind": "public_record_region",
        "accession_version": target["accession"],
        "source_length": len(source_record["sequence"]),
        "source_sequence_sha256": source_record["sequence_sha256"],
        "start": start,
        "end": end,
        "strand": "+",
        "wraps_origin": False,
        "sequence_sha256": hashlib.sha256(sequence.encode("ascii")).hexdigest(),
    }


def main():
    panel = yaml.safe_load(PANEL_PATH.read_text())
    primer_index = next(
        index for index, candidate in enumerate(panel["primers"]) if candidate["gene"] == "NADH"
    )
    primer = panel["primers"][primer_index]
    source_records = load_source_records()
    assessments = []
    for target in TARGETS:
        sequence, provenance = target_sequence(target, source_records, panel)
        mapping = assess_sequence(sequence, primer)
        add_source_coordinates(mapping, provenance)
        assessments.append(
            {
                **target,
                "sequence_sha256": hashlib.sha256(sequence.encode("ascii")).hexdigest(),
                "provenance": provenance,
                "mapping": mapping,
            }
        )
    nd2 = [assessment for assessment in assessments if assessment["gene"] == "ND2"]
    nd2_pairs = sum(
        len(orientation["eligible_length_primer_pairs"])
        for assessment in nd2
        for orientation in assessment["mapping"]["orientations"]
    )
    nd2_eligible_hits = sum(
        len(orientation[scan_name]["eligible_hits"])
        for assessment in nd2
        for orientation in assessment["mapping"]["orientations"]
        for scan_name in ("forward_effective_scan", "reverse_effective_binding_scan")
    )
    compatible_nd2 = [
        assessment
        for assessment in nd2
        if any(
            orientation["eligible_length_primer_pairs"]
            for orientation in assessment["mapping"]["orientations"]
        )
    ]
    if compatible_nd2:
        conclusion = (
            "The legacy NADH marker maps to the tRNA-Met-to-ND2 locus in complete mitochondrial "
            "references. NADH can remain the stable output marker label if curated metadata states "
            "that the assayed locus spans upstream tRNA-Met into annotated ND2; it must not be "
            "presented as an unspecified NADH gene. The partial KM252368.1 ND2 record lacks the "
            "upstream primer context and supplies homologous-locus support only."
        )
    else:
        conclusion = "Primer-to-locus mapping is unresolved and requires manual review."
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "Direct configured-primer mapping to independently annotated public features",
        "inputs": {
            "panel": {"path": str(PANEL_PATH), "sha256": sha256(PANEL_PATH)},
            "proposals": {"path": str(PROPOSALS_PATH), "sha256": sha256(PROPOSALS_PATH)},
        },
        "configured_primer": {
            "panel_index_zero_based": primer_index,
            "gene": primer["gene"],
            "index": primer.get("index"),
            "forward_seq": primer["forward_seq"],
            "reverse_seq": primer["reverse_seq"],
            "trim": primer["trim"],
            "mismatches": primer["mismatches"],
            "min_length": primer["min_length"],
            "max_length": primer["max_length"],
        },
        "coordinate_system": "zero-based half-open within the gene-oriented assessed sequence",
        "assessments": assessments,
        "summary": {
            "annotated_nd2_eligible_length_pair_count": nd2_pairs,
            "annotated_nd2_eligible_effective_primer_hit_count": nd2_eligible_hits,
            "annotated_nd2_contexts_with_eligible_pair": [
                assessment["name"] for assessment in compatible_nd2
            ],
            "conclusion": conclusion,
        },
        "limitations": [
            "No Sharkmer product sequence or read evidence was used.",
            "This evaluates configured trimmed-primer matching and length bounds, not assay sensitivity.",
            "Public-reference mapping does not establish any sequenced sample haplotype.",
        ],
    }
    output = ROOT / "nadh_primer_mapping.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(output)
    print(sha256(output))
    print(conclusion)


if __name__ == "__main__":
    main()
