import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LEGACY = Path("/tmp/sharkmer-reference-audit-20260913/legacy_references.json")
COMPLEMENT = str.maketrans("ACGTRYSWKMBDHVN", "TGCAYRSWMKVHDBN")


class ProposalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.document = json.loads((ROOT / "proposals.json").read_text())
        cls.proposals = cls.document["proposals"]
        cls.legacy = json.loads(LEGACY.read_text())

    def test_every_quarantined_insect_entry_has_one_proposal(self):
        expected = {
            entry["entry_id"]
            for entry in self.legacy["entries"]
            if entry.get("panel_path") == "panels/insecta.yaml"
            and entry["disposition"].startswith("quarantined")
        }
        observed = [
            proposal["legacy_entry_id"]
            for proposal in self.proposals
            if not proposal["disposition"].startswith("proposed_expansion")
        ]
        self.assertEqual(len(expected), 24)
        self.assertEqual(set(observed), expected)
        self.assertEqual(len(observed), len(set(observed)))

    def test_public_region_provenance_reconstructs_every_sequence(self):
        for proposal in self.proposals:
            source = proposal["source_record"]
            reference = proposal["reference"]
            provenance = reference["provenance"]
            sequence = source["sequence"][provenance["start"] : provenance["end"]]
            if provenance["strand"] == "-":
                sequence = sequence.translate(COMPLEMENT)[::-1]
            self.assertEqual(reference["sequence"], sequence)
            self.assertEqual(
                provenance["sequence_sha256"],
                hashlib.sha256(sequence.encode("ascii")).hexdigest(),
            )

    def test_source_records_follow_catalog_contract_and_size_limit(self):
        for proposal in self.proposals:
            source = proposal["source_record"]
            self.assertRegex(source["accession_version"], r"^[A-Z][A-Z0-9_]*\.[0-9]+$")
            self.assertLessEqual(len(source["sequence"]), 5 * 1024 * 1024)
            self.assertEqual(
                source["sequence_sha256"],
                hashlib.sha256(source["sequence"].encode("ascii")).hexdigest(),
            )
            self.assertIn(source["topology"], {"linear", "circular"})
            self.assertGreater(source["taxid"], 0)

    def test_raw_acquisition_receipts_are_current(self):
        for receipt in self.document["source_acquisition"]["raw_receipts"]:
            path = ROOT / receipt["path"]
            content = path.read_bytes()
            self.assertEqual(receipt["size_bytes"], len(content))
            self.assertEqual(receipt["sha256"], hashlib.sha256(content).hexdigest())

        for request in self.document["source_acquisition"]["source_requests"]:
            content = (ROOT / request["raw_file"]).read_bytes()
            self.assertEqual(request["raw_sha256"], hashlib.sha256(content).hexdigest())
            self.assertEqual(request["endpoint"], "efetch")
            self.assertEqual(request["params"]["rettype"], "gbwithparts")
            self.assertEqual(request["params"]["retmode"], "xml")

    def test_gene_references_are_annotated_features_not_whole_mitogenomes(self):
        for proposal in self.proposals:
            self.assertNotEqual(proposal["annotation"]["feature_type"], "source")
            if "mitochondrion, complete genome" in proposal["source_record"]["title"]:
                self.assertLess(
                    len(proposal["reference"]["sequence"]),
                    len(proposal["source_record"]["sequence"]),
                )

    def test_related_taxa_are_not_presented_as_same_species(self):
        for proposal in self.proposals:
            annotation = proposal["annotation"]
            same = annotation["legacy_taxon"] == proposal["reference"]["taxon"]
            self.assertEqual(annotation["taxon_relation"] == "same_species", same)
            if not same:
                self.assertIn("related_taxon", proposal["disposition"])

    def test_ambiguous_nadh_entries_are_reidentified_as_nd2(self):
        proposals = [
            proposal
            for proposal in self.proposals
            if proposal["legacy_entry_id"] in {"insecta:9:1", "insecta:9:2"}
        ]
        self.assertEqual({proposal["reference"]["gene_name"] for proposal in proposals}, {"ND2"})
        self.assertTrue(all("NADH_to_ND2" in proposal["disposition"] for proposal in proposals))

    def test_co1_expansion_is_full_annotated_feature(self):
        proposal = next(
            proposal
            for proposal in self.proposals
            if proposal["disposition"] == "proposed_expansion_of_retained_public_reference"
        )
        self.assertEqual(proposal["legacy_entry_id"], "insecta:2:1")
        self.assertEqual(proposal["reference"]["accession"], "PP230540.1")
        self.assertEqual(len(proposal["reference"]["sequence"]), 1531)
        legacy = next(
            entry for entry in self.legacy["entries"] if entry["entry_id"] == "insecta:2:1"
        )
        self.assertIn(
            legacy["original_reference"]["sequence"], proposal["reference"]["sequence"]
        )


if __name__ == "__main__":
    unittest.main()
