import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent


class PrimerMappingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.path = ROOT / "nadh_primer_mapping.json"
        cls.document = json.loads(cls.path.read_text())

    def test_inputs_are_bound_by_hash(self):
        for receipt in self.document["inputs"].values():
            path = Path(receipt["path"])
            self.assertEqual(receipt["sha256"], hashlib.sha256(path.read_bytes()).hexdigest())

    def test_effective_primers_match_configured_trim(self):
        primer = self.document["configured_primer"]
        for assessment in self.document["assessments"]:
            mapping = assessment["mapping"]
            self.assertEqual(mapping["effective_forward_primer"], primer["forward_seq"][-15:])
            self.assertEqual(mapping["effective_reverse_primer"], primer["reverse_seq"][-15:])

    def test_complete_nd2_contexts_have_eligible_configured_product(self):
        nd2 = [assessment for assessment in self.document["assessments"] if assessment["gene"] == "ND2"]
        self.assertEqual(len(nd2), 3)
        partial = next(assessment for assessment in nd2 if assessment["accession"] == "KM252368.1")
        self.assertFalse(
            any(
                orientation["eligible_length_primer_pairs"]
                for orientation in partial["mapping"]["orientations"]
            )
        )
        for assessment in [item for item in nd2 if item["accession"] != "KM252368.1"]:
            pairs = [
                pair
                for orientation in assessment["mapping"]["orientations"]
                for pair in orientation["eligible_length_primer_pairs"]
            ]
            self.assertTrue(pairs)

        pp230540 = next(item for item in nd2 if item["accession"] == "PP230540.1")
        pp_pair = next(
            pair
            for orientation in pp230540["mapping"]["orientations"]
            for pair in orientation["eligible_length_primer_pairs"]
        )
        self.assertEqual(
            (pp_pair["source_start"], pp_pair["source_end"], pp_pair["length"]),
            (158, 702, 544),
        )

    def test_configured_primer_identity_is_nadh_marker(self):
        primer = self.document["configured_primer"]
        self.assertEqual(primer["panel_index_zero_based"], 11)
        self.assertEqual(primer["gene"], "NADH")

    def test_retained_legacy_reference_cannot_form_a_configured_product(self):
        retained = next(
            assessment
            for assessment in self.document["assessments"]
            if assessment["gene"] == "legacy_NADH_reference_region"
        )
        pairs = [
            pair
            for orientation in retained["mapping"]["orientations"]
            for pair in orientation["eligible_length_primer_pairs"]
        ]
        self.assertTrue(pairs)
        self.assertEqual(
            (pairs[0]["source_start"], pairs[0]["source_end"], pairs[0]["length"]),
            (195, 745, 550),
        )


if __name__ == "__main__":
    unittest.main()
