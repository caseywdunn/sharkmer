import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path("/home/claude/repos/sharkmer")
OUTPUT = REPOSITORY / "benchmarks/benchmark_results/v3.2-public-replacements-20260913"


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    source_files = set()
    for pattern in ("panels/**/*.yaml", "scripts/sharkmer_validate/*.py", "tests/test_*.py", "tests/fixtures/validation/*", "schemas/panel/*.json"):
        source_files.update(path for path in REPOSITORY.glob(pattern) if path.is_file())
    source_files.update(REPOSITORY / path for path in (
        "panels/reference_sources.json.gz", "scripts/audit_panel_references.py", "scripts/validate_panel.py",
        "benchmarks/run_benchmark.py", "benchmarks/DATASETS.md", "CHANGELOG.md", "PCR.md",
        "dev_docs/PLAN.md", "dev_docs/REFERENCE_PROVENANCE.md", "dev_docs/PUBLIC_REFERENCE_REPLACEMENTS.md",
        ".github/workflows/ci.yml",
    ))
    for path in sorted(source_files):
        assert path.is_file() and not path.is_symlink(), path
        destination = ROOT / "source_tree" / path.relative_to(REPOSITORY)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())
    members = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.is_symlink() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        contents = path.read_bytes()
        members.append({"path": str(path.relative_to(ROOT)), "size_bytes": len(contents), "sha256": digest(contents)})
    OUTPUT.mkdir(parents=True, exist_ok=True)
    archive = OUTPUT / "evidence.tar.gz"
    with archive.open("wb") as raw_output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw_output, mtime=0) as compressed:
            with tarfile.open(mode="w", fileobj=compressed) as bundle:
                for member in members:
                    contents = (ROOT / member["path"]).read_bytes()
                    assert digest(contents) == member["sha256"], "Evidence changed during packaging"
                    info = tarfile.TarInfo(member["path"])
                    info.size = len(contents)
                    info.mode = 0o644
                    info.mtime = 0
                    bundle.addfile(info, io.BytesIO(contents))
    index_path = OUTPUT / "ARCHIVE_CONTENTS.json"
    index_path.write_text(json.dumps({"schema_version": 1, "member_count": len(members), "members": members}, indent=2, sort_keys=True) + "\n")
    with tarfile.open(archive) as bundle:
        assert len(bundle.getmembers()) == len(members)
        for member in members:
            contents = bundle.extractfile(member["path"]).read()
            assert len(contents) == member["size_bytes"] and digest(contents) == member["sha256"]
    checksums = "".join(f"{digest(path.read_bytes())}  {path.name}\n" for path in (archive, index_path))
    (OUTPUT / "SHA256SUMS").write_text(checksums)
    print(f"Packaged and verified {len(members)} members; {archive.stat().st_size} compressed bytes")
    print(checksums)


if __name__ == "__main__":
    main()
