# Saved-output public-reference reclassification

This is a post-hoc BLAST alignment of immutable saved FASTA receipts. It did not run Sharkmer, ingest reads, select references from products, or alter the raw products or source result receipts.

- Source: 60 completed result JSON receipts under `/tmp/sharkmer-high-copy-20260911/final-execution/results`.
- Deduplication: only three-replicate groups with identical product fingerprints were represented once; the output retains every source result path and SHA-256.
- Catalog: `panels/reference_sources.json.gz`, SHA-256 `bc277321831258c00b6794a51b0289445c837f99b2399e54aa43fe5e60b0f49a`.
- Classifier thresholds: at least 90% identity and 90% query coverage, using the coherent collinear HSP rule.
- Output: `saved_output_reclassification.json`, SHA-256 `b20a24758e02d53880e5ed8ddf4a1a8677e1c8e88e197c33fc4ad1f9c7eb2f97`.

## Focused saved products

| Product | Saved version(s) | New status | Evidence |
|---|---|---|---|
| Gryllus ITS_2, 978 bp | baseline | `no_significant_hit` | No significant alignment to the expanded verified reference database. |
| Gryllus CO1_1, 373 bp | baseline | `insufficient_alignment` | PP230540.1, same logical gene/taxon: 328/373 bp at 100% identity, 87.936% query coverage. |
| Drosophila 12S, 475/487/499 bp | baseline | `no_significant_hit` | No significant alignment to the expanded verified reference database. |
| Drosophila 16S_2, 590 bp | baseline | `no_significant_hit` | No significant alignment to the expanded verified reference database. |
| Heliconius ND1, 263 bp | baseline | `insufficient_alignment` | NC_024741.1, same logical gene/taxon: 134/135 aligned bases at 99.259% identity, 51.331% query coverage. |
| Gryllus CO1_1, retained 352 bp | baseline and candidate | `gene_supported_expected_taxon` | PP230540.1: 351 bp at 100% identity, 99.716% query coverage in both saved versions. |

## Limits

Reference relationship is not read support, haplotype truth, molecular provenance, or an explanation for a SNP, indel, partial alignment, or absent hit. A no-hit or insufficient alignment may reflect reference scope or divergence; it does not establish that an emitted historical product was biologically wrong. Primer-region support remains `not_established` in the classifier output.
