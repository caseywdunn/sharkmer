#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path('/tmp/sharkmer-public-replacements-20260913/plants_nematode')
HELPER = Path('/home/claude/.codex/plugins/cache/openai-curated-remote/life-sciences-databases/0.1.5/skills/ncbi-entrez-skill/scripts/ncbi_entrez.py')
ACCESSIONS = [
    'MN990625', 'OQ613386', 'NC_056221', 'NC_008326', 'OR400606', 'NC_049166',
    'LN680643', 'MZ366774', 'FO080948', 'X15634', 'NM_072875',
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    raw_dir = ROOT / 'raw' / 'genbank'
    raw_dir.mkdir(parents=True, exist_ok=True)
    receipts = []
    for index, accession in enumerate(ACCESSIONS):
        raw_path = raw_dir / f'{accession}.gb'
        request = {
            'endpoint': 'efetch',
            'params': {'db': 'nuccore', 'id': accession, 'rettype': 'gb', 'retmode': 'text'},
            'response_format': 'text',
            'save_raw': True,
            'raw_output_path': str(raw_path),
            'timeout_sec': 60,
        }
        completed = subprocess.run(
            [sys.executable, str(HELPER)], input=json.dumps(request), text=True,
            capture_output=True, check=False,
        )
        response = json.loads(completed.stdout)
        if completed.returncode or not response.get('ok') or not raw_path.is_file():
            raise RuntimeError(f'Entrez fetch failed for {accession}: {response}')
        if raw_path.stat().st_size > 5 * 1024 * 1024:
            raise RuntimeError(f'Source record exceeds 5 MiB: {accession}')
        receipts.append({
            'accession_requested': accession,
            'raw_path': str(raw_path),
            'sha256': digest(raw_path),
            'size_bytes': raw_path.stat().st_size,
            'response': response,
            'retrieved_at': datetime.now(timezone.utc).isoformat(),
        })
        if index + 1 < len(ACCESSIONS):
            time.sleep(2.1)
    (ROOT / 'raw' / 'genbank_receipts.json').write_text(
        json.dumps({'schema_version': 1, 'records': receipts}, indent=2, sort_keys=True) + '\n'
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
