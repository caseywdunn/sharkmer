#!/usr/bin/env python3
"""Offline integrity and scope validation for the plant/nematode proposals."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import yaml


ROOT = Path('/tmp/sharkmer-public-replacements-20260913/plants_nematode')
PROPOSALS = ROOT / 'proposals.json'
MANIFEST = ROOT / 'raw' / 'artifact_manifest.json'
PANELS = Path('/home/claude/repos/sharkmer/panels')
IUPAC = {
    'A': {'A'}, 'C': {'C'}, 'G': {'G'}, 'T': {'T'}, 'R': {'A', 'G'},
    'Y': {'C', 'T'}, 'S': {'C', 'G'}, 'W': {'A', 'T'}, 'K': {'G', 'T'},
    'M': {'A', 'C'}, 'B': {'C', 'G', 'T'}, 'D': {'A', 'G', 'T'},
    'H': {'A', 'C', 'T'}, 'V': {'A', 'C', 'G'}, 'N': {'A', 'C', 'G', 'T'},
}
COMPLEMENT = str.maketrans('ACGTRYWSKMBDHVN', 'TGCAYRWSMKVHDBN')


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def reverse_complement(sequence: str) -> str:
    return sequence.translate(COMPLEMENT)[::-1]


def source_sequence(path: Path) -> str:
    text = path.read_text()
    return ''.join(re.findall(r'[A-Za-z]+', text.split('\nORIGIN', 1)[1])).upper()


def best_matches(sequence: str, primer: str, max_mismatches: int) -> list[dict]:
    matches = []
    for start in range(len(sequence) - len(primer) + 1):
        mismatches = sum(base not in IUPAC[code] for base, code in zip(sequence[start:start + len(primer)], primer))
        if mismatches <= max_mismatches:
            matches.append({'start': start, 'end': start + len(primer), 'mismatches': mismatches})
    return matches


def paired_primer_scope(source: str, reference: dict, primer: dict) -> dict:
    forward = primer['forward_seq'].upper()
    reverse = primer['reverse_seq'].upper()
    mismatch_limit = primer['mismatches']
    orientations = [
        ('+', forward, reverse_complement(reverse)),
        ('-', reverse, reverse_complement(forward)),
    ]
    pairs = []
    for strand, left, right in orientations:
        for left_match in best_matches(source, left, mismatch_limit):
            for right_match in best_matches(source, right, mismatch_limit):
                if left_match['end'] <= right_match['start']:
                    pairs.append({
                        'strand': strand,
                        'start': left_match['start'],
                        'end': right_match['end'],
                        'mismatches': left_match['mismatches'] + right_match['mismatches'],
                    })
    if not pairs:
        return {'status': 'no_compatible_full_primer_pair_in_source'}
    start, end = reference['provenance']['start'], reference['provenance']['end']
    pair = min(pairs, key=lambda item: (item['mismatches'], abs(item['start'] - start) + abs(item['end'] - end)))
    pair['status'] = 'compatible_full_primer_pair_in_source'
    pair['compatible_pair_count'] = len(pairs)
    pair['left_bases_outside_reference'] = max(0, start - pair['start'])
    pair['right_bases_outside_reference'] = max(0, pair['end'] - end)
    pair['reference_contains_full_pair'] = pair['start'] >= start and pair['end'] <= end
    return pair


def main() -> int:
    proposals = json.loads(PROPOSALS.read_text())
    manifest = json.loads(MANIFEST.read_text())
    errors = []
    for entry in manifest['files']:
        path = Path(entry['path'])
        if not path.is_file() or path.stat().st_size != entry['size_bytes'] or digest(path.read_bytes()) != entry['sha256']:
            errors.append(f"raw receipt mismatch: {path}")
    panels = {
        'angiospermae': yaml.safe_load((PANELS / 'angiospermae.yaml').read_text()),
        'c_elegans': yaml.safe_load((PANELS / 'c_elegans.yaml').read_text()),
    }
    rows = []
    for row in proposals['records']:
        entry_id = row['legacy_entry_id']
        reference = row['reference']
        if reference is None:
            rows.append({'entry_id': entry_id, 'disposition': row['disposition'], 'scope': row['annotation']['scope']})
            continue
        source = row['source_record']
        raw_path = Path(source['raw_file'])
        raw = raw_path.read_bytes() if raw_path.is_file() else b''
        sequence = source_sequence(raw_path) if raw else ''
        provenance = reference['provenance']
        expected = sequence[provenance['start']:provenance['end']]
        if provenance['strand'] == '-':
            expected = reverse_complement(expected)
        checks = {
            'source_sha256': digest(sequence.encode()) == source['sequence_sha256'],
            'source_length': len(sequence) == provenance['source_length'],
            'source_record_sequence': sequence == source['sequence'],
            'extracted_sequence': expected == reference['sequence'],
            'extracted_sha256': digest(expected.encode()) == provenance['sequence_sha256'],
            'raw_sha256': raw and digest(raw) == source['raw_sha256'],
        }
        failed = [name for name, passed in checks.items() if not passed]
        if failed:
            errors.append(f"{entry_id}: {', '.join(failed)}")
        row_result = {
            'entry_id': entry_id,
            'disposition': row['disposition'],
            'accession_version': source['accession_version'],
            'coordinates': [provenance['start'], provenance['end']],
            'strand': provenance['strand'],
            'length': len(reference['sequence']),
            'taxon_relation': row['annotation']['taxon_relation'],
            'scope': row['annotation']['scope'],
            'checks': checks,
        }
        if row_result['scope'] == 'primer_bounded_locus_spanning_annotated_intergenic_region':
            panel_name = entry_id.split(':', 1)[0]
            primer = next(item for item in panels[panel_name]['primers'] if item['gene'] == reference['gene_name'])
            primer_check = paired_primer_scope(sequence, reference, primer)
            row_result['full_primer_scope_check'] = primer_check
            expected_pair = row['annotation']['qualifiers']['full_primer_pair']
            checks['unique_full_primer_pair'] = (
                primer_check.get('compatible_pair_count') == expected_pair['count'] == 1
                and primer_check.get('start') == expected_pair['start']
                and primer_check.get('end') == expected_pair['end']
                and primer_check.get('strand') == expected_pair['strand']
                and primer_check.get('mismatches') == expected_pair['mismatches']
            )
            if not checks['unique_full_primer_pair']:
                errors.append(f'{entry_id}: primer-pair mapping differs from recorded proposal')
        rows.append(row_result)
    expected_ids = {
        'angiospermae:0:1', 'angiospermae:0:2', 'angiospermae:2:0', 'angiospermae:2:1',
        'angiospermae:3:1', 'angiospermae:6:1', 'angiospermae:7:0', 'angiospermae:8:1',
        'angiospermae:8:2', 'c_elegans:6:0', 'c_elegans:7:0', 'c_elegans:7:1',
    }
    if {row['entry_id'] for row in rows} != expected_ids:
        errors.append('proposal entry identifiers differ from the assigned twelve')
    output = {
        'schema_version': 1,
        'proposal_sha256': digest(PROPOSALS.read_bytes()),
        'artifact_manifest_sha256': digest(MANIFEST.read_bytes()),
        'valid': not errors,
        'errors': errors,
        'rows': rows,
    }
    (ROOT / 'validation.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    lines = ['# Public replacement proposal validation', '', f"Valid: `{output['valid']}`", '']
    lines += ['| Legacy entry | Disposition | Source | Coordinates / strand | Taxon relation |', '|---|---|---|---|---|']
    for row in rows:
        source = row.get('accession_version', '—')
        coords = '—' if 'coordinates' not in row else f"[{row['coordinates'][0]},{row['coordinates'][1]}) {row['strand']}"
        lines.append(f"| {row['entry_id']} | {row['disposition']} | {source} | {coords} | {row.get('taxon_relation', '—')} |")
    lines += ['', '## Intergenic spacer scope', '', 'These references are unique full-primer-bounded public locus spans containing their documented annotated spacers. The retained spacer coordinates identify the intergenic portion; flanking bases can be in neighboring annotated genes. No primer, product, or gene label is changed by this receipt.', '']
    for row in rows:
        check = row.get('full_primer_scope_check')
        if check:
            lines.append(f"- `{row['entry_id']}`: `{check['status']}`; {json.dumps({key: value for key, value in check.items() if key != 'status'}, sort_keys=True)}")
    (ROOT / 'validation.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'valid': output['valid'], 'errors': errors, 'rows': len(rows)}, sort_keys=True))
    return 0 if output['valid'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
