#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path('/tmp/sharkmer-public-replacements-20260913/plants_nematode')
RAW = ROOT / 'raw' / 'genbank'
LEGACY = Path('/tmp/sharkmer-reference-audit-20260913/legacy_references.json')
EXTRA_RETRIEVED = {
    'NM_001268234.5': '2026-09-13T14:25:31.510760+00:00',
    'NM_066119.9': '2026-09-13T14:25:33.911233+00:00',
    'NC_003281.10': '2026-09-13T14:31:30.186778+00:00',
    'Z98866.1': '2026-09-13T14:35:01.317412+00:00',
    'FO080392.2': '2026-09-13T14:40:13.093158+00:00',
}
REGIONS = {
    'angiospermae:0:1': {
        'record': 'MN990625', 'start': 128, 'end': 663, 'strand': '-', 'gene_name': 'psbA-trnH',
        'scope': 'primer_bounded_locus_spanning_annotated_intergenic_region',
        'location': 'trnH-GUG complement(107..181); psbA complement(589..1650); retained annotated spacer [181,588), with unique compatible full-primer span [128,663) on reverse strand',
        'qualifiers': {'flanking_genes': ['trnH-GUG', 'psbA'], 'annotated_spacer_coordinates': [181, 588], 'full_primer_pair': {'count': 1, 'start': 128, 'end': 663, 'strand': '-', 'mismatches': 0}}, 'taxon_relation': 'same_species',
    },
    'angiospermae:0:2': {
        'record': 'OQ613386', 'start': 88190, 'end': 88684, 'gene_name': 'psbA-trnH',
        'scope': 'primer_bounded_locus_spanning_annotated_intergenic_region',
        'location': 'psbA 87204..88265; trnH-GUG 88633..88705; retained annotated spacer [88265,88632), with unique compatible full-primer span [88190,88684)',
        'qualifiers': {'flanking_genes': ['psbA', 'trnH-GUG'], 'annotated_spacer_coordinates': [88265, 88632], 'full_primer_pair': {'count': 1, 'start': 88190, 'end': 88684, 'strand': '+', 'mismatches': 1}}, 'taxon_relation': 'related_taxon',
    },
    'angiospermae:3:1': {
        'record': 'NC_008326', 'start': 29375, 'end': 30487, 'gene_name': 'trnC-ycf6',
        'scope': 'primer_bounded_locus_spanning_annotated_intergenic_region',
        'location': 'trnC-GCA 29328..29399; petN 30463..30552; retained annotated spacer [29399,30462), with unique compatible full-primer span [29375,30487)',
        'qualifiers': {'flanking_genes': ['trnC-GCA', 'petN'], 'panel_label_note': 'petN is annotated; ycf6 is the historical panel label', 'annotated_spacer_coordinates': [29399, 30462], 'full_primer_pair': {'count': 1, 'start': 29375, 'end': 30487, 'strand': '+', 'mismatches': 2}},
        'taxon_relation': 'same_species',
    },
    'angiospermae:6:1': {
        'record': 'OR400606', 'start': 58344, 'end': 59196, 'gene_name': 'atpB-rbcL',
        'scope': 'primer_bounded_locus_spanning_annotated_intergenic_region',
        'location': 'atpB complement(56872..58368); rbcL 59158..60585; retained annotated spacer [58368,59157), with unique compatible full-primer span [58344,59196)',
        'qualifiers': {'flanking_genes': ['atpB', 'rbcL'], 'annotated_spacer_coordinates': [58368, 59157], 'full_primer_pair': {'count': 1, 'start': 58344, 'end': 59196, 'strand': '+', 'mismatches': 2}}, 'taxon_relation': 'related_taxon',
    },
    'angiospermae:7:0': {
        'record': 'NC_049166', 'start': 49682, 'end': 50111, 'gene_name': 'trnL-F',
        'scope': 'primer_bounded_locus_spanning_annotated_intergenic_region',
        'location': 'trnL-UAA join(49099..49133,49655..49704); trnF-GAA 50052..50124; retained annotated spacer [49704,50051), with unique compatible full-primer span [49682,50111)',
        'qualifiers': {'flanking_genes': ['trnL-UAA', 'trnF-GAA'], 'trnL_feature_is_compound': True, 'annotated_spacer_coordinates': [49704, 50051], 'full_primer_pair': {'count': 1, 'start': 49682, 'end': 50111, 'strand': '+', 'mismatches': 0}},
        'taxon_relation': 'related_taxon',
    },
    'angiospermae:8:1': {
        'record': 'LN680643', 'start': 0, 'end': 737, 'gene_name': 'ITS',
        'scope': 'full_annotated_rDNA_region_without_subfeature_coordinates',
        'location': 'misc_RNA 1..737; note lists 18S, ITS1, 5.8S, ITS2, and 28S',
        'qualifiers': {'feature_note': 'sequence contains 18S rRNA gene, ITS1, 5.8S rRNA gene, ITS2, 28S rRNA gene'},
        'taxon_relation': 'related_taxon',
    },
    'angiospermae:8:2': {
        'record': 'MZ366774', 'start': 2406, 'end': 2980, 'gene_name': 'ITS',
        'scope': 'contiguous_annotated_ITS1_5.8S_ITS2_region',
        'location': 'ITS1 misc_RNA 2407..2599; 5.8S rRNA 2600..2761; ITS2 misc_RNA 2762..2980; extracted [2406,2980)',
        'qualifiers': {'parts': ['ITS1', '5.8S rRNA', 'ITS2']}, 'taxon_relation': 'related_taxon',
    },
    'c_elegans:6:0': {
        'record': 'FO080392.2', 'start': 8149, 'end': 8309, 'strand': '-', 'gene_name': 'EF1A',
        'scope': 'primer_bounded_region_in_complete_F31E3_genomic_clone',
        'location': 'FO080392.2 Cosmid F31E3 exact configured primer span [8149,8309) on the reverse strand; it maps to the NC_003281.10 eef-1A.1 complement exon 947..1767 in the bounded locus record',
        'qualifiers': {'annotated_gene': 'eef-1A.1', 'locus_tag': 'CELE_F31E3.5', 'clone_annotation_status': 'source clone has no feature table; locus identity and exon containment are independently verified in the bounded curated chromosome locus', 'annotation_evidence_files': ['/tmp/sharkmer-public-replacements-20260913/plants_nematode/raw/genbank/NC_003281.10_ef1a_locus.gb'], 'mRNA_comparator': {'accession_version': 'NM_066119.9', 'span': [824, 984], 'sequence_sha256': 'e8ad26f5384b83076102c9031864fa340cc4b3397af211d37fcd0dd151e441ab', 'crosses_exon_junction': False}, 'primer_matches': {'forward_reverse_complement': [8289, 8309], 'reverse': [8149, 8169]}},
        'taxon_relation': 'same_species',
    },
    'c_elegans:7:0': {
        'record': 'Z98866.1', 'start': 320, 'end': 753, 'strand': '-', 'gene_name': 'H3',
        'scope': 'primer_bounded_region_in_complete_Y49E10_genomic_clone',
        'location': 'Z98866.1 YAC Y49E10 exact configured primer span [320,753), mapped to curated NC_003281.10 his-72 complement(<476..>2051) locus',
        'qualifiers': {'annotated_gene': 'his-72', 'locus_tag': 'CELE_Y49E10.6', 'genomic_intron_bases': 59, 'clone_annotation_status': 'source clone has no feature table; locus identity is independently chained through Y49E10/CELE_Y49E10.6 and exact bounded curated locus sequence', 'annotation_evidence_files': ['/tmp/sharkmer-public-replacements-20260913/plants_nematode/raw/genbank/NC_003281.10_his72_locus.gb', '/tmp/sharkmer-public-replacements-20260913/plants_nematode/raw/gene_his72_summary.json'], 'primer_matches': {'forward_reverse_complement': [730, 753], 'reverse': [320, 343]}},
        'taxon_relation': 'same_species',
    },
    'c_elegans:7:1': {
        'record': 'Z98866.1', 'start': 320, 'end': 753, 'strand': '-', 'gene_name': 'H3',
        'scope': 'shared_primer_bounded_region_in_complete_Y49E10_genomic_clone',
        'location': 'Z98866.1 YAC Y49E10 exact configured primer span [320,753), mapped to curated NC_003281.10 his-72 complement(<476..>2051) locus',
        'qualifiers': {'annotated_gene': 'his-72', 'locus_tag': 'CELE_Y49E10.6', 'genomic_intron_bases': 59, 'shared_replacement_with': 'c_elegans:7:0', 'clone_annotation_status': 'source clone has no feature table; locus identity is independently chained through Y49E10/CELE_Y49E10.6 and exact bounded curated locus sequence', 'annotation_evidence_files': ['/tmp/sharkmer-public-replacements-20260913/plants_nematode/raw/genbank/NC_003281.10_his72_locus.gb', '/tmp/sharkmer-public-replacements-20260913/plants_nematode/raw/gene_his72_summary.json'], 'primer_matches': {'forward_reverse_complement': [730, 753], 'reverse': [320, 343]}},
        'taxon_relation': 'same_species', 'disposition': 'existing_shared_replacement',
    },
}
UNRESOLVED = {
    'angiospermae:2:0': {
        'record': 'NC_056221',
        'reason': 'The forward primer maps with two IUPAC mismatches inside annotated trnV-UAC at 0-based 54169; the reverse-complement primer maps with one mismatch inside annotated atpB at 55540. The 1396bp span exceeds the 1000bp panel maximum and does not flank atpE.',
        'qualifiers': {'primer_mapping': {'forward': {'start': 54169, 'end': 54191, 'mismatches': 2, 'feature': 'trnV-UAC'}, 'reverse_complement': {'start': 55540, 'end': 55565, 'mismatches': 1, 'feature': 'atpB'}, 'span_bases': 1396}},
    },
    'angiospermae:2:1': {
        'record': 'NC_008326',
        'reason': 'The forward primer maps with two IUPAC mismatches inside annotated trnV-UAC at 0-based 55518; the reverse-complement primer maps exactly inside annotated atpB at 56869. The 1376bp span exceeds the 1000bp panel maximum and does not flank atpE.',
        'qualifiers': {'primer_mapping': {'forward': {'start': 55518, 'end': 55540, 'mismatches': 2, 'feature': 'trnV-UAC'}, 'reverse_complement': {'start': 56869, 'end': 56894, 'mismatches': 0, 'feature': 'atpB'}, 'span_bases': 1376}},
    },
}


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans('ACGTRYWSKMBDHVN', 'TGCAYRWSMKVHDBN'))[::-1]


def gb_record(record_name: str) -> dict:
    path = RAW / f'{record_name}.gb'
    raw = path.read_bytes()
    if len(raw) > 5 * 1024 * 1024:
        raise ValueError(f'Source exceeds 5 MiB: {path}')
    text = raw.decode()
    origin = text.split('\nORIGIN', 1)[1]
    sequence = ''.join(re.findall(r'[A-Za-z]+', origin)).upper()
    version_match = re.search(r'^VERSION\s+([^\s]+)', text, re.MULTILINE)
    organism_match = re.search(r'^\s+/organism="([^"]+)"', text, re.MULTILINE)
    taxid_match = re.search(r'^\s+/db_xref="taxon:(\d+)"', text, re.MULTILINE)
    locus = text.splitlines()[0]
    definition = ''
    collecting = False
    for line in text.splitlines():
        if line.startswith('DEFINITION'):
            collecting = True
            definition += line.removeprefix('DEFINITION').strip() + ' '
        elif collecting and line.startswith('            '):
            definition += line.strip() + ' '
        elif collecting:
            break
    if not version_match or not organism_match or not taxid_match or not sequence:
        raise ValueError(f'Cannot parse source metadata: {path}')
    version = version_match.group(1)
    receipts = json.loads((ROOT / 'raw' / 'genbank_receipts.json').read_text())['records']
    receipt_times = {
        receipt['accession_requested']: receipt['response']['sources'][0]['retrieved_at']
        for receipt in receipts
    }
    retrieved_at = EXTRA_RETRIEVED.get(version) or receipt_times.get(record_name)
    if retrieved_at is None:
        raise ValueError(f'Missing Entrez retrieval receipt for {record_name}')
    return {
        'accession_version': version,
        'sequence': sequence,
        'sequence_sha256': sha256(sequence.encode()),
        'organism': organism_match.group(1),
        'taxid': int(taxid_match.group(1)),
        'topology': 'circular' if ' circular ' in locus else 'linear',
        'title': definition.strip(),
        'url': f'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id={version}&rettype=gb&retmode=text',
        'retrieved_at': retrieved_at,
        'raw_file': str(path),
        'raw_sha256': sha256(raw),
    }


def public_region(config: dict, source: dict) -> dict:
    sequence = source['sequence'][config['start']:config['end']]
    strand = config.get('strand', '+')
    if strand == '-':
        sequence = reverse_complement(sequence)
    if not sequence:
        raise ValueError(f'Empty proposed region: {config}')
    provenance = {
        'schema_version': 1,
        'kind': 'public_record_region',
        'accession_version': source['accession_version'],
        'source_sequence_sha256': source['sequence_sha256'],
        'source_length': len(source['sequence']),
        'start': config['start'],
        'end': config['end'],
        'strand': strand,
        'wraps_origin': False,
        'sequence_sha256': sha256(sequence.encode()),
    }
    return {
        'gene_name': config['gene_name'],
        'taxon': source['organism'],
        'accession': source['accession_version'],
        'sequence': sequence,
        'provenance': provenance,
    }


def main() -> int:
    legacy = json.loads(LEGACY.read_text())
    legacy_entries = {entry['entry_id']: entry for entry in legacy['entries']}
    expected = set(REGIONS) | set(UNRESOLVED)
    assigned = {
        entry_id for entry_id, entry in legacy_entries.items()
        if entry['panel_path'] in {'panels/angiospermae.yaml', 'panels/c_elegans.yaml'}
        and entry['disposition'] != 'rebuilt_from_public_record'
    }
    if expected != assigned:
        raise ValueError(f'Assigned entries differ: expected={sorted(expected)} assigned={sorted(assigned)}')
    sources = {}
    rows = []
    for entry_id in sorted(expected):
        config = REGIONS.get(entry_id) or UNRESOLVED[entry_id]
        source = sources.setdefault(config['record'], gb_record(config['record']))
        legacy_entry = legacy_entries[entry_id]
        annotation = {
            'raw_file': source['raw_file'],
            'feature_type': 'gene_or_intergenic_annotation' if entry_id in REGIONS else 'source_record_inspected_no_eligible_region',
            'location': config.get('location'),
            'qualifiers': config.get('qualifiers', {}),
            'scope': config.get('scope', 'unresolved'),
            'taxon_relation': config.get('taxon_relation', 'same_species_or_unresolved'),
        }
        if entry_id in REGIONS:
            rows.append({
                'legacy_entry_id': entry_id,
                'disposition': config.get('disposition', 'proposed_public_region'),
                'reference': public_region(config, source),
                'annotation': annotation,
                'reason': 'Sequence is extracted directly from a bounded public record region with the stated annotation; it is not reconstructed from the historical Sharkmer reference.',
                'source_record': source,
            })
        else:
            rows.append({
                'legacy_entry_id': entry_id,
                'disposition': 'unresolved',
                'reference': None,
                'annotation': annotation,
                'reason': config['reason'],
                'source_record': source,
            })
    output = {
        'schema_version': 1,
        'purpose': 'Candidate public replacements for assigned quarantined legacy references; proposals only.',
        'legacy_source': str(LEGACY),
        'records': rows,
        'summary': {
            'assigned_entries': len(rows),
            'proposed_public_regions': sum(row['disposition'] == 'proposed_public_region' for row in rows),
            'existing_shared_replacements': sum(row['disposition'] == 'existing_shared_replacement' for row in rows),
            'unresolved': sum(row['disposition'] == 'unresolved' for row in rows),
            'source_records': len(sources),
        },
    }
    (ROOT / 'proposals.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    raw_files = sorted((ROOT / 'raw').rglob('*'))
    receipts = [
        {'path': str(path), 'size_bytes': path.stat().st_size, 'sha256': sha256(path.read_bytes())}
        for path in raw_files if path.is_file() and path.name != 'artifact_manifest.json'
    ]
    (ROOT / 'raw' / 'artifact_manifest.json').write_text(
        json.dumps({'schema_version': 1, 'files': receipts}, indent=2, sort_keys=True) + '\n'
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
