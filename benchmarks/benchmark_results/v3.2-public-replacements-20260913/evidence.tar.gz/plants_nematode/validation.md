# Public replacement proposal validation

Valid: `True`

| Legacy entry | Disposition | Source | Coordinates / strand | Taxon relation |
|---|---|---|---|---|
| angiospermae:0:1 | proposed_public_region | MN990625.1 | [128,663) - | same_species |
| angiospermae:0:2 | proposed_public_region | OQ613386.1 | [88190,88684) + | related_taxon |
| angiospermae:2:0 | unresolved | — | — | — |
| angiospermae:2:1 | unresolved | — | — | — |
| angiospermae:3:1 | proposed_public_region | NC_008326.1 | [29375,30487) + | same_species |
| angiospermae:6:1 | proposed_public_region | OR400606.1 | [58344,59196) + | related_taxon |
| angiospermae:7:0 | proposed_public_region | NC_049166.1 | [49682,50111) + | related_taxon |
| angiospermae:8:1 | proposed_public_region | LN680643.1 | [0,737) + | related_taxon |
| angiospermae:8:2 | proposed_public_region | MZ366774.1 | [2406,2980) + | related_taxon |
| c_elegans:6:0 | proposed_public_region | FO080392.2 | [8149,8309) - | same_species |
| c_elegans:7:0 | proposed_public_region | Z98866.1 | [320,753) - | same_species |
| c_elegans:7:1 | existing_shared_replacement | Z98866.1 | [320,753) - | same_species |

## Intergenic spacer scope

These references are unique full-primer-bounded public locus spans containing their documented annotated spacers. The retained spacer coordinates identify the intergenic portion; flanking bases can be in neighboring annotated genes. No primer, product, or gene label is changed by this receipt.

- `angiospermae:0:1`: `compatible_full_primer_pair_in_source`; {"compatible_pair_count": 1, "end": 663, "left_bases_outside_reference": 0, "mismatches": 0, "reference_contains_full_pair": true, "right_bases_outside_reference": 0, "start": 128, "strand": "-"}
- `angiospermae:0:2`: `compatible_full_primer_pair_in_source`; {"compatible_pair_count": 1, "end": 88684, "left_bases_outside_reference": 0, "mismatches": 1, "reference_contains_full_pair": true, "right_bases_outside_reference": 0, "start": 88190, "strand": "+"}
- `angiospermae:3:1`: `compatible_full_primer_pair_in_source`; {"compatible_pair_count": 1, "end": 30487, "left_bases_outside_reference": 0, "mismatches": 2, "reference_contains_full_pair": true, "right_bases_outside_reference": 0, "start": 29375, "strand": "+"}
- `angiospermae:6:1`: `compatible_full_primer_pair_in_source`; {"compatible_pair_count": 1, "end": 59196, "left_bases_outside_reference": 0, "mismatches": 2, "reference_contains_full_pair": true, "right_bases_outside_reference": 0, "start": 58344, "strand": "+"}
- `angiospermae:7:0`: `compatible_full_primer_pair_in_source`; {"compatible_pair_count": 1, "end": 50111, "left_bases_outside_reference": 0, "mismatches": 0, "reference_contains_full_pair": true, "right_bases_outside_reference": 0, "start": 49682, "strand": "+"}
