## Finding

The public-reference replacement audit for #129 could not safely restore the two quarantined `angiospermae` `trnV-atpE` references. Independently mapped full-primer endpoints in the cited public plastomes lie near annotated `trnV-UAC` and within `atpB`, not `atpE`; the full-primer spans also exceed the current 1,000 bp maximum.

| Public source | Full-primer start (0-based) | Reverse-binding start | Full-primer span |
| --- | ---: | ---: | ---: |
| NC_056221.1 | 54169 | 55540 | 1396 bp |
| NC_008326.1 | 55518 | 56869 | 1376 bp |

This is an annotation/assay/length inconsistency requiring review, not proof that the current trimmed, mismatch-tolerant production search cannot emit a product. No Sharkmer product was used to select the source coordinates.

## Acceptance criteria

- Review the primer publication and versioned public feature context to establish the intended locus and boundary genes; do not rename from one best hit alone.
- Evaluate the actual effective primers, allowed mismatches, strand orientation, and configured length limits on independent source records.
- Propose any label/primer/bounds change separately, with explicit compatibility/versioning decisions and focused tests.
- Add exact public-region provenance and annotation receipts for any accepted reference; do not promote an assembly or silently substitute an unrelated locus.

The two references remain absent, and primers/bounds are unchanged in the current update. See `dev_docs/PUBLIC_REFERENCE_REPLACEMENTS.md` and the `v3.2-public-replacements-20260913` evidence archive. This does not authorize a release or assembly-policy change. Related release review: #153.
